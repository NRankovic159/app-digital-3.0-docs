/*
  Warnings:

  - You are about to drop the column `shop` on the `BulkOperationTriggers` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_BulkOperationTriggers" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "opTrigger" TEXT
);
INSERT INTO "new_BulkOperationTriggers" ("id", "opTrigger") SELECT "id", "opTrigger" FROM "BulkOperationTriggers";
DROP TABLE "BulkOperationTriggers";
ALTER TABLE "new_BulkOperationTriggers" RENAME TO "BulkOperationTriggers";
PRAGMA foreign_key_check;
PRAGMA foreign_keys=ON;
