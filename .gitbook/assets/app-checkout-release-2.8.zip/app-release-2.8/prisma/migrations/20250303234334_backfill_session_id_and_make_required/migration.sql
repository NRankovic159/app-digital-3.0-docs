/*
  Warnings:

  - The primary key for the `Session` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - Made the column `session_id` on table `Session` required. This step will fail if there are existing NULL values in that column.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;

-- (ADDED) First, fill in any NULL session_id values in the original "Session" table.
--         This ensures that the next step (creating and copying to new_Session) won't fail.
UPDATE "Session"
SET "session_id" = (
  hex(randomblob(4)) || '-' ||
  hex(randomblob(2)) || '-' ||
  '4' || substr(hex(randomblob(2)),2) || '-' ||
  substr('89AB', 1 + (abs(random()) % 4), 1) ||
  substr(hex(randomblob(2)),2) || '-' ||
  hex(randomblob(6))
)
WHERE "session_id" IS NULL;

CREATE TABLE "new_Session" (
    "session_id" TEXT NOT NULL PRIMARY KEY,
    "id" TEXT,
    "shop" TEXT NOT NULL,
    "state" TEXT NOT NULL,
    "isOnline" BOOLEAN NOT NULL DEFAULT false,
    "scope" TEXT,
    "expires" DATETIME,
    "accessToken" TEXT NOT NULL,
    "userId" BIGINT,
    "firstName" TEXT,
    "lastName" TEXT,
    "email" TEXT,
    "accountOwner" BOOLEAN NOT NULL DEFAULT false,
    "locale" TEXT,
    "collaborator" BOOLEAN DEFAULT false,
    "emailVerified" BOOLEAN DEFAULT false
);

INSERT INTO "new_Session" ("accessToken", "accountOwner", "collaborator", "email", "emailVerified", "expires", "firstName", "id", "isOnline", "lastName", "locale", "scope", "session_id", "shop", "state", "userId")
SELECT "accessToken", "accountOwner", "collaborator", "email", "emailVerified", "expires", "firstName", "id", "isOnline", "lastName", "locale", "scope", "session_id", "shop", "state", "userId"
FROM "Session";

DROP TABLE "Session";

ALTER TABLE "new_Session" RENAME TO "Session";

CREATE UNIQUE INDEX "Session_id_key" ON "Session"("id");

PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
