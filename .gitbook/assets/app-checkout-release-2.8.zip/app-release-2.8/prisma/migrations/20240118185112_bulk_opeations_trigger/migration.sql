-- CreateTable
CREATE TABLE "BulkOperationTriggers" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "shop" TEXT NOT NULL,
    "opTrigger" TEXT NOT NULL
);
