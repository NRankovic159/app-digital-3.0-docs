-- CreateTable
CREATE TABLE "BulkOperations" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "shop" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "operation" TEXT NOT NULL
);
