-- AlterTable
ALTER TABLE "BulkOperations" ADD COLUMN "opTrigger" TEXT;
