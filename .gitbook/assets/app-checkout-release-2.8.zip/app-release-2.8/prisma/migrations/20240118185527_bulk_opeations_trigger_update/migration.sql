-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_BulkOperationTriggers" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "shop" TEXT NOT NULL,
    "opTrigger" TEXT
);
INSERT INTO "new_BulkOperationTriggers" ("id", "opTrigger", "shop") SELECT "id", "opTrigger", "shop" FROM "BulkOperationTriggers";
DROP TABLE "BulkOperationTriggers";
ALTER TABLE "new_BulkOperationTriggers" RENAME TO "BulkOperationTriggers";
PRAGMA foreign_key_check;
PRAGMA foreign_keys=ON;
