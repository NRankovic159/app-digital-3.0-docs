-- AlterTable
ALTER TABLE "BulkOperations" ADD COLUMN "fileUrl" TEXT;
