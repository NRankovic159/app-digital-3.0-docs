export const APP_NAMESPACE_PREFIX = 'sdg:';

export const APP_CONFIG = {
  namespace: APP_NAMESPACE_PREFIX + 'app',
  key: 'config',
}

export const QUANTIY_CONFIG = {
  namespace: 'apple',
  key: 'apl_QuantityLimit',
}

export const APP_TRANSLATIONS_NAMESPACE = APP_NAMESPACE_PREFIX + 'translations';

