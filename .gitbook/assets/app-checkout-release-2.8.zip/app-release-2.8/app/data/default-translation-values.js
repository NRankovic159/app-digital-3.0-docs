export const TAX_ID_TRANSLATIONS = {
  en: {
    dni_nie_label: 'DNI/NIE',
    dni_nie_error: 'Please enter a valid DNI/NIE',
    cif_label: 'CIF',
    cif_error: 'Please enter a valid CIF',
    passport_label: 'Passport',
    passport_error: 'no symbols, only text and alphabets',
    residency_card_label: 'Residency card',
    residency_card_error: 'Please enter a valid residency card ID',
    document_type: 'Document type',
    document_type_empty: 'Please select a document type',
    id_field_label: 'Type your ID Number',
    id_empty_default: 'Please enter your ID Number',
  },
};

export const TERMS_CONDITIONS_TRANSLATIONS = {
  en: {
    heading: 'Terms and Conditions',
    terms_conditions_before_link: 'I have read, understand and agree to the',
    terms_conditions_after_link: 'and agree that APP will send an email and invoice to my email address.',
    link_text: 'Terms and Conditions of Sale',
    link_url: '/',
    error_message: 'Please accept the terms and conditions',
  },
};

export const TRADE_IN_TRANSLATIONS = {
  en: {
    heading: 'Trade in',
    summary: 'Do you want to trade in your old device?',
    yes_text: 'Yes',
    no_text: 'No',
    modal_trigger: 'See more',
    modal_heading: 'Modal Heading',
    modal_content: 'Modal Content',
  },
};

export const WIRE_TRANSER_TRANSLATIONS = {
  en: {
    summary: 'To formalize your order, please, make the deposit of the amount, in the account referred to below, within a period of less than 48 hours for our receipt, indicating exactly the concept as it appears below (you can copy and paste).',
    amount: 'Amount',
    current_account: 'Current account',
    owner: 'Owner',
    iban: 'IBAN',
    iban_no_spaces: 'IBAN without spaces',
    swift_bic: 'SWIFT/BIC',
    transfer_concept: 'Transfer/income concept',
    transfer_instructions: 'Copy and paste your Order Number from the Order Status page.',
    example: 'Example',
  },
};

export const CHECKOUT_ATTRIBUTES_BLOCK_TRANSLATIONS = {
  en: {
    block_heading: 'Additional Information',
    verification_heading: 'Personal Information',
    trade_in_heading: 'Trade In',
  },
};

export const LINE_ITEM_TRANSLATIONS = {
  en: {
    preorder: 'Preorder',
    remove: 'Remove',
  },
};

export const QUANTITY_LIMIT_TRANSLATIONS = {
  en: {
    error_one: 'Not possible to order more than one of each',
    error_multiple: 'Not possible to order more than {quantityLimit} of each',
  },
};

export const ESTIMATED_SHIPPING_TRANSLATIONS = {
  en: {
    delivery_heading: 'Delivery times',
    delivery_list: [
      { heading: 'Shipping to Store 1', content: '2 to 5 business days' },
    ],
    delivery_text_block: 'Purchases made to Dalas, have an additional validation by the APP team.',
    presale_delivery_heading: 'Delivery times Pre-Sale mode',
    presale_delivery_text_block: '',
    presale_delivery_text_block_secondary: '',
    presale_delivery_links: [
      { text: 'Delivery times', url: '/' },
    ]
  }
};

export const PERSONAL_PICKUP_INFO_TRANSLATIONS = {
  en: {
    heading: 'Personal Pickup Information',
    detail_heading: 'Pickup Person',
    name_label: 'Full name',
    name_error: 'Please enter your full name',
    email_label: 'Email',
    email_error: 'Please enter a valid email address',
    phone_label: 'Phone',
    phone_required: false,
    phone_error: 'Please enter a valid phone number',
    callout: '*You will receive an email notification when your order is ready for pickup. A valid government issued photo ID and your order number are required for pickup.',
  }
};

export const ORDER_NOTE_TRANSLATIONS = {
  en: {
    heading: 'Order Note',
  },
};

export const GIFT_MESSAGE_TRANSLATIONS = {
  en: {
    checkbox_label: 'Update me with your message',
    message_attribute: 'giftwrap-message',
    message_label: 'Gift Message',
  },
};

export const GIFT_WRAP_PRODUCT_TRANSLATIONS = {
  en: {
    heading: 'Add Gift Wrap',
    add_cta: 'Add',
    free: 'Free',
  }
};

export const PICKUP_LOCATION_CONFIRMATION_MESSAGE = {
  en: {
    message: 'Please confirm Pickup location. Previously selected location is {{store_name}}.'
  }
};

export const SMB_GUEST_USER_FORM = {
  en: {
    checkbox_label: 'Business user?',
    company_name_label: 'Company Name',
    vat_id_label: 'VAT Id',
    field_required_error_message: '{{field_name}} is required',
  }
};

export const DEFAULT_TRANSLATION_KEYS = [
  { key: 'tax_id', name: 'Tax ID Block', value: TAX_ID_TRANSLATIONS },
  { key: 'terms_conditions', name: 'Terms and Conditions', value: TERMS_CONDITIONS_TRANSLATIONS },
  { key: 'trade-in', name: 'Trade In Block', value: TRADE_IN_TRANSLATIONS },
  { key: 'wire_transfer', name: 'Wire Transfer', value: WIRE_TRANSER_TRANSLATIONS },
  { key: 'checkout_attributes_block', name: 'Checkout Attributes Block', value: CHECKOUT_ATTRIBUTES_BLOCK_TRANSLATIONS },
  { key: 'line_item', name: 'Line Item', value: LINE_ITEM_TRANSLATIONS },
  { key: 'estimated_shipping', name: 'Estimated Shipping', value: ESTIMATED_SHIPPING_TRANSLATIONS },
  { key: 'personal_pickup_info', name: 'Personal Pickup Info', value: PERSONAL_PICKUP_INFO_TRANSLATIONS },
  { key: 'quantity_limit', name: 'Quantity Limit', value: QUANTITY_LIMIT_TRANSLATIONS },
  { key: 'order_note', name: 'Order Note', value: ORDER_NOTE_TRANSLATIONS },
  { key: 'gift_message', name: 'Gift Message', value: GIFT_MESSAGE_TRANSLATIONS },
  { key: 'gift_wrap_product', name: 'Gift Wrap Product', value: GIFT_WRAP_PRODUCT_TRANSLATIONS },
  { key: 'pickup_location_confirmation_message', name: 'Pickup Location Confirmation Message', value: PICKUP_LOCATION_CONFIRMATION_MESSAGE },
  { key: 'smb_guest_user_form', name: 'Guest Business User Form', value: SMB_GUEST_USER_FORM },
];
