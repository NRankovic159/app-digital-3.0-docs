export const FONT_WEIGHTS = [
  { label: "Unset", value: "unset" },
  { label: "100", value: "100" },
  { label: "200", value: "200" },
  { label: "300", value: "300" },
  { label: "400", value: "400" },
  { label: "500", value: "500" },
  { label: "600", value: "600" },
  { label: "700", value: "700" },
  { label: "800", value: "800" },
  { label: "900", value: "900" },
];

export const CORNER_RADIUS = [
  { label: "None", value: "NONE" },
  { label: "Small", value: "SMALL" },
  { label: "Base", value: "BASE" },
  { label: "Large", value: "LARGE" },
];

export const FONT_CHOICES = [
  { label: "Primary", value: "PRIMARY" },
  { label: "Secondary", value: "SECONDARY" },
];

export const TEXT_SIZES = [
  { label: 'Extra Small', value: 'EXTRA_SMALL' },
  { label: 'Small', value: 'SMALL' },
  { label: 'Base', value: 'BASE' },
  { label: 'Medium', value: 'MEDIUM' },
  { label: 'Large', value: 'LARGE' },
  { label: 'Extra Large', value: 'EXTRA_LARGE' },
  { label: 'Extra Extra Large', value: 'EXTRA_EXTRA_LARGE' },
];

export const TEXT_KERNING = [
  { label: 'Base', value: 'BASE' },
  { label: 'Extra Loose', value: 'EXTRA_LOOSE' },
  { label: 'Loose', value: 'LOOSE' },
];

export const FONT_WEIGHT_OPTIONS = [
  { label: 'Base', value: 'BASE' },
  { label: 'Bold', value: 'BOLD' },
];

export const LETTER_CASE = [
  { label: 'None', value: 'NONE' },
  { label: 'Lowercase', value: 'LOWER' },
  { label: 'Title', value: 'TITLE' },
  { label: 'Uppercase', value: 'UPPER' },
]
