export const GET_CHECKOUT_BRAND_DATA = `
query($id: ID!) {
  files(first: 20, query: "(filename:*.woff) OR (filename:*.woff2)") {
    nodes {
      ... on GenericFile {
        id
        mimeType
        url
      }
    }
  }
  checkoutProfile(id: $id) {
    id
    name
  }
  checkoutBranding(checkoutProfileId: $id) {
    customizations {
      global {
        typography {
          kerning
          letterCase
        }
      }
      headingLevel1 {
        typography {
          font
          size
          weight
          kerning
          letterCase
        }
      }
      headingLevel2 {
        typography {
          font
          size
          weight
          kerning
          letterCase
        }
      }
      headingLevel3 {
        typography {
          font
          size
          weight
          kerning
          letterCase
        }
      }
      primaryButton {
        typography {
          font
        }
      }
      secondaryButton {
        typography {
          font
        }
      }
    }
    designSystem {
      typography {
        size {
          base
          ratio
        }
        primary {
          base {
            sources
            weight
          }
          bold {
            sources
            weight
          }
        }
        secondary {
          base {
            sources
            weight
          }
          bold {
            sources
            weight
          }
        }
      }
    }
  }
}
`
