import { task, logger } from "@trigger.dev/sdk/v3";
import db from "~/db.server";
import { triggerGqlHandler } from "~/lib/trigger-gql-handler";

export const queryJob = task({
  id: "variant-bulk-query",
  // In v3, you declare a `run` function receiving a plain JS `payload`
  run: async (payload) => {
    const { session, opTrigger } = payload;

    // 1. Run bulk query
    let bulkOperationId;
    try {
      const bulkQuery = await triggerGqlHandler({
        session,
        query: `
          mutation {
            bulkOperationRunQuery(
              query: """
                {
                  productVariants {
                    edges {
                      node {
                        id
                        inventoryItem {
                          inventoryLevels(first: 25) {
                            edges {
                              node {
                                location {
                                  id
                                }
                                quantities(names: ["available"]) {
                                  quantity
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              """
            ) {
              bulkOperation {
                id
                status
              }
              userErrors {
                field
                message
              }
            }
          }
        `,
      });

      const bulkQueryJson = await bulkQuery.json();
      const { bulkOperation, userErrors } = bulkQueryJson.data.bulkOperationRunQuery;

      if (userErrors && userErrors.length > 0) {
        logger.error("Bulk query failed with user errors:", userErrors);
        return; // or throw an error if you prefer
      }

      // Extract the bulkOperationId
      bulkOperationId = bulkOperation.id;
    } catch (error) {
      logger.error("Bulk query failed:", error);
      return;
    }

    // 2. Insert record into DB
    try {
      await db.bulkOperations.create({
        data: {
          id: bulkOperationId,
          shop: session.shop,
          status: "RUNNING",
          operation: "VARIANT_LOCATION_BULK_QUERY",
          opTrigger,
        },
      });
      logger.info("DB Update completed");
    } catch (error) {
      logger.error("DB Update failed:", error);
      return;
    }

    logger.info("Bulk query and DB insert completed successfully");
  },
});
