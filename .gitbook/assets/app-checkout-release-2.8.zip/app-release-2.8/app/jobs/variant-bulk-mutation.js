import { task, logger } from "@trigger.dev/sdk/v3";
import request from "request";
import db from "~/db.server";
import { triggerGqlHandler } from "~/lib/trigger-gql-handler";

import fs from "fs";
import path from "path";
const fsPromises = fs.promises;

// The GraphQL mutation string remains the same, just keep it in the same file
const BULK_METAFIELD_UPDATE = `
  mutation call($metafields: [MetafieldsSetInput!]!) {
    metafieldsSet(metafields: $metafields) {
      userErrors {
        field
        message
      }
    }
  }
`;

export const mutationJob = task({
  id: "variant-bulk-mutation",

  // No type annotations needed for JS
  run: async (payload) => {
    const { session, url, opTrigger } = payload;

    // 1. Parse the file URL
    const parseFileUrlTask = await new Promise((resolve) => {
      request(url, async (error, response, body) => {
        if (!error && response.statusCode === 200) {
          const jsonl = body.split("\n");
          logger.info("jsonl: ", jsonl);

          const jsonLines = jsonl.map((line) => {
            try {
              return JSON.parse(line);
            } catch (error) {
              return null;
            }
          });

          const jsonLinesFiltered = jsonLines.filter((line) => line !== null);
          const parentLines = jsonLinesFiltered.filter(
            (line) => !line.__parentId
          );

          // Merge child lines into parent lines
          jsonLinesFiltered.forEach((line) => {
            if (!line.__parentId) return;

            const parentIndex = parentLines.findIndex(
              (parent) => parent.id === line.__parentId
            );
            if (parentIndex === -1) return;

            parentLines[parentIndex].inventoryItem.inventoryLevels =
              parentLines[parentIndex].inventoryItem.inventoryLevels || [];
            parentLines[parentIndex].inventoryItem.inventoryLevels.push(line);
          });

          resolve(parentLines);
        } else {
          // If request failed or bad status, return empty
          resolve([]);
        }
      });
    });

    if (parseFileUrlTask.length === 0) {
      logger.info("No JSONL data found");
      return;
    }

    // 2. Generate bulk mutation lines
    const bulkMutationLines = await new Promise((resolve) => {
      const variantMetafieldLines = parseFileUrlTask.map((line) => {
        const { id, inventoryItem } = line;

        const inventoryLevels = inventoryItem.inventoryLevels.map(
          (inventoryLevel) => {
            const { location, quantities } = inventoryLevel;
            return {
              locationId: location.id.replace("gid://shopify/Location/", ""),
              available: quantities[0].quantity,
            };
          }
        );

        const filteredLevels = inventoryLevels
          .filter((level) => level.available > 0)
          .map((item) => item.locationId);

        return {
          key: "apple",
          namespace: "apl_VariantLocationAvailability",
          ownerId: id,
          type: "list.single_line_text_field",
          value: JSON.stringify(filteredLevels || []),
        };
      });

      // Chunk them into sets of 20
      const chunkedLines = [];
      const chunkSize = 20;
      for (let i = 0; i < variantMetafieldLines.length; i += chunkSize) {
        chunkedLines.push(variantMetafieldLines.slice(i, i + chunkSize));
      }

      // Create JSON strings
      const variantMetafieldMutationLines = chunkedLines.map((lines) =>
        JSON.stringify({ metafields: lines })
      );

      resolve(variantMetafieldMutationLines);
    });

    logger.info("variantMetafieldMutationLines: ", bulkMutationLines);

    // 3. Stage the upload
    const stageUploadTask = await (async () => {
      const stagedUpload = await triggerGqlHandler({
        session,
        query: `
          mutation {
            stagedUploadsCreate(input:{
              resource: BULK_MUTATION_VARIABLES,
              filename: "bulk_variant_location_op_vars",
              mimeType: "text/jsonl",
              httpMethod: POST
            }){
              userErrors{
                field,
                message
              },
              stagedTargets{
                url,
                resourceUrl,
                parameters {
                  name,
                  value
                }
              }
            }
          }
        `,
      });

      const stagedUploadJson = await stagedUpload.json();
      const { stagedTargets } = stagedUploadJson.data.stagedUploadsCreate;
      const { url, parameters } = stagedTargets[0];
      return { url, parameters };
    })();

    // 4. Run the bulk mutation query
    const runBulkMuationQuery = await (async () => {
      const jsonLines = bulkMutationLines.join("\n");
      const tmpFile = path.resolve(__dirname, `../bulk-ops/${Date.now()}.jsonl`);

      // Write to a temp file
      await fsPromises.writeFile(tmpFile, jsonLines);

      const { url, parameters } = stageUploadTask;
      let uploadJsonUrl = null;

      // Attempt file upload
      try {
        const uploadFormData = new FormData();
        parameters.forEach(({ name, value }) => {
          uploadFormData.append(name, value);
        });

        const blob = new Blob([fs.readFileSync(tmpFile)], {
          type: "text/jsonl",
        });
        uploadFormData.append("file", blob);

        const uploadJson = await fetch(url, {
          method: "POST",
          body: uploadFormData,
        });

        if (!uploadJson.ok) {
          logger.error("Failed to upload file");
          return { status: "error" };
        }

        // For an S3-style POST, you typically combine `url + key` for the resource path
        uploadJsonUrl = `${url}${uploadFormData.get("key")}`;
      } catch (error) {
        logger.error("Failed to upload file");
        return { status: "error" };
      }

      // Attempt the actual bulk mutation run
      let bulkMutationId = null;
      try {
        const BULK_MUTATION = `
          mutation {
            bulkOperationRunMutation(
              mutation: "${BULK_METAFIELD_UPDATE}",
              stagedUploadPath: "${uploadJsonUrl}"
            ) {
              bulkOperation {
                id
                url
                status
              }
              userErrors {
                message
                field
              }
            }
          }
        `;

        const bulkMutation = await triggerGqlHandler({
          session,
          query: BULK_MUTATION,
        });
        const bulkMutationJson = await bulkMutation.json();
        const { bulkOperation, userErrors } =
          bulkMutationJson.data.bulkOperationRunMutation;

        if (userErrors && userErrors.length > 0) {
          logger.error("Failed to update metafields");
          logger.error("userErrors: ", userErrors);
          return { status: "error" };
        }

        bulkMutationId = bulkOperation.id;
      } catch (error) {
        logger.error("Failed to update metafields");
        return { status: "error" };
      }

      // Save record to DB
      try {
        await db.bulkOperations.create({
          data: {
            id: bulkMutationId,
            status: "CREATED",
            operation: "VARIANT_LOCATION_METAFIELD_BULK_MUTATION",
            shop: session.shop,
            opTrigger,
          },
        });
      } catch (error) {
        logger.error("Failed to update db");
        return { status: "error" };
      }

      return { status: "ok", bulkMutationId };
    })();

    const { status } = runBulkMuationQuery;

    if (status === "error") {
      logger.error("Bulk mutation failed");
      return;
    }

    logger.info("Bulk mutation started");
  },
});
