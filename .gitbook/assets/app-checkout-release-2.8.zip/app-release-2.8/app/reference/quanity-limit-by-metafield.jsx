import { json } from '@remix-run/node';
import { useState, useEffect, Suspense, lazy } from 'react';
import {
  Card,
  Filters,
  InlineStack,
  InlineGrid,
  Page,
  ResourceList,
  ResourceItem,
  Text,
  TextField,
  Thumbnail,
} from '@shopify/polaris';
import { useLoaderData, useNavigate, useSubmit, useActionData } from '@remix-run/react';
import fsPormises from 'fs/promises';
import fs from 'fs';
import path from 'path';

import { authenticate } from '~/shopify.server';
import db from "../db.server";

import { QUANTIY_CONFIG } from '../data/metafields';

const BulkOperationStatus = lazy(() => import('../components/bulk-op-status'));

export async function loader({ request }) {
  const { admin } = await authenticate.admin(request);

  const url = new URL(request.url);
  const endCursor = url.searchParams.get('end');
  const startCursor = url.searchParams.get('start');
  const searchParam = url.searchParams.get('search');
  const after = endCursor ? `first: 25, after: "${endCursor}"` : '';
  const before = startCursor ? `last: 25, before: "${startCursor}"` : '';

  let startQuery = 'first: 25';
  let searchQuery = '';

  if (searchParam) {
    searchQuery = `(title:${searchParam}*) OR (product_type:${searchParam}*) OR (tag:${searchParam}*)`;
  }

  if (after) {
    startQuery = after;
  }

  if (before) {
    startQuery = before;
  }

  const productsQuery = await admin.graphql(`
    query ($searchQuery: String!) {
      products(${startQuery}, query: $searchQuery) {
        nodes {
          id
          title
          images(first: 1) {
            nodes {
              originalSrc
            }
          }
          quantityLimit: metafield(namespace: "${QUANTIY_CONFIG.namespace}", key: "${QUANTIY_CONFIG.key}") {
            value
          }
        }
        pageInfo {
          endCursor
          hasNextPage
          hasPreviousPage
          startCursor
        }
      }
    }
  `,
  {
    variables: {
      searchQuery,
    },
  });
  const productsJson = await productsQuery.json();
  const products = productsJson?.data?.products?.nodes || [];
  const pageInfo = productsJson?.data?.products?.pageInfo || {};

  return json({
    products,
    pageInfo,
    searchParam,
  });
}

export default function QuantityLimits() {
  const { products, pageInfo, searchParam } = useLoaderData();
  const navigate = useNavigate();
  const actionData = useActionData();
  const submitLimits = useSubmit();
  const [query, setQuery] = useState(searchParam || '');
  const [updatedProducts, setUpdatedProducts] = useState(new Map());
  const [loading, setLoading] = useState(false);

  const handlePageFilterNavigation = ({ endCursor, startCursor }) => {
    const url = new URL(window.location.href);

    if (endCursor) {
      url.searchParams.set('end', endCursor);
      url.searchParams.delete('start');
    }

    if (startCursor) {
      url.searchParams.set('start', startCursor);
      url.searchParams.delete('end');
    }

    navigate(`${url.pathname}${url.search}`, { replace: true });
  }

  const handleQueryChange = (value) => {
    setQuery(value);
  };

  const handleQuantityLimitSubmit = async () => {
    setLoading(true);

    const updatedProductsArray = Array.from(updatedProducts.entries());
    const updatedProductsObject = updatedProductsArray.reduce((acc, [key, value]) => {
      acc[key] = value;
      return acc;
    }, {});

    submitLimits({
      data: JSON.stringify(updatedProductsObject),
    }, { method: 'post' });
  }

  const handleOpFinished = () => {
    setLoading(false);
    navigate('.', { replace: true });
    setUpdatedProducts(new Map());
  }

  const handleOpStarted = () => {
    setLoading(true);
  }

  useEffect(() => {
    const handler = setTimeout(() => {
      const url = new URL(window.location.href);
      url.searchParams.set('search', query);
      url.searchParams.delete('end');
      url.searchParams.delete('start');
      navigate(`${url.pathname}${url.search}`, { replace: true });
    }, 300);

    return () => {
      clearTimeout(handler);
    };
  }, [query, navigate]);

  const filters = [];

  return (
    <Page
      title="Quantity Limits"
      primaryAction={{
        content: 'Save',
        disabled: updatedProducts.size === 0 || actionData?.status === 'loading' || loading,
        onAction: () => {
          handleQuantityLimitSubmit();
        },
      }}
    >
      <InlineGrid gap="300">
        <Suspense fallback={null}>
          <BulkOperationStatus
            bulkOpId={actionData?.id}
            handleOpFinished={handleOpFinished}
            handleOpStarted={handleOpStarted}
          />
        </Suspense>
        <Card>
          <ResourceList
            resourceName={{ singular: 'product', plural: 'products' }}
            items={products}
            pagination={{
              hasNext: pageInfo.hasNextPage,
              hasPrevious: pageInfo.hasPreviousPage,
              onNext: () => {
                handlePageFilterNavigation({ endCursor: pageInfo.endCursor });
              },
              onPrevious: () => {
                handlePageFilterNavigation({ startCursor: pageInfo.startCursor });
              }
            }}
            filterControl={
              <Filters
                queryPlaceholder='Search products'
                queryValue={query}
                filters={filters}
                onQueryChange={handleQueryChange}
                onQueryClear={() => handleQueryChange('')}
                hideFilters
              />
            }
            flushFilters
            loading={loading}
            renderItem={(product) => {
              const media = (
                <Thumbnail
                  alt={product.title}
                  source={product.images.nodes[0].originalSrc}
                />
              );

              const initialLimit = product.quantityLimit?.value;
              const updatedLimit = updatedProducts.get(product.id);

              return (
                <ResourceItem
                  id={product.id}
                  media={media}
                >
                  <InlineStack align="space-between" blockAlign="center" gap="200">
                    <h3>
                      <Text variation="strong">{product.title}</Text>
                    </h3>

                    <TextField
                      label="Quantity Limit"
                      value={updatedLimit || initialLimit}
                      onChange={(value) => {
                        if (isNaN(value)) return false;

                        setUpdatedProducts((prevMap) => {
                          const updatedMap = new Map(prevMap);
                          updatedMap.set(product.id, Number(value));
                          return updatedMap;
                        });
                      }}
                    />
                  </InlineStack>
                </ResourceItem>
              );
            }}
          />
        </Card>
      </InlineGrid>
    </Page>
  );
}

export const action = async ({ request }) => {
  if (request.method !== 'POST') {
    return json({ status: 'error', errors: [{ message: 'Method not allowed' }] }, { status: 400 });
  }

  const { admin, session } = await authenticate.admin(request);
  const formData = await request.formData();
  console.log({ session });
  const data = JSON.parse(formData.get('data'));

  const productMetafieldLines = Object.entries(data).map(([productId, quantityLimit]) => ({
    "key": QUANTIY_CONFIG.key,
    "namespace": QUANTIY_CONFIG.namespace,
    "ownerId": productId,
    "type": "number_integer",
    "value": quantityLimit.toString(),
  }));

  const chunkedLines = [];
  const chunkSize = 20;
  for (let i = 0; i < productMetafieldLines.length; i += chunkSize) {
    chunkedLines.push(productMetafieldLines.slice(i, i + chunkSize));
  }

  const productMetafieldMutations = chunkedLines.map((lines) => (JSON.stringify({
    metafields: lines,
  })));

  const jsonLines = productMetafieldMutations.join('\n');
  const tmpFile = path.resolve(__dirname, `../bulk-ops/${Date.now()}.jsonl`);
  await fsPormises.writeFile(tmpFile, jsonLines);

  let url;
  let parameters;

  try {
    const stagedUpload = await admin.graphql(`
      mutation {
        stagedUploadsCreate(input:{
          resource: BULK_MUTATION_VARIABLES,
          filename: "bulk_quantity_limit_op_vars",
          mimeType: "text/jsonl",
          httpMethod: POST
        }){
          userErrors{
            field,
            message
          },
          stagedTargets{
            url,
            resourceUrl,
            parameters {
              name,
              value
            }
          }
        }
      }
    `);

    const stagedUploadJson = await stagedUpload.json();

    const { stagedTargets } = stagedUploadJson.data.stagedUploadsCreate;
    ({ url, parameters } = stagedTargets[0]);
    console.log('stagedUpload success');
  } catch (error) {
    console.log({ error });
    return json({ status: 'error', errors: [{ message: 'Failed to create upload' }] }, { status: 400 });
  }

  let uploadJsonUrl;

  try {
    const uploadFormData = new FormData();
    parameters?.forEach(({ name, value }) => {
      uploadFormData.append(name, value);
    });

    const blob = new Blob([fs.readFileSync(tmpFile)], { type: 'text/jsonl' });
    uploadFormData.append('file', blob);

    const uploadJson = await fetch(url, {
      method: 'POST',
      body: uploadFormData,
    });

    if (!uploadJson.ok) {
      return json({ status: 'error', errors: [{ message: 'Failed to upload file' }] }, { status: 400 });
    }

    uploadJsonUrl = `${url}${uploadFormData.get('key')}`;
    console.log('upload success');
  } catch (error) {
    console.log({ error });
    return json({ status: 'error', errors: [{ message: 'Failed to upload file' }] }, { status: 400 });
  }


  let bulkMutationId;

  try {
    const BULK_MUTATION = `
      mutation {
        bulkOperationRunMutation(
          mutation: "${BULK_METAFIELD_UPDATE}",
          stagedUploadPath: "${uploadJsonUrl}"
        ) {
          bulkOperation {
            id
            url
            status
          }
          userErrors {
            message
            field
          }
        }
      }
    `;

    const bulkMutation = await admin.graphql(BULK_MUTATION);

    const bulkMutationJson = await bulkMutation.json();
    const { bulkOperation, userErrors } = bulkMutationJson.data.bulkOperationRunMutation;

    if (userErrors && userErrors.length > 0) {
      return json({ status: 'error', errors: userErrors }, { status: 400 });
    }

    console.log('bulkMutation success');
    console.log({ bulkOperation });
    bulkMutationId = bulkOperation.id;
  } catch (error) {
    console.log({ error });
    return json({ status: 'error', errors: [{ message: 'Failed to update metafields' }] }, { status: 400 });
  }

  try {
    await db.bulkOperations.create({
      data: {
        id: bulkMutationId,
        status: 'CREATED',
        operation: 'QUANTITY_LIMIT_UPDATE',
        shop: session.shop,
      }
    });
    console.log('bulkOperation database success');
  } catch (error) {
    console.log({ error });
    return json({ status: 'error', errors: [{ message: 'Failed to create bulk operation tracker' }] }, { status: 400 });
  }

  return json({ status: 'success', id: bulkMutationId });
};

const BULK_METAFIELD_UPDATE = `
  mutation call($metafields: [MetafieldsSetInput!]!) {
    metafieldsSet(metafields: $metafields) {
      userErrors {
        field
        message
      }
    }
  }
`;
