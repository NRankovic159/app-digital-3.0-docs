import { useEffect, useRef } from "react";
import { json } from "@remix-run/node";
import { useLoaderData, useNavigate, useSubmit, useActionData } from "@remix-run/react";
import { useForm, useField } from "@shopify/react-form";

import { authenticate } from "../shopify.server";
import handleCheckoutBrandUpdate from "../lib/handle-checkout-brand-update";

import {
  Banner,
  BlockStack,
  Button,
  Card,
  Divider,
  Form,
  FormLayout,
  InlineStack,
  TextField,
  Select,
  Layout,
  Text,
  Page,
} from "@shopify/polaris";
import { HeadingField } from "../components/heading-field";

import { CORNER_RADIUS, FONT_WEIGHTS, FONT_CHOICES } from "../data/checkout-options";
import { GET_CHECKOUT_BRAND_DATA } from "../data/checkout-brand-queries";

export const loader = async ({ request, params }) => {
  const { admin } = await authenticate.admin(request);
  const { id } = params;

  const checkoutProfileResp = await admin.graphql(
    GET_CHECKOUT_BRAND_DATA,
    {
      variables: { id: `gid://shopify/CheckoutProfile/${id}` },
    }
  );

  const checkoutProfileRespJson = await checkoutProfileResp.json();
  const profile = checkoutProfileRespJson.data.checkoutProfile;
  const branding = checkoutProfileRespJson.data.checkoutBranding;
  const files = checkoutProfileRespJson.data.files.nodes;

  return json({profile, branding, fontFiles: files });
};

export default function BrandingEdit() {
  const navigate = useNavigate();
  const actionData = useActionData();
  const { profile, branding, fontFiles } = useLoaderData();
  const submitForm = useSubmit();
  const errorBannerRef = useRef(null);

  const { designSystem, customizations } = branding || {};
  const { typography } = designSystem || {};
  const { primary, secondary } = typography || {};

  const validateFileAndWeight = (fieldName, file, weight, errors) => {
    if (file && weight === 'unset') {
      errors.push({
        field: fieldName,
        message: 'Weight is required',
      });
    }
  }

  const fontFileOptions = [
    {
      label: 'None',
      value: '',
    },
    ...fontFiles.map((file) => {
      const fileUrl = new URL(file.url);
      fileUrl.searchParams.delete('v');
      const fileName = fileUrl.pathname.split('/').pop();
      return {
        label: fileName,
        value: file.id,
      }
    })
  ];

  const parseFontFiles = (source) => {
    if (!source) return '';
    if (!fontFiles) return '';

    const file = fontFiles.find((file) => {
      const fileUrl = new URL(file.url);
      fileUrl.searchParams.delete('v');
      return source.includes(fileUrl.href);
    });
    if (!file) return '';

    return file.id;
  }

  const {
    fields: {
      baseSize,
      baseRatio,
      primaryBaseFile,
      primaryBaseWeight,
      primaryBoldFile,
      primaryBoldWeight,
      secondaryBaseFile,
      secondaryBaseWeight,
      secondaryBoldFile,
      secondaryBoldWeight,
      primaryButtonFont,
      primaryButtonCornerRadius,
      secondaryButtonFont,
      secondaryButtonCornerRadius,
      headingLevel1,
      headingLevel2,
      headingLevel3,
    },
    submit,
    submitting,
    submitErrors,
    dirty,
  } = useForm({
    fields: {
      baseSize: useField(primary?.size?.base?.toString() || '16'),
      baseRatio: useField(primary?.size?.ratio?.toString() || '1.4'),
      primaryBaseFile: useField(parseFontFiles(primary?.base?.sources)),
      primaryBaseWeight: useField(primary?.base?.weight?.toString() || 'unset'),
      primaryBoldFile: useField(parseFontFiles(primary?.bold?.sources)),
      primaryBoldWeight: useField(primary?.bold?.weight?.toString() || 'unset'),
      secondaryBaseFile: useField(parseFontFiles(secondary?.base?.sources)),
      secondaryBaseWeight: useField(secondary?.base?.weight?.toString() || 'unset'),
      secondaryBoldFile: useField(parseFontFiles(secondary?.bold?.sources)),
      secondaryBoldWeight: useField(secondary?.bold?.weight?.toString() || 'unset'),
      primaryButtonFont: useField(branding?.customizations?.primaryButton?.typography?.font || 'PRIMARY'),
      primaryButtonCornerRadius: useField(branding?.customizations?.primaryButton?.cornerRadius?.toString() || 'NONE'),
      secondaryButtonFont: useField(branding?.customizations?.secondaryButton?.typography?.font || 'SECONDARY'),
      secondaryButtonCornerRadius: useField(branding?.customizations?.secondaryButton?.cornerRadius?.toString() || 'NONE'),
      headingLevel1: {
        font: useField(customizations?.headingLevel1?.typography.font || 'PRIMARY'),
        weight: useField(customizations?.headingLevel1?.typography.weight || 'BASE'),
        size: useField(customizations?.headingLevel1?.typography.size || 'BASE'),
        kerning: useField(customizations?.headingLevel1?.typography.kerning || 'BASE'),
        letterCase: useField(customizations?.headingLevel1?.typography.letterCase || 'NONE'),
      },
      headingLevel2: {
        font: useField(customizations?.headingLevel2?.typography.font || 'PRIMARY'),
        weight: useField(customizations?.headingLevel2?.typography.weight || 'BASE'),
        size: useField(customizations?.headingLevel2?.typography.size || 'BASE'),
        kerning: useField(customizations?.headingLevel2?.typography.kerning || 'BASE'),
        letterCase: useField(customizations?.headingLevel2?.typography.letterCase || 'NONE'),
      },
      headingLevel3: {
        font: useField(customizations?.headingLevel3?.typography.font || 'PRIMARY'),
        weight: useField(customizations?.headingLevel3?.typography.weight || 'BASE'),
        size: useField(customizations?.headingLevel3?.typography.size || 'BASE'),
        kerning: useField(customizations?.headingLevel3?.typography.kerning || 'BASE'),
        letterCase: useField(customizations?.headingLevel3?.typography.letterCase || 'NONE'),
      }
    },
    onSubmit: async (values) => {
      if (submitting) return;
      const errors = [];

      Object.keys(values).forEach((key) => {
        if (values[key] === 'unset' || values[key] === '') {
          errors.push({
            field: key,
            message: 'This field is required',
          });
        }
      });

      if (isNaN(values.baseSize, 10)) {
        errors.push({
          field: 'Base Size (px)',
          message: 'Base Size must be a number',
        });
      }

      if (isNaN(values.baseRatio)) {
        errors.push({
          field: 'Ratio',
          message: 'Ratio must be a number',
        });
      }

      validateFileAndWeight('primaryBaseWeight', values.primaryBaseFile, values.primaryBaseWeight, errors);
      validateFileAndWeight('primaryBoldWeight', values.primaryBoldFile, values.primaryBoldWeight, errors);
      validateFileAndWeight('secondaryBaseWeight', values.secondaryBaseFile, values.secondaryBaseWeight, errors);
      validateFileAndWeight('secondaryBoldWeight', values.secondaryBoldFile, values.secondaryBoldWeight, errors);

      if (errors.length) {
        return {
          status: 'fail',
          errors,
        };
      }

      submitForm({ data: JSON.stringify(values)}, { method: "post" });

      return {
        status: 'success',
      };
    },
  });

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset?')) {
      submitForm({ data: JSON.stringify({})}, { method: "delete" });
    }
  }

  useEffect(() => {
    if (actionData?.errors.length === 0) {
      navigate('/app/checkout/all');
    }
  }, [actionData, navigate]);

  useEffect(() => {
    if (submitErrors?.length > 0) {
      errorBannerRef.current?.focus();
    }
  }, [submitErrors]);

  const errorBanner =
    submitErrors.length > 0 ? (
      <Layout.Section>
        <Banner ref={errorBannerRef} tone="critical">
          <p>There were some issues with your form submission:</p>
          <ul>
            {submitErrors.map(({ message, field }, index) => {
              return (
                <li key={`${message}${index}`}>
                  {field} - {message}
                </li>
              );
            })}
          </ul>
        </Banner>
      </Layout.Section>
    ) : null;

  return (
    <Page
      title={profile?.name}
      primaryAction={{
        content: 'Save',
        disabled: !dirty || submitting,
        onAction: () => submit(),
      }}
      secondaryActions={[
        {
          content: 'Cancel',
          onAction: () => navigate('/app/checkout/all'),
        },
      ]}
    >
      <Layout>
        {errorBanner}
        <Layout.Section>
          <BlockStack gap="400">
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingLg">Customize Checkout Fonts</Text>
                <Divider />
                <Text as="p" variant="bodyMd">Customize the fonts used in your checkout.</Text>

                <Text as="p" variant="bodyMd">
                  If there are no options available for a font, you can upload a font file in the <Text as="strong">Files</Text> section of your Shopify admin.
                </Text>

                <Text as="p" variant="bodyMd">
                  Shopify only accepts <Text as="strong">.woff</Text> and <Text as="strong">.woff2</Text> font files.
                </Text>

                <Text as="p" variant="bodyMd">
                  Other checkout customizations can be made in the <Text as="strong">Settings {'>'} Checkout {'>'} Checkout customization</Text> section of your Shopify admin.
                </Text>
              </BlockStack>
            </Card>
            <Card>
              <Form onSubmit={submit} noValidate={false}>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingLg">Branding</Text>
                  <Divider />
                  <Text as="h3" variant="headingMd">Typography</Text>

                  <BlockStack gap="200">
                    <FormLayout.Group title="Sizing">
                      <TextField
                        label="Base Size (px)"
                        {...baseSize}
                        requiredIndicator
                      />
                      <TextField
                        label="Ratio"
                        {...baseRatio}
                        requiredIndicator
                      />
                    </FormLayout.Group>

                    <FormLayout.Group title="Primary Base">
                      <Select
                        label="Font File"
                        options={fontFileOptions}
                        {...primaryBaseFile}
                        requiredIndicator
                      />
                      <Select
                        label="Weight"
                        options={FONT_WEIGHTS}
                        {...primaryBaseWeight}
                        requiredIndicator
                      />
                    </FormLayout.Group>

                    <FormLayout.Group title="Primary Bold">
                      <Select
                        label="Font File"
                        options={fontFileOptions}
                        {...primaryBoldFile}
                        requiredIndicator
                      />
                      <Select
                        label="Weight"
                        options={FONT_WEIGHTS}
                        {...primaryBoldWeight}
                        requiredIndicator
                      />
                    </FormLayout.Group>

                    <FormLayout.Group title="Secondary Base">
                      <Select
                        label="Font File"
                        options={fontFileOptions}
                        {...secondaryBaseFile}
                        requiredIndicator
                      />
                      <Select
                        label="Weight"
                        options={FONT_WEIGHTS}
                        {...secondaryBaseWeight}
                        requiredIndicator
                      />
                    </FormLayout.Group>

                    <FormLayout.Group title="Secondary Bold">
                      <Select
                        label="Font File"
                        options={fontFileOptions}
                        {...secondaryBoldFile}
                        requiredIndicator
                      />
                      <Select
                        label="Weight"
                        options={FONT_WEIGHTS}
                        {...secondaryBoldWeight}
                        requiredIndicator
                      />
                    </FormLayout.Group>
                  </BlockStack>

                  <Divider />

                  <Text as="h3" variant="headingMd">Buttons</Text>

                  <FormLayout.Group title="Fonts">
                    <Select
                      label="Primary Button"
                      options={FONT_CHOICES}
                      {...primaryButtonFont}
                      requiredIndicator
                    />
                    <Select
                      label="Secondary Button"
                      options={FONT_CHOICES}
                      {...secondaryButtonFont}
                      requiredIndicator
                    />
                  </FormLayout.Group>

                  <FormLayout.Group title="Corner Radius">
                    <Select
                      label="Primary Button Corner Radius"
                      options={CORNER_RADIUS}
                      {...primaryButtonCornerRadius}
                      requiredIndicator
                    />
                    <Select
                      label="Secondary Button Corner Radius"
                      options={CORNER_RADIUS}
                      {...secondaryButtonCornerRadius}
                      requiredIndicator
                    />
                  </FormLayout.Group>

                  <Divider />

                  <Text as="h3" variant="headingMd">Headings</Text>

                  <BlockStack gap="200">
                    <HeadingField
                      title="Heading Level 1"
                      fields={headingLevel1}
                    />

                    <HeadingField
                      title="Heading Level 2"
                      fields={headingLevel2}
                    />

                    <HeadingField
                      title="Heading Level 3"
                      fields={headingLevel3}
                    />
                  </BlockStack>

                  <InlineStack align="end" gap="300">
                    <Button
                      variant="plain"
                      tone="critical"
                      disabled={submitting}
                      onClick={handleReset}
                    >
                      Reset
                    </Button>
                    <Button
                      submit
                      primary
                      disabled={!dirty || submitting}
                    >
                      Save
                    </Button>
                  </InlineStack>
                </BlockStack>
              </Form>
            </Card>
            <InlineStack />
          </BlockStack>
        </Layout.Section>
      </Layout>
    </Page>
  )
}

export const action = async ({ request, params }) => {
  return handleCheckoutBrandUpdate({
    request,
    params,
    authenticate,
  });
};
