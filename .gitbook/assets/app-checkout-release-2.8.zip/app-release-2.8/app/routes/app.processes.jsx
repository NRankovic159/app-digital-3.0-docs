import {
  Page,
  Button,
  Layout,
  Text,
  Card,
  BlockStack,
} from "@shopify/polaris";
import { useLoaderData } from "@remix-run/react";
import { json } from "@remix-run/node";
import { useState, useEffect } from "react"
import db from "~/db.server";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }) => {
  const { session } = await authenticate.admin(request);

  const bulkOpTrigger = await db.bulkOperationTriggers.findFirst({
    where: {
      id: session.shop,
    }
  });

  if (!bulkOpTrigger || !bulkOpTrigger.opTrigger) {
    return json({ status: 200, json: { status: 'Idle' } });
  }


  const bulkOperations = await db.bulkOperations.findMany({
    where: {
      shop: session.shop,
      opTrigger: bulkOpTrigger.opTrigger,
    },
  });

  const hasFinished = bulkOperations.every((op) => op.status === 'COMPLETED') && bulkOperations.length === 2;

  if (hasFinished) {
    await db.bulkOperationTriggers.update({
      where: {
        id: session.shop,
      },
      data: {
        opTrigger: null,
      }
    });
    return json({ status: 200, json: { status: 'Idle' } });
  }

  return json({
    status: 200,
    json: {
      status: 'Running',
      bulkOperations,
    }
  });
}

export default function Index() {
  const data = useLoaderData();
  const [stream, setStream] = useState(data.json.status || 'Idle');

  useEffect(() => {
    const interval = setInterval(async () => {
      const bulkOpStatus = await fetch('/api/bulk-op-status');
      const bulkOpStatusData = await bulkOpStatus.json();
      setStream(bulkOpStatusData.json.status);

      if (bulkOpStatusData.json.status === 'Idle') {
        clearInterval(interval);
      }
    }, 2_500);

    return () => clearInterval(interval);
  }, [stream]);

  return (
    <Page>
      <ui-title-bar title="Tasks & Bulk Jobs" />
      <BlockStack gap="500">
        <Layout>
          <Layout.Section>
            <BlockStack gap="500">
              <Card>
                <BlockStack gap="400" align="start" inlineAlign="start">
                  <Text as="h2" variant="headingMd">
                    Sync Variant Location Metafields
                  </Text>

                  <Text>
                    This process will sync the location availbility metafields for each variant in your store. This process will run in the background and may take a few minutes to complete.
                    <br />

                    The metafield is used to support Front-End filtering of products for BOPIS.
                  </Text>

                  <Text>
                    Status: <span id="variant-status">{stream}</span>
                  </Text>

                  <Button
                    type="button"
                    onClick={() => {
                      try {
                        fetch('/api/trigger-variant-query', { method: 'POST' });
                        setStream('Starting up');
                        shopify.toast.show('Syncing variants...');
                      } catch (e) {
                        console.log(e);
                      }
                    }}
                    primary
                    loading={stream !== 'Idle'}
                  >
                    Run
                  </Button>
                </BlockStack>
              </Card>
            </BlockStack>
          </Layout.Section>
        </Layout>
      </BlockStack>
    </Page>
  );
}
