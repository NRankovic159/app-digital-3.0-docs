import { json } from '@remix-run/node';
import { authenticate } from '../shopify.server';

import { mutationJob } from '~/jobs/variant-bulk-mutation'

export const action = async ({ request }) => {
  const { session } = await authenticate.admin(request);

  try {
    const jobInit = await mutationJob.trigger({
      session,
      url: '',
    });

    console.log(jobInit);
  } catch (error) {
    console.error(error);
    return json({ status: 'error' });
  }

  return json({ status: 'ok' });
};
