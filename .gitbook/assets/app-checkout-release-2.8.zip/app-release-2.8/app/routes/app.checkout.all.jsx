import { useState, useCallback } from "react";
import { json } from "@remix-run/node";
import { useLoaderData, useNavigate } from "@remix-run/react";
import useSWR from "swr";
import {
  Page,
  Tabs,
  EmptyState,
  Card,
  Spinner,
  InlineStack,
} from "@shopify/polaris";

import { authenticate } from "../shopify.server";

const fetcher = (url) => fetch(url).then((res) => res.json());

export const loader = async ({ request }) => {
  const { admin } = await authenticate.admin(request);

  const response = await admin.graphql(
    `query {
      checkoutProfiles(first: 10) {
        nodes {
          id
          name
        }
      }
    }`
  );

  const responseJson = await response.json();
  const checkoutProfiles = responseJson.data.checkoutProfiles.nodes;
  const [firstProfile] = checkoutProfiles;

  if (!firstProfile) return json({ checkoutProfiles: [], profile: null });

  const checkoutProfileResp = await admin.graphql(
    `
      query($id: ID!) {
        checkoutBranding(checkoutProfileId: $id) {
          customizations {
            global {
              typography {
                kerning
              }
            }
          }
          designSystem {
            typography {
              primary {
                base {
                  sources
                }
              }
              secondary {
                base {
                  sources
                }
              }
            }
          }
        }
      }
    `,
    {
      variables: { id: firstProfile.id },
    }
  );

  const checkoutProfileRespJson = await checkoutProfileResp.json();
  const profile = checkoutProfileRespJson.data.checkoutBranding;

  return json({ checkoutProfiles, profile });
};

export default function Checkout() {
  const navigate = useNavigate();
  const { checkoutProfiles } = useLoaderData();
  const [firstProfile] = checkoutProfiles;

  const [selected, setSelected] = useState(0);
  const [tabProfile, setTabProfile] = useState(firstProfile);
  const profileId = tabProfile?.id.replace('gid://shopify/CheckoutProfile/', '');

  const {
    data: profileData,
    isLoading: profileLoading,
  } = useSWR(
    tabProfile?.id
      ? `/api/checkout-profiles/${profileId}`
      : null,
    fetcher
  );

  const handleTabChange = useCallback(
    (selectedTabIndex) => {
      setSelected(selectedTabIndex);
      setTabProfile(checkoutProfiles[selectedTabIndex]);
    },
    [checkoutProfiles]
  );

  const tabs = checkoutProfiles.map((profile) => ({
    id: profile.id,
    content: profile.name,
    panelID: profile.id,
  }));

  return (
    <Page>
      <ui-title-bar title="Custom Checkout Styles" />

      <Tabs tabs={tabs} selected={selected} onSelect={handleTabChange}>
        <Card>
          {profileLoading && !profileData && (
            <InlineStack align="center" blockAlign="center">
              <Spinner />
            </InlineStack>
          )}

          {!profileLoading && !profileData && (
            <EmptyState
              heading="We couldn't find any checkout profiles"
            />
          )}

          {!profileLoading && !profileData?.customizations && (
            <EmptyState
              heading={`No customizations for ${tabProfile.name}`}
              action={{
                content: 'Add Customizations',
                onAction: () => {
                  navigate(`/app/checkout/${profileId}`)
                },
              }}
              image="/emptystate-files.avif"
            >
              <p>Update this Checkout Profile with custom fonts.</p>
            </EmptyState>
          )}

          {!profileLoading && profileData?.customizations && (
            <EmptyState
              heading={`${tabProfile.name} has customizations`}
              action={{
                content: 'Edit Customizations',
                onAction: () => {
                  navigate(`/app/checkout/${profileId}`)
                },
              }}
              image="/emptystate-files.avif"
            >
              <p>Update this Checkout Profile with custom fonts.</p>
            </EmptyState>
          )}
        </Card>
      </Tabs>
    </Page>
  );
}
