import { json } from "@remix-run/node";
import { useEffect } from "react";
import { useLoaderData, useNavigate, useNavigation, useSubmit, useActionData } from "@remix-run/react";
import {
  Page,
  Button,
  Layout,
  Text,
  Card,
  BlockStack,
  Link,
  InlineStack,
} from "@shopify/polaris";

import { APP_TRANSLATIONS_NAMESPACE } from "../data/metafields";
import { DEFAULT_TRANSLATION_KEYS } from "../data/default-translation-values";

import { authenticate } from "../shopify.server";

export const loader = async ({ request }) => {
  const { admin } = await authenticate.admin(request);

  const translationsQuery = await admin.graphql(
    `
      query currentAppInstallation {
        shop {
          id
        }
        currentAppInstallation {
          id
          metafields(first: 20, namespace: "${APP_TRANSLATIONS_NAMESPACE}") {
            nodes {
              key
              value
            }
          }
        }
      }
    `
  );

  const translationsJson = await translationsQuery.json();

  const translations = translationsJson.data.currentAppInstallation.metafields.nodes
    .map((node) => {
      return {
        ...JSON.parse(node.value || '{}'),
      };
    });
  const appId = translationsJson.data.currentAppInstallation.id;

  return json({
    translations,
    appId,
    shopId: translationsJson.data.shop.id,
  });
};

export default function Index() {
  const navigate = useNavigate();
  const nav = useNavigation();
  const submit = useSubmit();
  const actionData = useActionData();
  const isLoading =
    ["loading", "submitting"].includes(nav.state) && nav.formMethod === "POST";
  const { translations, appId, shopId } = useLoaderData();

  const addDefaultTranslations = async () => {
    submit({
      data: JSON.stringify({
        translations,
        appId,
        shopId,
      })
    }, { replace: true, method: "POST" });
  };

  useEffect(() => {
    if (actionData?.success) {
      shopify.toast.show('Default translations added!');
    }
  }, [actionData]);

  return (
    <Page>
      <ui-title-bar title="APP" />
      <BlockStack gap="500">
        <Layout>
          <Layout.Section>
            <BlockStack gap="500">
              <Card>
                <BlockStack gap="500">
                  <BlockStack gap="200">
                    <Text as="h2" variant="headingMd">
                      Checkout Customizations and Extensions
                    </Text>
                    <Text variant="bodyMd" as="p">
                      Customize{" "}
                      <Link
                        to="/app/checkout/all"
                        onClick={() => navigate("/app/checkout/all")}
                        removeUnderline
                      >
                        Checkout Fonts
                      </Link>
                      {" "}or add{" "}
                      <Link
                        url="/app/checkout/translations"
                        onClick={() => navigate("/app/checkout/translations")}
                        removeUnderline
                      >
                        Translations
                      </Link>{" "}
                      for Checkout UI Extensions
                    </Text>
                  </BlockStack>
                </BlockStack>
              </Card>

              {translations.length !== DEFAULT_TRANSLATION_KEYS.length && (
                <Card>
                  <BlockStack gap="200">

                    <Text as="h2" variant="headingMd">
                      Finish Setup for Translations
                    </Text>

                    <Text variant="bodyMd" as="p">
                      Default values for translations are provided for you. After you finish setting up your app, you can edit the translations by navigating to the Extension Translation page.
                    </Text>

                    <InlineStack>
                      <Button
                        type="button"
                        onClick={() => addDefaultTranslations()}
                        primary
                        submit
                        loading={isLoading}
                        disabled={isLoading}
                      >
                        Finish Setup
                      </Button>
                    </InlineStack>
                  </BlockStack>
                </Card>
              )}
            </BlockStack>
          </Layout.Section>
        </Layout>
      </BlockStack>
    </Page>
  );
}

export const action = async ({ request }) => {
  const { method } = request;

  if (method !== 'POST') {
    return json({ errors: [{ message: 'Invalid method' }] });
  }

  const { admin } = await authenticate.admin(request);
  const formData = await request.formData();
  const fieldData = JSON.parse(formData.get('data'));
  const { appId, shopId, translations } = fieldData;

  const groups = DEFAULT_TRANSLATION_KEYS.map((defaultItem) => {
    const translation = translations.find((t) => t.key === defaultItem.key) || {};
    return {
      ...defaultItem,
      ...translation,
    };
  });

  const metafields = groups.map((item) => {
    const { key } = item;

    const metaFieldInput = {
      "key": key,
      "namespace": APP_TRANSLATIONS_NAMESPACE,
      "type": "json",
      "value": JSON.stringify(item),
    };

    return [
      { ...metaFieldInput, "ownerId": appId },
      { ...metaFieldInput, "ownerId": shopId },
    ];
  });

  const metafieldSetMutation = await admin.graphql(
    `mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) {
        metafields {
          id
        }
        userErrors {
          field
          message
        }
      }
    }`,
    {
      variables: {
        metafields: metafields.flat(),
      }
    }
  );

  const metafieldSetJson = await metafieldSetMutation.json();
  const { userErrors } = metafieldSetJson.data.metafieldsSet;
  if (userErrors && userErrors.length > 0) {
    return json({ errors: userErrors }, { status: 400 });
  }

  return json({ success: true });
};
