import { authenticate } from "../shopify.server";
import db from "../db.server";
// Import the v3 `task` you created for the mutation job
import { mutationJob } from "~/jobs/variant-bulk-mutation";

export const action = async ({ request }) => {
  const { topic, session, admin, payload } = await authenticate.webhook(request);

  console.log({ topic, payload });

  if (!admin) {
    // The admin context isn't returned if the webhook fired after a shop was uninstalled.
    throw new Response("", { status: 200 });
  }

  try {
    const { admin_graphql_api_id } = payload;

    // Run the GraphQL query to retrieve the BulkOperation info
    const bulkOperationQuery = await admin.graphql(
      `
        query ($id: ID!) {
          node(id: $id) {
            id
            ... on BulkOperation {
              status
              url
            }
          }
        }
      `,
      {
        variables: {
          id: admin_graphql_api_id,
        },
      }
    );

    const bulkOperationJson = await bulkOperationQuery.json();
    const bulkOperation = bulkOperationJson.data.node;

    if (bulkOperation) {
      // Update DB with the retrieved info
      const dbUpdate = await db.bulkOperations.update({
        where: { id: admin_graphql_api_id },
        data: {
          status: bulkOperation.status,
          fileUrl: bulkOperation.url,
        },
      });

      // If this indicates we should trigger the mutation
      if (dbUpdate.operation === "VARIANT_LOCATION_BULK_QUERY") {
        // v3: Trigger the mutationJob directly
        await mutationJob.trigger({
          session,
          url: bulkOperation.url,
          opTrigger: dbUpdate.opTrigger,
        });
      }
    }
  } catch (error) {
    console.error(error);
  }

  throw new Response("", { status: 200 });
};
