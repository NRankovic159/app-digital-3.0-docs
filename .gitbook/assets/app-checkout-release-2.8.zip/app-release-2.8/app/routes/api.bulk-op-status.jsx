import db from "../db.server";
import { json } from '@remix-run/node';
import { authenticate } from "../shopify.server";

export async function loader({ request }) {
  const { session } = await authenticate.admin(request);

  const bulkOpTrigger = await db.bulkOperationTriggers.findFirst({
    where: {
      id: session.shop,
    }
  });

  if (!bulkOpTrigger || !bulkOpTrigger.opTrigger) {
    return json({ status: 200, json: { status: 'Idle' } });
  }

  const bulkOperations = await db.bulkOperations.findMany({
    where: {
      shop: session.shop,
      opTrigger: bulkOpTrigger.opTrigger,
    },
  });

  const hasFinished = bulkOperations.every((op) => op.status === 'COMPLETED') && bulkOperations.length === 2;

  if (hasFinished) {
    await db.bulkOperationTriggers.update({
      where: {
        id: session.shop,
      },
      data: {
        opTrigger: null,
      }
    });

    return json({ status: 200, json: { status: 'Idle' } });
  }

  return json({
    status: 200,
    json: {
      status: 'Running',
      bulkOperations,
    }
  });
}
