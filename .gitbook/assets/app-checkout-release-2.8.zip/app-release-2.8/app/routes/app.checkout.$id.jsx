import { useEffect, useRef } from "react";
import { json } from "@remix-run/node";
import { useLoaderData, useNavigate, useSubmit, useActionData } from "@remix-run/react";
import { useForm, useField } from "@shopify/react-form";

import { authenticate } from "../shopify.server";
import handleCheckoutBrandUpdate from "../lib/handle-checkout-brand-update";

import {
  Banner,
  BlockStack,
  Button,
  Card,
  Divider,
  Form,
  FormLayout,
  InlineStack,
  Select,
  Layout,
  Text,
  Page,
} from "@shopify/polaris";
import { GET_CHECKOUT_BRAND_DATA } from "../data/checkout-brand-queries";

export const loader = async ({ request, params }) => {
  const { admin } = await authenticate.admin(request);
  const { id } = params;

  const checkoutProfileResp = await admin.graphql(
    GET_CHECKOUT_BRAND_DATA,
    {
      variables: { id: `gid://shopify/CheckoutProfile/${id}` },
    }
  );

  const checkoutProfileRespJson = await checkoutProfileResp.json();
  const profile = checkoutProfileRespJson.data.checkoutProfile;
  const branding = checkoutProfileRespJson.data.checkoutBranding;
  const files = checkoutProfileRespJson.data.files.nodes;

  return json({profile, branding, fontFiles: files });
};

export default function BrandingEdit() {
  const navigate = useNavigate();
  const actionData = useActionData();
  const { profile, branding, fontFiles } = useLoaderData();
  const submitForm = useSubmit();
  const errorBannerRef = useRef(null);

  const { designSystem } = branding || {};
  const { typography } = designSystem || {};
  const { primary, secondary } = typography || {};

  const validateFileAndWeight = (fieldName, file, weight, errors) => {
    if (file && weight === 'unset') {
      errors.push({
        field: fieldName,
        message: 'Weight is required',
      });
    }
  }

  const fontFileOptions = [
    {
      label: 'None',
      value: '',
    },
    ...fontFiles.map((file) => {
      const fileUrl = new URL(file.url);
      fileUrl.searchParams.delete('v');
      const fileName = fileUrl.pathname.split('/').pop();
      return {
        label: fileName,
        value: file.id,
      }
    })
  ];

  const parseFontFiles = (source) => {
    if (!source) return '';
    if (!fontFiles) return '';

    const file = fontFiles.find((file) => {
      const fileUrl = new URL(file.url);
      fileUrl.searchParams.delete('v');
      return source.includes(fileUrl.href);
    });
    if (!file) return '';

    return file.id;
  }

  const {
    fields: {
      primaryBaseFile,
      primaryBoldFile,
      secondaryBaseFile,
      secondaryBoldFile,

    },
    submit,
    submitting,
    submitErrors,
    dirty,
  } = useForm({
    fields: {
      baseSize: useField('16'),
      baseRatio: useField('1.4'),
      primaryBaseFile: useField(parseFontFiles(primary?.base?.sources)),
      primaryBaseWeight: useField('400'),
      primaryBoldFile: useField(parseFontFiles(primary?.bold?.sources)),
      primaryBoldWeight: useField('700'),
      secondaryBaseFile: useField(parseFontFiles(secondary?.base?.sources)),
      secondaryBaseWeight: useField('400'),
      secondaryBoldFile: useField(parseFontFiles(secondary?.bold?.sources)),
      secondaryBoldWeight: useField('700'),
      primaryButtonFont: useField('PRIMARY'),
      primaryButtonCornerRadius: useField('LARGE'),
      secondaryButtonFont: useField('SECONDARY'),
      secondaryButtonCornerRadius: useField('LARGE'),
      headingLevel1: {
        font: useField('PRIMARY'),
        weight: useField('BOLD'),
        size: useField('EXTRA_LARGE'),
        kerning: useField('BASE'),
        letterCase: useField('NONE'),
      },
      headingLevel2: {
        font: useField('PRIMARY'),
        weight: useField('BOLD'),
        size: useField('LARGE'),
        kerning: useField('BASE'),
        letterCase: useField('NONE'),
      },
      headingLevel3: {
        font: useField('PRIMARY'),
        weight: useField('BOLD'),
        size: useField('MEDIUM'),
        kerning: useField('BASE'),
        letterCase: useField('NONE'),
      }
    },
    onSubmit: async (values) => {
      if (submitting) return;
      const errors = [];

      Object.keys(values).forEach((key) => {
        if (values[key] === 'unset' || values[key] === '') {
          errors.push({
            field: key,
            message: 'This field is required',
          });
        }
      });

      if (isNaN(values.baseSize, 10)) {
        errors.push({
          field: 'Base Size (px)',
          message: 'Base Size must be a number',
        });
      }

      if (isNaN(values.baseRatio)) {
        errors.push({
          field: 'Ratio',
          message: 'Ratio must be a number',
        });
      }

      validateFileAndWeight('primaryBaseWeight', values.primaryBaseFile, values.primaryBaseWeight, errors);
      validateFileAndWeight('primaryBoldWeight', values.primaryBoldFile, values.primaryBoldWeight, errors);
      validateFileAndWeight('secondaryBaseWeight', values.secondaryBaseFile, values.secondaryBaseWeight, errors);
      validateFileAndWeight('secondaryBoldWeight', values.secondaryBoldFile, values.secondaryBoldWeight, errors);

      if (errors.length) {
        return {
          status: 'fail',
          errors,
        };
      }

      submitForm({ data: JSON.stringify(values)}, { method: "post" });

      return {
        status: 'success',
      };
    },
  });

  const handleReset = () => {
    if (window.confirm('Are you sure you want to reset?')) {
      submitForm({ data: JSON.stringify({})}, { method: "delete" });
    }
  }

  useEffect(() => {
    if (actionData?.errors.length === 0) {
      navigate('/app/checkout/all');
    }
  }, [actionData, navigate]);

  useEffect(() => {
    if (submitErrors?.length > 0) {
      errorBannerRef.current?.focus();
    }
  }, [submitErrors]);

  const errorBanner =
    submitErrors.length > 0 ? (
      <Layout.Section>
        <Banner ref={errorBannerRef} tone="critical">
          <p>There were some issues with your form submission:</p>
          <ul>
            {submitErrors.map(({ message, field }, index) => {
              return (
                <li key={`${message}${index}`}>
                  {field} - {message}
                </li>
              );
            })}
          </ul>
        </Banner>
      </Layout.Section>
    ) : null;

  return (
    <Page
      title={profile?.name}
      primaryAction={{
        content: 'Save',
        disabled: !dirty || submitting,
        onAction: () => submit(),
      }}
      secondaryActions={[
        {
          content: 'Cancel',
          onAction: () => navigate('/app/checkout/all'),
        },
      ]}
    >
      <Layout>
        {errorBanner}
        <Layout.Section>
          <BlockStack gap="400">
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingLg">Customize Checkout Fonts</Text>
                <Divider />
                <Text as="p" variant="bodyMd">Customize the fonts used in your checkout.</Text>

                <Text as="p" variant="bodyMd">
                  If there are no options available for a font, you can upload a font file in the <Text as="strong">Files</Text> section of your Shopify admin.
                </Text>

                <Text as="p" variant="bodyMd">
                  Shopify only accepts <Text as="strong">.woff</Text> and <Text as="strong">.woff2</Text> font files.
                </Text>

                <Text as="p" variant="bodyMd">
                  Other checkout customizations can be made in the <Text as="strong">Settings {'>'} Checkout {'>'} Checkout customization</Text> section of your Shopify admin.
                </Text>
              </BlockStack>
            </Card>
            <Card>
              <Form onSubmit={submit} noValidate={false}>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingLg">Branding</Text>
                  <Divider />
                  <Text as="h3" variant="headingMd">Typography</Text>

                  <BlockStack gap="200">
                    <FormLayout.Group title="Primary Font">
                      <Select
                        label="Base Font File"
                        options={fontFileOptions}
                        {...primaryBaseFile}
                        requiredIndicator
                      />

                      <Select
                        label="Bold Font File"
                        options={fontFileOptions}
                        {...primaryBoldFile}
                        requiredIndicator
                      />
                    </FormLayout.Group>

                    <FormLayout.Group title="Secondary Font">
                      <Select
                        label="Base Font File"
                        options={fontFileOptions}
                        {...secondaryBaseFile}
                        requiredIndicator
                      />

                      <Select
                        label="Bold Font File"
                        options={fontFileOptions}
                        {...secondaryBoldFile}
                        requiredIndicator
                      />
                    </FormLayout.Group>
                  </BlockStack>

                  <InlineStack align="end" gap="300">
                    <Button
                      variant="plain"
                      tone="critical"
                      disabled={submitting}
                      onClick={handleReset}
                    >
                      Reset
                    </Button>
                    <Button
                      submit
                      primary
                      disabled={!dirty || submitting}
                    >
                      Save
                    </Button>
                  </InlineStack>
                </BlockStack>
              </Form>
            </Card>
            <InlineStack />
          </BlockStack>
        </Layout.Section>
      </Layout>
    </Page>
  )
}

export const action = async ({ request, params }) => {
  return handleCheckoutBrandUpdate({
    request,
    params,
    authenticate,
  });
};
