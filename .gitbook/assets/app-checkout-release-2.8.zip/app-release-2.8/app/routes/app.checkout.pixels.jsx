import { json } from "@remix-run/node";
import { useLoaderData, useSubmit, useNavigate } from "@remix-run/react";
import { useForm, useField } from "@shopify/react-form";
import {
  Banner,
  Button,
  Form,
  FormLayout,
  Layout,
  InlineStack,
  Page,
  Text,
  TextField,
} from "@shopify/polaris";

import { authenticate } from "../shopify.server";
import { APP_CONFIG } from "../data/metafields";

export const loader = async ({ request }) => {
  const { admin } = await authenticate.admin(request);

  const configQuery = await admin.graphql(
    `
      query configPixelQuery {
        currentAppInstallation {
          id
          configMeta: metafield(namespace: "${APP_CONFIG.namespace}", key: "${APP_CONFIG.key}") {
            id
            value
          }
        }
      }
    `
  );

  const configJson = await configQuery.json();
  const { id, configMeta } = configJson.data.currentAppInstallation;
  const config = JSON.parse(configMeta?.value || '{}');

  let pixelData = {};
  if (config.pixelId) {
    try {
      const pixelQuery = await admin.graphql(
        `
          query pixelQuery($id: ID!) {
            webPixel(id: $id) {
              id
              settings
            }
          }
        `,
        {
          variables: {
            id: config.pixelId,
          }
        }
      );

      const pixelJson = await pixelQuery.json();
      const { webPixel } = pixelJson.data || {};
      pixelData = {
        id: webPixel.id || null,
        settings: JSON.parse(webPixel.settings || '{}'),
      };
    } catch (e) {
      console.log(e);
    }
  }

  return json({
    appId: id,
    pixelData,
  });
};

export default function CheckoutPixels() {
  const { appId, pixelData } = useLoaderData();
  const submitForm = useSubmit();
  const navigate = useNavigate();

  const {
    fields: {
      accountId,
    },
    submit,
    submitting,
    submitErrors,
    dirty,
  } = useForm({
    fields: {
      appId: useField(appId),
      pixelId: useField(pixelData.id || ''),
      accountId: useField(pixelData.settings?.accountID || ''),
    },
    onSubmit: async (values) => {
      const { pixelId, accountId } = values;

      if (!accountId) {
        return {
          errors: [
            {
              message: 'Account ID is required',
              field: 'accountId',
            }
          ],
        };
      }

      if (!pixelId) {
        submitForm(
          { data: JSON.stringify(values) },
          { method: 'post' },
        );

        return { status: 'success' };
      }

      submitForm(
        { data: JSON.stringify(values) },
        { method: 'put' },
      );

      return { status: 'success' };
    }
  });

  const deletePixel = async () => {
    submitForm(
      { data: JSON.stringify({ pixelId: pixelData.id, appId }) },
      { method: 'delete' },
    );
  };

  navigate('/app', { replace: true });

  const errorBanner =
  submitErrors.length > 0 ? (
    <Layout.Section>
      <Banner tone="critical">
        <p>There were some issues with your form submission:</p>
        <ul>
          {submitErrors.map(({ message, field }, index) => {
            return (
              <li key={`${message}${index}`}>
                {field} - {message}
              </li>
            );
          })}
        </ul>
      </Banner>
    </Layout.Section>
  ) : null;

  return (
    <Page narrowWidth>
      <ui-title-bar title="Checkout Pixels" />
      <Layout>
        {errorBanner}
        <Layout.Section>
          <Form onSubmit={submit}>
            <FormLayout>
              <Text variant="headingLg">
                {pixelData.id ? 'Edit' : 'Activate'} Pixel
              </Text>

              <TextField
                autoComplete="off"
                label="Account ID (GTM-XXXXXX)"
                requiredIndicator
                {...accountId}
              />

              <InlineStack gap="200" align="end">
                {pixelData.id && (
                  <Button
                    tone="critical"
                    loading={submitting}
                    outline
                    onClick={deletePixel}
                  >
                    Deactivate
                  </Button>
                )}
                <Button
                  primary
                  submit
                  loading={submitting}
                  disabled={!dirty}
                >
                  {pixelData.id ? 'Update' : 'Activate'}
                </Button>
              </InlineStack>
            </FormLayout>
          </Form>
        </Layout.Section>
      </Layout>
    </Page>
  );
}

export const action = async ({ request }) => {
  const { method } = request;

  if (method !== 'POST' && method !== 'PUT' && method !== 'DELETE') {
    return json({ errors: [{ message: 'Method not allowed' }] }, { status: 405 });
  }

  const formData = await request.formData();
  const fieldData = JSON.parse(formData.get('data'));
  const { admin } = await authenticate.admin(request);

  const { appId, pixelId, accountId } = fieldData;

  // Delete Pixel
  if (method === 'DELETE') {
    const pixelDeleteMutation = await admin.graphql(
      `mutation($id: ID!) {
        webPixelDelete(id: $id) {
          deletedWebPixelId
          userErrors {
            code
            field
            message
          }
        }
      }`,
      {
        variables: {
          id: pixelId,
        }
      }
    );

    const pixelDeleteJson = await pixelDeleteMutation.json();
    const { userErrors } = pixelDeleteJson.data;
    if (userErrors && userErrors.length > 0) {
      return json({ errors: userErrors }, { status: 400 });
    }

    const configUpdateMutation = await admin.graphql(
      `mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
        metafieldsSet(metafields: $metafields) {
          metafields {
            id
          }
          userErrors {
            field
            message
          }
        }
      }`,
      {
        variables: {
          metafields: [
            {
              "key": APP_CONFIG.key,
              "namespace": APP_CONFIG.namespace,
              "ownerId": appId,
              "type": "json",
              "value": JSON.stringify({ pixelId: null }),
            }
          ]
        }
      }
    );

    const configUpdateJson = await configUpdateMutation.json();
    const { userErrors: metafieldErrors } = configUpdateJson.data;
    if (metafieldErrors && metafieldErrors.length > 0) {
      return json({ errors: metafieldErrors }, { status: 400 });
    }

    return json({ status: 'success' });
  }

  // Create Pixel
  if (method === 'POST') {
    const pixelCreateMuation = await admin.graphql(
      `mutation($settings: JSON!) {
        webPixelCreate(webPixel: { settings: $settings }) {
          userErrors {
            code
            field
            message
          }
          webPixel {
            settings
            id
          }
        }
      }`,
      {
        variables: {
          settings: JSON.stringify({ accountID: accountId }),
        }
      }
    );

    const pixelCreateJson = await pixelCreateMuation.json();
    const { webPixelCreate } = pixelCreateJson.data;
    const { userErrors } = webPixelCreate;
    if (userErrors && userErrors.length > 0) {
      return json({ errors: userErrors }, { status: 400 });
    }

    const { id: newPixelId } = webPixelCreate.webPixel;
    const configUpdateMutation = await admin.graphql(
      `mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
        metafieldsSet(metafields: $metafields) {
          metafields {
            id
          }
          userErrors {
            field
            message
          }
        }
      }`,
      {
        variables: {
          metafields: [
            {
              "key": APP_CONFIG.key,
              "namespace": APP_CONFIG.namespace,
              "ownerId": appId,
              "type": "json",
              "value": JSON.stringify({ pixelId: newPixelId }),
            }
          ]
        }
      }
    );

    const configUpdateJson = await configUpdateMutation.json();
    const { userErrors: metafieldErrors } = configUpdateJson.data;
    if (metafieldErrors && metafieldErrors.length > 0) {
      return json({ errors: metafieldErrors }, { status: 400 });
    }

    return json({ status: 'success' });
  }

  // Update Pixel
  const pixelUpdateMutation = await admin.graphql(
    `mutation($id: ID!, $settings: JSON!) {
      webPixelUpdate(id: $id, webPixel: { settings: $settings }) {
        userErrors {
          code
          field
          message
        }
        webPixel {
          id
        }
      }
    }`,
    {
      variables: {
        id: pixelId,
        settings: JSON.stringify({ accountID: accountId }),
      }
    }
  );

  const pixelUpdateJson = await pixelUpdateMutation.json();
  const { userErrors } = pixelUpdateJson.data;
  if (userErrors && userErrors.length > 0) {
    return json({ errors: userErrors }, { status: 400 });
  }

  return json({ status: 'success' });
};
