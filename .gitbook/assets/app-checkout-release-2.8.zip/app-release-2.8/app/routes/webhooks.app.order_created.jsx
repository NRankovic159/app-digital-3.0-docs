import { authenticate } from "../shopify.server";

const MUTATION_UPDATE_CUSTOMER_METAFIELDS = `#graphql
  mutation updateCustomerMetafields($input: CustomerInput!) {
    customerUpdate(input: $input) {
      customer {
        id
      }
      userErrors {
        message
        field
      }
    }
}
`

export const action = async ({ request }) => {
  const { topic, admin, payload } = await authenticate.webhook(request);

  if (!admin || topic !== 'ORDERS_CREATE') {
    // The admin context isn't returned if the webhook fired after a shop was uninstalled.
    throw new Response('', { status: 200 });
  }
  const {
    note_attributes: orderAttributes,
    customer,
  } = payload;

  const isBusinessCustomerAttr = orderAttributes.find((attr) => attr.name === '__isBusinessCustomer');
  if (!isBusinessCustomerAttr || isBusinessCustomerAttr.value !== 'true') {
    throw new Response('', { status: 200 })
  }

  const companyNameAttr = orderAttributes.find((attr) => attr.name === '__companyName');
  const vatIdAttr = orderAttributes.find((attr) => attr.name === '__vatId');
  if ((!companyNameAttr || !companyNameAttr.value) ||(!vatIdAttr || !vatIdAttr.value)) {
    throw new Response('', { status: 200 })
  }

  try {
    const response = await admin.graphql(
      MUTATION_UPDATE_CUSTOMER_METAFIELDS,
      {
        variables: {
          input: {
            id: customer.admin_graphql_api_id,
            metafields: [
              {
                namespace: 'apple',
                key: 'smb_CompanyName',
                value: companyNameAttr.value,
                type: 'single_line_text_field'
              },
              {
                namespace: 'apple',
                key: 'smb_VatId',
                value: vatIdAttr.value,
                type: 'single_line_text_field'
              }
            ]
          }
        }
      }
    );
    const responseJSON = await response.json();
    if (responseJSON?.data?.userErrors) {
      console.error('Error updating customer metafields', responseJSON.data?.userErrors)
    }

    throw new Response('', { status: 200 });
  } catch (error) {
    console.error(error);
    throw new Response('', { status: 200 });
  }
};

