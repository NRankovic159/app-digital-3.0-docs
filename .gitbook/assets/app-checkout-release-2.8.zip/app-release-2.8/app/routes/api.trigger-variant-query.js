import { json } from '@remix-run/node';
import { authenticate } from '../shopify.server';
import db from "~/db.server";

import { queryJob } from '../jobs/variant-bulk-query';

export const action = async ({ request }) => {
  const { session } = await authenticate.admin(request);

  const { shop } = session;
  const opTrigger = Date.now().toString();

  try {
    await db.bulkOperationTriggers.upsert({
      where: {
        id: shop,
      },
      create: {
        id: shop,
        opTrigger: opTrigger,
      },
      update: {
        opTrigger: opTrigger,
      },
    });

    const jobInit = await queryJob.trigger({
      session,
      opTrigger,
    });

    console.log(jobInit);
  } catch (error) {
    console.error(error);
    return json({ status: 'error' });
  }

  return json({ status: 'ok' });
};
