import { useState, useCallback, useEffect, useRef, lazy, Suspense } from "react";
import { json } from "@remix-run/node";
import { useLoaderData, useSubmit, useActionData } from "@remix-run/react";
import {
  Banner,
  BlockStack,
  Button,
  Card,
  Collapsible,
  InlineStack,
  Page,
  Layout,
  Text,
} from "@shopify/polaris";
import JSONInput from 'react-json-editor-ajrm';
import locale from 'react-json-editor-ajrm/locale/en';
import jsonStyles from 'jsoneditor/dist/jsoneditor.css?url';

import { authenticate } from "../shopify.server";
import { APP_TRANSLATIONS_NAMESPACE } from "../data/metafields";
import { DEFAULT_TRANSLATION_KEYS } from "../data/default-translation-values";

const JSONEditor = lazy(() => import('../components/json-editor'));

export const links = () => [{ rel: 'stylesheet', href: jsonStyles }];

const styles = `
.ace_editor {
  min-height: 550px !important;
}
`

export const loader = async ({ request }) => {
  const { admin } = await authenticate.admin(request);

  const translationsQuery = await admin.graphql(
    `
      query currentAppInstallation {
        shop {
          id
        }
        currentAppInstallation {
          id
          metafields(first: 10, namespace: "${APP_TRANSLATIONS_NAMESPACE}") {
            nodes {
              key
              value
            }
          }
        }
      }
    `
  );

  const translationsJson = await translationsQuery.json();

  const translations = translationsJson.data.currentAppInstallation.metafields.nodes
    .map((node) => {
      return {
        ...JSON.parse(node.value || '{}'),
      };
    });
  const appId = translationsJson.data.currentAppInstallation.id;

  return json({
    translations,
    appId,
    shopId: translationsJson.data.shop.id,
  });
};

export default function ExtensionTranslations() {
  const { translations, appId, shopId } = useLoaderData();
  const groups = DEFAULT_TRANSLATION_KEYS.map((defaultItem) => {
    const translation = translations.find((t) => t.key === defaultItem.key) || {};
    return {
      ...defaultItem,
      ...translation,
    };
  });

  return (
    <Page>
      <ui-title-bar title="Extension Translations" />
      <Layout>
        <Layout.Section>
          <Banner tone="info">
            <p>
              To support additional languages, copy the contents of the `en` translation and paste it into a new translation. Then, replace the values with the translated text.
            </p>

            <p>
              Example:
            </p>

            <br />
            <JSONInput
              id="example"
              locale={locale}
              placeholder={{
                fr: {
                  field: "translation"
                }
              }}
              theme="dark_vscode_tribute"
              height="115px"
              width="100%"
              confirmGood={false}
              style={{
                contentBox: {
                  fontSize: '14px',
                }
              }}
              viewOnly={true}
            />
            <br />
            <p>
              Please save each translation block separately.
            </p>
          </Banner>
        </Layout.Section>
        <Layout.Section>
          <BlockStack gap="200">
            {groups.map((group) => {
              return (
                <TranslationCard
                  key={group.key}
                  translation={group}
                  appId={appId}
                  shopId={shopId}
                />
              );
            })}
          </BlockStack>
        </Layout.Section>
      </Layout>
      <style>
        {styles}
      </style>
    </Page>
  );
}

const TranslationCard = ({ translation, appId, shopId }) => {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState(null);
  const [value, setValue] = useState(translation.value);
  const [jsonSet, onJsonSet] = useState('');
  const [submitting, setIsSubmitting] = useState(false);
  const actionData = useActionData();
  const jsonErrorRef = useRef(null);

  const submitForm = useSubmit();

  const handleToggle = useCallback(() => {
    setOpen((open) => {
      const newValue = !open;
      localStorage.setItem('sdg-translation-open-' + translation.key, newValue);
      return newValue;
    });
  }, [translation?.key]);

  const handleSubmit = (newValue) => {
    setIsSubmitting(true);
    setValue(newValue);

    submitForm({
      data: JSON.stringify({
        translation: {
          ...translation,
          value: typeof newValue === 'string' ? JSON.parse(newValue) : newValue,
        },
        appId,
        shopId,
      }),
    }, { method: 'post' });

    return { status: 'success' };
  };

  useEffect(() => {
    if (translation?.key) {
      setOpen(localStorage.getItem('sdg-translation-open-' + translation.key) === 'true');
    }

  }, [translation?.key]);

  useEffect(() => {
    if (jsonErrorRef?.current && error) {
      jsonErrorRef.current.focus();
    }
  }, [error, jsonErrorRef]);

  useEffect(() => {
    if (!actionData) return;

    if (actionData.success && actionData.key === translation.key) {
      shopify.toast.show(`${translation.name} translations saved!`);
      setIsSubmitting(false);
    }
  }, [actionData, translation]);

  return (
    <Card>
      <BlockStack gap="200">
        <InlineStack align="space-between" blockAlign="center">
          <Text>
            {translation.name}
          </Text>

          <Button
            accessibilityLabel="Toggle visibility"
            onClick={handleToggle}
            plain
          >
            {open ? "Hide" : "Show"}
          </Button>
        </InlineStack>

        <Collapsible
          open={open && jsonSet}
          id="basic-collapsible"
          transition={{duration: '500ms', timingFunction: 'ease-in-out'}}
          expandOnPrint
        >
          <BlockStack gap="200">
            {error && (
              <Banner ref={jsonErrorRef} tone="critical" title="Format Error">
                <p>
                  {error}
                </p>
              </Banner>
            )}

            <Suspense>
              <JSONEditor
                json={value}
                submitting={submitting}
                handleSubmit={handleSubmit}
                setError={setError}
                onSet={onJsonSet}
              />
            </Suspense>
          </BlockStack>
        </Collapsible>
      </BlockStack>
    </Card>
  )
};

export const action = async ({ request }) => {
  const { method } = request;

  if (method !== 'POST') {
    return json({ errors: [{ message: 'Invalid method' }] });
  }

  const { admin } = await authenticate.admin(request);
  const formData = await request.formData();
  const fieldData = JSON.parse(formData.get('data'));

  const { translation, appId, shopId } = fieldData;
  const { key } = translation;

  const metafieldSetMutation = await admin.graphql(
    `mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) {
        metafields {
          id
        }
        userErrors {
          field
          message
        }
      }
    }`,
    {
      variables: {
        metafields: [
          {
            "key": key,
            "namespace": APP_TRANSLATIONS_NAMESPACE,
            "ownerId": appId,
            "type": "json",
            "value": JSON.stringify(translation),
          },
          {
            "key": key,
            "namespace": APP_TRANSLATIONS_NAMESPACE,
            "ownerId": shopId,
            "type": "json",
            "value": JSON.stringify(translation),
          }
        ]
      }
    }
  );

  const metafieldSetJson = await metafieldSetMutation.json();
  const { userErrors } = metafieldSetJson.data.metafieldsSet;
  if (userErrors && userErrors.length > 0) {
    return json({ errors: userErrors, key }, { status: 400 });
  }

  return json({ success: true, key });
};
