import { json } from "@remix-run/node";
import { authenticate } from "../shopify.server";

export const loader = async ({ request, params }) => {
  const { admin } = await authenticate.admin(request);
  const { id } = params;

  const checkoutProfileResp = await admin.graphql(
    `
      query($id: ID!) {
        checkoutBranding(checkoutProfileId: $id) {
          customizations {
            global {
              typography {
                kerning
                letterCase
              }
            }
          }
        }
      }
    `,
    {
      variables: { id: `gid://shopify/CheckoutProfile/${id}` },
    }
  );

  const checkoutProfileRespJson = await checkoutProfileResp.json();
  const profile = checkoutProfileRespJson.data.checkoutBranding;

  return json(profile);
};
