import { FormLayout, InlineGrid, Select } from '@shopify/polaris';
import { FONT_CHOICES, FONT_WEIGHT_OPTIONS, LETTER_CASE, TEXT_KERNING, TEXT_SIZES } from '../data/checkout-options';

export function HeadingField({ title, fields }) {
  return (
    <FormLayout.Group title={title}>
      <InlineGrid columns="2" gap="200">
        <Select
          label="Font"
          options={FONT_CHOICES}
          {...fields.font}
        />
        <Select
          label="Weight"
          options={FONT_WEIGHT_OPTIONS}
          {...fields.weight}
        />
        <Select
          label="Size"
          options={TEXT_SIZES}
          {...fields.size}
        />
        <Select
          label="Kerning"
          options={TEXT_KERNING}
          {...fields.kerning}
        />
        <Select
          label="Letter Casing"
          options={LETTER_CASE}
          {...fields.letterCase}
        />
      </InlineGrid>
    </FormLayout.Group>
  );
}
