import { useEffect, useRef } from 'react';
import { Button, InlineStack } from '@shopify/polaris';

import JSONEditor from 'jsoneditor';

export default function JSONEditorComponent({
  mode = 'code',
  json = {},
  handleSubmit,
  submitting,
  setError,
  onSet,
}) {
  const container = useRef(null);
  const editorRef = useRef(null);

  useEffect(() => {
    if (!container.current) return;

    const options = {
      mode,
    };

    editorRef.current = new JSONEditor(container.current, options);
    editorRef.current.set(json);
    if (typeof onSet === 'function') onSet(Date.now());

    return () => {
      editorRef.current.destroy();
    };
  }, [container, json, mode, onSet]);

  const onSubmit = () => {
    try {
      const json = editorRef.current.get();
      handleSubmit(json);
    } catch (e) {
      setError('Invalid JSON, please refer to the JSON Editor for more details.');
    }
  }

  return (
    <>
      <div
        className="jsoneditor-react-container"
        style={{
          width: '100%',
          height: '100%',
          minHeight: '550px',
        }}
        ref={container}
      />
      <InlineStack align="end">
        <Button
          primary
          onClick={onSubmit}
          loading={submitting}
        >
          Save
        </Button>
      </InlineStack>
    </>
  )
}
