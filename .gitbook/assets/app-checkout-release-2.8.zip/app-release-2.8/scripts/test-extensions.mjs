#!/usr/bin/env node
// Run every extension test suite in sequence and print one summary table.
//
// Each extension pins its own vitest (0.29 through 3.2) and some need
// SHOPIFY_CLI_NO_ANALYTICS=1, so they cannot share a single vitest run --
// this shells out per workspace instead.
import { spawnSync } from 'node:child_process';
import { readdirSync, existsSync, readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const extensionsDir = join(root, 'extensions');

const only = process.argv.slice(2);

const targets = readdirSync(extensionsDir, { withFileTypes: true })
  .filter((entry) => entry.isDirectory())
  .map((entry) => entry.name)
  .filter((name) => (only.length ? only.includes(name) : true))
  .filter((name) => {
    const pkgPath = join(extensionsDir, name, 'package.json');
    if (!existsSync(pkgPath)) return false;
    const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
    return Boolean(pkg.scripts?.test || pkg.scripts?.['test:unit']);
  })
  .sort();

const results = [];

for (const name of targets) {
  const cwd = join(extensionsDir, name);
  const pkg = JSON.parse(readFileSync(join(cwd, 'package.json'), 'utf8'));
  // Prefer test:unit where it exists: those extensions keep a separate
  // integration suite that needs a live CLI.
  const script = pkg.scripts['test:unit'] ? 'test:unit' : 'test';
  const args = script === 'test' ? ['run', script, '--', '--run'] : ['run', script];

  process.stdout.write(`\n─── ${name} (npm run ${script}) ───\n`);
  const proc = spawnSync('npm', args, {
    cwd,
    stdio: 'inherit',
    env: { ...process.env, SHOPIFY_CLI_NO_ANALYTICS: '1' },
  });
  results.push({ name, script, ok: proc.status === 0 });
}

process.stdout.write('\n════ extension test summary ════\n');
for (const { name, script, ok } of results) {
  process.stdout.write(`${ok ? '✓' : '✗'}  ${name.padEnd(44)} ${script}\n`);
}

const failed = results.filter((r) => !r.ok);
process.stdout.write(
  `\n${results.length - failed.length}/${results.length} suites passed\n`,
);
process.exit(failed.length > 0 ? 1 : 0);
