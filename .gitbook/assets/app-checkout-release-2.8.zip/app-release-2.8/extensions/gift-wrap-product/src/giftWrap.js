/**
 * Gift-wrap variant lookup and cart payload.
 *
 * Split out from the component so the Storefront query, the line matching and
 * the `addCartLine` payload can be tested without a `shopify` global. The payload
 * matters most: it carries the `_giftWrap` attribute that `line-item-details`
 * keys its Remove link off, so a change here silently breaks that extension too.
 */

/** Line attribute marking the added line as gift wrap. */
export const GIFT_WRAP_LINE_ATTRIBUTE = '_giftWrap';

/**
 * Storefront query for the configured gift-wrap variant. Kept byte-identical to
 * the pre-migration query — the shape of `data.node` is what the UI reads.
 */
export const VARIANT_QUERY = `query productVariant($id: ID!) {
        node(id: $id) {
          ... on ProductVariant {
            id
            title
            image {
              originalSrc
              height
              width
              altText
            }
            price {
              amount
              currencyCode
            }
            product {
              title
            }
          }
        }
      }`;

/**
 * The cart line already holding the gift-wrap variant, if any.
 *
 * Matched on `merchandise.id` (the variant GID), which is what the merchant
 * setting stores.
 * @param {Array} lines value of `shopify.lines`
 * @param {String} giftWrapVariantId
 * @returns {Object|undefined}
 */
export const findGiftWrapLine = (lines, giftWrapVariantId) =>
  (lines || []).find((line) => line?.merchandise?.id === giftWrapVariantId);

/**
 * The `applyCartLinesChange` payload that adds one gift wrap.
 * @param {String} merchandiseId variant GID
 * @returns {Object}
 */
export const addGiftWrapChange = (merchandiseId) => ({
  type: 'addCartLine',
  merchandiseId,
  quantity: 1,
  attributes: [
    {
      key: GIFT_WRAP_LINE_ATTRIBUTE,
      value: 'true',
    },
  ],
});

/**
 * Whether the variant price should read as free rather than a formatted amount.
 *
 * ⚠️ Exact string comparison against `'0.0'`, preserved from the pre-migration
 * code. A zero price serialised as `'0.00'` or `'0'` would format as a currency
 * amount instead.
 * @param {String} amount `price.amount` as returned by the Storefront API
 * @returns {Boolean}
 */
export const isFreeAmount = (amount) => amount === '0.0';

/**
 * Whether the query returned a usable variant.
 *
 * An unset or deleted variant reference yields a node with no `title`, in which
 * case the block hides itself rather than rendering an empty row.
 * @param {Object|null} variant
 * @returns {Boolean}
 */
export const isRenderableVariant = (variant) => Boolean(variant?.title);
