import {describe, expect, it} from 'vitest';

import {
  GIFT_WRAP_LINE_ATTRIBUTE,
  VARIANT_QUERY,
  addGiftWrapChange,
  findGiftWrapLine,
  isFreeAmount,
  isRenderableVariant,
} from './giftWrap.js';

const GIFT_WRAP_VARIANT = 'gid://shopify/ProductVariant/99';

const line = (merchandiseId) => ({
  id: `gid://shopify/CartLine/${merchandiseId}`,
  quantity: 1,
  attributes: [],
  merchandise: {id: merchandiseId},
});

describe('findGiftWrapLine', () => {
  it('finds the line holding the configured variant', () => {
    const lines = [line('gid://shopify/ProductVariant/1'), line(GIFT_WRAP_VARIANT)];

    expect(findGiftWrapLine(lines, GIFT_WRAP_VARIANT)?.merchandise.id).toBe(
      GIFT_WRAP_VARIANT,
    );
  });

  it('is undefined when the variant is not in the cart', () => {
    expect(
      findGiftWrapLine([line('gid://shopify/ProductVariant/1')], GIFT_WRAP_VARIANT),
    ).toBeUndefined();
  });

  it('matches on the variant id, not the product id', () => {
    // The merchant setting stores a variant GID and `merchandise.id` is the
    // variant, so a product GID must not match.
    expect(
      findGiftWrapLine([line(GIFT_WRAP_VARIANT)], 'gid://shopify/Product/99'),
    ).toBeUndefined();
  });

  it('handles an empty or missing cart', () => {
    expect(findGiftWrapLine([], GIFT_WRAP_VARIANT)).toBeUndefined();
    expect(findGiftWrapLine(undefined, GIFT_WRAP_VARIANT)).toBeUndefined();
  });
});

describe('addGiftWrapChange', () => {
  it('builds an addCartLine payload for one unit', () => {
    expect(addGiftWrapChange(GIFT_WRAP_VARIANT)).toEqual({
      type: 'addCartLine',
      merchandiseId: GIFT_WRAP_VARIANT,
      quantity: 1,
      attributes: [{key: '_giftWrap', value: 'true'}],
    });
  });

  it('tags the line with the attribute line-item-details keys off', () => {
    // `line-item-details` shows its Remove link when a line carries
    // `_giftWrap = "true"`. Changing either the key or the value silently breaks
    // that extension.
    const [attribute] = addGiftWrapChange(GIFT_WRAP_VARIANT).attributes;

    expect(attribute.key).toBe(GIFT_WRAP_LINE_ATTRIBUTE);
    expect(GIFT_WRAP_LINE_ATTRIBUTE).toBe('_giftWrap');
    expect(attribute.value).toBe('true');
  });
});

describe('isFreeAmount', () => {
  it('treats the exact string "0.0" as free', () => {
    expect(isFreeAmount('0.0')).toBe(true);
  });

  it('does not treat other zero spellings as free', () => {
    expect(isFreeAmount('0.00')).toBe(false);
    expect(isFreeAmount('0')).toBe(false);
    expect(isFreeAmount(0)).toBe(false);
  });

  it('is false for a real price', () => {
    expect(isFreeAmount('5.0')).toBe(false);
  });
});

describe('isRenderableVariant', () => {
  it('requires a title', () => {
    expect(isRenderableVariant({title: 'Gift wrap'})).toBe(true);
    expect(isRenderableVariant({})).toBe(false);
    expect(isRenderableVariant(null)).toBe(false);
    expect(isRenderableVariant(undefined)).toBe(false);
  });
});

describe('VARIANT_QUERY', () => {
  it('asks for every field the UI renders', () => {
    for (const field of [
      'title',
      'originalSrc',
      'altText',
      'amount',
      'currencyCode',
      'product',
    ]) {
      expect(VARIANT_QUERY).toContain(field);
    }
  });

  it('is parameterised by variant id', () => {
    expect(VARIANT_QUERY).toContain('$id: ID!');
    expect(VARIANT_QUERY).toContain('node(id: $id)');
    expect(VARIANT_QUERY).toContain('... on ProductVariant');
  });
});
