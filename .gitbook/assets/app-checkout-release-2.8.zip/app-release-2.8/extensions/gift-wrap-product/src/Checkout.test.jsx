import {act, cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {Extension} from './Checkout.jsx';

const GIFT_WRAP_VARIANT = 'gid://shopify/ProductVariant/99';

const translationEntry = (byLanguage, key = 'gift_wrap_product') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {heading: 'Add gift wrapping?', add_cta: 'Add wrap', free: 'Free'},
  fr: {heading: 'Ajouter un emballage?', add_cta: 'Ajouter', free: 'Gratuit'},
};

const VARIANT = {
  id: GIFT_WRAP_VARIANT,
  title: 'Default',
  image: {originalSrc: 'https://cdn.example/wrap.png', altText: 'Gift wrap'},
  price: {amount: '5.0', currencyCode: 'USD'},
  product: {title: 'Gift Wrap'},
};

const line = (merchandiseId) => ({
  id: `gid://shopify/CartLine/${merchandiseId}`,
  quantity: 1,
  attributes: [],
  merchandise: {id: merchandiseId},
});

let query;
let applyCartLinesChange;
let formatCurrency;

const stubShopify = ({
  settings = {giftWrapVariantId: GIFT_WRAP_VARIANT},
  lines = [],
  appMetafields = [translationEntry(TRANSLATIONS)],
  isoCode = 'en',
  node = VARIANT,
} = {}) => {
  query = vi.fn().mockResolvedValue({data: {node}});
  applyCartLinesChange = vi.fn().mockResolvedValue({type: 'success'});
  formatCurrency = vi.fn((amount) => `$${amount}`);
  globalThis.shopify = {
    settings: {value: settings},
    lines: {value: lines},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    query,
    applyCartLinesChange,
    i18n: {formatCurrency},
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

// The query resolves on a microtask, so the loaded state needs a flush.
const settle = async () => {
  await act(async () => {
    await Promise.resolve();
    await Promise.resolve();
  });
};

const button = (container) => container.querySelector('s-button');

describe('gating', () => {
  it('renders nothing when no variant is configured', () => {
    stubShopify({settings: {}});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
    expect(query).not.toHaveBeenCalled();
  });

  it('renders nothing when the gift wrap is already in the cart', async () => {
    stubShopify({lines: [line(GIFT_WRAP_VARIANT)]});

    const {container} = render(<Extension />);
    await settle();

    expect(container.innerHTML).toBe('');
  });

  it('still renders when a different product is in the cart', async () => {
    stubShopify({lines: [line('gid://shopify/ProductVariant/1')]});

    const {container} = render(<Extension />);
    await settle();

    expect(container.textContent).toContain('Gift Wrap');
  });

  it('renders nothing once the query returns a variant with no title', async () => {
    stubShopify({node: {}});

    const {container} = render(<Extension />);
    await settle();

    expect(container.innerHTML).toBe('');
  });

  it('renders nothing when the query returns no node at all', async () => {
    stubShopify({node: null});

    const {container} = render(<Extension />);
    await settle();

    expect(container.innerHTML).toBe('');
  });
});

describe('loading state', () => {
  it('shows a skeleton row with a loading button before the query resolves', () => {
    const {container} = render(<Extension />);

    expect(container.querySelectorAll('s-skeleton-paragraph')).toHaveLength(2);
    expect(container.querySelector('s-box')).not.toBeNull();
    expect(button(container).hasAttribute('loading')).toBe(true);
    expect(container.querySelector('s-product-thumbnail')).toBeNull();
  });

  it('replaces the skeleton with the product once loaded', async () => {
    const {container} = render(<Extension />);
    await settle();

    expect(container.querySelectorAll('s-skeleton-paragraph')).toHaveLength(0);
    expect(container.querySelector('s-product-thumbnail')).not.toBeNull();
  });

  it('queries the configured variant by id', () => {
    render(<Extension />);

    expect(query).toHaveBeenCalledWith(expect.stringContaining('ProductVariant'), {
      variables: {id: GIFT_WRAP_VARIANT},
    });
  });
});

describe('the product row', () => {
  it('shows the product title and thumbnail', async () => {
    const {container} = render(<Extension />);
    await settle();

    const thumb = container.querySelector('s-product-thumbnail');
    expect(container.textContent).toContain('Gift Wrap');
    expect(thumb.getAttribute('src')).toBe('https://cdn.example/wrap.png');
    expect(thumb.getAttribute('alt')).toBe('Gift wrap');
  });

  it('formats a non-zero price through i18n', async () => {
    const {container} = render(<Extension />);
    await settle();

    expect(formatCurrency).toHaveBeenCalledWith(5);
    expect(container.textContent).toContain('$5');
  });

  it('passes a number to formatCurrency, not the raw string', async () => {
    render(<Extension />);
    await settle();

    expect(formatCurrency).toHaveBeenCalledWith(5);
    expect(formatCurrency).not.toHaveBeenCalledWith('5.0');
  });

  it('shows the free label for a zero price', async () => {
    stubShopify({node: {...VARIANT, price: {amount: '0.0', currencyCode: 'USD'}}});

    const {container} = render(<Extension />);
    await settle();

    expect(container.textContent).toContain('Free');
    expect(formatCurrency).not.toHaveBeenCalled();
  });

  it('renders the translated heading and CTA', async () => {
    const {container} = render(<Extension />);
    await settle();

    expect(container.textContent).toContain('Add gift wrapping?');
    expect(button(container).textContent).toContain('Add wrap');
  });

  it('uses the buyer language for a regional locale', async () => {
    stubShopify({isoCode: 'fr-CA'});

    const {container} = render(<Extension />);
    await settle();

    expect(container.textContent).toContain('Ajouter un emballage?');
  });

  it('falls back to hardcoded English when untranslated', async () => {
    stubShopify({isoCode: 'de'});

    const {container} = render(<Extension />);
    await settle();

    expect(container.textContent).toContain('Add Gift Wrap?');
    expect(button(container).textContent).toContain('Add');
  });

  it('ignores a translations entry belonging to another extension', async () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {heading: 'Wrong block'}}, 'order_note'),
        translationEntry(TRANSLATIONS),
      ],
    });

    const {container} = render(<Extension />);
    await settle();

    expect(container.textContent).toContain('Add gift wrapping?');
    expect(container.textContent).not.toContain('Wrong block');
  });
});

describe('adding to the cart', () => {
  it('adds one gift wrap line tagged _giftWrap', async () => {
    const {container} = render(<Extension />);
    await settle();

    button(container).dispatchEvent(new Event('click'));

    expect(applyCartLinesChange).toHaveBeenCalledWith({
      type: 'addCartLine',
      merchandiseId: GIFT_WRAP_VARIANT,
      quantity: 1,
      attributes: [{key: '_giftWrap', value: 'true'}],
    });
  });

  it('adds the variant returned by the query, not the raw setting', async () => {
    // They are normally the same, but the payload must use the resolved variant.
    stubShopify({node: {...VARIANT, id: 'gid://shopify/ProductVariant/123'}});
    const {container} = render(<Extension />);
    await settle();

    button(container).dispatchEvent(new Event('click'));

    expect(applyCartLinesChange).toHaveBeenCalledWith(
      expect.objectContaining({merchandiseId: 'gid://shopify/ProductVariant/123'}),
    );
  });

  it('does not add anything on render', async () => {
    render(<Extension />);
    await settle();

    expect(applyCartLinesChange).not.toHaveBeenCalled();
  });

  it('shows the button as loading while the add is in flight', async () => {
    let resolveAdd;
    const {container} = render(<Extension />);
    await settle();
    applyCartLinesChange.mockImplementation(
      () => new Promise((resolve) => (resolveAdd = resolve)),
    );

    await act(async () => {
      button(container).dispatchEvent(new Event('click'));
    });
    expect(button(container).hasAttribute('loading')).toBe(true);

    await act(async () => {
      resolveAdd({type: 'success'});
    });
    expect(button(container).hasAttribute('loading')).toBe(false);
  });
});
