import '@shopify/ui-extensions/preact';
import {useSignal} from '@preact/signals';
import {render} from "preact";
import {useEffect} from 'preact/hooks';

import {
  VARIANT_QUERY,
  addGiftWrapChange,
  findGiftWrapLine,
  isFreeAmount,
  isRenderableVariant,
} from './giftWrap.js';
import {readTranslations} from './translations.js';

export default async () => {
  render(<Extension />, document.body)
};

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const {giftWrapVariantId} = shopify.settings.value;
  // Settings values arrive as `string | number | boolean`. This one is a
  // `variant_reference`, so it is always a GID string when set; anything else is
  // treated as unset.
  const variantId =
    typeof giftWrapVariantId === 'string' ? giftWrapVariantId : '';
  const language = shopify.localization.language.value;
  const cartLines = shopify.lines.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'gift_wrap_product',
    language,
  });
  const {heading = 'Add Gift Wrap?', add_cta = 'Add'} = localTranslations;

  const giftWrapLine = findGiftWrapLine(cartLines, variantId);
  const variantData = useSignal(null);
  const loading = useSignal(true);

  // Deliberately `useEffect` with an explicit dependency rather than
  // `useSignalEffect`: this callback *writes* the `loading` and `variantData`
  // signals, so a signal-tracked effect would re-subscribe to its own writes and
  // loop forever. The old dependency list also named `query`, which is now the
  // stable `shopify.query` global and needs no tracking.
  useEffect(() => {
    if (!variantId) return;
    loading.value = true;
    variantData.value = null;

    shopify
      .query(VARIANT_QUERY, {variables: {id: variantId}})
      .then((resp) => {
        const {node} =
          /** @type {{data?: {node?: Object}}} */ (resp)?.data || {};
        variantData.value = node ?? {};
        loading.value = false;
      });
  }, [variantId]);

  if (!variantId) return null;
  if (giftWrapLine) return null;
  if (!loading.value && !isRenderableVariant(variantData.value)) return null;

  return (
    <s-stack direction="block" gap="base">
      {heading && <s-heading>{heading}</s-heading>}
      {loading.value ? (
        <s-grid gridTemplateColumns="auto 1fr" alignItems="center">
          <s-stack direction="inline" alignItems="center" gap="base">
            <s-box inlineSize="64px" blockSize="64px" background="subdued" />
            <s-stack direction="block" gap="small-400">
              <s-skeleton-paragraph />
              <s-skeleton-paragraph />
            </s-stack>
          </s-stack>

          <s-stack direction="inline" justifyContent="end">
            <s-button variant="secondary" loading>
              {add_cta}
            </s-button>
          </s-stack>
        </s-grid>
      ) : (
        <ProductBlock
          variant={variantData.value}
          localTranslations={localTranslations}
        />
      )}
    </s-stack>
  );
}

// Exported for unit tests.
export const ProductBlock = ({variant, localTranslations}) => {
  const adding = useSignal(false);
  const {add_cta = 'Add', free = 'Free'} = localTranslations;

  const amount = variant?.price?.amount;
  const priceLabel = isFreeAmount(amount)
    ? free
    : shopify.i18n.formatCurrency(Number(amount));

  return (
    <s-grid gridTemplateColumns="3fr 1fr" alignItems="center">
      <s-grid
        gridTemplateColumns="auto 1fr"
        alignItems="center"
        gap="small-200"
      >
        <s-product-thumbnail
          src={variant?.image?.originalSrc}
          alt={variant?.image?.altText}
        />

        <s-stack direction="block" gap="small-400">
          <s-text>{variant?.product?.title}</s-text>
          <s-text>{priceLabel}</s-text>
        </s-stack>
      </s-grid>

      <s-stack direction="inline" justifyContent="end">
        <s-button
          variant="secondary"
          loading={adding.value}
          onClick={() => {
            adding.value = true;
            shopify
              .applyCartLinesChange(addGiftWrapChange(variant.id))
              .then(() => {
                adding.value = false;
              });
          }}
        >
          {add_cta}
        </s-button>
      </s-stack>
    </s-grid>
  );
};
