import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {removeGiftWrapLine} from './CheckoutLine.jsx';

const applyCartLinesChange = vi.fn();

beforeEach(() => {
  applyCartLinesChange.mockReset();
  globalThis.shopify = {applyCartLinesChange};
});

afterEach(() => {
  delete globalThis.shopify;
});

describe('removeGiftWrapLine', () => {
  it('builds a removeCartLine change for the whole line', () => {
    removeGiftWrapLine({id: 'gid://shopify/CartLine/42', quantity: 3});

    expect(applyCartLinesChange).toHaveBeenCalledTimes(1);
    expect(applyCartLinesChange).toHaveBeenCalledWith({
      type: 'removeCartLine',
      id: 'gid://shopify/CartLine/42',
      quantity: 3,
    });
  });
});
