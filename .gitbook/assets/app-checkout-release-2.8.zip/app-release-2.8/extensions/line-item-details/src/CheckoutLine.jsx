import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {Extension} from './Extension.jsx';

/**
 * Removes a gift-wrap line from the cart. Lives here rather than in the shared
 * component because `applyCartLinesChange` only exists on the checkout target.
 * Exported for unit tests.
 * @param {{id: String, quantity: Number}} line
 */
export const removeGiftWrapLine = ({id, quantity}) =>
  shopify.applyCartLinesChange({
    type: 'removeCartLine',
    id: id,
    quantity: quantity,
  });

export default async () => {
  render(<Extension onRemoveGiftWrap={removeGiftWrapLine} />, document.body)
};
