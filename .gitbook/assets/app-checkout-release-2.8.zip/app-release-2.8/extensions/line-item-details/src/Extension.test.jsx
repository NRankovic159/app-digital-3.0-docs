import {cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {Extension} from './Extension.jsx';

const translationEntry = (byLanguage) => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key: 'line_item',
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const onRemoveGiftWrap = vi.fn();

/**
 * Minimal stand-in for the `shopify` global on a cart-line-item target.
 */
const stubShopify = ({
  lineAttributes = [],
  appMetafields = [],
  isoCode = 'en',
  id = 'gid://shopify/CartLine/1',
  quantity = 1,
} = {}) => {
  globalThis.shopify = {
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    target: {value: {attributes: lineAttributes, id, quantity}},
  };
};

beforeEach(() => {
  onRemoveGiftWrap.mockReset();
  stubShopify();
});

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

describe('pre-order label', () => {
  it('renders nothing when the line is not a pre-order', () => {
    stubShopify({lineAttributes: [{key: '_preOrder', value: 'false'}]});

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('');
  });

  it('prefers the line-level pre-order message', () => {
    stubShopify({
      lineAttributes: [
        {key: '_preOrder', value: 'true'},
        {key: '_preOrderMessage', value: 'Ships 12 March'},
      ],
      appMetafields: [translationEntry({en: {preorder: 'Pre-ordered'}})],
    });

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Ships 12 March');
  });

  it('falls back to the translated label when the line has no message', () => {
    stubShopify({
      lineAttributes: [{key: '_preOrder', value: 'true'}],
      appMetafields: [translationEntry({en: {preorder: 'Pre-ordered'}})],
    });

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Pre-ordered');
  });

  it('falls back to the hardcoded label when there is no translation', () => {
    stubShopify({lineAttributes: [{key: '_preOrder', value: 'true'}]});

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Pre-order');
  });

  it('renders the buyer language label', () => {
    stubShopify({
      isoCode: 'fr-CA',
      lineAttributes: [{key: '_preOrder', value: 'true'}],
      appMetafields: [
        translationEntry({en: {preorder: 'Pre-ordered'}, fr: {preorder: 'Précommandé'}}),
      ],
    });

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Précommandé');
  });

  it('strips html out of the message', () => {
    stubShopify({
      lineAttributes: [
        {key: '_preOrder', value: 'true'},
        {key: '_preOrderMessage', value: '<p>Ships <strong>12 March</strong></p>'},
      ],
    });

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Ships 12 March');
  });

  it('treats any value other than the string "true" as not a pre-order', () => {
    stubShopify({lineAttributes: [{key: '_preOrder', value: '1'}]});

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('');
  });
});

describe('gift wrap remove control', () => {
  const giftWrapLine = {
    lineAttributes: [{key: '_giftWrap', value: 'true'}],
    id: 'gid://shopify/CartLine/99',
    quantity: 2,
  };

  it('renders on the checkout target', () => {
    stubShopify(giftWrapLine);

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Remove');
  });

  it('does not render off the checkout target', () => {
    // Thank you and Order status can't mutate the cart, so they pass no
    // handler and the control must never appear there.
    stubShopify(giftWrapLine);

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('uses the translated label', () => {
    stubShopify({
      ...giftWrapLine,
      appMetafields: [translationEntry({en: {remove: 'Remove gift wrap'}})],
    });

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Remove gift wrap');
  });

  it('passes its own line id and full quantity to the remove handler', () => {
    stubShopify(giftWrapLine);

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);
    container.querySelector('s-link').click();

    expect(onRemoveGiftWrap).toHaveBeenCalledTimes(1);
    expect(onRemoveGiftWrap).toHaveBeenCalledWith({
      id: 'gid://shopify/CartLine/99',
      quantity: 2,
    });
  });

  it('does not render when the line is not gift wrap', () => {
    stubShopify({lineAttributes: [{key: '_giftWrap', value: 'false'}]});

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('');
  });
});

describe('metafield selection', () => {
  it('ignores a same-key metafield from another namespace', () => {
    // shopify.appMetafields is no longer filtered for us.
    stubShopify({
      lineAttributes: [{key: '_preOrder', value: 'true'}],
      appMetafields: [
        {
          target: {type: 'shop', id: 'gid://shopify/Shop/1'},
          metafield: {
            namespace: 'apple',
            key: 'line_item',
            value: JSON.stringify({value: {en: {preorder: 'Wrong app copy'}}}),
            type: 'json',
          },
        },
      ],
    });

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Pre-order');
  });

  it('ignores another key in our own namespace', () => {
    stubShopify({
      lineAttributes: [{key: '_preOrder', value: 'true'}],
      appMetafields: [
        {
          target: {type: 'shop', id: 'gid://shopify/Shop/1'},
          metafield: {
            namespace: 'sdg:translations',
            key: 'pickup_location_confirmation_message',
            value: JSON.stringify({value: {en: {preorder: 'Other block copy'}}}),
            type: 'json',
          },
        },
      ],
    });

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Pre-order');
  });
});

describe('both details together', () => {
  it('renders the pre-order label and the remove control', () => {
    stubShopify({
      lineAttributes: [
        {key: '_preOrder', value: 'true'},
        {key: '_giftWrap', value: 'true'},
      ],
      appMetafields: [
        translationEntry({en: {preorder: 'Pre-ordered', remove: 'Remove'}}),
      ],
    });

    const {container} = render(<Extension onRemoveGiftWrap={onRemoveGiftWrap} />);

    expect(container.textContent).toBe('Pre-orderedRemove');
  });
});
