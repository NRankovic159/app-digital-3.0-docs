import {findAttributeValue, readTranslations, stripHtml} from './translations.js';

/**
 * Pre-order and gift-wrap details rendered under a single cart line.
 *
 * Shared by all three targets. Only the checkout target can mutate the cart,
 * so it's the only one that passes `onRemoveGiftWrap` — on the Thank you and
 * Order status pages the remove control simply isn't rendered.
 *
 * @param {{onRemoveGiftWrap?: (line: {id: String, quantity: Number}) => void}} props
 */
export function Extension({onRemoveGiftWrap}) {
  const language = shopify.localization.language.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'line_item',
    language,
  });

  const {attributes, id, quantity} = shopify.target.value;
  const isPreOrder = findAttributeValue(attributes, '_preOrder') === 'true';
  const preOrderMessage = findAttributeValue(attributes, '_preOrderMessage');
  const isGiftWrap = findAttributeValue(attributes, '_giftWrap') === 'true';

  return (
    <s-stack
      direction="block"
      gap="small-200"
      padding="small-400 none"
      alignItems="start"
    >
      {isPreOrder && (
        // `Text` no longer takes `size`, and `type` holds one value, so small
        // and bold have to nest.
        <s-text type="small">
          <s-text type="strong">
            {stripHtml(preOrderMessage || localTranslations?.preorder || 'Pre-order')}
          </s-text>
        </s-text>
      )}

      {isGiftWrap && onRemoveGiftWrap && (
        // `Button kind="plain"` was removed; s-link is its replacement.
        <s-link onClick={() => onRemoveGiftWrap({id, quantity})}>
          {stripHtml(localTranslations?.remove || 'Remove')}
        </s-link>
      )}
    </s-stack>
  );
}
