/**
 * Helpers for reading the `sdg:translations` app metafield.
 */

/**
 * Metafield entries matching a namespace and key, in API order.
 * @param {Array} appMetafields value of `shopify.appMetafields`
 * @param {String} namespace
 * @param {String} key
 * @returns {Array}
 */
export const filterAppMetafields = (appMetafields, namespace, key) =>
  (appMetafields || []).filter(
    (entry) =>
      entry?.metafield?.namespace === namespace && entry?.metafield?.key === key,
  );

/**
 * The buyer's base language code — `en` for `en-CA`. Falls back to `en` when
 * the language isn't available.
 * @param {Object} language value of `shopify.localization.language`
 * @returns {String}
 */
export const languageCodeFrom = (language) => {
  const [languageCode] = language?.isoCode?.split('-') || ['en'];
  return languageCode;
};

/**
 * Translations for the buyer's language out of an `sdg:translations` metafield.
 * Returns `{}` when the metafield is missing, empty, or holds no entry for the
 * language.
 * @param {Array} appMetafields value of `shopify.appMetafields`
 * @param {{namespace?: String, key: String, language: Object}} options
 * @returns {Object}
 */
export const readTranslations = (
  appMetafields,
  {namespace = 'sdg:translations', key, language},
) => {
  const [translationMetafield] = filterAppMetafields(
    appMetafields,
    namespace,
    key,
  );
  const translationJson =
    JSON.parse(translationMetafield?.metafield?.value || '{}')?.value || {};
  return translationJson?.[languageCodeFrom(language)] || {};
};

/**
 * The value of an attribute, or `undefined` when it isn't set. Replaces
 * `useAttributeValues([key])` for cart attributes, and reads cart *line*
 * attributes off `shopify.target.value.attributes` just the same.
 * @param {Array} attributes
 * @param {String} key
 * @returns {String|undefined}
 */
export const findAttributeValue = (attributes, key) =>
  (attributes || []).find((attribute) => attribute?.key === key)?.value;

/**
 * Strip html elements from string
 * @param {String} htmlString
 * @returns {String}
 */
export const stripHtml = (htmlString) => {
  return htmlString.replace(/<\/?[^>]+(>|$)/g, '');
};
