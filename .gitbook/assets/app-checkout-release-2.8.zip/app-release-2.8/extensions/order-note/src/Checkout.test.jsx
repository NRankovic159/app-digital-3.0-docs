import {cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {Extension, setOrderNote} from './Checkout.jsx';

const translationEntry = (byLanguage, key = 'order_note') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {heading: 'Order instructions'},
  fr: {heading: 'Instructions de commande'},
};

let applyNoteChange;

const stubShopify = ({
  settings = {enable: true},
  appMetafields = [],
  isoCode = 'en',
  note = undefined,
} = {}) => {
  applyNoteChange = vi.fn().mockResolvedValue({type: 'success'});
  globalThis.shopify = {
    settings: {value: settings},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    note: {value: note},
    applyNoteChange,
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

const textArea = (container) => container.querySelector('s-text-area');

describe('settings gate', () => {
  it('renders nothing when the block is disabled', () => {
    stubShopify({settings: {enable: false}});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders nothing when enable is absent', () => {
    // The old code destructured `enable` with no default, so an unset setting
    // hides the block. Preserved.
    stubShopify({settings: {}});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders the field when enabled', () => {
    stubShopify({settings: {enable: true}});

    const {container} = render(<Extension />);

    expect(textArea(container)).not.toBeNull();
  });
});

describe('translations', () => {
  it('labels the field from the buyer language', () => {
    stubShopify({appMetafields: [translationEntry(TRANSLATIONS)]});

    const {container} = render(<Extension />);

    expect(textArea(container).getAttribute('label')).toBe('Order instructions');
  });

  it('uses the base language code for a regional locale', () => {
    stubShopify({
      isoCode: 'fr-CA',
      appMetafields: [translationEntry(TRANSLATIONS)],
    });

    const {container} = render(<Extension />);

    expect(textArea(container).getAttribute('label')).toBe(
      'Instructions de commande',
    );
  });

  it('renders an unlabelled field for an untranslated language', () => {
    stubShopify({isoCode: 'de', appMetafields: [translationEntry(TRANSLATIONS)]});

    const {container} = render(<Extension />);

    // No fallback to en — matches pre-migration behaviour.
    expect(textArea(container).getAttribute('label')).toBeNull();
    expect(textArea(container)).not.toBeNull();
  });

  it('renders an unlabelled field when the metafield is missing', () => {
    stubShopify({appMetafields: []});

    const {container} = render(<Extension />);

    expect(textArea(container).getAttribute('label')).toBeNull();
  });

  it('ignores a metafield with a different key', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {heading: 'Wrong block'}}, 'gift_message'),
        translationEntry(TRANSLATIONS),
      ],
    });

    const {container} = render(<Extension />);

    expect(textArea(container).getAttribute('label')).toBe('Order instructions');
  });
});

describe('note value', () => {
  it('shows the existing note', () => {
    stubShopify({note: 'Leave at the front desk'});

    const {container} = render(<Extension />);

    expect(textArea(container).getAttribute('value')).toBe(
      'Leave at the front desk',
    );
  });

  it('renders an empty field when there is no note', () => {
    stubShopify({note: undefined});

    const {container} = render(<Extension />);

    expect(textArea(container).getAttribute('value')).toBeNull();
  });

  it('renders 4 rows, as the old multiline={4} did', () => {
    const {container} = render(<Extension />);

    expect(textArea(container).getAttribute('rows')).toBe('4');
  });
});

describe('setOrderNote', () => {
  it('updates the note when given a value', () => {
    setOrderNote('Ring the bell');

    expect(applyNoteChange).toHaveBeenCalledWith({
      type: 'updateNote',
      note: 'Ring the bell',
    });
  });

  it('removes the note when the field is emptied', () => {
    setOrderNote('');

    expect(applyNoteChange).toHaveBeenCalledWith({type: 'removeNote'});
  });

  it('removes the note for undefined', () => {
    setOrderNote(undefined);

    expect(applyNoteChange).toHaveBeenCalledWith({type: 'removeNote'});
  });

  it('never sends updateNote with an empty note', () => {
    // Shopify rejects updateNote with an empty string; the remove branch exists
    // precisely to avoid it.
    setOrderNote('');

    expect(applyNoteChange).not.toHaveBeenCalledWith(
      expect.objectContaining({type: 'updateNote'}),
    );
  });
});

describe('change wiring', () => {
  it('reads the value off the event target', () => {
    const {container} = render(<Extension />);
    const field = textArea(container);

    field.value = 'Typed by the buyer';
    field.dispatchEvent(new Event('change'));

    expect(applyNoteChange).toHaveBeenCalledWith({
      type: 'updateNote',
      note: 'Typed by the buyer',
    });
  });

  it('removes the note when the buyer clears the field', () => {
    const {container} = render(<Extension />);
    const field = textArea(container);

    field.value = '';
    field.dispatchEvent(new Event('change'));

    expect(applyNoteChange).toHaveBeenCalledWith({type: 'removeNote'});
  });
});
