import {describe, expect, it} from 'vitest';

import {fieldValue} from './events.js';

describe('fieldValue', () => {
  const eventFrom = (currentTarget) => ({currentTarget});

  it('reads the value off the control that raised the event', () => {
    expect(fieldValue(eventFrom({value: 'typed'}))).toBe('typed');
  });

  it('returns an empty string when the control has no value', () => {
    // Must not return undefined: the caller branches on falsiness to decide
    // between updateNote and removeNote, and `undefined` would be indistinguishable
    // from a crash upstream.
    expect(fieldValue(eventFrom({}))).toBe('');
  });

  it('returns an empty string when there is no currentTarget', () => {
    expect(fieldValue(eventFrom(null))).toBe('');
  });

  it('preserves an empty string rather than coercing it', () => {
    expect(fieldValue(eventFrom({value: ''}))).toBe('');
  });
});
