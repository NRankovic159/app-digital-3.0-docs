/**
 * Form-event helpers.
 */

/**
 * The current value of the form control that raised an event.
 * @param {Event} event
 * @returns {String}
 */
export const fieldValue = (event) =>
  /** @type {{value?: String}} */ (event.currentTarget)?.value ?? '';
