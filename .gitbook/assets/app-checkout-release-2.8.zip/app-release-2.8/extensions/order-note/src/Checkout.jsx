import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {fieldValue} from './events.js';
import {readTranslations} from './translations.js';

export default async () => {
  render(<Extension />, document.body)
};

/**
 * Writes the buyer's note, or clears it when the field is emptied.
 *
 * Kept as a named export so the remove-on-empty branch can be tested directly —
 * it's the branch that would silently strand a stale note if it regressed.
 * @param {String} value
 * @returns {Promise}
 */
export const setOrderNote = (value) => {
  if (!value) {
    return shopify.applyNoteChange({
      type: 'removeNote',
    });
  }

  return shopify.applyNoteChange({
    type: 'updateNote',
    note: value,
  });
};

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const language = shopify.localization.language.value;
  const note = shopify.note.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'order_note',
    language,
  });
  const {enable} = shopify.settings.value;

  if (!enable) return null;

  return (
    <s-stack direction="block" gap="base">
      <s-text-area
        label={localTranslations?.heading}
        rows={4}
        value={note}
        onChange={(event) => setOrderNote(fieldValue(event))}
      />
    </s-stack>
  );
}
