import { describe, it, expect } from 'vitest';
import { cartTransformRun } from './cart_transform_run';

/**
 * @typedef {import("../generated/api").CartTransformRunResult} CartTransformRunResult
 */

/**
 * Build a cart line matching the shape of src/cart_transform_run.graphql.
 * Attribute aliases are `{value}` objects or null, exactly as the input query
 * returns them.
 */
function line(overrides = {}) {
  return {
    id: 'gid://shopify/CartLine/1',
    quantity: 1,
    cost: { amountPerQuantity: { amount: '100.00' } },
    merchandise: {
      __typename: 'ProductVariant',
      id: 'gid://shopify/ProductVariant/1',
      product: { title: 'Hero product' },
    },
    bundleId: null,
    bundleTitle: null,
    bundlePrice: null,
    bundleItem1Id: null,
    bundleItem2Id: null,
    bundleItem3Id: null,
    bundleCustomPricing1: null,
    bundleCustomPricing2: null,
    bundleCustomPricing3: null,
    bundleHeroUUID: null,
    ...overrides,
  };
}

describe('cart transform function', () => {
  it('returns no operations for a cart with no bundle lines', () => {
    const result = cartTransformRun({ cart: { lines: [line()] } });
    const expected = /** @type {CartTransformRunResult} */ ({ operations: [] });

    expect(result).toEqual(expected);
  });

  it('returns no operations for an empty cart', () => {
    const result = cartTransformRun({ cart: { lines: [] } });

    expect(result).toEqual({ operations: [] });
  });

  it('ignores non-ProductVariant merchandise', () => {
    const custom = line({
      merchandise: { __typename: 'CustomProduct' },
      bundleId: { value: 'uuid-1' },
      bundlePrice: { value: '150.00' },
    });

    expect(cartTransformRun({ cart: { lines: [custom] } })).toEqual({
      operations: [],
    });
  });

  it('expands a two-item bundle, distributing the price difference', () => {
    // Bundle totals 150.00, hero line costs 100.00, so the second item
    // absorbs the remaining 50.00.
    const bundleLine = line({
      bundleId: { value: 'uuid-1' },
      bundleTitle: { value: 'Desk bundle' },
      bundlePrice: { value: '150.00' },
      bundleItem1Id: { value: '1' },
      bundleItem2Id: { value: '2' },
      bundleHeroUUID: { value: 'hero-uuid' },
    });

    const { operations } = cartTransformRun({ cart: { lines: [bundleLine] } });

    expect(operations).toHaveLength(1);
    const { lineExpand } = operations[0];
    expect(lineExpand.cartLineId).toBe('gid://shopify/CartLine/1');
    expect(lineExpand.title).toBe('Desk bundle');
    expect(lineExpand.expandedCartItems).toHaveLength(2);

    const [first, second] = lineExpand.expandedCartItems;
    expect(first.merchandiseId).toBe('gid://shopify/ProductVariant/1');
    expect(first.price.adjustment.fixedPricePerUnit.amount).toBe('100.00');
    expect(second.merchandiseId).toBe('gid://shopify/ProductVariant/2');
    expect(second.price.adjustment.fixedPricePerUnit.amount).toBe('50.00');
  });

  it('uses custom per-item prices when they sum to the bundle price', () => {
    const bundleLine = line({
      bundleId: { value: 'uuid-2' },
      bundleTitle: { value: 'Custom priced bundle' },
      bundlePrice: { value: '150.00' },
      bundleItem1Id: { value: '1' },
      bundleItem2Id: { value: '2' },
      bundleCustomPricing1: { value: '120.00' },
      bundleCustomPricing2: { value: '30.00' },
    });

    const { operations } = cartTransformRun({ cart: { lines: [bundleLine] } });
    const [first, second] = operations[0].lineExpand.expandedCartItems;

    expect(first.price.adjustment.fixedPricePerUnit.amount).toBe('120.00');
    expect(second.price.adjustment.fixedPricePerUnit.amount).toBe('30.00');
  });

  it('falls back to distribution when custom prices do not sum to the total', () => {
    const bundleLine = line({
      bundleId: { value: 'uuid-3' },
      bundlePrice: { value: '150.00' },
      bundleItem1Id: { value: '1' },
      bundleItem2Id: { value: '2' },
      bundleCustomPricing1: { value: '10.00' },
      bundleCustomPricing2: { value: '10.00' },
    });

    const { operations } = cartTransformRun({ cart: { lines: [bundleLine] } });
    const [first, second] = operations[0].lineExpand.expandedCartItems;

    expect(first.price.adjustment.fixedPricePerUnit.amount).toBe('100.00');
    expect(second.price.adjustment.fixedPricePerUnit.amount).toBe('50.00');
  });

  it('splits the price difference across both children for a three-item bundle', () => {
    const bundleLine = line({
      bundleId: { value: 'uuid-4' },
      bundlePrice: { value: '200.00' },
      bundleItem1Id: { value: '1' },
      bundleItem2Id: { value: '2' },
      bundleItem3Id: { value: '3' },
    });

    const { operations } = cartTransformRun({ cart: { lines: [bundleLine] } });
    const items = operations[0].lineExpand.expandedCartItems;

    expect(items).toHaveLength(3);
    // 200.00 - 100.00 = 100.00, split evenly between items 2 and 3.
    expect(items[1].price.adjustment.fixedPricePerUnit.amount).toBe('50.00');
    expect(items[2].price.adjustment.fixedPricePerUnit.amount).toBe('50.00');
  });

  it('carries bundle attributes onto the expanded hero item', () => {
    const bundleLine = line({
      bundleId: { value: 'uuid-5' },
      bundleTitle: { value: 'Desk bundle' },
      bundlePrice: { value: '150.00' },
      bundleItem1Id: { value: '1' },
      bundleItem2Id: { value: '2' },
      bundleHeroUUID: { value: 'hero-uuid' },
    });

    const { operations } = cartTransformRun({ cart: { lines: [bundleLine] } });
    const [hero, child] = operations[0].lineExpand.expandedCartItems;

    expect(hero.attributes).toEqual([
      { key: '_bundle_uuid', value: 'uuid-5' },
      { key: '_bundle_title', value: 'Desk bundle' },
      { key: '_bundle_price', value: '150.00' },
      { key: '_bundle_item_1_id', value: '1' },
      { key: '_bundle_item_2_id', value: '2' },
      { key: '_uuid', value: 'hero-uuid' },
    ]);
    expect(child.attributes).toEqual([
      { key: '_second_child_bundle_uuid', value: 'uuid-5' },
      { key: '_bundle_title', value: 'Desk bundle' },
    ]);
  });

  it('falls back to the product title when no bundle title is set', () => {
    const bundleLine = line({
      bundleId: { value: 'uuid-6' },
      bundlePrice: { value: '150.00' },
      bundleItem1Id: { value: '1' },
      bundleItem2Id: { value: '2' },
    });

    const { operations } = cartTransformRun({ cart: { lines: [bundleLine] } });

    expect(operations[0].lineExpand.title).toBe('Hero product');
  });
});
