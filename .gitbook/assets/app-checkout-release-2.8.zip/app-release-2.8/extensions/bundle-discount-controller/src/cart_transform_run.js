// @ts-check

/**
 * @typedef {import("../generated/api").CartTransformRunInput} CartTransformRunInput
 * @typedef {import("../generated/api").CartTransformRunResult} CartTransformRunResult
 */

/**
 * @type {CartTransformRunResult}
 */
const NO_CHANGES = {
  operations: [],
};

/**
 * @param {CartTransformRunInput} input
 * @returns {CartTransformRunResult}
 */
export function cartTransformRun(input) {
  const operations = input.cart.lines
    .filter(line => line.merchandise.__typename === "ProductVariant")
    .reduce((acc, cartLine) => {
      // Ensure this is a bundle line by checking for the bundleId custom attribute.
      if (cartLine.bundleId?.value) {
        const bundleProduct2 = cartLine.bundleItem2Id?.value ? `gid://shopify/ProductVariant/${cartLine.bundleItem2Id?.value}` : null;
        const bundleProduct3 = cartLine.bundleItem3Id?.value ? `gid://shopify/ProductVariant/${cartLine.bundleItem3Id?.value}` : null;
        const totalBundlePrice = parseFloat(cartLine.bundlePrice?.value);
        let useCustomPrices = false;
        let price1, price2, price3;
        const customPrice1Attr = cartLine.bundleCustomPricing1?.value;
        const customPrice2Attr = cartLine.bundleCustomPricing2?.value;
        const customPrice3Attr = cartLine.bundleCustomPricing3?.value;

        // Check if the custom price attributes exist.
        if (customPrice1Attr && customPrice2Attr && (!bundleProduct3 || (bundleProduct3 && customPrice3Attr))) {
          const p1 = parseFloat(customPrice1Attr);
          const p2 = parseFloat(customPrice2Attr);
          const p3 = bundleProduct3 ? parseFloat(customPrice3Attr) : 0;
          
          const customPriceSum = p1 + p2 + p3;

          // Validate if the sum of custom prices equals the total bundle price.
          // Used a small tolerance (0.01) to avoid floating point precision issues.
          if (Math.abs(customPriceSum - totalBundlePrice) < 0.01) {
            useCustomPrices = true;
            price1 = p1;
            price2 = p2;
            price3 = p3;
          }
        }
        
        if (!useCustomPrices) {
          const originalItemPrice = parseFloat(cartLine.cost.amountPerQuantity.amount);
          const bundlePriceDiff = totalBundlePrice - originalItemPrice;
          // Distribute the remaining cost between the other items.
          const bundlePriceDiscount = bundleProduct3 ? bundlePriceDiff / 2 : bundlePriceDiff;
          
          price1 = originalItemPrice;
          price2 = bundlePriceDiscount;
          price3 = bundlePriceDiscount;
        }

        const expandedCartItems = [
          {
            merchandiseId: cartLine.merchandise.id,
            quantity: 1,
            price: {
              adjustment: {
                // @ts-ignore
                fixedPricePerUnit: { amount: price1.toFixed(2) }
              }
            },
            attributes: [
              { key: '_bundle_uuid', value: cartLine.bundleId?.value || "" },
              { key: '_bundle_title', value: cartLine.bundleTitle?.value || "" },
              { key: '_bundle_price', value: cartLine.bundlePrice?.value || "" },
              { key: '_bundle_item_1_id', value: cartLine.bundleItem1Id?.value || "" },
              { key: '_bundle_item_2_id', value: cartLine.bundleItem2Id?.value || "" },
              { key: '_uuid', value: cartLine.bundleHeroUUID?.value || "" }
            ]
          }
        ];

        if (bundleProduct2) {
          expandedCartItems.push({
            merchandiseId: bundleProduct2,
            quantity: 1,
            price: {
              adjustment: {
                fixedPricePerUnit: { amount: price2.toFixed(2) }
              }
            },
            attributes: [
              { key: '_second_child_bundle_uuid', value: cartLine.bundleId?.value || "" },
              { key: '_bundle_title', value: cartLine.bundleTitle?.value || "" }
            ]
          });
        }

        if (bundleProduct3) {
          expandedCartItems.push({
            merchandiseId: bundleProduct3,
            quantity: 1,
            price: {
              adjustment: {
                fixedPricePerUnit: { amount: price3.toFixed(2) }
              }
            },
            attributes: [
              { key: '_third_child_bundle_uuid', value: cartLine.bundleId?.value || "" },
              { key: '_bundle_title', value: cartLine.bundleTitle?.value || "" }
            ]
          });
        }

        const expandOperation = {
          lineExpand: {
            cartLineId: cartLine.id,
            title: cartLine.bundleTitle?.value || cartLine.merchandise.product.title,
            expandedCartItems
          }
        };
        
        acc.push(expandOperation);
      }
      return acc;
    }, []);

  if (operations.length === 0) {
    return NO_CHANGES;
  }

  return { operations };
}