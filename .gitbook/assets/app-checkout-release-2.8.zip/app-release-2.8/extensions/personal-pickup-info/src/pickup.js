/**
 * Personal pickup contact details.
 *
 * The rules live here, away from the five target modules, because two of them are
 * consequential: the required-field check runs inside a buyer-journey interceptor,
 * and the delivery-type check decides whether saved contact details get wiped.
 */

export const PICKUP_NAME_ATTRIBUTE_KEY = 'PersonalPickupName';
export const PICKUP_EMAIL_ATTRIBUTE_KEY = 'PersonalPickupEmail';
export const PICKUP_PHONE_ATTRIBUTE_KEY = 'PersonalPickupPhone';

/** Passed to the platform for logging; never shown to the buyer. */
export const BLOCK_REASON = 'Missing required fields';

export const DEFAULT_HEADING = 'Personal Pickup Information';
export const DEFAULT_NAME_LABEL = 'Full name';
export const DEFAULT_EMAIL_LABEL = 'Email';
/** Misspelling preserved from the pre-migration copy — it is the shipped default. */
export const DEFAULT_PHONE_LABEL = 'Phone nunber (optional)';
export const DEFAULT_DETAIL_HEADING = 'Pickup person';
export const DEFAULT_NAME_ERROR = 'Please enter your full name';
export const DEFAULT_EMAIL_ERROR = 'Please enter your email address';
export const DEFAULT_PHONE_ERROR = 'Please enter your phone number';

/**
 * Delivery option types that mean "not being picked up in person", and therefore
 * that any saved pickup contact details are stale.
 */
export const DELIVERY_TYPES = ['shipping', 'local'];

/**
 * The three pickup attributes, read off the cart attribute list.
 * @param {Array} attributes value of `shopify.attributes`
 * @returns {{name: String|undefined, email: String|undefined, phone: String|undefined}}
 */
export const pickupAttributes = (attributes) => {
  const valueOf = (key) =>
    attributes?.find((attribute) => attribute.key === key)?.value;

  return {
    name: valueOf(PICKUP_NAME_ATTRIBUTE_KEY),
    email: valueOf(PICKUP_EMAIL_ATTRIBUTE_KEY),
    phone: valueOf(PICKUP_PHONE_ATTRIBUTE_KEY),
  };
};

/**
 * The `type` of the delivery option the buyer has selected for the first delivery
 * group, or `undefined` when nothing is selected yet.
 *
 * @param {Array} deliveryGroups value of `shopify.deliveryGroups`
 * @returns {String|undefined}
 */
export const selectedDeliveryType = (deliveryGroups) => {
  const [group] = deliveryGroups || [];
  if (!group) return undefined;

  const handle = group.selectedDeliveryOption?.handle;
  if (!handle) return undefined;

  return group.deliveryOptions?.find((option) => option.handle === handle)?.type;
};

/**
 * Whether the selected delivery option means the buyer is *not* collecting in
 * person, so saved pickup contact details should be cleared.
 * @param {Array} deliveryGroups value of `shopify.deliveryGroups`
 * @returns {Boolean}
 */
export const isBeingDelivered = (deliveryGroups) =>
  DELIVERY_TYPES.includes(selectedDeliveryType(deliveryGroups));

/**
 * Errors for the required pickup fields. Empty strings mean "no error", matching
 * how the pre-migration code used `false`.
 *
 * Name and email are always required. Phone is required only when the merchant's
 * translations set `phone_required` — the label still says "(optional)" by default,
 * so those two settings need to agree.
 *
 * @param {{name?: String, email?: String, phone?: String, text?: Object}} input
 * @returns {{blocked: Boolean, nameError: String, emailError: String, phoneError: String}}
 */
export const requiredFieldErrors = ({name, email, phone, text = {}}) => {
  const nameError = name ? '' : text?.name_error || DEFAULT_NAME_ERROR;
  const emailError = email ? '' : text?.email_error || DEFAULT_EMAIL_ERROR;
  const phoneError =
    text?.phone_required && !phone
      ? text?.phone_error || DEFAULT_PHONE_ERROR
      : '';

  return {
    blocked: Boolean(nameError || emailError || phoneError),
    nameError,
    emailError,
    phoneError,
  };
};
