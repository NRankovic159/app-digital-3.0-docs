import '@shopify/ui-extensions/preact';

import {DEFAULT_DETAIL_HEADING, pickupAttributes} from './pickup.js';
import {liveTranslations} from './translations.js';

/**
 * Read-only summary of who is collecting the order.
 *
 * Used by three targets: the checkout block, the thank-you page and the
 * customer-account order status page. Renders nothing until both a name and an
 * email are stored, so it stays invisible for delivery orders.
 */
export function InfoDisplay() {
  const text = liveTranslations();
  const {name, email, phone} = pickupAttributes(shopify.attributes.value);

  if (!name && !email) return null;

  return (
    <s-stack
      direction="block"
      gap="base"
      justifyContent="start"
      alignItems="start"
      padding="base"
      borderRadius="base"
      border="base"
    >
      <s-heading>{text?.detail_heading || DEFAULT_DETAIL_HEADING}</s-heading>

      <s-stack direction="block" gap="small-400">
        <s-text>{name}</s-text>
        <s-text>{email}</s-text>
        {phone && <s-text>{phone}</s-text>}
      </s-stack>
    </s-stack>
  );
}
