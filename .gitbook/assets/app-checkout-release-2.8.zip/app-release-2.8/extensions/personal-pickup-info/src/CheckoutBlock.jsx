import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {InfoDisplay} from './InfoDisplay.jsx';

export default async () => {
  render(<InfoDisplay />, document.body)
};
