import {useEffect} from 'preact/hooks';

/**
 * Buyer-journey interceptor registration.
 *
 * The React `useBuyerJourneyIntercept(cb)` hook handled registration and teardown
 * and re-registered on every render, so the callback always closed over fresh
 * state. On 2026-07 registration is manual: `shopify.buyerJourney.intercept()`
 * returns a **promise of a teardown function**, and the caller owns its lifetime.
 *
 * ⚠️ Because this registers **once** on mount, the interceptor must read live
 * values — signals via `.value`, or `shopify.*` directly — rather than closing over
 * values captured during a render. Anything captured at registration time will be
 * stale forever, and for these extensions "stale" means either blocking a valid
 * checkout or letting an invalid one through.
 *
 * Note `buyerJourney.intercept` is marked deprecated on 2026-07 in favour of cart
 * and checkout validation functions. It still works;
 */

/**
 * Installs a buyer-journey interceptor for the lifetime of the component.
 * @param {(props: {canBlockProgress: Boolean}) => Object|Promise<Object>} interceptor
 */
export const useInterceptor = (interceptor) => {
  useEffect(() => {
    let remove;
    let cancelled = false;

    // Registration is async, so a component that unmounts before it resolves
    // would otherwise leak an interceptor that can block checkout forever.
    shopify.buyerJourney.intercept(interceptor).then((teardown) => {
      if (cancelled) {
        teardown();
        return;
      }
      remove = teardown;
    });

    return () => {
      cancelled = true;
      remove?.();
    };
  }, []);
};

/** An interceptor result that lets the buyer continue. */
export const ALLOW = {behavior: 'allow'};

/**
 * An interceptor result that stops the buyer, with a reason for the logs.
 *
 * `reason` is not shown to the buyer, so the caller is responsible for surfacing
 * something in the UI — otherwise checkout appears to silently do nothing.
 * @param {String} reason
 * @returns {Object}
 */
export const block = (reason) => ({behavior: 'block', reason});
