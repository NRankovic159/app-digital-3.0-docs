import '@shopify/ui-extensions/preact';
import {useEffect} from 'preact/hooks';

import {
  PICKUP_EMAIL_ATTRIBUTE_KEY,
  PICKUP_NAME_ATTRIBUTE_KEY,
  PICKUP_PHONE_ATTRIBUTE_KEY,
  isBeingDelivered,
  pickupAttributes,
} from './pickup.js';

/**
 * Renders nothing. Clears saved pickup contact details when the buyer switches
 * from collecting in person to having the order delivered, so a stale pickup
 * person doesn't ride along on a shipped order.
 *
 * Lives on the shipping-option list target, which is where that switch happens.
 *
 * `useEffect` rather than `useSignalEffect`: the callback writes cart attributes,
 * which feed back into `shopify.attributes`, so a signal-tracked effect would
 * re-trigger on its own writes.
 *
 * @returns {null}
 */
export function AttributeCleanup() {
  const deliveryGroups = shopify.deliveryGroups.value;
  const {name, email, phone} = pickupAttributes(shopify.attributes.value);
  const delivered = isBeingDelivered(deliveryGroups);

  useEffect(() => {
    if (!delivered) return;

    // Each is cleared only if it currently has a value, so this settles after one
    // pass instead of writing empty strings on every render.
    if (name) {
      shopify.applyAttributeChange({
        type: 'updateAttribute',
        key: PICKUP_NAME_ATTRIBUTE_KEY,
        value: '',
      });
    }

    if (email) {
      shopify.applyAttributeChange({
        type: 'updateAttribute',
        key: PICKUP_EMAIL_ATTRIBUTE_KEY,
        value: '',
      });
    }

    if (phone) {
      shopify.applyAttributeChange({
        type: 'updateAttribute',
        key: PICKUP_PHONE_ATTRIBUTE_KEY,
        value: '',
      });
    }
  }, [delivered, name, email, phone]);

  return null;
}
