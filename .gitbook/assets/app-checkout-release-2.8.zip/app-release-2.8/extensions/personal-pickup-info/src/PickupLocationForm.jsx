import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {InfoForm} from './InfoForm.jsx';

export default async () => {
  render(<InfoForm />, document.body)
};
