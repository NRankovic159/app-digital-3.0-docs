import {describe, expect, it} from 'vitest';

import {
  DEFAULT_EMAIL_ERROR,
  DEFAULT_NAME_ERROR,
  DEFAULT_PHONE_ERROR,
  PICKUP_EMAIL_ATTRIBUTE_KEY,
  PICKUP_NAME_ATTRIBUTE_KEY,
  PICKUP_PHONE_ATTRIBUTE_KEY,
  isBeingDelivered,
  pickupAttributes,
  requiredFieldErrors,
  selectedDeliveryType,
} from './pickup.js';

const group = (selectedHandle, options) => ({
  id: 'gid://shopify/DeliveryGroup/1',
  selectedDeliveryOption: selectedHandle ? {handle: selectedHandle} : undefined,
  deliveryOptions: options,
  targetedCartLines: [],
});

const SHIPPING = {handle: 'ship-1', type: 'shipping', title: 'Standard'};
const LOCAL = {handle: 'local-1', type: 'local', title: 'Local delivery'};
const PICKUP = {handle: 'pickup-1', type: 'pickupLocation', title: 'Store'};
const PICKUP_POINT = {handle: 'pp-1', type: 'pickupPoint', title: 'Locker'};

describe('pickupAttributes', () => {
  it('reads all three attributes', () => {
    expect(
      pickupAttributes([
        {key: PICKUP_NAME_ATTRIBUTE_KEY, value: 'Ada'},
        {key: PICKUP_EMAIL_ATTRIBUTE_KEY, value: 'ada@example.com'},
        {key: PICKUP_PHONE_ATTRIBUTE_KEY, value: '+441234'},
      ]),
    ).toEqual({name: 'Ada', email: 'ada@example.com', phone: '+441234'});
  });

  it('is all-undefined for an empty or missing list', () => {
    expect(pickupAttributes([])).toEqual({
      name: undefined,
      email: undefined,
      phone: undefined,
    });
    expect(pickupAttributes(undefined).name).toBeUndefined();
  });

  it('ignores unrelated attributes', () => {
    expect(pickupAttributes([{key: 'tradein', value: 'Yes'}]).name).toBeUndefined();
  });
});

describe('selectedDeliveryType', () => {
  it('resolves the selected handle to its option type', () => {
    expect(
      selectedDeliveryType([group('ship-1', [SHIPPING, PICKUP])]),
    ).toBe('shipping');
  });

  it('resolves a pickup selection', () => {
    expect(selectedDeliveryType([group('pickup-1', [SHIPPING, PICKUP])])).toBe(
      'pickupLocation',
    );
  });

  it('is undefined when nothing is selected yet', () => {
    expect(selectedDeliveryType([group(undefined, [SHIPPING])])).toBeUndefined();
  });

  it('is undefined when the handle matches no option', () => {
    expect(selectedDeliveryType([group('gone', [SHIPPING])])).toBeUndefined();
  });

  it('is undefined for no delivery groups at all', () => {
    expect(selectedDeliveryType([])).toBeUndefined();
    expect(selectedDeliveryType(undefined)).toBeUndefined();
  });

  it('uses only the first delivery group, as before', () => {
    expect(
      selectedDeliveryType([
        group('pickup-1', [PICKUP]),
        group('ship-1', [SHIPPING]),
      ]),
    ).toBe('pickupLocation');
  });
});

describe('isBeingDelivered', () => {
  it('is true for shipping and local delivery', () => {
    expect(isBeingDelivered([group('ship-1', [SHIPPING])])).toBe(true);
    expect(isBeingDelivered([group('local-1', [LOCAL])])).toBe(true);
  });

  it('is false for in-person pickup', () => {
    expect(isBeingDelivered([group('pickup-1', [PICKUP])])).toBe(false);
  });

  it('is false for a third-party pickup point', () => {
    // A pickup point is still collected in person, so contact details stay.
    expect(isBeingDelivered([group('pp-1', [PICKUP_POINT])])).toBe(false);
  });

  it('is false before anything is selected', () => {
    expect(isBeingDelivered([group(undefined, [SHIPPING])])).toBe(false);
    expect(isBeingDelivered([])).toBe(false);
  });
});

describe('requiredFieldErrors', () => {
  it('passes when name and email are present', () => {
    expect(
      requiredFieldErrors({name: 'Ada', email: 'ada@example.com'}),
    ).toEqual({blocked: false, nameError: '', emailError: '', phoneError: ''});
  });

  it('blocks on a missing name', () => {
    const result = requiredFieldErrors({email: 'ada@example.com'});

    expect(result.blocked).toBe(true);
    expect(result.nameError).toBe(DEFAULT_NAME_ERROR);
    expect(result.emailError).toBe('');
  });

  it('blocks on a missing email', () => {
    const result = requiredFieldErrors({name: 'Ada'});

    expect(result.blocked).toBe(true);
    expect(result.emailError).toBe(DEFAULT_EMAIL_ERROR);
  });

  it('reports both when both are missing', () => {
    const result = requiredFieldErrors({});

    expect(result.nameError).toBe(DEFAULT_NAME_ERROR);
    expect(result.emailError).toBe(DEFAULT_EMAIL_ERROR);
  });

  it('does not require a phone by default', () => {
    expect(
      requiredFieldErrors({name: 'Ada', email: 'ada@example.com'}).phoneError,
    ).toBe('');
  });

  it('requires a phone only when the merchant sets phone_required', () => {
    const result = requiredFieldErrors({
      name: 'Ada',
      email: 'ada@example.com',
      text: {phone_required: true},
    });

    expect(result.blocked).toBe(true);
    expect(result.phoneError).toBe(DEFAULT_PHONE_ERROR);
  });

  it('passes when phone_required is set and a phone is given', () => {
    expect(
      requiredFieldErrors({
        name: 'Ada',
        email: 'ada@example.com',
        phone: '+441234',
        text: {phone_required: true},
      }).blocked,
    ).toBe(false);
  });

  it('uses the translated error messages', () => {
    const result = requiredFieldErrors({
      text: {
        name_error: 'Nombre obligatorio',
        email_error: 'Correo obligatorio',
        phone_required: true,
        phone_error: 'Teléfono obligatorio',
      },
    });

    expect(result.nameError).toBe('Nombre obligatorio');
    expect(result.emailError).toBe('Correo obligatorio');
    expect(result.phoneError).toBe('Teléfono obligatorio');
  });

  it('treats an empty string as missing', () => {
    expect(requiredFieldErrors({name: '', email: ''}).blocked).toBe(true);
  });

  it('treats whitespace as filled, matching pre-migration behaviour', () => {
    expect(requiredFieldErrors({name: ' ', email: ' '}).blocked).toBe(false);
  });
});
