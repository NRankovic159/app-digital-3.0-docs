/**
 * Helpers for reading the `sdg:translations` app metafield.
 */

/**
 * Metafield entries matching a namespace and key, in API order.
 * @param {Array} appMetafields value of `shopify.appMetafields`
 * @param {String} namespace
 * @param {String} key
 * @returns {Array}
 */
export const filterAppMetafields = (appMetafields, namespace, key) =>
  (appMetafields || []).filter(
    (entry) =>
      entry?.metafield?.namespace === namespace && entry?.metafield?.key === key,
  );

/**
 * The buyer's base language code — `en` for `en-CA`. Falls back to `en` when
 * the language isn't available.
 * @param {Object} language value of `shopify.localization.language`
 * @returns {String}
 */
export const languageCodeFrom = (language) => {
  const [languageCode] = language?.isoCode?.split('-') || ['en'];
  return languageCode;
};

/**
 * Translations for the buyer's language out of an `sdg:translations` metafield.
 * Returns `{}` when the metafield is missing, empty, or holds no entry for the
 * language.
 * @param {Array} appMetafields value of `shopify.appMetafields`
 * @param {{namespace?: String, key: String, language: Object}} options
 * @returns {Object}
 */
export const readTranslations = (
  appMetafields,
  {namespace = 'sdg:translations', key, language},
) => {
  const [translationMetafield] = filterAppMetafields(
    appMetafields,
    namespace,
    key,
  );
  const translationJson =
    JSON.parse(translationMetafield?.metafield?.value || '{}')?.value || {};
  return translationJson?.[languageCodeFrom(language)] || {};
};

/**
 * This extension's translations, read straight off the `shopify` global.
 *
 * Needed inside the buyer-journey interceptor, which registers once and so cannot
 * use values captured during a render.
 * @returns {Object}
 */
export const liveTranslations = () =>
  readTranslations(shopify.appMetafields.value, {
    key: 'personal_pickup_info',
    language: shopify.localization.language.value,
  });
