import '@shopify/ui-extensions/preact';
import {useSignal} from '@preact/signals';
import {useEffect} from 'preact/hooks';

import {ALLOW, block, useInterceptor} from './buyerJourney.js';
import {fieldValue} from './events.js';
import {
  BLOCK_REASON,
  DEFAULT_EMAIL_LABEL,
  DEFAULT_HEADING,
  DEFAULT_NAME_LABEL,
  DEFAULT_PHONE_LABEL,
  PICKUP_EMAIL_ATTRIBUTE_KEY,
  PICKUP_NAME_ATTRIBUTE_KEY,
  PICKUP_PHONE_ATTRIBUTE_KEY,
  pickupAttributes,
  requiredFieldErrors,
} from './pickup.js';
import {liveTranslations} from './translations.js';

/**
 * The contact form, rendered under the pickup location list — so it only appears
 * when the buyer is actually choosing a pickup location.
 *
 * This is the component that can block checkout.
 */
export function InfoForm() {
  const text = liveTranslations();
  const saved = pickupAttributes(shopify.attributes.value);

  const fullName = useSignal(saved.name || '');
  const email = useSignal(saved.email || '');
  const phone = useSignal(saved.phone || '');
  const nameError = useSignal('');
  const emailError = useSignal('');
  const phoneError = useSignal('');

  useEffect(() => {
    if (!saved.name) fullName.value = '';
    if (!saved.email) email.value = '';
    if (!saved.phone) phone.value = '';
  }, [saved.name, saved.email, saved.phone]);

  // Registered once, so every value is read live. A captured empty name would
  // block the buyer forever no matter what they typed.
  useInterceptor(({canBlockProgress}) => {
    if (!canBlockProgress) return ALLOW;

    const result = requiredFieldErrors({
      name: fullName.value,
      email: email.value,
      phone: phone.value,
      text: liveTranslations(),
    });

    nameError.value = result.nameError;
    emailError.value = result.emailError;
    phoneError.value = result.phoneError;

    return result.blocked ? block(BLOCK_REASON) : ALLOW;
  });

  const handleFieldUpdate = (key, value) => {
    if (key === PICKUP_NAME_ATTRIBUTE_KEY) {
      fullName.value = value;
      nameError.value = '';
    }
    if (key === PICKUP_EMAIL_ATTRIBUTE_KEY) {
      email.value = value;
      emailError.value = '';
    }
    if (key === PICKUP_PHONE_ATTRIBUTE_KEY) {
      phone.value = value;
      phoneError.value = '';
    }

    return shopify.applyAttributeChange({
      type: 'updateAttribute',
      key,
      value,
    });
  };

  return (
    <s-stack direction="block" gap="base">
      <s-heading>{text?.heading || DEFAULT_HEADING}</s-heading>

      <s-text-field
        label={text?.name_label || DEFAULT_NAME_LABEL}
        name="fullName"
        value={fullName.value}
        error={nameError.value}
        required
        onChange={(event) =>
          handleFieldUpdate(PICKUP_NAME_ATTRIBUTE_KEY, fieldValue(event))
        }
      />

      <s-email-field
        label={text?.email_label || DEFAULT_EMAIL_LABEL}
        name="email"
        value={email.value}
        error={emailError.value}
        required
        onChange={(event) =>
          handleFieldUpdate(PICKUP_EMAIL_ATTRIBUTE_KEY, fieldValue(event))
        }
      />

      <s-phone-field
        label={text?.phone_label || DEFAULT_PHONE_LABEL}
        name="phone"
        value={phone.value}
        error={text?.phone_required ? phoneError.value : ''}
        onChange={(event) =>
          handleFieldUpdate(PICKUP_PHONE_ATTRIBUTE_KEY, fieldValue(event))
        }
      />

      {text?.callout && <s-paragraph>{text?.callout}</s-paragraph>}
    </s-stack>
  );
}
