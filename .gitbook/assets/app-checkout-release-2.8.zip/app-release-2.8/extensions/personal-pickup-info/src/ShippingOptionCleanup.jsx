import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {AttributeCleanup} from './AttributeCleanup.jsx';

export default async () => {
  render(<AttributeCleanup />, document.body)
};
