import {act, cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {AttributeCleanup} from './AttributeCleanup.jsx';
import {InfoDisplay} from './InfoDisplay.jsx';
import {InfoForm} from './InfoForm.jsx';
import {BLOCK_REASON} from './pickup.js';

const translationEntry = (byLanguage, key = 'personal_pickup_info') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {
    heading: 'Who is collecting?',
    name_label: 'Collector name',
    email_label: 'Collector email',
    phone_label: 'Phone (optional)',
    detail_heading: 'Collected by',
    callout: 'Bring photo ID.',
  },
  fr: {heading: 'Qui récupère?'},
};

const pickupAttrs = ({name, email, phone} = {}) =>
  [
    name === undefined ? null : {key: 'PersonalPickupName', value: name},
    email === undefined ? null : {key: 'PersonalPickupEmail', value: email},
    phone === undefined ? null : {key: 'PersonalPickupPhone', value: phone},
  ].filter(Boolean);

const group = (selectedHandle, options) => ({
  id: 'gid://shopify/DeliveryGroup/1',
  selectedDeliveryOption: selectedHandle ? {handle: selectedHandle} : undefined,
  deliveryOptions: options,
  targetedCartLines: [],
});

const SHIPPING = {handle: 'ship-1', type: 'shipping', title: 'Standard'};
const PICKUP = {handle: 'pickup-1', type: 'pickupLocation', title: 'Store'};

let intercept;
let registeredInterceptor;
let teardown;
let applyAttributeChange;
let attributes;

const stubShopify = ({
  initialAttributes = [],
  appMetafields = [translationEntry(TRANSLATIONS)],
  isoCode = 'en',
  deliveryGroups = [],
} = {}) => {
  registeredInterceptor = undefined;
  teardown = vi.fn();
  attributes = {value: initialAttributes};
  applyAttributeChange = vi.fn().mockResolvedValue({type: 'success'});
  intercept = vi.fn(async (interceptor) => {
    registeredInterceptor = interceptor;
    return teardown;
  });
  globalThis.shopify = {
    attributes,
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    deliveryGroups: {value: deliveryGroups},
    applyAttributeChange,
    buyerJourney: {intercept},
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

const settle = () =>
  act(async () => {
    await Promise.resolve();
    await Promise.resolve();
  });

const run = (props = {canBlockProgress: true}) => registeredInterceptor(props);

const change = async (element, value) => {
  element.value = value;
  await act(async () => {
    element.dispatchEvent(new Event('change'));
  });
};

const nameField = (c) => c.querySelector('s-text-field');
const emailField = (c) => c.querySelector('s-email-field');
const phoneField = (c) => c.querySelector('s-phone-field');

describe('InfoForm — the interceptor', () => {
  it('blocks with name and email errors when empty', async () => {
    const {container} = render(<InfoForm />);
    await settle();

    let result;
    await act(async () => {
      result = run();
    });

    expect(result).toEqual({behavior: 'block', reason: BLOCK_REASON});
    expect(nameField(container).getAttribute('error')).toBe(
      'Please enter your full name',
    );
    expect(emailField(container).getAttribute('error')).toBe(
      'Please enter your email address',
    );
  });

  it('allows once name and email are filled', async () => {
    const {container} = render(<InfoForm />);
    await settle();

    await change(nameField(container), 'Ada');
    await change(emailField(container), 'ada@example.com');

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('allows when the extension cannot block progress', async () => {
    render(<InfoForm />);
    await settle();

    expect(run({canBlockProgress: false})).toEqual({behavior: 'allow'});
  });

  it('does not require a phone by default', async () => {
    const {container} = render(<InfoForm />);
    await settle();
    await change(nameField(container), 'Ada');
    await change(emailField(container), 'ada@example.com');

    await act(async () => {
      run();
    });

    expect(phoneField(container).getAttribute('error')).toBeFalsy();
    expect(run()).toEqual({behavior: 'allow'});
  });

  it('requires a phone when the merchant sets phone_required', async () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {...TRANSLATIONS.en, phone_required: true}}),
      ],
    });
    const {container} = render(<InfoForm />);
    await settle();
    await change(nameField(container), 'Ada');
    await change(emailField(container), 'ada@example.com');

    let result;
    await act(async () => {
      result = run();
    });

    expect(result).toEqual({behavior: 'block', reason: BLOCK_REASON});
    expect(phoneField(container).getAttribute('error')).toBe(
      'Please enter your phone number',
    );
  });

  it('clears an error as soon as the buyer types', async () => {
    const {container} = render(<InfoForm />);
    await settle();
    await act(async () => {
      run();
    });
    expect(nameField(container).getAttribute('error')).toBeTruthy();

    await change(nameField(container), 'A');

    expect(nameField(container).getAttribute('error')).toBeFalsy();
  });

  it('registers once and reads values live', async () => {
    const {container} = render(<InfoForm />);
    await settle();
    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});

    await change(nameField(container), 'Ada');
    await change(emailField(container), 'ada@example.com');
    await settle();

    expect(run()).toEqual({behavior: 'allow'});
    expect(intercept).toHaveBeenCalledTimes(1);
  });

  it('removes the interceptor on unmount', async () => {
    render(<InfoForm />);
    await settle();

    cleanup();

    expect(teardown).toHaveBeenCalled();
  });
});

describe('InfoForm — writing attributes', () => {
  it('writes each field to its own attribute', async () => {
    const {container} = render(<InfoForm />);
    await settle();

    await change(nameField(container), 'Ada');
    await change(emailField(container), 'ada@example.com');
    await change(phoneField(container), '+441234');

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'PersonalPickupName',
      value: 'Ada',
    });
    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'PersonalPickupEmail',
      value: 'ada@example.com',
    });
    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'PersonalPickupPhone',
      value: '+441234',
    });
  });

  it('seeds the fields from saved attributes', () => {
    stubShopify({
      initialAttributes: pickupAttrs({
        name: 'Ada',
        email: 'ada@example.com',
        phone: '+441234',
      }),
    });

    const {container} = render(<InfoForm />);

    expect(nameField(container).getAttribute('value')).toBe('Ada');
    expect(emailField(container).getAttribute('value')).toBe('ada@example.com');
    expect(phoneField(container).getAttribute('value')).toBe('+441234');
  });
});

describe('InfoForm — rendering', () => {
  it('uses typed field components for email and phone', () => {
    const {container} = render(<InfoForm />);

    expect(emailField(container)).not.toBeNull();
    expect(phoneField(container)).not.toBeNull();
  });

  it('marks name and email required but not phone', () => {
    const {container} = render(<InfoForm />);

    expect(nameField(container).hasAttribute('required')).toBe(true);
    expect(emailField(container).hasAttribute('required')).toBe(true);
    expect(phoneField(container).hasAttribute('required')).toBe(false);
  });

  it('renders the translated heading, labels and callout', () => {
    const {container} = render(<InfoForm />);

    expect(container.textContent).toContain('Who is collecting?');
    expect(nameField(container).getAttribute('label')).toBe('Collector name');
    expect(container.textContent).toContain('Bring photo ID.');
  });

  it('omits the callout when not configured', () => {
    stubShopify({appMetafields: [translationEntry({en: {heading: 'Pickup'}})]});

    const {container} = render(<InfoForm />);

    expect(container.querySelector('s-paragraph')).toBeNull();
  });

  it('falls back to hardcoded English when untranslated', () => {
    stubShopify({isoCode: 'de'});

    const {container} = render(<InfoForm />);

    expect(container.textContent).toContain('Personal Pickup Information');
    expect(nameField(container).getAttribute('label')).toBe('Full name');
  });

  it('uses the buyer language for a regional locale', () => {
    stubShopify({isoCode: 'fr-CA'});

    const {container} = render(<InfoForm />);

    expect(container.textContent).toContain('Qui récupère?');
  });
});

describe('InfoDisplay', () => {
  it('renders nothing without a name and email', () => {
    const {container} = render(<InfoDisplay />);

    expect(container.innerHTML).toBe('');
  });

  it('renders nothing with only a phone', () => {
    stubShopify({initialAttributes: pickupAttrs({phone: '+441234'})});

    const {container} = render(<InfoDisplay />);

    expect(container.innerHTML).toBe('');
  });

  it('renders with only a name', () => {
    // The guard is `!name && !email`, so either one is enough. Preserved.
    stubShopify({initialAttributes: pickupAttrs({name: 'Ada'})});

    const {container} = render(<InfoDisplay />);

    expect(container.textContent).toContain('Ada');
  });

  it('shows the heading, name, email and phone', () => {
    stubShopify({
      initialAttributes: pickupAttrs({
        name: 'Ada',
        email: 'ada@example.com',
        phone: '+441234',
      }),
    });

    const {container} = render(<InfoDisplay />);

    expect(container.textContent).toContain('Collected by');
    expect(container.textContent).toContain('Ada');
    expect(container.textContent).toContain('ada@example.com');
    expect(container.textContent).toContain('+441234');
  });

  it('omits the phone line when there is no phone', () => {
    stubShopify({
      initialAttributes: pickupAttrs({name: 'Ada', email: 'ada@example.com'}),
    });

    const {container} = render(<InfoDisplay />);

    expect(container.querySelectorAll('s-text')).toHaveLength(2);
  });

  it('falls back to a hardcoded heading when untranslated', () => {
    stubShopify({
      isoCode: 'de',
      initialAttributes: pickupAttrs({name: 'Ada', email: 'a@b.c'}),
    });

    const {container} = render(<InfoDisplay />);

    expect(container.textContent).toContain('Pickup person');
  });
});

describe('AttributeCleanup', () => {
  it('renders nothing', () => {
    const {container} = render(<AttributeCleanup />);

    expect(container.innerHTML).toBe('');
  });

  it('clears all three attributes when the buyer switches to shipping', async () => {
    stubShopify({
      initialAttributes: pickupAttrs({
        name: 'Ada',
        email: 'ada@example.com',
        phone: '+441234',
      }),
      deliveryGroups: [group('ship-1', [SHIPPING, PICKUP])],
    });

    render(<AttributeCleanup />);
    await settle();

    expect(applyAttributeChange.mock.calls.map(([c]) => c)).toEqual([
      {type: 'updateAttribute', key: 'PersonalPickupName', value: ''},
      {type: 'updateAttribute', key: 'PersonalPickupEmail', value: ''},
      {type: 'updateAttribute', key: 'PersonalPickupPhone', value: ''},
    ]);
  });

  it('leaves the attributes alone for an in-person pickup', async () => {
    stubShopify({
      initialAttributes: pickupAttrs({name: 'Ada', email: 'ada@example.com'}),
      deliveryGroups: [group('pickup-1', [SHIPPING, PICKUP])],
    });

    render(<AttributeCleanup />);
    await settle();

    expect(applyAttributeChange).not.toHaveBeenCalled();
  });

  it('does nothing before a delivery option is selected', async () => {
    stubShopify({
      initialAttributes: pickupAttrs({name: 'Ada', email: 'ada@example.com'}),
      deliveryGroups: [group(undefined, [SHIPPING, PICKUP])],
    });

    render(<AttributeCleanup />);
    await settle();

    expect(applyAttributeChange).not.toHaveBeenCalled();
  });

  it('does nothing with no delivery groups', async () => {
    stubShopify({
      initialAttributes: pickupAttrs({name: 'Ada', email: 'ada@example.com'}),
      deliveryGroups: [],
    });

    render(<AttributeCleanup />);
    await settle();

    expect(applyAttributeChange).not.toHaveBeenCalled();
  });

  it('only clears attributes that actually have a value', async () => {
    // Keeps it settling after one pass instead of writing empties every render.
    stubShopify({
      initialAttributes: pickupAttrs({name: 'Ada'}),
      deliveryGroups: [group('ship-1', [SHIPPING])],
    });

    render(<AttributeCleanup />);
    await settle();

    expect(applyAttributeChange).toHaveBeenCalledTimes(1);
    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'PersonalPickupName',
      value: '',
    });
  });

  it('does nothing when there is nothing stored', async () => {
    stubShopify({deliveryGroups: [group('ship-1', [SHIPPING])]});

    render(<AttributeCleanup />);
    await settle();

    expect(applyAttributeChange).not.toHaveBeenCalled();
  });
});
