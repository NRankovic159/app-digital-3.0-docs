// @ts-check

/**
 * @typedef {import("../generated/api").InputQuery} InputQuery
 * @typedef {import("../generated/api").FunctionResult} FunctionResult
 */

/**
 * @param {InputQuery} input
 * @returns {FunctionResult}
 */
export function run(input) {
  const operations = [];
  const { localization } = input;
  const { isoCode } = localization?.language || 'en';
  const lowerCaseIsoCode = isoCode?.toLowerCase();

  const containsPreOrderItems = hasPreOrderItems(input.cart.lines);
  const containsZMPNItems = hasZMPNItems(input.cart.lines);
  const containsBundles = hasBundleItems(input.cart.lines);

  // Get eligible fufullment locations
  const allFufillmentLocations = input.fulfillmentGroups.flatMap((group) => {
    // Check fulfillment group lines to ensure there is more than just applecare in the group
    const onlyAppleCareLines = group.lines.length > 0 && group.lines.every((line) => {
      if (line.merchandise.__typename !== 'ProductVariant') return false;
      const isAppleCare = line.merchandise.product.productType === 'AppleCare';
      const isSecondWarranty = line.merchandise.product.productType === 'SecondWarranty';
      return isSecondWarranty || isAppleCare;
    });

    // if fufillment group only contains apple care lines don't show locations
    if (onlyAppleCareLines) return [];

    return group.inventoryLocationHandles;
  });
  const uniqueFulfillmentLocations = [...new Set(allFufillmentLocations)];

  // Filter by locations that are available on all fulfillment groups
  const fulfillmentLocationsWhereAllAvailable = uniqueFulfillmentLocations.filter(
    (location) => input.fulfillmentGroups.every(
      (group) => group.inventoryLocationHandles.includes(location)
    )
  );

  // If location meets all requirements, add to operations list
  input.locations.forEach((location) => {
    const {
      storeLocatorEnabled,
      checkoutEnabled,
      preOrderEnabled,
      CTOEnabled,
    } = location.enableToggles?.jsonValue || {};
    const enabled = location.localPickup.enabled;
    const enabledInLocator = metafieldToBool(storeLocatorEnabled);
    const enabledInCheckout = metafieldToBool(checkoutEnabled);
    const allowsPreOrderPickup = metafieldToBool(preOrderEnabled);
    const allowsCTOPickup = metafieldToBool(CTOEnabled);

    // Skip if not enabled for locator page or checkout page
    if (!enabled || !enabledInLocator || !enabledInCheckout) return;

    // Skip if not enabled for pre-order, and cart contains pre-order items
    if (containsPreOrderItems && !allowsPreOrderPickup) return;

    // Skip if not enabled for CTO/ZMPN, and cart contains CTO/ZMPN items
    if (containsZMPNItems && !allowsCTOPickup) return;
    const localizedPickupMessages = location.pickupMessages?.jsonValue?.[lowerCaseIsoCode];

    let pickupMessage = localizedPickupMessages?.inStock;
    const productWithInStockMessage = input.cart.lines.find((line) => {
      if (line.merchandise.__typename !== 'ProductVariant') return false;
      if (line.merchandise.product.isPreOrder?.value) return false;
      const productPickupMessages = line.merchandise.product.pickupMessages?.jsonValue;
      const localizedProductPickupMessages = productPickupMessages?.[lowerCaseIsoCode]
      const hasMessage = localizedProductPickupMessages?.inStock
      return hasMessage;
    })

    if (productWithInStockMessage) {
      if (productWithInStockMessage.merchandise.__typename === 'ProductVariant') {
        const productPickupMessages = productWithInStockMessage.merchandise.product.pickupMessages?.jsonValue;
        pickupMessage = productPickupMessages?.[lowerCaseIsoCode]?.inStock;
      }
    }

    const availableInStore = fulfillmentLocationsWhereAllAvailable.includes(location.handle);
    if (!availableInStore) return;

    // If Pre-Order - Use Pre-Order Message
    if (containsPreOrderItems) {
      const preOrderItem = input.cart.lines.find(isPreOrderItem);
      const productPickupMessages = preOrderItem?.merchandise.product.pickupMessages?.jsonValue;
      const productMessages = productPickupMessages?.[lowerCaseIsoCode]
      if (productMessages?.preOrder) {
        pickupMessage = productMessages.preOrder;
      } else {
        pickupMessage = localizedPickupMessages?.preOrder;
      }
    }

    if (containsZMPNItems) {
      const ctoProductItem = input.cart.lines.find((line) => {
        if (line.merchandise.__typename !== 'ProductVariant') return false;
        if (!line.merchandise.product.isCTOorMPN) return false;
        return metafieldToBool(line.merchandise.product.isCTOorMPN);
      });
      const productPickupMessages = ctoProductItem?.merchandise.product.pickupMessages?.jsonValue;
      const productMessages = productPickupMessages?.[lowerCaseIsoCode];
      if (productMessages?.cto) {
        pickupMessage = productMessages.cto;
      } else {
        pickupMessage = localizedPickupMessages?.cto;
      }
    }

    if(containsBundles) {
      pickupMessage = localizedPickupMessages?.cto;
    }

    operations.push({
      add: {
        title: location.name,
        pickupLocation: {
          locationHandle: location.handle,
          pickupInstruction: pickupMessage ? stripHtml(pickupMessage) : undefined,
        }
      }
    })
  });

  return {
    operations,
  };
};

/**
 * Check if a cart line is a pre-order item by checking its metafield or attributes.
 * @param {InputQuery["cart"]["lines"][0]} line
 * @returns {Boolean}
 */
const isPreOrderItem = (line) => {
  if (line.merchandise.__typename !== 'ProductVariant') return false;
  
  const hasPreOrderMetafield = line.merchandise.product.isPreOrder ? metafieldToBool(line.merchandise.product.isPreOrder) : false;
  const hasPreOrderAttribute = line.preOrderAttr?.value === 'true';

  return hasPreOrderMetafield || hasPreOrderAttribute;
};


/**
 * Check cart for any pre-order items
 * @param {InputQuery["cart"]["lines"]} lines
 * @returns {Boolean}
 */
const hasPreOrderItems = (lines) => {
  return lines.some(isPreOrderItem);
}

/**
 * Check cart for CTO/ZMPN items
 * @param {InputQuery["cart"]["lines"]} lines
 * @returns {Boolean}
 */
const hasZMPNItems = (lines) => {
  return lines.some((line) => {
    if (line.merchandise.__typename !== 'ProductVariant') return false;
    if (!line.merchandise.product.isCTOorMPN) return false;
    return metafieldToBool(line.merchandise.product.isCTOorMPN);
  });
}

/**
 * Check cart for bundle items
 * @param {InputQuery["cart"]["lines"]} lines
 * @returns {Boolean}
 */
const hasBundleItems = (lines) => {
  return lines.some((line) => {
    return (line.bundleUUID && line.bundleUUID?.value)
  });
}

/**
 * Convert Metafield to Boolean
 * @param metafield
 * @returns {Boolean}
 */
const metafieldToBool = (metafield) => {
  if (metafield === undefined || metafield === null) return true;
  if (typeof metafield === 'boolean') return metafield;
  if (metafield.value && typeof metafield.value === 'boolean') return metafield.value;
  if (metafield.value && typeof metafield.value === 'string') return stringToBool(metafield.value);
  return stringToBool(metafield);
}

/**
 * Convert a string to boolean value
 * @param {String} str
 * @returns {Boolean}
 */
const stringToBool = (str) => {
  return str === 'true' ? true : false;
}

/**
 * Strip html elements from string
 * @param {String} htmlString
 * @returns {String}
 */
const stripHtml = (htmlString) => {
  return htmlString ? htmlString.replace(/<\/?[^>]+(>|$)/g, '') : '';
}