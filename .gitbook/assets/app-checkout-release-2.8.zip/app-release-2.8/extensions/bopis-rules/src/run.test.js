import { describe, it, expect } from 'vitest';
import { run } from './run';

/**
 * @typedef {import("../generated/api").FunctionResult} FunctionResult
 */

const LOCATION_HANDLE = '2578303';

/**
 * Build a cart line matching the shape of src/run.graphql.
 */
function line(product = {}, attrs = {}) {
  return {
    merchandise: {
      __typename: 'ProductVariant',
      product: {
        isCTOorMPN: null,
        isPreOrder: null,
        pickupMessages: null,
        ...product,
      },
    },
    bundleUUID: null,
    preOrderAttr: null,
    ...attrs,
  };
}

/**
 * Build a pickup location. `enableToggles.jsonValue` gates visibility; the run
 * function treats a missing toggle as enabled (see metafieldToBool).
 */
function location(overrides = {}) {
  return {
    handle: LOCATION_HANDLE,
    name: 'Main St.',
    localPickup: { enabled: true },
    enableToggles: {
      jsonValue: {
        storeLocatorEnabled: 'true',
        checkoutEnabled: 'true',
        preOrderEnabled: 'true',
        CTOEnabled: 'true',
      },
    },
    pickupMessages: {
      jsonValue: {
        en: {
          inStock: 'Usually ready in 24 hours.',
          preOrder: 'Ready when your pre-order ships.',
          cto: 'Ready in 5-7 business days.',
        },
      },
    },
    ...overrides,
  };
}

/**
 * Assemble a full input, defaulting to one plain line available at one location.
 */
function input(overrides = {}) {
  const lines = overrides.lines ?? [line()];
  return {
    cart: { lines },
    fulfillmentGroups: [
      {
        inventoryLocationHandles: [LOCATION_HANDLE],
        lines: lines.map((l) => ({ merchandise: l.merchandise })),
      },
    ],
    localization: { language: { isoCode: 'EN' } },
    locations: [location()],
    ...overrides.rest,
  };
}

describe('local pickup delivery option generator function', () => {
  it('offers an enabled location with its in-stock message', () => {
    const result = run(input());

    expect(result).toEqual(
      /** @type {FunctionResult} */ ({
        operations: [
          {
            add: {
              title: 'Main St.',
              pickupLocation: {
                locationHandle: LOCATION_HANDLE,
                pickupInstruction: 'Usually ready in 24 hours.',
              },
            },
          },
        ],
      }),
    );
  });

  it('skips a location with local pickup disabled', () => {
    const result = run({
      ...input(),
      locations: [location({ localPickup: { enabled: false } })],
    });

    expect(result.operations).toEqual([]);
  });

  it('skips a location disabled for checkout', () => {
    const result = run({
      ...input(),
      locations: [
        location({
          enableToggles: {
            jsonValue: { storeLocatorEnabled: 'true', checkoutEnabled: 'false' },
          },
        }),
      ],
    });

    expect(result.operations).toEqual([]);
  });

  it('skips a location not stocking every fulfillment group', () => {
    const base = input();
    const result = run({
      ...base,
      fulfillmentGroups: [
        { inventoryLocationHandles: [LOCATION_HANDLE], lines: [] },
        { inventoryLocationHandles: ['other-location'], lines: [] },
      ],
    });

    expect(result.operations).toEqual([]);
  });

  it('uses the pre-order message when the cart holds a pre-order item', () => {
    const preOrder = line({ isPreOrder: { value: 'true' } });
    const result = run(input({ lines: [preOrder] }));

    expect(result.operations[0].add.pickupLocation.pickupInstruction).toBe(
      'Ready when your pre-order ships.',
    );
  });

  it('hides a pre-order cart from a location that disallows pre-order pickup', () => {
    const preOrder = line({ isPreOrder: { value: 'true' } });
    const result = run({
      ...input({ lines: [preOrder] }),
      locations: [
        location({
          enableToggles: {
            jsonValue: {
              storeLocatorEnabled: 'true',
              checkoutEnabled: 'true',
              preOrderEnabled: 'false',
            },
          },
        }),
      ],
    });

    expect(result.operations).toEqual([]);
  });

  it('uses the CTO message when the cart holds a CTO/ZMPN item', () => {
    const cto = line({ isCTOorMPN: { value: 'true' } });
    const result = run(input({ lines: [cto] }));

    expect(result.operations[0].add.pickupLocation.pickupInstruction).toBe(
      'Ready in 5-7 business days.',
    );
  });

  it('uses the CTO message when the cart holds a bundle', () => {
    const bundled = line({}, { bundleUUID: { value: 'uuid-1' } });
    const result = run(input({ lines: [bundled] }));

    expect(result.operations[0].add.pickupLocation.pickupInstruction).toBe(
      'Ready in 5-7 business days.',
    );
  });

  it('prefers a product-level pickup message over the location default', () => {
    const withMessage = line({
      pickupMessages: { jsonValue: { en: { inStock: 'Ships from this store today.' } } },
    });
    const result = run(input({ lines: [withMessage] }));

    expect(result.operations[0].add.pickupLocation.pickupInstruction).toBe(
      'Ships from this store today.',
    );
  });

  it('strips HTML from pickup instructions', () => {
    const result = run({
      ...input(),
      locations: [
        location({
          pickupMessages: {
            jsonValue: { en: { inStock: '<p>Ready <strong>today</strong></p>' } },
          },
        }),
      ],
    });

    expect(result.operations[0].add.pickupLocation.pickupInstruction).toBe(
      'Ready today',
    );
  });

  it('falls back to no instruction when the locale has no message', () => {
    const result = run({
      ...input(),
      localization: { language: { isoCode: 'FR' } },
    });

    expect(result.operations[0].add.pickupLocation.pickupInstruction).toBeUndefined();
  });

  it('hides locations when the group holds only AppleCare lines', () => {
    const appleCare = line({ productType: 'AppleCare' });

    const result = run({
      cart: { lines: [appleCare] },
      fulfillmentGroups: [
        {
          inventoryLocationHandles: [LOCATION_HANDLE],
          lines: [{ merchandise: appleCare.merchandise }],
        },
      ],
      localization: { language: { isoCode: 'EN' } },
      locations: [location()],
    });

    expect(result.operations).toEqual([]);
  });
});
