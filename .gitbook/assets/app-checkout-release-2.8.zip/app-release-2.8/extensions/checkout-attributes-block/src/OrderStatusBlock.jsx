import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {Extension} from './Extension.jsx';

export default async () => {
  render(<Extension />, document.body)
};
