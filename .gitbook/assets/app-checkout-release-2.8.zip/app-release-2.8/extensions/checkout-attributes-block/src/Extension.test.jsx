import {cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it} from 'vitest';

import {Extension} from './Extension.jsx';

const translationEntry = (byLanguage, key = 'checkout_attributes_block') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {
    block_heading: 'Order details',
    verification_heading: 'Verification',
    trade_in_heading: 'Trade-in',
  },
  fr: {
    block_heading: 'Détails de la commande',
    verification_heading: 'Vérification',
    trade_in_heading: 'Reprise',
  },
};

const DOCUMENT_ATTRIBUTES = [
  {key: 'VerificationIdType', value: 'Passport'},
  {key: 'VerificationId', value: '12345'},
];

const TRADE_IN_ATTRIBUTE = [{key: 'tradein', value: 'iPhone 14 Pro'}];

const stubShopify = ({
  settings = {enable: true},
  attributes = [],
  appMetafields = [translationEntry(TRANSLATIONS)],
  isoCode = 'en',
} = {}) => {
  globalThis.shopify = {
    settings: {value: settings},
    attributes: {value: attributes},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

describe('settings gate', () => {
  it('renders nothing when disabled', () => {
    stubShopify({settings: {enable: false}, attributes: TRADE_IN_ATTRIBUTE});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('defaults to enabled when the setting is absent', () => {
    // Unlike order-note, this block destructures `enable = true`. An unset
    // setting shows the block.
    stubShopify({settings: {}, attributes: TRADE_IN_ATTRIBUTE});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('iPhone 14 Pro');
  });
});

describe('attribute gating', () => {
  it('renders nothing when no relevant attributes are set', () => {
    stubShopify({attributes: [{key: 'somethingElse', value: 'x'}]});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders nothing when attributes are empty', () => {
    stubShopify({attributes: []});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders nothing when the id type is present but the id is not', () => {
    stubShopify({attributes: [{key: 'VerificationIdType', value: 'Passport'}]});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders nothing when the id is present but the type is not', () => {
    // Both halves are required: an id with no type reads as a bare number.
    stubShopify({attributes: [{key: 'VerificationId', value: '12345'}]});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('shows the verification section when both halves are present', () => {
    stubShopify({attributes: DOCUMENT_ATTRIBUTES});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Verification');
    expect(container.textContent).toContain('Passport 12345');
  });

  it('shows the trade-in section on its own', () => {
    stubShopify({attributes: TRADE_IN_ATTRIBUTE});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Trade-in');
    expect(container.textContent).toContain('iPhone 14 Pro');
    expect(container.textContent).not.toContain('Verification');
  });

  it('shows both sections together, verification first', () => {
    stubShopify({attributes: [...DOCUMENT_ATTRIBUTES, ...TRADE_IN_ATTRIBUTE]});

    const {container} = render(<Extension />);

    const text = container.textContent;
    expect(text).toContain('Passport 12345');
    expect(text).toContain('iPhone 14 Pro');
    expect(text.indexOf('Verification')).toBeLessThan(text.indexOf('Trade-in'));
  });

  it('treats an empty attribute value as absent', () => {
    stubShopify({
      attributes: [
        {key: 'VerificationIdType', value: 'Passport'},
        {key: 'VerificationId', value: ''},
      ],
    });

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });
});

describe('translations', () => {
  it('renders headings in the buyer language', () => {
    stubShopify({
      isoCode: 'fr-CA',
      attributes: [...DOCUMENT_ATTRIBUTES, ...TRADE_IN_ATTRIBUTE],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Détails de la commande');
    expect(container.textContent).toContain('Vérification');
    expect(container.textContent).toContain('Reprise');
  });

  it('renders the values but no headings for an untranslated language', () => {
    // No fallback to en — matches pre-migration behaviour.
    stubShopify({isoCode: 'de', attributes: DOCUMENT_ATTRIBUTES});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Passport 12345');
    expect(container.textContent).not.toContain('Verification');
  });

  it('omits the block heading when it is not translated', () => {
    stubShopify({
      appMetafields: [translationEntry({en: {verification_heading: 'Verification'}})],
      attributes: DOCUMENT_ATTRIBUTES,
    });

    const {container} = render(<Extension />);

    expect(container.querySelectorAll('s-heading')).toHaveLength(1);
  });

  it('still renders when the metafield is missing entirely', () => {
    stubShopify({appMetafields: [], attributes: DOCUMENT_ATTRIBUTES});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Passport 12345');
  });

  it('ignores a translations entry belonging to another extension', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {block_heading: 'Wrong block'}}, 'order_note'),
        translationEntry(TRANSLATIONS),
      ],
      attributes: DOCUMENT_ATTRIBUTES,
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Order details');
    expect(container.textContent).not.toContain('Wrong block');
  });
});
