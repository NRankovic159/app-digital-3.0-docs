import '@shopify/ui-extensions/preact';

import {readTranslations} from './translations.js';

/**
 * Shared between the thank-you page and the customer-account order status page.
 * Both targets expose `settings`, `attributes`, `appMetafields` and
 * `localization`, so one component serves both.
 *
 * Read-only: it displays checkout attributes written by other extensions in this
 * app (`tax-id-block` writes the verification pair, `trade-in-block` writes the
 * trade-in selection) and never mutates anything.
 */
export function Extension() {
  const {enable = true} = shopify.settings.value;
  const language = shopify.localization.language.value;
  const attributes = shopify.attributes.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'checkout_attributes_block',
    language,
  });

  if (!enable) return null;

  const documentAttributeType = attributes?.find(
    (attribute) => attribute.key === 'VerificationIdType',
  )?.value;
  const verificationId = attributes?.find(
    (attribute) => attribute.key === 'VerificationId',
  )?.value;
  const tradeInSelection = attributes?.find(
    (attribute) => attribute.key === 'tradein',
  )?.value;

  // Both halves of the pair are required — an id with no type reads as a bare
  // number, so the block stays hidden until both are present.
  const hasDocumentAttributes = documentAttributeType && verificationId;
  if (!hasDocumentAttributes && !tradeInSelection) return null;

  return (
    <s-stack
      direction="block"
      gap="base"
      justifyContent="start"
      alignItems="start"
      padding="base"
      borderRadius="base"
      border="base"
    >
      {localTranslations?.block_heading && (
        <s-heading>{localTranslations?.block_heading}</s-heading>
      )}

      {hasDocumentAttributes && (
        <s-stack direction="block" gap="base">
          <s-heading>{localTranslations?.verification_heading}</s-heading>
          <s-paragraph>
            {documentAttributeType} {verificationId}
          </s-paragraph>
        </s-stack>
      )}

      {tradeInSelection && (
        <s-stack direction="block" gap="base">
          <s-heading>{localTranslations?.trade_in_heading}</s-heading>
          <s-paragraph>{tradeInSelection}</s-paragraph>
        </s-stack>
      )}
    </s-stack>
  );
}
