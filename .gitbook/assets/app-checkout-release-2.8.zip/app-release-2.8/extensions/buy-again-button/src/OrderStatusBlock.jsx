import '@shopify/ui-extensions/preact';
import {render} from "preact";

export default async () => {
  render(<Extension />, document.body)
}

function Extension() {
  const cartLines = shopify.lines.value;
  const order = shopify.order.value;

  if (!order || !cartLines || cartLines.length === 0) {
    return null;
  }

  async function handleBuyAgainClick() {
    if (!order) return;

    const lines = cartLines
      .filter((line) => {
        const attrs = line.attributes ?? [];
        const hasBundleTitle = attrs.some((attr) => attr.key === '_bundle_title');
        const hasBundleUuid = attrs.some((attr) => attr.key === '_bundle_uuid');
        return !(hasBundleTitle && !hasBundleUuid);
      })
      .map((line) => ({
        merchandiseId: line.merchandise.id,
        quantity: line.quantity,
        attributes: (line.attributes ?? []).filter((attr) => attr.key !== '_tradeInEligible'),
      }));

    const cartAttributes = shopify.attributes?.value ?? [];

    // Storefront cartCreate mutation
    const mutation = `
      mutation BuyAgainCartCreate($lines: [CartLineInput!]!, $attributes: [AttributeInput!]) {
        cartCreate(input: { lines: $lines, attributes: $attributes }) {
          cart {
            id
            checkoutUrl
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

    try {
      const {data, errors} = await shopify.query(
        mutation,
        {
          variables: { lines, attributes: cartAttributes },
          // Storefront API version that supports cartCreate
          version: '2025-10',
        },
      );

      if (errors && errors.length > 0) {
        await shopify.toast.show('Something went wrong, please re-add these products manually');
        return;
      }

      const typedData = data
      const cartCreateResult = typedData;
      
      const checkoutUrl = cartCreateResult.cartCreate.cart.checkoutUrl;
      const userErrors = cartCreateResult && cartCreateResult.userErrors;
      
      if (userErrors && userErrors.length > 0) {
        await shopify.toast.show('Something went wrong, please re-add these products manually');
        return;
      }
      

      // Redirect to the checkout URL of the new cart
      const topWindow = window.top;
      if (topWindow) {
        topWindow.location.href = checkoutUrl;
      }
    } catch (error) {
      await shopify.toast.show('Something went wrong, please re-add these products manually');
    }
  }

  return (
    <s-stack direction="block" gap="base" paddingBlockStart="base">
      <s-stack direction="inline" gap="base" justifyContent="end">
        <s-button
          tone="neutral"
          variant="primary"
          onClick={handleBuyAgainClick}
        >
          {shopify.i18n.translate('buyAgain')}
        </s-button>
      </s-stack>
    </s-stack>
  );
}