import '@shopify/ui-extensions/preact';
import {render} from "preact";

// The shop's primary language is served without a locale prefix (`/cart`).
const PRIMARY_LANGUAGE = 'en';

export default async () => {
  render(<Extension />, document.body)
};

/**
 * `shop.storefrontUrl` always points to the primary-language storefront, while
 * other languages live in a URL subfolder (`/es/cart`), so add the buyer's
 * language as a prefix to keep it when returning to the cart.
 *
 * @param {{isoCode: string} | undefined} language value of `shopify.localization.language`
 * @returns {string}
 */
function getCartPath(language) {
  const [languageCode] = language?.isoCode?.toLowerCase().split('-') || [PRIMARY_LANGUAGE];
  return languageCode === PRIMARY_LANGUAGE ? '/cart' : `/${languageCode}/cart`;
}

function Extension() {
  const {storefrontUrl} = shopify.shop;
  const cartPath = getCartPath(shopify.localization.language.value);
  const linkText = shopify.i18n.translate("cartLinkText");

  const handleClick = () => {
    shopify.analytics.publish('return_to_cart_clicked', {
      event_category: 'ecommerce',
      event_location: 'Checkout',
      event_action: 'return_to_cart',
      event_label: linkText,
      click_url: cartPath,
    });
  };

  return (
    <s-stack direction='inline'>
      <s-link href={new URL(cartPath, storefrontUrl).href} onClick={handleClick}>
        <s-stack direction='inline' alignItems='center' gap='small-500'>
          <s-icon type="chevron-left" size='small' /><s-text>{linkText}</s-text>
        </s-stack>
      </s-link>
    </s-stack>
  );
}