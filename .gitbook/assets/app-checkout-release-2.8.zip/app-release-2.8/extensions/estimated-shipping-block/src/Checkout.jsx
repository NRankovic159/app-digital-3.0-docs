import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {readTranslations} from './translations.js';

export default async () => {
  render(<Extension />, document.body)
};

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const {enable} = shopify.settings.value;
  const language = shopify.localization.language.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'estimated_shipping',
    language,
  });

  if (!enable) return null;

  return (
    <s-stack direction="block" gap="large-500">
      <s-stack direction="block" gap="large-200">
        <CenteredHeading>{localTranslations?.delivery_heading}</CenteredHeading>
        <s-stack direction="block" gap="base">
          {localTranslations?.delivery_list?.length > 0 && (
            <s-unordered-list>
              {localTranslations?.delivery_list?.map((item, idx) => (
                <s-list-item key={item.heading + idx}>
                  <s-text>
                    <s-text type="strong">{item.heading}</s-text> {'->'} {item.content}
                  </s-text>
                </s-list-item>
              ))}
            </s-unordered-list>
          )}

          {localTranslations?.delivery_text_block && (
            <s-paragraph>
              {localTranslations?.delivery_text_block}
            </s-paragraph>
          )}
        </s-stack>
      </s-stack>

      <s-stack direction="block" gap="large-200">
        {localTranslations?.presale_delivery_heading && (
          <CenteredHeading>
            {localTranslations?.presale_delivery_heading}
          </CenteredHeading>
        )}

        <s-stack direction="block" gap="base">
          {localTranslations?.presale_delivery_text_block && (
            <s-paragraph>
              {localTranslations?.presale_delivery_text_block}
            </s-paragraph>
          )}

          {localTranslations?.presale_delivery_text_block_secondary && (
            <s-paragraph>
              {localTranslations?.presale_delivery_text_block_secondary}
            </s-paragraph>
          )}

          {localTranslations?.presale_delivery_links?.length > 0 && (
            <s-stack direction="block" gap="base">
              {localTranslations?.presale_delivery_links?.map((item, idx) => (
                <s-stack
                  key={item.heading + idx.toString()}
                  direction="inline"
                  gap="none"
                  alignItems="start"
                >
                  <s-text type="small">{'*'.repeat(idx + 1)}</s-text>
                  <s-link href={item.url} target="_blank">
                    {item.text}
                  </s-link>
                </s-stack>
              ))}
            </s-stack>
          )}
        </s-stack>
      </s-stack>
    </s-stack>
  );
}

function CenteredHeading({children}) {
  return (
    <s-stack direction="block" alignItems="center">
      <s-heading>{children}</s-heading>
    </s-stack>
  );
}
