import {cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it} from 'vitest';

import {Extension} from './Checkout.jsx';

const KEY = 'estimated_shipping';

const translationEntry = (byLanguage) => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key: KEY,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const FULL_EN = {
  delivery_heading: 'Delivery times',
  delivery_list: [
    {heading: 'Shipping to Store 1', content: '2 to 5 business days'},
    {heading: 'Shipping to Store 2', content: '5 to 9 business days'},
  ],
  delivery_text_block: 'Purchases made to Dalas have an additional validation.',
  presale_delivery_heading: 'Delivery times Pre-Sale mode',
  presale_delivery_text_block: 'Pre-sale primary copy',
  presale_delivery_text_block_secondary: 'Pre-sale secondary copy',
  presale_delivery_links: [
    {text: 'Delivery times', url: '/pages/delivery'},
    {text: 'Returns', url: '/pages/returns'},
  ],
};

/**
 * Minimal stand-in for the `shopify` global. `settings` is passed through
 * verbatim so a test can omit `enable` entirely, not just set it false.
 */
const stubShopify = ({
  settings = {enable: true},
  appMetafields = [],
  isoCode = 'en',
} = {}) => {
  globalThis.shopify = {
    settings: {value: settings},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
  };
};

beforeEach(() => {
  stubShopify();
});

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

describe('enable setting', () => {
  it('renders nothing when the block is disabled', () => {
    stubShopify({
      settings: {enable: false},
      appMetafields: [translationEntry({en: FULL_EN})],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('renders nothing when the setting was never saved', () => {
    stubShopify({settings: {}, appMetafields: [translationEntry({en: FULL_EN})]});

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('renders content when enabled', () => {
    stubShopify({appMetafields: [translationEntry({en: FULL_EN})]});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Delivery times');
  });
});

describe('delivery section', () => {
  it('renders every list entry as a list item with heading and content', () => {
    stubShopify({appMetafields: [translationEntry({en: FULL_EN})]});

    const {container} = render(<Extension />);
    const items = container.querySelectorAll('s-list-item');

    expect(items).toHaveLength(2);
    expect(items[0].textContent).toContain('Shipping to Store 1');
    expect(items[0].textContent).toContain('2 to 5 business days');
    expect(items[1].textContent).toContain('Shipping to Store 2');
  });

  it('renders the list inside an unordered list', () => {
    stubShopify({appMetafields: [translationEntry({en: FULL_EN})]});

    const {container} = render(<Extension />);

    expect(container.querySelectorAll('s-unordered-list')).toHaveLength(1);
  });

  it('omits the list entirely when it is empty', () => {
    stubShopify({
      appMetafields: [translationEntry({en: {...FULL_EN, delivery_list: []}})],
    });

    const {container} = render(<Extension />);

    expect(container.querySelector('s-unordered-list')).toBeNull();
  });

  it('omits the list when the key is absent', () => {
    const {delivery_list: _omitted, ...withoutList} = FULL_EN;
    stubShopify({appMetafields: [translationEntry({en: withoutList})]});

    const {container} = render(<Extension />);

    expect(container.querySelector('s-unordered-list')).toBeNull();
    expect(container.textContent).toContain('Delivery times');
  });

  it('omits the delivery paragraph when it is blank', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {...FULL_EN, delivery_text_block: ''}}),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).not.toContain('additional validation');
  });
});

describe('pre-sale section', () => {
  it('renders both paragraphs and every link', () => {
    stubShopify({appMetafields: [translationEntry({en: FULL_EN})]});

    const {container} = render(<Extension />);
    const links = container.querySelectorAll('s-link');

    expect(container.textContent).toContain('Pre-sale primary copy');
    expect(container.textContent).toContain('Pre-sale secondary copy');
    expect(links).toHaveLength(2);
    expect(links[0].getAttribute('href')).toBe('/pages/delivery');
    expect(links[0].getAttribute('target')).toBe('_blank');
    expect(links[1].getAttribute('href')).toBe('/pages/returns');
  });

  it('marks each link with an incrementing run of asterisks', () => {
    stubShopify({appMetafields: [translationEntry({en: FULL_EN})]});

    const {container} = render(<Extension />);
    const markers = [...container.querySelectorAll('s-text[type="small"]')].map(
      (node) => node.textContent,
    );

    expect(markers).toEqual(['*', '**']);
  });

  it('omits the pre-sale heading when it is blank', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {...FULL_EN, presale_delivery_heading: ''}}),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).not.toContain('Pre-Sale mode');
  });

  it('omits the links when there are none', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {...FULL_EN, presale_delivery_links: []}}),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.querySelector('s-link')).toBeNull();
  });
});

describe('translations', () => {
  it('renders the buyer language, not the default', () => {
    stubShopify({
      isoCode: 'fr-CA',
      appMetafields: [
        translationEntry({
          en: FULL_EN,
          fr: {
            delivery_heading: 'Délais de livraison',
            delivery_list: [{heading: 'Livraison en magasin', content: '2 à 5 jours'}],
            delivery_text_block: 'Validation supplémentaire',
            presale_delivery_heading: 'Délais en prévente',
            presale_delivery_links: [{text: 'Nos délais', url: '/fr/delais'}],
          },
        }),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Délais de livraison');
    expect(container.textContent).toContain('Livraison en magasin');
    expect(container.textContent).toContain('Nos délais');
    // Nothing from the en payload may leak through.
    expect(container.textContent).not.toContain('Shipping to Store');
    expect(container.textContent).not.toContain('Pre-Sale mode');
    expect(container.textContent).not.toContain('Pre-sale primary copy');
  });

  it('renders an empty shell when the metafield is missing', () => {
    // Enabled but untranslated: every section is conditional, so nothing but
    // the empty heading slot renders. It must not throw.
    stubShopify();

    const {container} = render(<Extension />);

    expect(container.querySelector('s-link')).toBeNull();
    expect(container.querySelector('s-unordered-list')).toBeNull();
    expect(container.textContent).toBe('');
  });

  it('ignores a same-key metafield from another namespace', () => {
    stubShopify({
      appMetafields: [
        {
          target: {type: 'shop', id: 'gid://shopify/Shop/1'},
          metafield: {
            namespace: 'apple',
            key: KEY,
            value: JSON.stringify({value: {en: FULL_EN}}),
            type: 'json',
          },
        },
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });
});
