// @ts-check

/**
 * @typedef {import("../generated/api").CartDeliveryOptionsTransformRunInput} CartDeliveryOptionsTransformRunInput
 * @typedef {import("../generated/api").CartDeliveryOptionsTransformRunResult} CartDeliveryOptionsTransformRunResult
 */

/**
 * @type {CartDeliveryOptionsTransformRunResult}
 */
const NO_CHANGES = {
  operations: [],
};

/**
 * @param {CartDeliveryOptionsTransformRunInput} input
 * @returns {CartDeliveryOptionsTransformRunResult}
 */
export function cartDeliveryOptionsTransformRun(input) {
  const selectedLocation = input?.cart?.attribute?.value;

  if (!selectedLocation || !input.cart.deliveryGroups?.length) {
    console.error("No selected location or delivery groups found.");
    return NO_CHANGES;
  }

  const deliveryGroup = input.cart.deliveryGroups[0];

  const optionToMove = deliveryGroup.deliveryOptions.find(
    (option) => option.title === selectedLocation
  );

  if (!optionToMove) {
    return NO_CHANGES;
  }

  const reorderOperation = {
    deliveryOptionMove: {
      deliveryOptionHandle: optionToMove.handle,
      index: 0,
    },
  };

  return {
    operations: [reorderOperation],
  };
};