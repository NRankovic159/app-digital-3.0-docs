import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { cartDeliveryOptionsTransformRun } from './cart_delivery_options_transform_run';

/**
 * @typedef {import("../generated/api").CartDeliveryOptionsTransformRunResult} CartDeliveryOptionsTransformRunResult
 */

/**
 * Build an input matching src/cart_delivery_options_transform_run.graphql.
 */
function input(selectedLocation, deliveryOptions) {
  return {
    cart: {
      attribute: selectedLocation === null ? null : { value: selectedLocation },
      deliveryGroups: deliveryOptions === null ? [] : [{ deliveryOptions }],
    },
  };
}

const OPTIONS = [
  { handle: 'handle-a', title: 'Downtown Store' },
  { handle: 'handle-b', title: 'Airport Store' },
  { handle: 'handle-c', title: 'Main St.' },
];

describe('cart delivery options transform function', () => {
  beforeEach(() => {
    // The no-op paths log to stderr by design; keep test output readable.
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('moves the selected pickup location to the top', () => {
    const result = cartDeliveryOptionsTransformRun(input('Airport Store', OPTIONS));

    expect(result).toEqual(
      /** @type {CartDeliveryOptionsTransformRunResult} */ ({
        operations: [
          { deliveryOptionMove: { deliveryOptionHandle: 'handle-b', index: 0 } },
        ],
      }),
    );
  });

  it('still emits a move when the selected option is already first', () => {
    const result = cartDeliveryOptionsTransformRun(input('Downtown Store', OPTIONS));

    expect(result.operations).toEqual([
      { deliveryOptionMove: { deliveryOptionHandle: 'handle-a', index: 0 } },
    ]);
  });

  it('returns no operations when no location attribute is set', () => {
    expect(cartDeliveryOptionsTransformRun(input(null, OPTIONS))).toEqual({
      operations: [],
    });
  });

  it('returns no operations when the attribute value is empty', () => {
    expect(cartDeliveryOptionsTransformRun(input('', OPTIONS))).toEqual({
      operations: [],
    });
  });

  it('returns no operations when there are no delivery groups', () => {
    expect(cartDeliveryOptionsTransformRun(input('Main St.', null))).toEqual({
      operations: [],
    });
  });

  it('returns no operations when the selected location has no matching option', () => {
    const result = cartDeliveryOptionsTransformRun(
      input('Nonexistent Store', OPTIONS),
    );

    expect(result).toEqual({ operations: [] });
  });

  it('matches option titles exactly, not by prefix', () => {
    const result = cartDeliveryOptionsTransformRun(input('Main', OPTIONS));

    expect(result).toEqual({ operations: [] });
  });

  it('tolerates a missing cart entirely', () => {
    expect(cartDeliveryOptionsTransformRun({})).toEqual({ operations: [] });
  });
});
