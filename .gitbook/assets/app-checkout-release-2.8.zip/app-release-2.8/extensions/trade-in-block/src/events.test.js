import {describe, expect, it} from 'vitest';

import {firstSelectedValue} from './events.js';

describe('firstSelectedValue', () => {
  const eventFrom = (currentTarget) => ({currentTarget});

  it('reads the first selected value', () => {
    expect(firstSelectedValue(eventFrom({values: ['Yes']}))).toBe('Yes');
  });

  it('takes only the first when several are selected', () => {
    // This list is single-select, but `values` is always an array.
    expect(firstSelectedValue(eventFrom({values: ['Yes', 'No']}))).toBe('Yes');
  });

  it('returns an empty string when nothing is selected', () => {
    expect(firstSelectedValue(eventFrom({values: []}))).toBe('');
  });

  it('returns an empty string when there are no values or no target', () => {
    expect(firstSelectedValue(eventFrom({}))).toBe('');
    expect(firstSelectedValue(eventFrom(null))).toBe('');
  });
});
