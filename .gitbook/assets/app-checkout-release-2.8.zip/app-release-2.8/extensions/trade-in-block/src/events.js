/**
 * Form-event helpers.
 */

/**
 * The first selected value of the choice list that raised an event.
 *
 * `s-choice-list` always reports selection as an array (`values`), even when
 * `multiple` is false, where the React `ChoiceList` gave a bare string for
 * single-select. This list is single-select, so the first entry is the selection.
 * @param {Event} event
 * @returns {String}
 */
export const firstSelectedValue = (event) => {
  const [value] =
    /** @type {{values?: String[]}} */ (event.currentTarget)?.values || [];
  return value ?? '';
};
