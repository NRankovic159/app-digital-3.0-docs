import {act, cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {
  ELIGIBLE_LINE_ATTRIBUTE,
  Extension,
  TRADE_IN_ATTRIBUTE,
  hasTradeInEligibleLines,
} from './Checkout.jsx';

const translationEntry = (byLanguage, key = 'trade-in') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {
    heading: 'Trade in your device',
    summary: 'Get credit towards your purchase.',
    yes_text: 'Yes please',
    no_text: 'No thanks',
    modal_trigger: 'How does it work?',
    modal_heading: 'Trade-in details',
    modal_content: 'Send us your old device within 14 days.',
  },
  fr: {
    heading: 'Reprise de votre appareil',
    yes_text: 'Oui',
    no_text: 'Non',
  },
};

const eligibleLine = (eligible = 'true') => ({
  id: 'gid://shopify/CartLine/1',
  quantity: 1,
  attributes: [{key: ELIGIBLE_LINE_ATTRIBUTE, value: eligible}],
  merchandise: {id: 'gid://shopify/ProductVariant/1'},
});

let applyAttributeChange;

const stubShopify = ({
  settings = {},
  attributes = [],
  lines = [eligibleLine()],
  appMetafields = [translationEntry(TRANSLATIONS)],
  isoCode = 'en',
} = {}) => {
  applyAttributeChange = vi.fn().mockResolvedValue({type: 'success'});
  globalThis.shopify = {
    settings: {value: settings},
    attributes: {value: attributes},
    lines: {value: lines},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    applyAttributeChange,
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

const choiceList = (container) => container.querySelector('s-choice-list');
const choices = (container) => [...container.querySelectorAll('s-choice')];

const selectedValues = (element) =>
  Array.isArray(element.values)
    ? element.values
    : (element.getAttribute('values') ?? '').split(',').filter(Boolean);

const choose = (container, value) => {
  const list = choiceList(container);
  list.values = [value];
  act(() => {
    list.dispatchEvent(new Event('change'));
  });
};

describe('hasTradeInEligibleLines', () => {
  it('is true when a line is flagged eligible', () => {
    expect(hasTradeInEligibleLines([eligibleLine()])).toBe(true);
  });

  it('is false when the flag is not the string "true"', () => {
    expect(hasTradeInEligibleLines([eligibleLine('false')])).toBe(false);
    expect(hasTradeInEligibleLines([eligibleLine('1')])).toBe(false);
    expect(hasTradeInEligibleLines([eligibleLine('True')])).toBe(false);
  });

  it('is false when no line carries the attribute', () => {
    expect(
      hasTradeInEligibleLines([{id: 'x', quantity: 1, attributes: []}]),
    ).toBe(false);
  });

  it('is true when only one of several lines is eligible', () => {
    expect(
      hasTradeInEligibleLines([
        {id: 'x', quantity: 1, attributes: []},
        eligibleLine(),
      ]),
    ).toBe(true);
  });

  it('is false for an empty or missing cart', () => {
    expect(hasTradeInEligibleLines([])).toBe(false);
    expect(hasTradeInEligibleLines(undefined)).toBe(false);
  });
});

describe('gating', () => {
  it('renders nothing when no cart line is eligible', () => {
    stubShopify({lines: [{id: 'x', quantity: 1, attributes: []}]});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders nothing when the block is disabled', () => {
    stubShopify({settings: {enable: false}});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('defaults to enabled when the setting is absent', () => {
    stubShopify({settings: {}});

    const {container} = render(<Extension />);

    expect(choiceList(container)).not.toBeNull();
  });

  it('renders nothing for an empty cart', () => {
    stubShopify({lines: []});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });
});

describe('choices', () => {
  it('offers exactly two translated choices, yes first', () => {
    const {container} = render(<Extension />);

    expect(choices(container).map((c) => c.getAttribute('value'))).toEqual([
      'Yes please',
      'No thanks',
    ]);
  });

  it('falls back to hardcoded Yes/No when untranslated', () => {
    stubShopify({isoCode: 'de'});

    const {container} = render(<Extension />);

    expect(choices(container).map((c) => c.getAttribute('value'))).toEqual([
      'Yes',
      'No',
    ]);
  });

  it('starts on the "no" choice', () => {
    const {container} = render(<Extension />);

    expect(selectedValues(choiceList(container))).toEqual(['No thanks']);
  });

  it('starts on "no" even when the saved attribute says yes', () => {
    stubShopify({
      attributes: [{key: TRADE_IN_ATTRIBUTE, value: 'Yes please'}],
    });

    const {container} = render(<Extension />);

    expect(selectedValues(choiceList(container))).toEqual(['No thanks']);
  });
});

describe('writing the answer', () => {
  it('writes the yes value when yes is chosen', () => {
    const {container} = render(<Extension />);

    choose(container, 'Yes please');

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: TRADE_IN_ATTRIBUTE,
      value: 'Yes please',
    });
  });

  it('writes the no value when no is chosen', () => {
    const {container} = render(<Extension />);

    choose(container, 'No thanks');

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: TRADE_IN_ATTRIBUTE,
      value: 'No thanks',
    });
  });

  it('writes nothing until the buyer chooses', () => {
    render(<Extension />);

    expect(applyAttributeChange).not.toHaveBeenCalled();
  });

  it('reflects the new choice back into the control', () => {
    const {container} = render(<Extension />);

    choose(container, 'Yes please');

    expect(selectedValues(choiceList(container))).toEqual(['Yes please']);
  });

  it('writes the translated value, so the attribute is language-dependent', () => {
    // Worth pinning: the stored value is display copy, not a stable token, so a
    // French buyer stores "Oui". checkout-attributes-block echoes it verbatim.
    stubShopify({isoCode: 'fr'});
    const {container} = render(<Extension />);

    choose(container, 'Oui');

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: TRADE_IN_ATTRIBUTE,
      value: 'Oui',
    });
  });

  it('posts under the checkout attributes form name', () => {
    const {container} = render(<Extension />);

    expect(choiceList(container).getAttribute('name')).toBe(
      'checkout[attributes][tradein]',
    );
  });
});

describe('copy and modal', () => {
  it('renders the heading and summary', () => {
    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Trade in your device');
    expect(container.textContent).toContain('Get credit towards your purchase.');
  });

  it('renders the modal trigger as a link wired to the modal id', () => {
    const {container} = render(<Extension />);
    const link = container.querySelector('s-link');

    expect(link.textContent).toContain('How does it work?');
    expect(link.getAttribute('command')).toBe('--show');
    expect(link.getAttribute('commandfor')).toBe('trade-in-modal');
    expect(container.querySelector('s-modal').getAttribute('id')).toBe(
      'trade-in-modal',
    );
  });

  it('omits the trigger when no trigger copy is configured', () => {
    stubShopify({
      appMetafields: [translationEntry({en: {heading: 'Trade in'}})],
    });

    const {container} = render(<Extension />);

    expect(container.querySelector('s-link')).toBeNull();
  });

  it('renders the modal heading and content', () => {
    const {container} = render(<Extension />);
    const modal = container.querySelector('s-modal');

    expect(modal.getAttribute('heading')).toBe('Trade-in details');
    expect(modal.textContent).toContain('Send us your old device within 14 days.');
  });

  it('uses the buyer language for a regional locale', () => {
    stubShopify({isoCode: 'fr-CA'});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Reprise de votre appareil');
  });

  it('ignores a translations entry belonging to another extension', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {heading: 'Wrong block'}}, 'order_note'),
        translationEntry(TRANSLATIONS),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Trade in your device');
    expect(container.textContent).not.toContain('Wrong block');
  });
});
