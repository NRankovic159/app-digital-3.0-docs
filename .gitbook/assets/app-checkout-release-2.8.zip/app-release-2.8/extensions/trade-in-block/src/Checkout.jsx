import '@shopify/ui-extensions/preact';
import {useSignal} from '@preact/signals';
import {render} from "preact";

import {firstSelectedValue} from './events.js';
import {readTranslations} from './translations.js';

export default async () => {
  render(<Extension />, document.body)
};

/** Cart attribute this block writes the buyer's answer to. */
export const TRADE_IN_ATTRIBUTE = 'tradein';

/** Line attribute marking a product as trade-in eligible. */
export const ELIGIBLE_LINE_ATTRIBUTE = '_tradeInEligible';

const MODAL_ID = 'trade-in-modal';

/**
 * Whether any cart line is flagged trade-in eligible.
 *
 * Exported for unit tests: this is the gate that decides whether the block shows
 * at all, so a regression here either hides it from eligible carts or offers
 * trade-in on every order.
 * @param {Array} lines value of `shopify.lines`
 * @returns {Boolean}
 */
export const hasTradeInEligibleLines = (lines) =>
  Boolean(
    lines?.some(
      (line) =>
        line?.attributes?.find(
          (attribute) => attribute.key === ELIGIBLE_LINE_ATTRIBUTE,
        )?.value === 'true',
    ),
  );

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const attributes = shopify.attributes.value;
  const language = shopify.localization.language.value;
  const lines = shopify.lines.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'trade-in',
    language,
  });
  const {enable = true} = shopify.settings.value;

  const yes_text = localTranslations?.yes_text || 'Yes';
  const no_text = localTranslations?.no_text || 'No';

  const previousSelection = /** @type {any} */ (
    attributes?.find((attribute) => attribute.key === TRADE_IN_ATTRIBUTE)
  );
  const selected = useSignal(
    previousSelection === yes_text ? yes_text : no_text,
  );

  const handleTradeInSelection = (value) => {
    selected.value = value;

    return shopify.applyAttributeChange({
      type: 'updateAttribute',
      key: TRADE_IN_ATTRIBUTE,
      value: value,
    });
  };

  if (!enable || !hasTradeInEligibleLines(lines)) return null;

  return (
    <s-stack direction="block" gap="base">
      <s-heading>{localTranslations?.heading}</s-heading>
      <s-paragraph>{localTranslations?.summary}</s-paragraph>

      {localTranslations?.modal_trigger && (
        <s-stack direction="inline" justifyContent="start">
          <s-link command="--show" commandFor={MODAL_ID}>
            {localTranslations?.modal_trigger}
          </s-link>
        </s-stack>
      )}

      <s-modal
        id={MODAL_ID}
        heading={localTranslations?.modal_heading || ''}
        padding="base"
      >
        <s-stack direction="block" gap="base">
          <s-paragraph>{localTranslations?.modal_content}</s-paragraph>
        </s-stack>
      </s-modal>

      <s-choice-list
        name={`checkout[attributes][${TRADE_IN_ATTRIBUTE}]`}
        variant="block"
        values={[selected.value]}
        onChange={(event) => handleTradeInSelection(firstSelectedValue(event))}
      >
        <s-choice value={yes_text}>{yes_text}</s-choice>
        <s-choice value={no_text}>{no_text}</s-choice>
      </s-choice-list>
    </s-stack>
  );
}
