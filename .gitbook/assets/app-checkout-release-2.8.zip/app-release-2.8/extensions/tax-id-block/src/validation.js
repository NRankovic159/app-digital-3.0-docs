/**
 * Tax/ID document validation.
 *
 * Extracted from the component because these rules run inside a buyer-journey
 * interceptor: a mistake here either blocks a buyer with a valid document or lets
 * an invalid tax id through onto the order.
 *
 */

export const VERIFICATION_TYPE_ATTRIBUTE = 'VerificationIdType';
export const VERIFICATION_ID_ATTRIBUTE = 'VerificationId';

/** The value of the placeholder option, which clears the selection. */
export const UNSET_OPTION = 'unset';

export const INVALID_ID_REASON = 'Invalid ID value';
export const MISSING_FIELDS_REASON = 'Missing required fields';

export const DEFAULT_TYPE_EMPTY_MESSAGE = 'Please select a document type';
export const DEFAULT_ID_EMPTY_MESSAGE = 'Please enter your ID number';
export const DEFAULT_PASSPORT_MESSAGE = 'no symbols, only text and alphabets';
export const DEFAULT_FORMAT_MESSAGE = 'Please enter a valid ID number';

/**
 * Document types, in the order they appear in the dropdown, with their label
 * fallbacks.
 */
export const DOCUMENT_TYPES = [
  {value: 'DNI_NIE', labelKey: 'dni_nie_label', defaultLabel: 'DNI/NIE'},
  {value: 'CIF', labelKey: 'cif_label', defaultLabel: 'CIF'},
  {
    value: 'RESIDENCY_CARD',
    labelKey: 'residency_card_label',
    defaultLabel: 'RESIDENCY_CARD',
  },
  {value: 'PASSPORT', labelKey: 'passport_label', defaultLabel: 'PASSPORT'},
];

/**
 * The pattern and error message for each document type.
 *
 * Every type falls back to a generic message when its `*_error` translation key
 * is missing, so a missing key degrades to a vague message rather than to an
 * empty one that blocks the buyer with no explanation.
 * @param {Object} translations
 * @returns {Object}
 */
export const validationMapFrom = (translations = {}) => ({
  DNI_NIE: {
    validation: /^(\d{8})([A-Z])$/,
    message: translations?.dni_nie_error || DEFAULT_FORMAT_MESSAGE,
  },
  CIF: {
    validation: /^([ABCDEFGHJKLMNPQRSUVW])(\d{7})([0-9A-J])$/,
    message: translations?.cif_error || DEFAULT_FORMAT_MESSAGE,
  },
  RESIDENCY_CARD: {
    validation: /^[XYZ]\d{7,8}[A-Z]$/,
    message: translations?.residency_card_error || DEFAULT_FORMAT_MESSAGE,
  },
  PASSPORT: {
    validation: /^[a-zA-Z0-9_]+$/,
    message: translations?.passport_error || DEFAULT_PASSPORT_MESSAGE,
  },
});

/**
 * Whether the buyer may continue, and which errors to show.
 *
 * ⚠️ The pattern check runs **before** the empty check, which has a consequence
 * worth knowing: with a document type selected and an empty id, the pattern fails
 * first, so the buyer sees that type's *format* error rather than the
 * "please enter your ID" message. The empty-id message is therefore only ever
 * reachable when no document type is selected. Preserved exactly.
 *
 * @param {{documentType: String, idValue: String, translations?: Object}} input
 * @returns {{blocked: Boolean, reason: String, typeError: String, idError: String}}
 */
export const validateDocument = ({
  documentType,
  idValue,
  translations = {},
}) => {
  const {validation, message} = validationMapFrom(translations)[documentType] || {};
  const isValid = validation?.test(idValue) || false;

  if (validation && !isValid) {
    return {
      blocked: true,
      reason: INVALID_ID_REASON,
      typeError: '',
      idError: message || '',
    };
  }

  if (!documentType || !idValue) {
    return {
      blocked: true,
      reason: MISSING_FIELDS_REASON,
      typeError: documentType
        ? ''
        : translations?.document_type_empty || DEFAULT_TYPE_EMPTY_MESSAGE,
      idError: idValue
        ? ''
        : translations?.id_empty_default || DEFAULT_ID_EMPTY_MESSAGE,
    };
  }

  return {blocked: false, reason: '', typeError: '', idError: ''};
};
