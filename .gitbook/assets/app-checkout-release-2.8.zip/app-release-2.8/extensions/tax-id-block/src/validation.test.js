import {describe, expect, it} from 'vitest';

import {
  DEFAULT_FORMAT_MESSAGE,
  DEFAULT_ID_EMPTY_MESSAGE,
  DEFAULT_PASSPORT_MESSAGE,
  DEFAULT_TYPE_EMPTY_MESSAGE,
  INVALID_ID_REASON,
  MISSING_FIELDS_REASON,
  validateDocument,
  validationMapFrom,
} from './validation.js';

const TRANSLATIONS = {
  dni_nie_error: 'DNI must be 8 digits and a letter',
  cif_error: 'CIF is not valid',
  residency_card_error: 'Residency card is not valid',
  passport_error: 'Passport can only contain letters and numbers',
  document_type_empty: 'Pick a document',
  id_empty_default: 'Enter your number',
};

const check = (documentType, idValue, translations = TRANSLATIONS) =>
  validateDocument({documentType, idValue, translations});

describe('validationMapFrom', () => {
  it('falls back to the generic message for the three Spanish types', () => {
    const map = validationMapFrom({});

    expect(map.DNI_NIE.message).toBe(DEFAULT_FORMAT_MESSAGE);
    expect(map.CIF.message).toBe(DEFAULT_FORMAT_MESSAGE);
    expect(map.RESIDENCY_CARD.message).toBe(DEFAULT_FORMAT_MESSAGE);
  });

  it('falls back to the passport-specific message for passports', () => {
    expect(validationMapFrom({}).PASSPORT.message).toBe(
      DEFAULT_PASSPORT_MESSAGE,
    );
  });

  it('prefers the translation over the fallback when present', () => {
    const map = validationMapFrom(TRANSLATIONS);

    expect(map.DNI_NIE.message).toBe('DNI must be 8 digits and a letter');
    expect(map.CIF.message).toBe('CIF is not valid');
  });

  it('never blocks with an empty message', () => {
    // The whole point of the fallback: an empty message blocks the buyer with no
    // explanation, which is indistinguishable from a broken checkout.
    const map = validationMapFrom({});

    for (const {message} of Object.values(map)) expect(message).not.toBe('');
  });
});

describe('DNI_NIE', () => {
  it('accepts 8 digits and an uppercase letter', () => {
    expect(check('DNI_NIE', '12345678Z').blocked).toBe(false);
  });

  it('rejects a lowercase letter', () => {
    expect(check('DNI_NIE', '12345678z').blocked).toBe(true);
  });

  it('rejects too few digits', () => {
    expect(check('DNI_NIE', '1234567Z').blocked).toBe(true);
  });

  it('rejects trailing content', () => {
    expect(check('DNI_NIE', '12345678ZZ').blocked).toBe(true);
  });

  it('reports the translated message', () => {
    expect(check('DNI_NIE', 'nope').idError).toBe(
      'DNI must be 8 digits and a letter',
    );
  });
});

describe('CIF', () => {
  it('accepts a valid CIF', () => {
    expect(check('CIF', 'A1234567J').blocked).toBe(false);
  });

  it('rejects a leading letter outside the allowed set', () => {
    // 'I', 'O', 'T', 'X', 'Y', 'Z' are absent from the pattern.
    expect(check('CIF', 'I1234567J').blocked).toBe(true);
  });

  it('rejects a trailing character past J', () => {
    expect(check('CIF', 'A1234567K').blocked).toBe(true);
  });
});

describe('RESIDENCY_CARD', () => {
  it('accepts 7 or 8 digits between an XYZ prefix and a letter', () => {
    expect(check('RESIDENCY_CARD', 'X1234567A').blocked).toBe(false);
    expect(check('RESIDENCY_CARD', 'Z12345678A').blocked).toBe(false);
  });

  it('rejects a prefix outside XYZ', () => {
    expect(check('RESIDENCY_CARD', 'A1234567A').blocked).toBe(true);
  });

  it('rejects too many digits', () => {
    expect(check('RESIDENCY_CARD', 'X123456789A').blocked).toBe(true);
  });
});

describe('PASSPORT', () => {
  it('accepts letters, digits and underscores', () => {
    expect(check('PASSPORT', 'AB123456').blocked).toBe(false);
    expect(check('PASSPORT', 'ab_123').blocked).toBe(false);
  });

  it('rejects symbols', () => {
    expect(check('PASSPORT', 'AB-123').blocked).toBe(true);
    expect(check('PASSPORT', 'AB 123').blocked).toBe(true);
  });

  it('falls back to the built-in message when untranslated', () => {
    expect(
      validateDocument({
        documentType: 'PASSPORT',
        idValue: 'AB-123',
        translations: {},
      }).idError,
    ).toBe(DEFAULT_PASSPORT_MESSAGE);
  });
});

describe('empty fields', () => {
  it('blocks with both messages when nothing is selected or entered', () => {
    expect(check('', '')).toEqual({
      blocked: true,
      reason: MISSING_FIELDS_REASON,
      typeError: 'Pick a document',
      idError: 'Enter your number',
    });
  });

  it('blocks with only the type message when an id is typed but no type chosen', () => {
    expect(check('', 'ABC123')).toEqual({
      blocked: true,
      reason: MISSING_FIELDS_REASON,
      typeError: 'Pick a document',
      idError: '',
    });
  });

  it('falls back to built-in empty messages when untranslated', () => {
    const result = validateDocument({
      documentType: '',
      idValue: '',
      translations: {},
    });

    expect(result.typeError).toBe(DEFAULT_TYPE_EMPTY_MESSAGE);
    expect(result.idError).toBe(DEFAULT_ID_EMPTY_MESSAGE);
  });

  it('shows the format error, not the empty-id error, when a type is chosen', () => {
    // Ordering is load-bearing: the pattern check runs first, so with a type
    // selected and an empty id the buyer sees that type's format message and the
    // "enter your number" copy is unreachable. Preserved from the old code.
    const result = check('DNI_NIE', '');

    expect(result.reason).toBe(INVALID_ID_REASON);
    expect(result.idError).toBe('DNI must be 8 digits and a letter');
    expect(result.idError).not.toBe('Enter your number');
  });
});

describe('unknown document types', () => {
  it('falls through to the empty check rather than blocking on a pattern', () => {
    // No entry in the validation map means no pattern, so a filled id passes.
    expect(check('SOMETHING_ELSE', 'anything').blocked).toBe(false);
  });
});

describe('a blocked buyer always sees a reason', () => {
  // With no translations at all — the worst case — anything that blocks must
  // still surface copy on at least one of the two fields. Otherwise Continue
  // does nothing with no explanation.
  const UNTRANSLATED = {};

  it.each([
    ['DNI_NIE', ''],
    ['DNI_NIE', 'nope'],
    ['CIF', 'nope'],
    ['RESIDENCY_CARD', 'nope'],
    ['PASSPORT', 'AB-123'],
    ['', ''],
    ['', 'ABC123'],
  ])('shows a message for type=%o id=%o', (documentType, idValue) => {
    const result = check(documentType, idValue, UNTRANSLATED);

    expect(result.blocked).toBe(true);
    expect(`${result.typeError}${result.idError}`).not.toBe('');
  });
});
