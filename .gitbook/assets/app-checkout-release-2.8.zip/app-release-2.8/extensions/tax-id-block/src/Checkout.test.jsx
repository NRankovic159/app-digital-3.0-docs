import {act, cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {Extension} from './Checkout.jsx';
import {INVALID_ID_REASON, MISSING_FIELDS_REASON} from './validation.js';

const translationEntry = (byLanguage, key = 'tax_id') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {
    document_type: 'Document type',
    id_field_label: 'ID number',
    document_type_empty: 'Pick a document',
    id_empty_default: 'Enter your number',
    dni_nie_label: 'DNI / NIE',
    dni_nie_error: 'DNI must be 8 digits and a letter',
    passport_label: 'Passport',
  },
  fr: {document_type: 'Type de document'},
};

const saved = (type, id) =>
  [
    type === undefined ? null : {key: 'VerificationIdType', value: type},
    id === undefined ? null : {key: 'VerificationId', value: id},
  ].filter(Boolean);

let intercept;
let registeredInterceptor;
let teardown;
let applyAttributeChange;
let settings;

const stubShopify = ({
  initialSettings = {enable_validation: true},
  initialAttributes = [],
  appMetafields = [translationEntry(TRANSLATIONS)],
  isoCode = 'en',
} = {}) => {
  registeredInterceptor = undefined;
  teardown = vi.fn();
  settings = {value: initialSettings};
  applyAttributeChange = vi.fn().mockResolvedValue({type: 'success'});
  intercept = vi.fn(async (interceptor) => {
    registeredInterceptor = interceptor;
    return teardown;
  });
  globalThis.shopify = {
    settings,
    attributes: {value: initialAttributes},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    applyAttributeChange,
    buyerJourney: {intercept},
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

const select = (container) => container.querySelector('s-select');
const options = (container) => [...container.querySelectorAll('s-option')];
const textField = (container) => container.querySelector('s-text-field');

const settle = () =>
  act(async () => {
    await Promise.resolve();
    await Promise.resolve();
  });

const run = (props = {canBlockProgress: true}) => registeredInterceptor(props);

const change = async (element, value) => {
  element.value = value;
  await act(async () => {
    element.dispatchEvent(new Event('change'));
  });
};

describe('the interceptor — blocking branch', () => {
  it('blocks an empty form and shows both errors', async () => {
    const {container} = render(<Extension />);
    await settle();

    let result;
    await act(async () => {
      result = run();
    });

    expect(result).toEqual({behavior: 'block', reason: MISSING_FIELDS_REASON});
    expect(select(container).getAttribute('error')).toBe('Pick a document');
    expect(textField(container).getAttribute('error')).toBe('Enter your number');
  });

  it('blocks an invalid id for the chosen type', async () => {
    const {container} = render(<Extension />);
    await settle();
    await change(select(container), 'DNI_NIE');
    await change(textField(container), 'not-a-dni');

    let result;
    await act(async () => {
      result = run();
    });

    expect(result).toEqual({behavior: 'block', reason: INVALID_ID_REASON});
    expect(textField(container).getAttribute('error')).toBe(
      'DNI must be 8 digits and a letter',
    );
  });
});

describe('the interceptor — allowing branch', () => {
  it('allows a valid type and id', async () => {
    const {container} = render(<Extension />);
    await settle();
    await change(select(container), 'DNI_NIE');
    await change(textField(container), '12345678Z');

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('allows when validation is disabled', async () => {
    stubShopify({initialSettings: {enable_validation: false}});
    render(<Extension />);
    await settle();

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('allows when the extension cannot block progress', async () => {
    render(<Extension />);
    await settle();

    expect(run({canBlockProgress: false})).toEqual({behavior: 'allow'});
  });

  it('clears stale errors on each run', async () => {
    const {container} = render(<Extension />);
    await settle();
    await act(async () => {
      run();
    });
    expect(select(container).getAttribute('error')).toBe('Pick a document');

    await change(select(container), 'DNI_NIE');
    await change(textField(container), '12345678Z');
    await act(async () => {
      run();
    });

    expect(select(container).getAttribute('error')).toBeFalsy();
    expect(textField(container).getAttribute('error')).toBeFalsy();
  });
});

describe('the interceptor reads live values', () => {
  it('honours validation being switched off after registration', async () => {
    render(<Extension />);
    await settle();
    expect(await run()).toEqual({
      behavior: 'block',
      reason: MISSING_FIELDS_REASON,
    });

    settings.value = {enable_validation: false};

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('registers exactly once across edits', async () => {
    const {container} = render(<Extension />);
    await settle();

    await change(select(container), 'PASSPORT');
    await change(textField(container), 'AB123');
    await settle();

    expect(intercept).toHaveBeenCalledTimes(1);
  });
});

describe('teardown', () => {
  it('removes the interceptor on unmount', async () => {
    render(<Extension />);
    await settle();

    cleanup();

    expect(teardown).toHaveBeenCalled();
  });
});

describe('writing attributes', () => {
  it('writes both attributes when a type is chosen', async () => {
    const {container} = render(<Extension />);
    await settle();

    await change(select(container), 'PASSPORT');

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'VerificationIdType',
      value: 'PASSPORT',
    });
    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'VerificationId',
      value: '',
    });
  });

  it('writes both attributes as the id is typed', async () => {
    const {container} = render(<Extension />);
    await settle();
    await change(select(container), 'PASSPORT');
    applyAttributeChange.mockClear();

    await change(textField(container), 'AB123');

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'VerificationIdType',
      value: 'PASSPORT',
    });
    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'VerificationId',
      value: 'AB123',
    });
  });

  it('clears both fields and both attributes when the placeholder is re-selected', async () => {
    const {container} = render(<Extension />);
    await settle();
    await change(select(container), 'PASSPORT');
    await change(textField(container), 'AB123');
    applyAttributeChange.mockClear();

    await change(select(container), 'unset');

    // A half-filled pair must not be left on the cart.
    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'VerificationIdType',
      value: '',
    });
    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'VerificationId',
      value: '',
    });
    expect(textField(container).getAttribute('value')).toBeFalsy();
  });
});

describe('rendering', () => {
  it('renders nothing when validation is disabled', () => {
    stubShopify({initialSettings: {enable_validation: false}});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('defaults to enabled when the setting is absent', () => {
    stubShopify({initialSettings: {}});

    const {container} = render(<Extension />);

    expect(select(container)).not.toBeNull();
  });

  it('offers the placeholder plus four document types, in order', () => {
    const {container} = render(<Extension />);

    expect(options(container).map((option) => option.getAttribute('value'))).toEqual(
      ['unset', 'DNI_NIE', 'CIF', 'RESIDENCY_CARD', 'PASSPORT'],
    );
  });

  it('labels options from translations, falling back per option', () => {
    const {container} = render(<Extension />);
    const [placeholder, dni, cif] = options(container);

    expect(placeholder.textContent).toContain('Pick a document');
    expect(dni.textContent).toContain('DNI / NIE');
    expect(cif.textContent).toContain('CIF');
  });

  it('caps the id field at 40 characters', () => {
    const {container} = render(<Extension />);

    expect(textField(container).getAttribute('maxlength')).toBe('40');
  });

  it('seeds both controls from previously saved attributes', () => {
    stubShopify({initialAttributes: saved('PASSPORT', 'AB123')});

    const {container} = render(<Extension />);

    expect(select(container).getAttribute('value')).toBe('PASSPORT');
    expect(textField(container).getAttribute('value')).toBe('AB123');
  });

  it('uses the buyer language for a regional locale', () => {
    stubShopify({isoCode: 'fr-CA'});

    const {container} = render(<Extension />);

    expect(select(container).getAttribute('label')).toBe('Type de document');
  });

  it('renders unlabelled fields for an untranslated language', () => {
    stubShopify({isoCode: 'de'});

    const {container} = render(<Extension />);

    expect(select(container).getAttribute('label')).toBeNull();
    expect(select(container)).not.toBeNull();
  });

  it('ignores a translations entry belonging to another extension', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {document_type: 'Wrong block'}}, 'order_note'),
        translationEntry(TRANSLATIONS),
      ],
    });

    const {container} = render(<Extension />);

    expect(select(container).getAttribute('label')).toBe('Document type');
  });
});
