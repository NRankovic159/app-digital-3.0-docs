import '@shopify/ui-extensions/preact';
import {useSignal} from '@preact/signals';
import {render} from "preact";
import {useEffect} from 'preact/hooks';

import {ALLOW, block, useInterceptor} from './buyerJourney.js';
import {fieldValue} from './events.js';
import {readTranslations} from './translations.js';
import {
  DEFAULT_TYPE_EMPTY_MESSAGE,
  DOCUMENT_TYPES,
  UNSET_OPTION,
  VERIFICATION_ID_ATTRIBUTE,
  VERIFICATION_TYPE_ATTRIBUTE,
  validateDocument,
} from './validation.js';

export default async () => {
  render(<Extension />, document.body)
};

const TRANSLATION_KEY = 'tax_id';

/** Read straight off the global, for use inside the interceptor. */
const liveTranslations = () =>
  readTranslations(shopify.appMetafields.value, {
    key: TRANSLATION_KEY,
    language: shopify.localization.language.value,
  });

const attributeValue = (attributes, key) =>
  attributes?.find((attribute) => attribute.key === key)?.value;

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const {enable_validation = true} = shopify.settings.value;
  const attributes = shopify.attributes.value;
  const localTranslations = liveTranslations();

  const savedType = attributeValue(attributes, VERIFICATION_TYPE_ATTRIBUTE);
  const savedId = attributeValue(attributes, VERIFICATION_ID_ATTRIBUTE);

  const documentType = useSignal(savedType || '');
  const idValue = useSignal(savedId || '');
  const typeError = useSignal('');
  const idError = useSignal('');

  // Adopt values written elsewhere (or restored on return to checkout) without
  // clobbering what the buyer is currently typing. `useEffect`, not
  // `useSignalEffect`: the callback writes signals, so tracking would loop.
  useEffect(() => {
    if (savedType) documentType.value = savedType;
    if (savedId) idValue.value = savedId;
  }, [savedType, savedId]);

  // Registered once, so everything is read live. A captured `enable_validation`
  // would be frozen for the session, and a stale `true` after the merchant turned
  // validation off would keep blocking every checkout.
  useInterceptor(({canBlockProgress}) => {
    typeError.value = '';
    idError.value = '';

    const {enable_validation: enabled = true} = shopify.settings.value;
    if (!enabled || !canBlockProgress) return ALLOW;

    const result = validateDocument({
      documentType: documentType.value,
      idValue: idValue.value,
      translations: liveTranslations(),
    });

    if (!result.blocked) return ALLOW;

    typeError.value = result.typeError;
    idError.value = result.idError;
    return block(result.reason);
  });

  const postAttributes = (docTypeValue, idInputValue) =>
    Promise.all([
      shopify.applyAttributeChange({
        type: 'updateAttribute',
        key: VERIFICATION_TYPE_ATTRIBUTE,
        value: docTypeValue,
      }),
      shopify.applyAttributeChange({
        type: 'updateAttribute',
        key: VERIFICATION_ID_ATTRIBUTE,
        value: idInputValue,
      }),
    ]);

  const onDocumentTypeChange = (typeValue) => {
    typeError.value = '';

    // Re-selecting the placeholder clears both fields, so a half-filled pair can't
    // be left on the cart.
    if (typeValue === UNSET_OPTION) {
      documentType.value = '';
      idValue.value = '';
      return postAttributes('', '');
    }

    documentType.value = typeValue;
    return postAttributes(typeValue, idValue.value);
  };

  const handleIdUpdate = (idInputValue) => {
    idError.value = '';
    idValue.value = idInputValue;
    return postAttributes(documentType.value, idInputValue);
  };

  if (!enable_validation) return null;

  return (
    <s-grid gridTemplateColumns="1fr 1fr" gap="base">
      <s-select
        label={localTranslations?.document_type}
        value={documentType.value}
        error={typeError.value}
        onChange={(event) => onDocumentTypeChange(fieldValue(event))}
      >
        <s-option value={UNSET_OPTION}>
          {localTranslations?.document_type_empty || DEFAULT_TYPE_EMPTY_MESSAGE}
        </s-option>
        {DOCUMENT_TYPES.map(({value, labelKey, defaultLabel}) => (
          <s-option key={value} value={value}>
            {localTranslations?.[labelKey] || defaultLabel}
          </s-option>
        ))}
      </s-select>

      <s-text-field
        label={localTranslations?.id_field_label}
        value={idValue.value}
        maxLength={40}
        error={idError.value}
        onChange={(event) => handleIdUpdate(fieldValue(event))}
      />
    </s-grid>
  );
}
