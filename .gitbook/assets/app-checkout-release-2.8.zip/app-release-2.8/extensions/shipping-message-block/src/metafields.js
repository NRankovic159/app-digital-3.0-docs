/**
 * Metafield reading for the shipping message block.
 */

/** The product-level metafield keys this block reads, by the name it uses. */
export const PRODUCT_METAFIELD_KEYS = {
  preOrderEligible: 'apl_EligibileForPreOrder',
  preOrderMessage: 'apl_PreOrderMessage',
  isCTOProduct: 'apl_cto_Product',
  preOrderStartDate: 'apl_PreOrdersDatetime',
  preOrderLaunchDate: 'apl_LaunchDatetime',
};

const NAMESPACE = 'apple';

/**
 * Metafield entries matching a namespace and key, in API order.
 * @param {Array} appMetafields value of `shopify.appMetafields`
 * @param {String} namespace
 * @param {String} key
 * @returns {Array}
 */
export const filterAppMetafields = (appMetafields, namespace, key) =>
  (appMetafields || []).filter(
    (entry) =>
      entry?.metafield?.namespace === namespace && entry?.metafield?.key === key,
  );

/**
 * The buyer's base language code — `en` for `en-CA`. Falls back to `en` when
 * the language isn't available.
 * @param {Object} language value of `shopify.localization.language`
 * @returns {String}
 */
export const languageCodeFrom = (language) => {
  const [languageCode] = language?.isoCode?.split('-') || ['en'];
  return languageCode;
};

/**
 * The trailing numeric part of a Shopify id, accepting either a GID
 * (`gid://shopify/Product/123`) or a bare id (`123`). Lets id comparisons.
 * @param {String} id
 * @returns {String}
 */
export const numericIdFrom = (id) => String(id ?? '').split('/').pop();

/**
 * Shop-level shipping messages for the buyer's language.
 *
 * Note this metafield is *not* in the `sdg:translations` shape used elsewhere
 * in this app — the language map sits at the top level, with no `value`
 * wrapper. Preserved as-is.
 * @param {Array} appMetafields value of `shopify.appMetafields`
 * @param {Object} language value of `shopify.localization.language`
 * @returns {Object}
 */
export const readShippingMessages = (appMetafields, language) => {
  const [entry] = filterAppMetafields(
    appMetafields,
    NAMESPACE,
    'apl_ShippingMessages',
  );
  const shippingMessagesJSON = JSON.parse(entry?.metafield?.value || '{}');
  return shippingMessagesJSON?.[languageCodeFrom(language)] || {};
};

/**
 * The value of one product-level metafield, or `null` when the product has no
 * entry for it.
 * @param {Array} appMetafields value of `shopify.appMetafields`
 * @param {String} key
 * @param {String} productId product GID
 * @returns {String|null}
 */
export const productMetafieldValue = (appMetafields, key, productId) => {
  const wantedId = numericIdFrom(productId);
  const entry = filterAppMetafields(appMetafields, NAMESPACE, key).find(
    (meta) => numericIdFrom(meta?.target?.id) === wantedId,
  );
  return entry?.metafield?.value || null;
};

/**
 * Pair every cart line with its product's metafield values.
 *
 * The old implementation assigned these onto `line.merchandise.product`, which
 * mutated objects owned by the checkout API. This returns a derived list
 * instead and leaves `shopify.lines` untouched.
 * @param {Array} lines value of `shopify.lines`
 * @param {Array} appMetafields value of `shopify.appMetafields`
 * @returns {Array<{line: Object, preOrderEligible: String|null, preOrderMessage: String|null, isCTOProduct: String|null, preOrderStartDate: String|null, preOrderLaunchDate: String|null}>}
 */
export const mapMetasToLines = (lines, appMetafields) =>
  (lines || []).map((line) => {
    const productId = line?.merchandise?.product?.id;
    const valueOf = (key) =>
      productMetafieldValue(appMetafields, key, productId);

    // Spelled out rather than built by looping `PRODUCT_METAFIELD_KEYS`: the loop
    // form left the returned shape untypeable, so the declared `@returns` above
    // couldn't be checked against it.
    return {
      line,
      preOrderEligible: valueOf(PRODUCT_METAFIELD_KEYS.preOrderEligible),
      preOrderMessage: valueOf(PRODUCT_METAFIELD_KEYS.preOrderMessage),
      isCTOProduct: valueOf(PRODUCT_METAFIELD_KEYS.isCTOProduct),
      preOrderStartDate: valueOf(PRODUCT_METAFIELD_KEYS.preOrderStartDate),
      preOrderLaunchDate: valueOf(PRODUCT_METAFIELD_KEYS.preOrderLaunchDate),
    };
  });

/**
 * Whether a line counts as a pre-order right now.
 *
 * When the product carries both a pre-order start and launch date, the current
 * time has to fall inside that window. Unparseable or missing dates fall back
 * to the boolean `apl_EligibileForPreOrder` metafield.
 * @param {Object} entry one element of `mapMetasToLines`
 * @param {Date} now
 * @returns {Boolean}
 */
export const isPreOrder = (entry, now) => {
  const {preOrderStartDate, preOrderLaunchDate, preOrderEligible} = entry;

  if (preOrderStartDate && preOrderLaunchDate) {
    const startDate = new Date(preOrderStartDate);
    const launchDate = new Date(preOrderLaunchDate);

    if (!isNaN(startDate.getTime()) && !isNaN(launchDate.getTime())) {
      return now >= startDate && now <= launchDate;
    }
  }

  return preOrderEligible === 'true';
};

/**
 * Whether a line is part of a bundle.
 * @param {Object} entry one element of `mapMetasToLines`
 * @returns {Boolean}
 */
export const isBundle = (entry) => (entry.line?.lineComponents?.length || 0) > 0;

/**
 * Strip html elements from string
 * @param {String} htmlString
 * @returns {String}
 */
export const stripHtml = (htmlString) => {
  return htmlString.replace(/<\/?[^>]+(>|$)/g, '');
};
