import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {
  isBundle,
  isPreOrder,
  mapMetasToLines,
  readShippingMessages,
  stripHtml,
} from './metafields.js';

export default async () => {
  render(<Extension />, document.body)
};

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const language = shopify.localization.language.value;
  const cartLines = shopify.lines.value;
  const appMetafields = shopify.appMetafields.value;

  // Shop level metafield
  const localShippingMessages = readShippingMessages(appMetafields, language);

  const regularShippingMessage = localShippingMessages?.inStock;
  const preOrderShippingMessage = localShippingMessages?.preOrder;
  const ctoShippingMessage = localShippingMessages?.cto;

  // Pair each line with its product level metafields
  const linesWithMetas = mapMetasToLines(cartLines, appMetafields);

  const ctoProducts = linesWithMetas.filter(
    (entry) => entry.isCTOProduct === 'true',
  );

  const bundleProducts = linesWithMetas.filter(isBundle);

  if ((ctoProducts.length > 0 || bundleProducts.length > 0) && ctoShippingMessage) {
    // we will add cto specific messaging here
    return (
      <s-stack direction="block" gap="base" padding="none">
        <s-text>
          {stripHtml(ctoShippingMessage)}
        </s-text>
      </s-stack>
    )
  }

  // Pre-order Logic
  const currentDate = new Date();

  const preOrderProducts = linesWithMetas.filter((entry) =>
    isPreOrder(entry, currentDate),
  );

  if (preOrderProducts && preOrderProducts.length > 0) {
    // we will add pre order specific messaging here
    const firstPreOrderProduct = preOrderProducts.find(
      (entry) => entry.preOrderMessage,
    );
    const preOrderProductMessage = firstPreOrderProduct?.preOrderMessage;
    return (
      <s-stack direction="block" gap="base" padding="none">
        <s-text>
          {preOrderProductMessage
            ? stripHtml(preOrderProductMessage)
            : stripHtml(preOrderShippingMessage)}
        </s-text>
      </s-stack>
    )
  }

  // If no shipping message set, render nothing
  if (!regularShippingMessage) return null;

  // This is regular in-stock message
  return (
    <s-stack direction="block" gap="base" padding="none">
      <s-text>{stripHtml(regularShippingMessage)}</s-text>
    </s-stack>
  );
}
