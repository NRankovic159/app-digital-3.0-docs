import {describe, expect, it} from 'vitest';

import {
  filterAppMetafields,
  isBundle,
  isPreOrder,
  mapMetasToLines,
  numericIdFrom,
  productMetafieldValue,
  readShippingMessages,
} from './metafields.js';

const shopEntry = (byLanguage) => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'apple',
    key: 'apl_ShippingMessages',
    value: JSON.stringify(byLanguage),
    type: 'json',
  },
});

const productEntry = (key, productId, value) => ({
  target: {type: 'product', id: productId},
  metafield: {namespace: 'apple', key, value, type: 'single_line_text_field'},
});

const line = (productId, lineComponents = []) => ({
  id: 'gid://shopify/CartLine/1',
  quantity: 1,
  lineComponents,
  merchandise: {id: 'gid://shopify/ProductVariant/9', product: {id: productId}},
});

describe('numericIdFrom', () => {
  // target.id was documented as a bare numeric id through 2024-10 and as a GID
  // from 2026-07, so both have to normalise to the same thing.
  it('extracts the id from a GID', () => {
    expect(numericIdFrom('gid://shopify/Product/123')).toBe('123');
  });

  it('passes a bare numeric id through', () => {
    expect(numericIdFrom('123')).toBe('123');
  });

  it('handles missing ids without throwing', () => {
    expect(numericIdFrom(undefined)).toBe('');
    expect(numericIdFrom(null)).toBe('');
  });
});

describe('readShippingMessages', () => {
  // This metafield has no `value` wrapper, unlike sdg:translations elsewhere.
  it('reads the buyer language off the top level of the payload', () => {
    const entries = [shopEntry({en: {inStock: 'en copy'}, fr: {inStock: 'fr copy'}})];

    expect(readShippingMessages(entries, {isoCode: 'fr-CA'})).toEqual({
      inStock: 'fr copy',
    });
  });

  it('falls back to en when the language is unknown', () => {
    const entries = [shopEntry({en: {inStock: 'en copy'}})];

    expect(readShippingMessages(entries, undefined)).toEqual({inStock: 'en copy'});
  });

  it('returns {} when the buyer language is absent from the payload', () => {
    const entries = [shopEntry({en: {inStock: 'en copy'}})];

    expect(readShippingMessages(entries, {isoCode: 'de'})).toEqual({});
  });

  it('returns {} when the metafield is missing or empty', () => {
    expect(readShippingMessages([], {isoCode: 'en'})).toEqual({});
    expect(readShippingMessages(undefined, {isoCode: 'en'})).toEqual({});
  });

  it('is not confused by the product metafields sharing its namespace', () => {
    const entries = [
      productEntry('apl_cto_Product', 'gid://shopify/Product/1', 'true'),
      shopEntry({en: {inStock: 'en copy'}}),
    ];

    expect(readShippingMessages(entries, {isoCode: 'en'})).toEqual({
      inStock: 'en copy',
    });
  });
});

describe('filterAppMetafields', () => {
  it('narrows by both namespace and key', () => {
    const entries = [
      {metafield: {namespace: 'other', key: 'apl_cto_Product', value: 'x'}},
      {metafield: {namespace: 'apple', key: 'apl_PreOrderMessage', value: 'y'}},
      {metafield: {namespace: 'apple', key: 'apl_cto_Product', value: 'z'}},
    ];

    const result = filterAppMetafields(entries, 'apple', 'apl_cto_Product');

    expect(result).toHaveLength(1);
    expect(result[0].metafield.value).toBe('z');
  });
});

describe('productMetafieldValue', () => {
  it('matches a GID target against a GID product id', () => {
    const entries = [
      productEntry('apl_cto_Product', 'gid://shopify/Product/1', 'false'),
      productEntry('apl_cto_Product', 'gid://shopify/Product/2', 'true'),
    ];

    expect(
      productMetafieldValue(entries, 'apl_cto_Product', 'gid://shopify/Product/2'),
    ).toBe('true');
  });

  it('still matches when the platform sends bare numeric target ids', () => {
    const entries = [productEntry('apl_cto_Product', '2', 'true')];

    expect(
      productMetafieldValue(entries, 'apl_cto_Product', 'gid://shopify/Product/2'),
    ).toBe('true');
  });

  it('returns null when no entry belongs to the product', () => {
    const entries = [productEntry('apl_cto_Product', 'gid://shopify/Product/1', 'true')];

    expect(
      productMetafieldValue(entries, 'apl_cto_Product', 'gid://shopify/Product/2'),
    ).toBeNull();
  });

  it('does not read a different key belonging to the same product', () => {
    const entries = [
      productEntry('apl_PreOrderMessage', 'gid://shopify/Product/1', 'Ships soon'),
    ];

    expect(
      productMetafieldValue(entries, 'apl_cto_Product', 'gid://shopify/Product/1'),
    ).toBeNull();
  });
});

describe('mapMetasToLines', () => {
  it('pairs each line with only its own product metafields', () => {
    const lines = [line('gid://shopify/Product/1'), line('gid://shopify/Product/2')];
    const entries = [
      productEntry('apl_cto_Product', 'gid://shopify/Product/1', 'true'),
      productEntry('apl_PreOrderMessage', 'gid://shopify/Product/2', 'Ships 12 March'),
    ];

    const result = mapMetasToLines(lines, entries);

    expect(result[0].isCTOProduct).toBe('true');
    expect(result[0].preOrderMessage).toBeNull();
    expect(result[1].isCTOProduct).toBeNull();
    expect(result[1].preOrderMessage).toBe('Ships 12 March');
  });

  it('leaves the cart lines untouched', () => {
    // The old implementation assigned metafield values onto
    // line.merchandise.product, mutating objects owned by the checkout API.
    const lines = [line('gid://shopify/Product/1')];
    const entries = [productEntry('apl_cto_Product', 'gid://shopify/Product/1', 'true')];

    mapMetasToLines(lines, entries);

    expect(Object.keys(lines[0].merchandise.product)).toEqual(['id']);
  });

  it('handles an empty or missing cart', () => {
    expect(mapMetasToLines([], [])).toEqual([]);
    expect(mapMetasToLines(undefined, [])).toEqual([]);
  });
});

describe('isPreOrder', () => {
  const inWindow = {
    preOrderStartDate: '2026-01-01T00:00:00Z',
    preOrderLaunchDate: '2026-12-31T00:00:00Z',
    preOrderEligible: null,
  };

  it('is true inside the pre-order window', () => {
    expect(isPreOrder(inWindow, new Date('2026-06-01T00:00:00Z'))).toBe(true);
  });

  it('is false before the window opens', () => {
    expect(isPreOrder(inWindow, new Date('2025-06-01T00:00:00Z'))).toBe(false);
  });

  it('is false after the window closes', () => {
    expect(isPreOrder(inWindow, new Date('2027-06-01T00:00:00Z'))).toBe(false);
  });

  it('includes both boundaries', () => {
    expect(isPreOrder(inWindow, new Date('2026-01-01T00:00:00Z'))).toBe(true);
    expect(isPreOrder(inWindow, new Date('2026-12-31T00:00:00Z'))).toBe(true);
  });

  it('ignores the window when the dates are unparseable and uses the flag', () => {
    const entry = {
      preOrderStartDate: 'not a date',
      preOrderLaunchDate: 'also not a date',
      preOrderEligible: 'true',
    };

    expect(isPreOrder(entry, new Date('2026-06-01T00:00:00Z'))).toBe(true);
  });

  it('falls back to the flag when only one date is present', () => {
    const entry = {
      preOrderStartDate: '2026-01-01T00:00:00Z',
      preOrderLaunchDate: null,
      preOrderEligible: 'true',
    };

    expect(isPreOrder(entry, new Date('2020-01-01T00:00:00Z'))).toBe(true);
  });

  it('requires the flag to be exactly "true"', () => {
    const base = {preOrderStartDate: null, preOrderLaunchDate: null};

    expect(isPreOrder({...base, preOrderEligible: 'true'}, new Date())).toBe(true);
    expect(isPreOrder({...base, preOrderEligible: '1'}, new Date())).toBe(false);
    expect(isPreOrder({...base, preOrderEligible: null}, new Date())).toBe(false);
  });
});

describe('isBundle', () => {
  it('is true when the line has components', () => {
    expect(isBundle({line: line('gid://shopify/Product/1', [{id: 'c1'}])})).toBe(true);
  });

  it('is false for a plain line', () => {
    expect(isBundle({line: line('gid://shopify/Product/1')})).toBe(false);
  });

  it('is false when lineComponents is absent', () => {
    expect(isBundle({line: {merchandise: {product: {id: 'x'}}}})).toBe(false);
  });
});
