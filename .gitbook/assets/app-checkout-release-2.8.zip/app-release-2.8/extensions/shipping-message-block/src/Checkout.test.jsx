import {cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {Extension} from './Checkout.jsx';

const NOW = new Date('2026-06-01T00:00:00Z');

const shopEntry = (byLanguage) => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'apple',
    key: 'apl_ShippingMessages',
    value: JSON.stringify(byLanguage),
    type: 'json',
  },
});

const productEntry = (key, productId, value) => ({
  target: {type: 'product', id: productId},
  metafield: {namespace: 'apple', key, value, type: 'single_line_text_field'},
});

const line = (productId, lineComponents = []) => ({
  id: `gid://shopify/CartLine/${productId}`,
  quantity: 1,
  lineComponents,
  merchandise: {id: 'gid://shopify/ProductVariant/9', product: {id: productId}},
});

const MESSAGES = {
  en: {
    inStock: 'Ships in 1-2 business days',
    preOrder: 'This is a pre-order',
    cto: 'Custom configured, ships in 3 weeks',
  },
};

const stubShopify = ({lines = [], appMetafields = [], isoCode = 'en'} = {}) => {
  globalThis.shopify = {
    lines: {value: lines},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
  };
};

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(NOW);
  stubShopify();
});

afterEach(() => {
  vi.useRealTimers();
  cleanup();
  delete globalThis.shopify;
});

describe('message precedence', () => {
  it('prefers the CTO message when any line is a CTO product', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry(MESSAGES),
        productEntry('apl_cto_Product', 'gid://shopify/Product/1', 'true'),
        productEntry('apl_EligibileForPreOrder', 'gid://shopify/Product/1', 'true'),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Custom configured, ships in 3 weeks');
  });

  it('prefers the CTO message when any line is a bundle', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1', [{id: 'component-1'}])],
      appMetafields: [shopEntry(MESSAGES)],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Custom configured, ships in 3 weeks');
  });

  it('falls through to pre-order when there is no CTO message configured', () => {
    const {cto: _omitted, ...withoutCto} = MESSAGES.en;
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry({en: withoutCto}),
        productEntry('apl_cto_Product', 'gid://shopify/Product/1', 'true'),
        productEntry('apl_EligibileForPreOrder', 'gid://shopify/Product/1', 'true'),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('This is a pre-order');
  });

  it('shows the in-stock message for an ordinary cart', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [shopEntry(MESSAGES)],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Ships in 1-2 business days');
  });

  it('renders nothing when no in-stock message is configured', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [shopEntry({en: {preOrder: 'x', cto: 'y'}})],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('renders nothing when the shop metafield is missing entirely', () => {
    stubShopify({lines: [line('gid://shopify/Product/1')]});

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });
});

describe('pre-order messaging', () => {
  it('prefers a product-specific pre-order message', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry(MESSAGES),
        productEntry('apl_EligibileForPreOrder', 'gid://shopify/Product/1', 'true'),
        productEntry('apl_PreOrderMessage', 'gid://shopify/Product/1', 'Ships 12 March'),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Ships 12 March');
  });

  it('uses the shop-level pre-order message when the product has none', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry(MESSAGES),
        productEntry('apl_EligibileForPreOrder', 'gid://shopify/Product/1', 'true'),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('This is a pre-order');
  });

  it('takes the message from whichever pre-order line has one', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1'), line('gid://shopify/Product/2')],
      appMetafields: [
        shopEntry(MESSAGES),
        productEntry('apl_EligibileForPreOrder', 'gid://shopify/Product/1', 'true'),
        productEntry('apl_EligibileForPreOrder', 'gid://shopify/Product/2', 'true'),
        productEntry('apl_PreOrderMessage', 'gid://shopify/Product/2', 'Second line copy'),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Second line copy');
  });

  it('treats a product inside its pre-order date window as a pre-order', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry(MESSAGES),
        productEntry('apl_PreOrdersDatetime', 'gid://shopify/Product/1', '2026-01-01T00:00:00Z'),
        productEntry('apl_LaunchDatetime', 'gid://shopify/Product/1', '2026-12-31T00:00:00Z'),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('This is a pre-order');
  });

  it('does not treat a product outside its window as a pre-order', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry(MESSAGES),
        productEntry('apl_PreOrdersDatetime', 'gid://shopify/Product/1', '2020-01-01T00:00:00Z'),
        productEntry('apl_LaunchDatetime', 'gid://shopify/Product/1', '2020-12-31T00:00:00Z'),
        // The window has closed, and the flag must not rescue it.
        productEntry('apl_EligibileForPreOrder', 'gid://shopify/Product/1', 'true'),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Ships in 1-2 business days');
  });
});

describe('product metafield attribution', () => {
  it('does not apply one product\'s metafields to another line', () => {
    // The whole point of the id matching: product 2 is the CTO product, and a
    // cart containing only product 1 must not inherit that.
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry(MESSAGES),
        productEntry('apl_cto_Product', 'gid://shopify/Product/2', 'true'),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Ships in 1-2 business days');
  });

  it('matches products even if the platform sends bare numeric target ids', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/7')],
      appMetafields: [shopEntry(MESSAGES), productEntry('apl_cto_Product', '7', 'true')],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Custom configured, ships in 3 weeks');
  });
});

describe('presentation', () => {
  it('strips html out of the message', () => {
    stubShopify({
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry({en: {inStock: '<p>Ships <strong>fast</strong></p>'}}),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Ships fast');
  });

  it('renders the buyer language, not the default', () => {
    stubShopify({
      isoCode: 'fr-CA',
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [
        shopEntry({
          en: {inStock: 'Ships in 1-2 business days'},
          fr: {inStock: 'Expédié sous 1 à 2 jours'},
        }),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Expédié sous 1 à 2 jours');
  });

  it('renders nothing for an untranslated language', () => {
    stubShopify({
      isoCode: 'de',
      lines: [line('gid://shopify/Product/1')],
      appMetafields: [shopEntry(MESSAGES)],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('renders nothing for an empty cart when no message is set', () => {
    stubShopify({lines: []});

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('still shows the in-stock message for an empty cart when one is set', () => {
    stubShopify({lines: [], appMetafields: [shopEntry(MESSAGES)]});

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Ships in 1-2 business days');
  });
});
