import {act, cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {
  DEFAULT_CHECKBOX_LABEL,
  DEFAULT_MESSAGE_ATTRIBUTE,
  DEFAULT_MESSAGE_LABEL,
  Extension,
} from './Checkout.jsx';

const translationEntry = (byLanguage, key = 'gift_message') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {
    checkbox_label: 'Add a gift message',
    message_label: 'Your message',
  },
  fr: {
    checkbox_label: 'Ajouter un message cadeau',
    message_label: 'Votre message',
  },
};

let applyAttributeChange;

const stubShopify = ({
  settings = {},
  attributes = [],
  appMetafields = [translationEntry(TRANSLATIONS)],
  isoCode = 'en',
} = {}) => {
  applyAttributeChange = vi.fn().mockResolvedValue({type: 'success'});
  globalThis.shopify = {
    settings: {value: settings},
    attributes: {value: attributes},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    applyAttributeChange,
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
  vi.restoreAllMocks();
});

const checkbox = (container) => container.querySelector('s-checkbox');
const textArea = (container) => container.querySelector('s-text-area');

// `s-checkbox` is not a registered element under happy-dom, so Preact reflects
// `checked` as an attribute rather than a property. Once a test has dispatched a
// change the expando property exists, so read whichever is present.
const isChecked = (element) =>
  typeof element.checked === 'boolean'
    ? element.checked
    : element.hasAttribute('checked');

// The checkbox drives a signal, and signal-triggered re-renders are batched, so
// the dispatch has to be flushed before the DOM reflects the new state.
const tick = (element, checked) => {
  element.checked = checked;
  act(() => {
    element.dispatchEvent(new Event('change'));
  });
};

describe('initial state', () => {
  it('shows an unticked checkbox and no field when there is no saved message', () => {
    const {container} = render(<Extension />);

    expect(isChecked(checkbox(container))).toBe(false);
    expect(textArea(container)).toBeNull();
  });

  it('starts ticked with the field open when a message is already saved', () => {
    stubShopify({
      attributes: [{key: DEFAULT_MESSAGE_ATTRIBUTE, value: 'Happy birthday'}],
    });

    const {container} = render(<Extension />);

    expect(isChecked(checkbox(container))).toBe(true);
    expect(textArea(container).getAttribute('value')).toBe('Happy birthday');
  });

  it('stays unticked when the saved attribute is an empty string', () => {
    stubShopify({attributes: [{key: DEFAULT_MESSAGE_ATTRIBUTE, value: ''}]});

    const {container} = render(<Extension />);

    expect(isChecked(checkbox(container))).toBe(false);
    expect(textArea(container)).toBeNull();
  });

  it('ignores an unrelated cart attribute', () => {
    stubShopify({attributes: [{key: 'somethingElse', value: 'x'}]});

    const {container} = render(<Extension />);

    expect(isChecked(checkbox(container))).toBe(false);
  });
});

describe('toggling the checkbox', () => {
  it('reveals the field when ticked, without writing anything', () => {
    const {container} = render(<Extension />);

    tick(checkbox(container), true);

    expect(textArea(container)).not.toBeNull();
    expect(applyAttributeChange).not.toHaveBeenCalled();
  });

  it('clears the saved message when unticked', () => {
    stubShopify({
      attributes: [{key: DEFAULT_MESSAGE_ATTRIBUTE, value: 'Happy birthday'}],
    });
    const {container} = render(<Extension />);

    tick(checkbox(container), false);

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: DEFAULT_MESSAGE_ATTRIBUTE,
      value: '',
    });
    expect(textArea(container)).toBeNull();
  });

  it('reads the checked state, not the value, off the event', () => {
    // s-checkbox splits what the React Checkbox combined: `checked` is the
    // boolean state and `value` is the form value. Reading `value` would give a
    // string and the toggle would latch on.
    const {container} = render(<Extension />);
    const box = checkbox(container);
    box.value = 'on';

    tick(box, true);

    expect(textArea(container)).not.toBeNull();
  });
});

describe('writing the message', () => {
  it('saves what the buyer typed', () => {
    const {container} = render(<Extension />);
    tick(checkbox(container), true);

    const field = textArea(container);
    field.value = 'With love';
    field.dispatchEvent(new Event('change'));

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: DEFAULT_MESSAGE_ATTRIBUTE,
      value: 'With love',
    });
  });

  it('writes to the attribute key from the translations payload', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {message_attribute: 'custom-gift-key'}}),
      ],
    });
    const {container} = render(<Extension />);
    tick(checkbox(container), true);

    const field = textArea(container);
    field.value = 'Hi';
    field.dispatchEvent(new Event('change'));

    expect(applyAttributeChange).toHaveBeenCalledWith({
      type: 'updateAttribute',
      key: 'custom-gift-key',
      value: 'Hi',
    });
  });

  it('reads an existing message stored under a custom attribute key', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {message_attribute: 'custom-gift-key'}}),
      ],
      attributes: [{key: 'custom-gift-key', value: 'Saved earlier'}],
    });

    const {container} = render(<Extension />);

    expect(textArea(container).getAttribute('value')).toBe('Saved earlier');
  });
});

describe('labels', () => {
  it('uses the translated labels', () => {
    const {container} = render(<Extension />);
    tick(checkbox(container), true);

    expect(checkbox(container).getAttribute('label')).toBe('Add a gift message');
    expect(textArea(container).getAttribute('label')).toBe('Your message');
  });

  it('uses the buyer language for a regional locale', () => {
    stubShopify({isoCode: 'fr-CA'});
    const {container} = render(<Extension />);

    expect(checkbox(container).getAttribute('label')).toBe(
      'Ajouter un message cadeau',
    );
  });

  it('falls back to hardcoded English for an untranslated language', () => {
    // Not a fallback to the `en` payload — these are literals in the source.
    stubShopify({isoCode: 'de'});
    const {container} = render(<Extension />);
    tick(checkbox(container), true);

    expect(checkbox(container).getAttribute('label')).toBe(DEFAULT_CHECKBOX_LABEL);
    expect(textArea(container).getAttribute('label')).toBe(
      DEFAULT_MESSAGE_LABEL,
    );
  });

  it('falls back when the metafield is missing entirely', () => {
    stubShopify({appMetafields: []});
    const {container} = render(<Extension />);

    expect(checkbox(container).getAttribute('label')).toBe(DEFAULT_CHECKBOX_LABEL);
  });

  it('ignores a translations entry belonging to another extension', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {checkbox_label: 'Wrong block'}}, 'order_note'),
        translationEntry(TRANSLATIONS),
      ],
    });

    const {container} = render(<Extension />);

    expect(checkbox(container).getAttribute('label')).toBe('Add a gift message');
  });
});

describe('settings', () => {
  it('applies the merchant character limit', () => {
    stubShopify({settings: {message_limit: 40}});
    const {container} = render(<Extension />);
    tick(checkbox(container), true);

    expect(textArea(container).getAttribute('maxlength')).toBe('40');
  });

  it('defaults the limit to 150 when unset', () => {
    const {container} = render(<Extension />);
    tick(checkbox(container), true);

    expect(textArea(container).getAttribute('maxlength')).toBe('150');
  });

  it('treats a zero limit as unset', () => {
    // `message_limit || 150` in the original — a 0 from the merchant means
    // "no limit configured", not "no characters allowed".
    stubShopify({settings: {message_limit: 0}});
    const {container} = render(<Extension />);
    tick(checkbox(container), true);

    expect(textArea(container).getAttribute('maxlength')).toBe('150');
  });

  it('logs the attributes only in debug mode', () => {
    const log = vi.spyOn(console, 'log').mockImplementation(() => {});

    stubShopify({settings: {debug_mode: false}});
    render(<Extension />);
    expect(log).not.toHaveBeenCalled();

    cleanup();
    stubShopify({settings: {debug_mode: true}});
    render(<Extension />);
    expect(log).toHaveBeenCalledWith('attributes', []);
  });

  it('disables browser autofill on the message field', () => {
    // The old code passed `autocomplete={false}`, which is not a valid value on
    // 2026-07; "off" is the equivalent.
    const {container} = render(<Extension />);
    tick(checkbox(container), true);

    expect(textArea(container).getAttribute('autocomplete')).toBe('off');
  });
});
