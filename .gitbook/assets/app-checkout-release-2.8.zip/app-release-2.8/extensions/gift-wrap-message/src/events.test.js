import {describe, expect, it} from 'vitest';

import {fieldChecked, fieldValue} from './events.js';

describe('fieldValue', () => {
  const eventFrom = (currentTarget) => ({currentTarget});

  it('reads the value off the control that raised the event', () => {
    expect(fieldValue(eventFrom({value: 'typed'}))).toBe('typed');
  });

  it('returns an empty string when the control has no value', () => {
    // Must not return undefined: the caller branches on falsiness to decide
    // between updateNote and removeNote, and `undefined` would be indistinguishable
    // from a crash upstream.
    expect(fieldValue(eventFrom({}))).toBe('');
  });

  it('returns an empty string when there is no currentTarget', () => {
    expect(fieldValue(eventFrom(null))).toBe('');
  });

  it('preserves an empty string rather than coercing it', () => {
    expect(fieldValue(eventFrom({value: ''}))).toBe('');
  });
});

describe('fieldChecked', () => {
  const eventFrom = (currentTarget) => ({currentTarget});

  it('reads the checked state', () => {
    expect(fieldChecked(eventFrom({checked: true}))).toBe(true);
    expect(fieldChecked(eventFrom({checked: false}))).toBe(false);
  });

  it('ignores the form value, which is a separate prop on s-checkbox', () => {
    expect(fieldChecked(eventFrom({checked: false, value: 'on'}))).toBe(false);
  });

  it('is false when there is no checked state or no target', () => {
    expect(fieldChecked(eventFrom({}))).toBe(false);
    expect(fieldChecked(eventFrom(null))).toBe(false);
  });
});
