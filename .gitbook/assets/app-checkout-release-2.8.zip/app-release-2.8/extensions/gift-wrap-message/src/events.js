/**
 * Form-event helpers.
 */

/**
 * The current value of the form control that raised an event.
 * @param {Event} event
 * @returns {String}
 */
export const fieldValue = (event) =>
  /** @type {{value?: String}} */ (event.currentTarget)?.value ?? '';

/**
 * The checked state of the checkbox that raised an event.
 *
 * Note `s-checkbox` splits what the old React `Checkbox` combined: `checked` is
 * the boolean state, while `value` is the string submitted with a form. Reading
 * `value` here would return the form value, not the state.
 * @param {Event} event
 * @returns {Boolean}
 */
export const fieldChecked = (event) =>
  Boolean(/** @type {{checked?: Boolean}} */ (event.currentTarget)?.checked);
