import '@shopify/ui-extensions/preact';
import {useSignal} from '@preact/signals';
import {render} from "preact";

import {fieldChecked, fieldValue} from './events.js';
import {readTranslations} from './translations.js';

export default async () => {
  render(<Extension />, document.body)
};

/** Fallback copy used when the translation metafield has no entry. */
export const DEFAULT_CHECKBOX_LABEL = 'Include a gift message?';
export const DEFAULT_MESSAGE_LABEL = 'Gift Message';
export const DEFAULT_MESSAGE_ATTRIBUTE = 'giftwrap-message';
export const DEFAULT_MESSAGE_LIMIT = 150;

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const {
    message_limit = DEFAULT_MESSAGE_LIMIT,
    debug_mode = false,
  } = shopify.settings.value;
  const language = shopify.localization.language.value;
  const attributes = shopify.attributes.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'gift_message',
    language,
  });
  const {
    checkbox_label,
    // The cart-attribute key comes out of the translations payload, which means
    // it can differ per language.
    message_attribute = DEFAULT_MESSAGE_ATTRIBUTE,
    message_label,
  } = localTranslations;

  const messageValue =
    attributes?.find(({key}) => key === message_attribute)?.value || '';

  // Seeded from the saved attribute so a buyer returning to the step sees their
  // message already expanded. `useSignal` only takes the initial value on mount.
  const checkboxValue = useSignal(!!messageValue);

  const writeMessage = (value) =>
    shopify.applyAttributeChange({
      type: 'updateAttribute',
      key: message_attribute,
      value,
    });

  if (debug_mode) console.log('attributes', attributes);

  return (
    <s-stack direction="block" gap="base">
      {/*
        The label moved from children to a `label` attribute: `s-checkbox` takes
        no children (a rich label goes in a `label` slot instead).
      */}
      <s-checkbox
        label={checkbox_label || DEFAULT_CHECKBOX_LABEL}
        checked={checkboxValue.value}
        onChange={(event) => {
          const checked = fieldChecked(event);
          checkboxValue.value = checked;

          // Unticking clears the stored message; ticking leaves it alone.
          if (!checked) writeMessage('');
        }}
      />

      {checkboxValue.value && (
        <s-text-area
          label={message_label || DEFAULT_MESSAGE_LABEL}
          name={`checkout[attributes][${message_attribute}]`}
          value={messageValue}
          rows={4}
          autocomplete="off"
          maxLength={Number(message_limit) || DEFAULT_MESSAGE_LIMIT}
          onChange={(event) => writeMessage(fieldValue(event))}
        />
      )}
    </s-stack>
  );
}
