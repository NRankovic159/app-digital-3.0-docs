import {cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it} from 'vitest';

import {Extension} from './Checkout.jsx';

const KEY = 'pickup_location_confirmation_message';

const translationEntry = (byLanguage) => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key: KEY,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

/**
 * Minimal stand-in for the `shopify` global. Only the members this extension
 * reads are present, so a lookup this block doesn't declare fails loudly.
 */
const stubShopify = ({attributes = [], appMetafields = [], isoCode = 'en'} = {}) => {
  globalThis.shopify = {
    attributes: {value: attributes},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
  };
};

beforeEach(() => {
  stubShopify();
});

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

describe('pickup location confirmation message', () => {
  it('interpolates the selected location into the translated message', () => {
    stubShopify({
      attributes: [{key: '_selected_location', value: 'Berlin Store'}],
      appMetafields: [
        translationEntry({en: {message: 'Pick up at {{store_name}} tomorrow.'}}),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Pick up at Berlin Store tomorrow.');
  });

  it('renders the buyer language, not the default', () => {
    stubShopify({
      isoCode: 'fr-CA',
      attributes: [{key: '_selected_location', value: 'Magasin de Paris'}],
      appMetafields: [
        translationEntry({
          en: {message: 'Pick up at {{store_name}}.'},
          fr: {message: 'Retrait chez {{store_name}}.'},
        }),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('Retrait chez Magasin de Paris.');
  });

  it('renders nothing when no location is selected', () => {
    stubShopify({
      appMetafields: [translationEntry({en: {message: 'Pick up at {{store_name}}.'}})],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('renders nothing when the translations metafield is missing', () => {
    stubShopify({attributes: [{key: '_selected_location', value: 'Berlin Store'}]});

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('renders nothing when the buyer language has no message', () => {
    stubShopify({
      isoCode: 'de',
      attributes: [{key: '_selected_location', value: 'Berlin Store'}],
      appMetafields: [translationEntry({en: {message: 'Pick up at {{store_name}}.'}})],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('ignores a same-key metafield from another namespace', () => {
    // shopify.appMetafields is no longer filtered by the platform, so an
    // unrelated app's metafield must not be mistaken for ours.
    stubShopify({
      attributes: [{key: '_selected_location', value: 'Berlin Store'}],
      appMetafields: [
        {
          target: {type: 'shop', id: 'gid://shopify/Shop/1'},
          metafield: {
            namespace: 'apple',
            key: KEY,
            value: JSON.stringify({value: {en: {message: 'Wrong app copy'}}}),
            type: 'json',
          },
        },
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });
});
