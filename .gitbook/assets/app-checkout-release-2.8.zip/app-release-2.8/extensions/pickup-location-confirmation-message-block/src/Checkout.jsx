import '@shopify/ui-extensions/preact';
import {render} from "preact";

import {findAttributeValue, readTranslations} from './translations.js';

export default async () => {
  render(<Extension />, document.body)
};

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const language = shopify.localization.language.value;
  const selectedLocation = findAttributeValue(
    shopify.attributes.value,
    '_selected_location',
  );
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'pickup_location_confirmation_message',
    language,
  });

  if (!selectedLocation || !localTranslations.message) return null;

  const finalMessage = localTranslations.message.replace(
    '{{store_name}}',
    selectedLocation,
  );

  return (
    <s-stack direction="block" gap="base">
      <s-text color="subdued">{finalMessage}</s-text>
    </s-stack>
  );
}
