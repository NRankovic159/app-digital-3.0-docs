import {describe, expect, it} from 'vitest';

import {
  filterAppMetafields,
  findAttributeValue,
  languageCodeFrom,
  readTranslations,
} from './translations.js';

const KEY = 'pickup_location_confirmation_message';

const translationMetafield = (value) => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {namespace: 'sdg:translations', key: KEY, value, type: 'json'},
});

const payload = (byLanguage) => JSON.stringify({value: byLanguage});

describe('languageCodeFrom', () => {
  it('takes the base language from a regional isoCode', () => {
    expect(languageCodeFrom({isoCode: 'fr-CA'})).toBe('fr');
  });

  it('passes a bare language code through', () => {
    expect(languageCodeFrom({isoCode: 'fr'})).toBe('fr');
  });

  it('falls back to en when the language is missing', () => {
    expect(languageCodeFrom(undefined)).toBe('en');
    expect(languageCodeFrom({})).toBe('en');
  });
});

describe('filterAppMetafields', () => {
  // 2026-07 hands over every declared metafield rather than the filtered set
  // the useAppMetafields hook used to return, so this narrowing is the whole
  // reason the helper exists.
  it('ignores entries from another namespace or key', () => {
    const entries = [
      {metafield: {namespace: 'apple', key: KEY, value: 'wrong namespace'}},
      {metafield: {namespace: 'sdg:translations', key: 'line_item', value: 'wrong key'}},
      translationMetafield('right one'),
    ];

    expect(filterAppMetafields(entries, 'sdg:translations', KEY)).toEqual([
      translationMetafield('right one'),
    ]);
  });

  it('returns an empty list for missing input', () => {
    expect(filterAppMetafields(undefined, 'sdg:translations', KEY)).toEqual([]);
  });
});

describe('readTranslations', () => {
  it('reads the buyer language out of the sdg:translations payload', () => {
    const entries = [
      translationMetafield(payload({en: {message: 'en copy'}, fr: {message: 'fr copy'}})),
    ];

    expect(readTranslations(entries, {key: KEY, language: {isoCode: 'fr-CA'}})).toEqual({
      message: 'fr copy',
    });
  });

  it('does not fall back to en when the buyer language is absent from the payload', () => {
    const entries = [translationMetafield(payload({en: {message: 'en copy'}}))];

    expect(readTranslations(entries, {key: KEY, language: {isoCode: 'de'}})).toEqual({});
  });

  it('uses en when the buyer language itself is unknown', () => {
    const entries = [translationMetafield(payload({en: {message: 'en copy'}}))];

    expect(readTranslations(entries, {key: KEY, language: undefined})).toEqual({
      message: 'en copy',
    });
  });

  it('returns {} when the metafield is missing', () => {
    expect(readTranslations([], {key: KEY, language: {isoCode: 'en'}})).toEqual({});
    expect(readTranslations(undefined, {key: KEY, language: {isoCode: 'en'}})).toEqual({});
  });

  it('returns {} when the metafield holds an empty value', () => {
    expect(
      readTranslations([translationMetafield('')], {key: KEY, language: {isoCode: 'en'}}),
    ).toEqual({});
  });

  it('returns {} when the payload has no value wrapper', () => {
    expect(
      readTranslations([translationMetafield('{"en":{"message":"unwrapped"}}')], {
        key: KEY,
        language: {isoCode: 'en'},
      }),
    ).toEqual({});
  });

  it('reads the entry for this key even when other metafields come first', () => {
    const entries = [
      {metafield: {namespace: 'sdg:translations', key: 'line_item', value: payload({en: {message: 'line item copy'}})}},
      translationMetafield(payload({en: {message: 'pickup copy'}})),
    ];

    expect(readTranslations(entries, {key: KEY, language: {isoCode: 'en'}})).toEqual({
      message: 'pickup copy',
    });
  });
});

describe('findAttributeValue', () => {
  it('finds the value for a key', () => {
    const attributes = [
      {key: '_other', value: 'nope'},
      {key: '_selected_location', value: 'Berlin Store'},
    ];

    expect(findAttributeValue(attributes, '_selected_location')).toBe('Berlin Store');
  });

  it('returns undefined when the key is absent or the list is missing', () => {
    expect(findAttributeValue([{key: '_other', value: 'nope'}], '_selected_location')).toBeUndefined();
    expect(findAttributeValue(undefined, '_selected_location')).toBeUndefined();
  });
});
