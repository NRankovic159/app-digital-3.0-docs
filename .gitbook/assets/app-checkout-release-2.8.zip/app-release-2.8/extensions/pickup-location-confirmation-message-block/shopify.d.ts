import '@shopify/ui-extensions';

//@ts-ignore
declare module './src/Checkout.jsx' {
  const shopify: import('@shopify/ui-extensions/purchase.checkout.pickup-location-list.render-before').Api;
  const globalThis: { shopify: typeof shopify };
}

//@ts-ignore
declare module './src/translations.js' {
  const shopify: import('@shopify/ui-extensions/purchase.checkout.pickup-location-list.render-before').Api;
  const globalThis: { shopify: typeof shopify };
}
