import '@shopify/ui-extensions/preact';
import {useSignalEffect} from '@preact/signals';
import {render} from 'preact';

import {invalidWarrantyChanges} from './warranties';

export default async () => {
  render(<Extension />, document.body);
};

/**
 * Renders nothing. This extension exists purely to keep AppleCare warranty lines
 * consistent with the products they cover, reacting to every cart change.
 *
 * Exported for unit tests; the bundle only ever uses the default export.
 */
export function Extension() {
  useSignalEffect(() => {
    const changes = invalidWarrantyChanges(shopify.lines.value);

    // Applied one at a time and in order: each change invalidates the cart line
    // ids in the next, so they cannot be batched or run concurrently.
    void (async () => {
      for (const change of changes) {
        await shopify.applyCartLinesChange(change);
      }
    })();
  });

  return null;
}
