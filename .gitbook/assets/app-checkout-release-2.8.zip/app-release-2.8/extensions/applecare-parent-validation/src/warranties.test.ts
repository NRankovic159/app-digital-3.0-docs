import {describe, expect, it} from 'vitest';

import {
  findParentLine,
  getAttribute,
  invalidWarrantyChanges,
  partitionWarranties,
} from './warranties';

const line = ({
  id,
  productType,
  quantity = 1,
  uuid,
}: {
  id: string;
  productType: string;
  quantity?: number;
  uuid?: string;
}) => ({
  id: `gid://shopify/CartLine/${id}`,
  quantity,
  attributes: uuid === undefined ? [] : [{key: '_uuid', value: uuid}],
  merchandise: {
    id: `gid://shopify/ProductVariant/${id}`,
    product: {id: `gid://shopify/Product/${id}`, productType},
  },
  lineComponents: [],
});

const laptop = (over = {}) =>
  line({id: '1', productType: 'Laptop', uuid: 'abc', ...over});
const warranty = (over = {}) =>
  line({id: '2', productType: 'AppleCare', uuid: 'abc', ...over});

describe('getAttribute', () => {
  it('finds the attribute by key', () => {
    expect(getAttribute(laptop() as any, '_uuid')).toEqual({
      key: '_uuid',
      value: 'abc',
    });
  });

  it('returns null when the line has no such attribute', () => {
    expect(getAttribute(laptop({uuid: undefined}) as any, '_uuid')).toBeNull();
  });
});

describe('partitionWarranties', () => {
  it('splits warranties from everything else', () => {
    const [warranties, others] = partitionWarranties([
      laptop(),
      warranty(),
    ] as any);

    expect(warranties).toHaveLength(1);
    expect(others).toHaveLength(1);
    expect(warranties[0].id).toContain('/2');
    expect(others[0].id).toContain('/1');
  });

  it('matches the product type case-insensitively', () => {
    const [warranties] = partitionWarranties([
      line({id: 'a', productType: 'applecare'}),
      line({id: 'b', productType: 'AppleCare'}),
      line({id: 'c', productType: 'APPLECARE'}),
    ] as any);

    expect(warranties).toHaveLength(3);
  });

  it('does not treat a partial match as a warranty', () => {
    const [warranties, others] = partitionWarranties([
      line({id: 'a', productType: 'AppleCare Plus'}),
      line({id: 'b', productType: 'Care'}),
    ] as any);

    expect(warranties).toHaveLength(0);
    expect(others).toHaveLength(2);
  });

  it('preserves cart order within each group', () => {
    const [warranties] = partitionWarranties([
      line({id: 'w1', productType: 'applecare'}),
      line({id: 'x', productType: 'Laptop'}),
      line({id: 'w2', productType: 'applecare'}),
    ] as any);

    expect(warranties.map((l) => l.id)).toEqual([
      'gid://shopify/CartLine/w1',
      'gid://shopify/CartLine/w2',
    ]);
  });

  it('handles an empty or missing cart', () => {
    expect(partitionWarranties([])).toEqual([[], []]);
    expect(partitionWarranties(undefined as any)).toEqual([[], []]);
  });
});

describe('findParentLine', () => {
  it('matches on the _uuid attribute', () => {
    expect(findParentLine([laptop()] as any, warranty() as any)?.id).toBe(
      'gid://shopify/CartLine/1',
    );
  });

  it('does not match a different uuid', () => {
    expect(
      findParentLine([laptop({uuid: 'other'})] as any, warranty() as any),
    ).toBeUndefined();
  });

  it('does not match when the warranty has no uuid', () => {
    expect(
      findParentLine([laptop()] as any, warranty({uuid: undefined}) as any),
    ).toBeUndefined();
  });

  it('does not match when the candidate parent has no uuid', () => {
    expect(
      findParentLine([laptop({uuid: undefined})] as any, warranty() as any),
    ).toBeUndefined();
  });

  it('does not match two lines that both lack a uuid', () => {
    // Both sides missing must not count as "equal and therefore linked" — a
    // plain product and an unlinked warranty would silently adopt each other.
    expect(
      findParentLine(
        [laptop({uuid: undefined})] as any,
        warranty({uuid: undefined}) as any,
      ),
    ).toBeUndefined();
  });

  it('DOES match two lines whose uuid is an empty string', () => {
    expect(
      findParentLine([laptop({uuid: ''})] as any, warranty({uuid: ''}) as any)
        ?.id,
    ).toBe('gid://shopify/CartLine/1');
  });
});

describe('invalidWarrantyChanges', () => {
  it('leaves a valid pairing alone', () => {
    expect(invalidWarrantyChanges([laptop(), warranty()] as any)).toEqual([]);
  });

  it('removes a warranty whose parent is gone', () => {
    expect(invalidWarrantyChanges([warranty()] as any)).toEqual([
      {
        type: 'removeCartLine',
        id: 'gid://shopify/CartLine/2',
        quantity: 1,
      },
    ]);
  });

  it('removes with the warranty line quantity, not 1', () => {
    // The payload has to carry the full quantity or the removal only takes one
    // unit off and leaves a stranded warranty.
    expect(invalidWarrantyChanges([warranty({quantity: 3})] as any)).toEqual([
      {
        type: 'removeCartLine',
        id: 'gid://shopify/CartLine/2',
        quantity: 3,
      },
    ]);
  });

  it('removes a warranty carrying no _uuid at all', () => {
    expect(
      invalidWarrantyChanges([laptop(), warranty({uuid: undefined})] as any),
    ).toEqual([
      {
        type: 'removeCartLine',
        id: 'gid://shopify/CartLine/2',
        quantity: 1,
      },
    ]);
  });

  it('clamps a warranty down to its parent quantity', () => {
    expect(
      invalidWarrantyChanges([
        laptop({quantity: 1}),
        warranty({quantity: 3}),
      ] as any),
    ).toEqual([
      {
        type: 'updateCartLine',
        id: 'gid://shopify/CartLine/2',
        quantity: 1,
      },
    ]);
  });

  it('leaves a warranty alone when the parent has more units', () => {
    expect(
      invalidWarrantyChanges([
        laptop({quantity: 5}),
        warranty({quantity: 2}),
      ] as any),
    ).toEqual([]);
  });

  it('does not treat another warranty as a parent', () => {
    // Parents are only ever drawn from the non-warranty group, so two warranties
    // sharing a uuid must both be removed rather than adopting each other.
    const changes = invalidWarrantyChanges([
      line({id: 'w1', productType: 'applecare', uuid: 'same'}),
      line({id: 'w2', productType: 'applecare', uuid: 'same'}),
    ] as any);

    expect(changes).toHaveLength(2);
    expect(changes.every((c) => c.type === 'removeCartLine')).toBe(true);
  });

  it('reports one change per invalid warranty, in cart order', () => {
    const changes = invalidWarrantyChanges([
      line({id: 'w1', productType: 'applecare', uuid: 'gone'}),
      laptop({quantity: 1}),
      line({id: 'w2', productType: 'applecare', uuid: 'abc', quantity: 4}),
    ] as any);

    expect(changes).toEqual([
      {
        type: 'removeCartLine',
        id: 'gid://shopify/CartLine/w1',
        quantity: 1,
      },
      {
        type: 'updateCartLine',
        id: 'gid://shopify/CartLine/w2',
        quantity: 1,
      },
    ]);
  });

  it('does nothing for a cart with no warranties', () => {
    expect(invalidWarrantyChanges([laptop(), laptop({id: '9'})] as any)).toEqual(
      [],
    );
  });

  it('does nothing for an empty cart', () => {
    expect(invalidWarrantyChanges([])).toEqual([]);
  });
});
