import type {
  Attribute,
  CartLine,
  CartLineChange,
} from '@shopify/ui-extensions/checkout';

/**
 * AppleCare parent-line validation.
 *
 * A warranty line is only valid while the product it covers is still in the cart
 * in at least the same quantity. This module decides what to do about the ones
 * that aren't; `Checkout.tsx` applies the result.
 *
 * Split out from the component so the rules can be tested directly. This
 * extension mutates the cart with no buyer interaction, so a mistake here
 * silently deletes line items.
 */

/** Products whose `productType` matches this (case-insensitively) are warranties. */
export const WARRANTY_PRODUCT_TYPE = 'applecare';

/** The line attribute pairing a warranty to the product it covers. */
export const PARENT_LINK_ATTRIBUTE = '_uuid';

/**
 * One line attribute by key, or `null` when the line doesn't carry it.
 */
export const getAttribute = (
  line: CartLine,
  key: string,
): Attribute | null =>
  line.attributes.find((attribute) => attribute.key === key) || null;

/**
 * Split lines into warranties and everything else, preserving cart order.
 */
export const partitionWarranties = (
  lines: CartLine[],
): [CartLine[], CartLine[]] =>
  (lines || []).reduce<[CartLine[], CartLine[]]>(
    ([warranties, others], line) => {
      if (
        line.merchandise.product.productType.toLowerCase() ===
        WARRANTY_PRODUCT_TYPE
      ) {
        warranties.push(line);
      } else {
        others.push(line);
      }
      return [warranties, others];
    },
    [[], []],
  );

/**
 * The line a warranty covers, matched on the `_uuid` attribute.
 *
 * Both lines must carry the attribute. A warranty with no `_uuid` therefore has
 * no parent and gets removed.
 */
export const findParentLine = (
  others: CartLine[],
  warrantyLine: CartLine,
): CartLine | undefined => {
  const warrantyLineUUID = getAttribute(warrantyLine, PARENT_LINK_ATTRIBUTE);

  return others.find((line) => {
    const lineUUID = getAttribute(line, PARENT_LINK_ATTRIBUTE);
    return Boolean(
      lineUUID && warrantyLineUUID && lineUUID.value === warrantyLineUUID.value,
    );
  });
};

/**
 * The cart changes needed to bring warranty lines back in line with their
 * parents, in cart order. Empty when nothing is wrong.
 *
 * - no parent line      -> remove the warranty entirely
 * - parent quantity low -> clamp the warranty down to the parent's quantity
 */
export const invalidWarrantyChanges = (
  lines: CartLine[],
): CartLineChange[] => {
  const [warrantyItems, otherItems] = partitionWarranties(lines);

  return warrantyItems.reduce<CartLineChange[]>((updates, warrantyLine) => {
    const warrantyParentLine = findParentLine(otherItems, warrantyLine);

    if (!warrantyParentLine) {
      return [
        ...updates,
        {
          type: 'removeCartLine',
          id: warrantyLine.id,
          quantity: warrantyLine.quantity,
        },
      ];
    }

    if (warrantyParentLine.quantity < warrantyLine.quantity) {
      return [
        ...updates,
        {
          type: 'updateCartLine',
          id: warrantyLine.id,
          quantity: warrantyParentLine.quantity,
        },
      ];
    }

    return updates;
  }, []);
};
