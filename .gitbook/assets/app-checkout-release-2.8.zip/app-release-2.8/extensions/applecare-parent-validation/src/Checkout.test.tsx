import {signal} from '@preact/signals';
import {cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {Extension} from './Checkout';

const line = ({id, productType, quantity = 1, uuid}) => ({
  id: `gid://shopify/CartLine/${id}`,
  quantity,
  attributes: uuid === undefined ? [] : [{key: '_uuid', value: uuid}],
  merchandise: {
    id: `gid://shopify/ProductVariant/${id}`,
    product: {id: `gid://shopify/Product/${id}`, productType},
  },
  lineComponents: [],
});

const laptop = (over = {}) =>
  line({id: '1', productType: 'Laptop', uuid: 'abc', ...over});
const warranty = (over = {}) =>
  line({id: '2', productType: 'AppleCare', uuid: 'abc', ...over});

let lines;
let applyCartLinesChange;

const stubShopify = (initialLines = []) => {
  // A real signal, so useSignalEffect subscribes the way it does in the runtime.
  lines = signal(initialLines);
  applyCartLinesChange = vi.fn().mockResolvedValue({type: 'success'});
  globalThis.shopify = {lines, applyCartLinesChange};
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

const flush = () => new Promise((resolve) => setTimeout(resolve, 0));

describe('rendering', () => {
  it('renders nothing at all', () => {
    stubShopify([laptop(), warranty()]);

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });
});

describe('cart correction', () => {
  it('does not touch a valid cart', async () => {
    stubShopify([laptop(), warranty()]);

    render(<Extension />);
    await flush();

    expect(applyCartLinesChange).not.toHaveBeenCalled();
  });

  it('does not touch an empty cart', async () => {
    stubShopify([]);

    render(<Extension />);
    await flush();

    expect(applyCartLinesChange).not.toHaveBeenCalled();
  });

  it('removes an orphaned warranty on mount', async () => {
    stubShopify([warranty()]);

    render(<Extension />);
    await flush();

    expect(applyCartLinesChange).toHaveBeenCalledTimes(1);
    expect(applyCartLinesChange).toHaveBeenCalledWith({
      type: 'removeCartLine',
      id: 'gid://shopify/CartLine/2',
      quantity: 1,
    });
  });

  it('reacts when the cart changes after mount', async () => {
    stubShopify([laptop(), warranty()]);

    render(<Extension />);
    await flush();
    expect(applyCartLinesChange).not.toHaveBeenCalled();

    // The buyer removes the covered product, orphaning the warranty.
    lines.value = [warranty()];
    await flush();

    expect(applyCartLinesChange).toHaveBeenCalledWith({
      type: 'removeCartLine',
      id: 'gid://shopify/CartLine/2',
      quantity: 1,
    });
  });

  it('applies multiple corrections one at a time, in order', async () => {
    stubShopify([
      line({id: 'w1', productType: 'applecare', uuid: 'gone'}),
      laptop({quantity: 1}),
      line({id: 'w2', productType: 'applecare', uuid: 'abc', quantity: 4}),
    ]);

    render(<Extension />);
    await flush();

    // Sequential, not batched: each change invalidates the ids in the next.
    expect(applyCartLinesChange.mock.calls.map(([change]) => change)).toEqual([
      {
        type: 'removeCartLine',
        id: 'gid://shopify/CartLine/w1',
        quantity: 1,
      },
      {
        type: 'updateCartLine',
        id: 'gid://shopify/CartLine/w2',
        quantity: 1,
      },
    ]);
  });

  it('waits for each change to resolve before sending the next', async () => {
    const order = [];
    stubShopify([
      line({id: 'w1', productType: 'applecare', uuid: 'gone'}),
      line({id: 'w2', productType: 'applecare', uuid: 'alsogone'}),
    ]);
    applyCartLinesChange.mockImplementation(async (change) => {
      order.push(`start:${change.id}`);
      await new Promise((resolve) => setTimeout(resolve, 5));
      order.push(`end:${change.id}`);
      return {type: 'success'};
    });

    render(<Extension />);
    await new Promise((resolve) => setTimeout(resolve, 40));

    expect(order).toEqual([
      'start:gid://shopify/CartLine/w1',
      'end:gid://shopify/CartLine/w1',
      'start:gid://shopify/CartLine/w2',
      'end:gid://shopify/CartLine/w2',
    ]);
  });

  it('converges: once corrected, a re-run issues no further changes', async () => {
    stubShopify([warranty()]);

    render(<Extension />);
    await flush();
    expect(applyCartLinesChange).toHaveBeenCalledTimes(1);

    // The platform reflects the removal back into the signal. This must not
    // start another round of mutations.
    lines.value = [];
    await flush();

    expect(applyCartLinesChange).toHaveBeenCalledTimes(1);
  });
});
