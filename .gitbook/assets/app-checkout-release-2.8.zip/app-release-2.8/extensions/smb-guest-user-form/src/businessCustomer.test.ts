import {describe, expect, it} from 'vitest';

import {
  COMPANY_NAME_ATTRIBUTE,
  DEFAULT_COMPANY_NAME_LABEL,
  DEFAULT_VAT_ID_LABEL,
  VAT_ID_ATTRIBUTE,
  attributeValue,
  errorFor,
  labelsFrom,
  requiredFieldErrors,
} from './businessCustomer';

const TRANSLATIONS = {
  checkbox_label: 'Buying for a business?',
  company_name_label: 'Legal company name',
  vat_id_label: 'VAT number',
  field_required_error_message: 'Please enter your {{field_name}}',
};

describe('attributeValue', () => {
  const attributes = [
    {key: '__isBusinessCustomer', value: 'true'},
    {key: '__companyName', value: 'Acme'},
  ];

  it('finds a value by key', () => {
    expect(attributeValue(attributes as any, '__companyName')).toBe('Acme');
  });

  it('is undefined for a key that is not set', () => {
    expect(attributeValue(attributes as any, '__vatId')).toBeUndefined();
  });

  it('handles a missing attribute list', () => {
    expect(attributeValue(undefined, '__companyName')).toBeUndefined();
  });

  it('returns an empty string as an empty string', () => {
    // The clear-on-untick path writes '', which must read back as falsy-but-set
    // rather than undefined.
    expect(attributeValue([{key: 'x', value: ''}] as any, 'x')).toBe('');
  });
});

describe('labelsFrom', () => {
  it('uses the translated labels', () => {
    expect(labelsFrom(TRANSLATIONS)).toEqual({
      checkboxLabel: 'Buying for a business?',
      companyNameLabel: 'Legal company name',
      vatIdLabel: 'VAT number',
      fieldRequiredMessage: 'Please enter your {{field_name}}',
    });
  });

  it('falls back to hardcoded English when untranslated', () => {
    expect(labelsFrom({})).toEqual({
      checkboxLabel: 'Business User?',
      companyNameLabel: 'Company Name',
      vatIdLabel: 'VAT ID',
      fieldRequiredMessage: '{{field_name}} is required',
    });
  });

  it('falls back with no argument at all', () => {
    expect(labelsFrom().checkboxLabel).toBe('Business User?');
  });
});

describe('requiredFieldErrors', () => {
  it('is empty when both fields are filled', () => {
    expect(
      requiredFieldErrors({companyName: 'Acme', vatId: 'GB123'}),
    ).toEqual([]);
  });

  it('flags a missing company name', () => {
    expect(requiredFieldErrors({vatId: 'GB123'})).toEqual([
      {
        field: COMPANY_NAME_ATTRIBUTE,
        message: `${DEFAULT_COMPANY_NAME_LABEL} is required`,
      },
    ]);
  });

  it('flags a missing VAT id', () => {
    expect(requiredFieldErrors({companyName: 'Acme'})).toEqual([
      {field: VAT_ID_ATTRIBUTE, message: `${DEFAULT_VAT_ID_LABEL} is required`},
    ]);
  });

  it('flags both, company name first', () => {
    const errors = requiredFieldErrors({});

    expect(errors.map((error) => error.field)).toEqual([
      COMPANY_NAME_ATTRIBUTE,
      VAT_ID_ATTRIBUTE,
    ]);
  });

  it('treats an empty string as missing', () => {
    expect(requiredFieldErrors({companyName: '', vatId: ''})).toHaveLength(2);
  });

  it('treats whitespace as filled, matching pre-migration behaviour', () => {
    expect(requiredFieldErrors({companyName: ' ', vatId: ' '})).toEqual([]);
  });

  it('interpolates the translated field name into the translated message', () => {
    expect(requiredFieldErrors({translations: TRANSLATIONS})).toEqual([
      {
        field: COMPANY_NAME_ATTRIBUTE,
        message: 'Please enter your Legal company name',
      },
      {field: VAT_ID_ATTRIBUTE, message: 'Please enter your VAT number'},
    ]);
  });

  it('leaves the placeholder alone if the message omits it', () => {
    expect(
      requiredFieldErrors({
        translations: {field_required_error_message: 'This field is required'},
      })[0].message,
    ).toBe('This field is required');
  });
});

describe('errorFor', () => {
  const errors = [{field: COMPANY_NAME_ATTRIBUTE, message: 'Needed'}];

  it('returns the message for a field with an error', () => {
    expect(errorFor(errors, COMPANY_NAME_ATTRIBUTE)).toBe('Needed');
  });

  it('is undefined for a field with no error', () => {
    expect(errorFor(errors, VAT_ID_ATTRIBUTE)).toBeUndefined();
  });

  it('is undefined when there are no errors', () => {
    expect(errorFor([], COMPANY_NAME_ATTRIBUTE)).toBeUndefined();
  });
});
