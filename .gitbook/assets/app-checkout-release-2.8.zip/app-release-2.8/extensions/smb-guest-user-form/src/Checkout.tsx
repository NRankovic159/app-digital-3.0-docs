import '@shopify/ui-extensions/preact';
import {useSignal} from '@preact/signals';
import {render} from 'preact';

import {ALLOW, block, useInterceptor} from './buyerJourney';
import {
  BLOCK_REASON,
  BUSINESS_CUSTOMER_ATTRIBUTE,
  COMPANY_NAME_ATTRIBUTE,
  VAT_ID_ATTRIBUTE,
  attributeValue,
  errorFor,
  labelsFrom,
  requiredFieldErrors,
} from './businessCustomer';
import {fieldChecked, fieldValue} from './events';
import {readTranslations} from './translations';

export default async () => {
  render(<Extension />, document.body);
};

const TRANSLATION_KEY = 'smb_guest_user_form';

/**
 * Reads the translations straight off the `shopify` global.
 *
 * Needed inside the interceptor, which registers once and therefore cannot use
 * values captured during a render.
 */
const liveTranslations = () =>
  readTranslations(shopify.appMetafields.value, {
    key: TRANSLATION_KEY,
    language: shopify.localization.language.value,
  });

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const attributes = shopify.attributes.value;
  const purchasingCompany = shopify.buyerIdentity?.purchasingCompany?.value;
  const localTranslations = liveTranslations();

  const isBusinessCustomer = attributeValue(
    attributes,
    BUSINESS_CUSTOMER_ATTRIBUTE,
  );
  const companyName = attributeValue(attributes, COMPANY_NAME_ATTRIBUTE);
  const vatId = attributeValue(attributes, VAT_ID_ATTRIBUTE);

  const fieldErrors = useSignal([]);
  const {checkboxLabel, companyNameLabel, vatIdLabel} =
    labelsFrom(localTranslations);

  // Registered once, so everything it needs is read live from the `shopify`
  // global. Values captured during a render would be stale for the rest of the
  // session — and a stale "not a business customer" would let orders through with
  // no VAT details, while a stale "is a business customer" would block a checkout
  // the buyer has already corrected.
  useInterceptor(({canBlockProgress}) => {
    const currentAttributes = shopify.attributes.value;
    const isBusiness = attributeValue(
      currentAttributes,
      BUSINESS_CUSTOMER_ATTRIBUTE,
    );

    if (!canBlockProgress || !isBusiness) return ALLOW;

    const errors = requiredFieldErrors({
      companyName: attributeValue(currentAttributes, COMPANY_NAME_ATTRIBUTE),
      vatId: attributeValue(currentAttributes, VAT_ID_ATTRIBUTE),
      translations: liveTranslations(),
    });
    fieldErrors.value = errors;

    return errors.length > 0 ? block(BLOCK_REASON) : ALLOW;
  });

  const onCheckboxChange = async (isChecked) => {
    await shopify.applyAttributeChange({
      key: BUSINESS_CUSTOMER_ATTRIBUTE,
      type: 'updateAttribute',
      value: isChecked ? 'true' : '',
    });

    // Unticking clears the business fields so a stale VAT id can't ride along on
    // a consumer order.
    if (!isChecked) {
      await shopify.applyAttributeChange({
        key: COMPANY_NAME_ATTRIBUTE,
        type: 'updateAttribute',
        value: '',
      });
      await shopify.applyAttributeChange({
        key: VAT_ID_ATTRIBUTE,
        type: 'updateAttribute',
        value: '',
      });
    }
  };

  const onInputChange = (field, value) =>
    shopify.applyAttributeChange({
      key: field,
      type: 'updateAttribute',
      value: value ?? '',
    });

  // B2B buyers already have company details on the account, so the form is only
  // for guests.
  if (purchasingCompany) return null;

  return (
    <s-stack direction="block" gap="base">
      <s-checkbox
        label={checkboxLabel}
        checked={isBusinessCustomer === 'true'}
        onChange={(event) => onCheckboxChange(fieldChecked(event))}
      />

      {isBusinessCustomer === 'true' && (
        <s-stack direction="block" gap="base">
          <s-text-field
            label={companyNameLabel}
            value={companyName}
            error={errorFor(fieldErrors.value, COMPANY_NAME_ATTRIBUTE)}
            onChange={(event) =>
              onInputChange(COMPANY_NAME_ATTRIBUTE, fieldValue(event))
            }
          />
          <s-text-field
            label={vatIdLabel}
            value={vatId}
            error={errorFor(fieldErrors.value, VAT_ID_ATTRIBUTE)}
            onChange={(event) =>
              onInputChange(VAT_ID_ATTRIBUTE, fieldValue(event))
            }
          />
        </s-stack>
      )}
    </s-stack>
  );
}
