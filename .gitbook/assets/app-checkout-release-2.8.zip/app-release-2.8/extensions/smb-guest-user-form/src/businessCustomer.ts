import type {Attribute} from '@shopify/ui-extensions/checkout';

/**
 * Business-customer field rules for the SMB guest form.
 *
 * Kept separate from the component because these rules run inside a buyer-journey
 * interceptor: getting them wrong either blocks a checkout that should proceed or
 * lets an order through without the VAT details the business needs.
 */

export const BUSINESS_CUSTOMER_ATTRIBUTE = '__isBusinessCustomer';
export const COMPANY_NAME_ATTRIBUTE = '__companyName';
export const VAT_ID_ATTRIBUTE = '__vatId';

/** Passed to the platform for logging; never shown to the buyer. */
export const BLOCK_REASON = 'Missing Required Business Customer Info';

/** Copy used when the translations metafield has no entry. */
export const DEFAULT_CHECKBOX_LABEL = 'Business User?';
export const DEFAULT_COMPANY_NAME_LABEL = 'Company Name';
export const DEFAULT_VAT_ID_LABEL = 'VAT ID';
export const DEFAULT_FIELD_REQUIRED_MESSAGE = '{{field_name}} is required';

export interface FieldError {
  field: string;
  message: string;
}

/**
 * One cart attribute's value, or `undefined` when it isn't set.
 *
 * Replaces `useAttributeValues([...])`, which returned values positionally.
 */
export const attributeValue = (
  attributes: Attribute[] | undefined,
  key: string,
): string | undefined =>
  attributes?.find((attribute) => attribute.key === key)?.value ?? undefined;

/**
 * The labels this form shows, with fallbacks applied.
 */
export const labelsFrom = (translations: Record<string, string> = {}) => ({
  checkboxLabel: translations?.checkbox_label ?? DEFAULT_CHECKBOX_LABEL,
  companyNameLabel:
    translations?.company_name_label ?? DEFAULT_COMPANY_NAME_LABEL,
  vatIdLabel: translations?.vat_id_label ?? DEFAULT_VAT_ID_LABEL,
  fieldRequiredMessage:
    translations?.field_required_error_message ??
    DEFAULT_FIELD_REQUIRED_MESSAGE,
});

/**
 * Errors for any required business field left empty, in form order.
 *
 * Both fields are required once the buyer identifies as a business. Empty means
 * missing — a whitespace-only value counts as filled, which is the pre-migration
 * behaviour.
 */
export const requiredFieldErrors = ({
  companyName,
  vatId,
  translations,
}: {
  companyName?: string;
  vatId?: string;
  translations?: Record<string, string>;
}): FieldError[] => {
  const {companyNameLabel, vatIdLabel, fieldRequiredMessage} =
    labelsFrom(translations);
  const errors: FieldError[] = [];

  if (!companyName) {
    errors.push({
      field: COMPANY_NAME_ATTRIBUTE,
      message: fieldRequiredMessage.replace('{{field_name}}', companyNameLabel),
    });
  }

  if (!vatId) {
    errors.push({
      field: VAT_ID_ATTRIBUTE,
      message: fieldRequiredMessage.replace('{{field_name}}', vatIdLabel),
    });
  }

  return errors;
};

/**
 * The message for one field, or `undefined` when that field is fine.
 */
export const errorFor = (
  errors: FieldError[],
  field: string,
): string | undefined => errors.find((error) => error.field === field)?.message;
