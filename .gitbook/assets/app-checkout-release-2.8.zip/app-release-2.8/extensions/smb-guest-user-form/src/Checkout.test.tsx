import {act, cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {Extension} from './Checkout';
import {BLOCK_REASON} from './businessCustomer';

const translationEntry = (byLanguage, key = 'smb_guest_user_form') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {
    checkbox_label: 'Buying for a business?',
    company_name_label: 'Legal company name',
    vat_id_label: 'VAT number',
    field_required_error_message: 'Please enter your {{field_name}}',
  },
  fr: {checkbox_label: 'Achat professionnel?'},
};

const businessAttributes = ({company = 'Acme', vat = 'GB123'} = {}) => [
  {key: '__isBusinessCustomer', value: 'true'},
  {key: '__companyName', value: company},
  {key: '__vatId', value: vat},
];

let intercept;
let registeredInterceptor;
let teardown;
let applyAttributeChange;
let attributes;

const stubShopify = ({
  initialAttributes = [],
  appMetafields = [translationEntry(TRANSLATIONS)],
  isoCode = 'en',
  purchasingCompany = undefined,
} = {}) => {
  registeredInterceptor = undefined;
  teardown = vi.fn();
  attributes = {value: initialAttributes};
  applyAttributeChange = vi.fn().mockResolvedValue({type: 'success'});
  intercept = vi.fn(async (interceptor) => {
    registeredInterceptor = interceptor;
    return teardown;
  });
  globalThis.shopify = {
    attributes,
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    buyerIdentity: {purchasingCompany: {value: purchasingCompany}},
    applyAttributeChange,
    buyerJourney: {intercept},
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

const checkbox = (container) => container.querySelector('s-checkbox');
const fields = (container) => [...container.querySelectorAll('s-text-field')];

const settle = () =>
  act(async () => {
    await Promise.resolve();
    await Promise.resolve();
  });

const run = (props = {canBlockProgress: true}) => registeredInterceptor(props);

describe('the interceptor — allowing branch', () => {
  it('allows a consumer checkout with nothing filled in', async () => {
    render(<Extension />);
    await settle();

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('allows when the extension cannot block progress', async () => {
    stubShopify({initialAttributes: [{key: '__isBusinessCustomer', value: 'true'}]});
    render(<Extension />);
    await settle();

    expect(run({canBlockProgress: false})).toEqual({behavior: 'allow'});
  });

  it('allows a business customer with both fields filled', async () => {
    stubShopify({initialAttributes: businessAttributes()});
    render(<Extension />);
    await settle();

    expect(run()).toEqual({behavior: 'allow'});
  });
});

describe('the interceptor — blocking branch', () => {
  it('blocks a business customer with nothing filled', async () => {
    stubShopify({initialAttributes: [{key: '__isBusinessCustomer', value: 'true'}]});
    render(<Extension />);
    await settle();

    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});
  });

  it('blocks when only the company name is missing', async () => {
    stubShopify({initialAttributes: businessAttributes({company: ''})});
    render(<Extension />);
    await settle();

    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});
  });

  it('blocks when only the VAT id is missing', async () => {
    stubShopify({initialAttributes: businessAttributes({vat: ''})});
    render(<Extension />);
    await settle();

    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});
  });

  it('shows a per-field error on the right field when it blocks', async () => {
    stubShopify({initialAttributes: businessAttributes({vat: ''})});
    const {container} = render(<Extension />);
    await settle();

    await act(async () => {
      run();
    });

    const [company, vat] = fields(container);
    expect(company.getAttribute('error')).toBeFalsy();
    expect(vat.getAttribute('error')).toBe('Please enter your VAT number');
  });

  it('shows errors on both fields when both are missing', async () => {
    stubShopify({
      initialAttributes: businessAttributes({company: '', vat: ''}),
    });
    const {container} = render(<Extension />);
    await settle();

    await act(async () => {
      run();
    });

    const [company, vat] = fields(container);
    expect(company.getAttribute('error')).toBe(
      'Please enter your Legal company name',
    );
    expect(vat.getAttribute('error')).toBe('Please enter your VAT number');
  });
});

describe('the interceptor reads live values', () => {
  // Registered once, so anything captured at registration is stale forever.
  it('stops blocking once the buyer fills the fields in', async () => {
    stubShopify({
      initialAttributes: businessAttributes({company: '', vat: ''}),
    });
    render(<Extension />);
    await settle();
    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});

    attributes.value = businessAttributes();

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('starts blocking once the buyer ticks the business checkbox', async () => {
    render(<Extension />);
    await settle();
    expect(run()).toEqual({behavior: 'allow'});

    attributes.value = businessAttributes({company: '', vat: ''});

    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});
  });

  it('registers exactly once across attribute changes', async () => {
    render(<Extension />);
    await settle();

    attributes.value = businessAttributes();
    await settle();

    expect(intercept).toHaveBeenCalledTimes(1);
  });
});

describe('teardown', () => {
  it('removes the interceptor on unmount', async () => {
    render(<Extension />);
    await settle();

    cleanup();

    expect(teardown).toHaveBeenCalled();
  });

  it('removes an interceptor that resolves after unmount', async () => {
    let resolveRegistration;
    intercept.mockImplementation(
      () => new Promise((resolve) => (resolveRegistration = resolve)),
    );

    render(<Extension />);
    cleanup();

    await act(async () => {
      resolveRegistration(teardown);
    });

    expect(teardown).toHaveBeenCalled();
  });
});

describe('B2B buyers', () => {
  it('renders nothing when the buyer is purchasing for a company', () => {
    stubShopify({purchasingCompany: {company: {id: 'gid://shopify/Company/1'}}});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders when buyerIdentity is absent entirely', () => {
    // `buyerIdentity` is optional on the API, and protected-customer-data access
    // can withhold it. The form must still work for guests.
    stubShopify();
    delete globalThis.shopify.buyerIdentity;

    const {container} = render(<Extension />);

    expect(checkbox(container)).not.toBeNull();
  });
});

describe('the form', () => {
  it('shows only the checkbox until it is ticked', () => {
    const {container} = render(<Extension />);

    expect(checkbox(container).getAttribute('label')).toBe(
      'Buying for a business?',
    );
    expect(fields(container)).toHaveLength(0);
  });

  it('reveals both fields when the attribute says business', () => {
    stubShopify({initialAttributes: businessAttributes()});

    const {container} = render(<Extension />);

    const [company, vat] = fields(container);
    expect(company.getAttribute('label')).toBe('Legal company name');
    expect(company.getAttribute('value')).toBe('Acme');
    expect(vat.getAttribute('label')).toBe('VAT number');
    expect(vat.getAttribute('value')).toBe('GB123');
  });

  it('requires the attribute to be exactly "true"', () => {
    stubShopify({initialAttributes: [{key: '__isBusinessCustomer', value: 'yes'}]});

    const {container} = render(<Extension />);

    expect(fields(container)).toHaveLength(0);
  });

  it('writes the business flag when ticked, without clearing the fields', async () => {
    const {container} = render(<Extension />);

    await act(async () => {
      const box = checkbox(container);
      box.checked = true;
      box.dispatchEvent(new Event('change'));
    });

    expect(applyAttributeChange).toHaveBeenCalledTimes(1);
    expect(applyAttributeChange).toHaveBeenCalledWith({
      key: '__isBusinessCustomer',
      type: 'updateAttribute',
      value: 'true',
    });
  });

  it('clears the flag and both fields when unticked', async () => {
    stubShopify({initialAttributes: businessAttributes()});
    const {container} = render(<Extension />);

    await act(async () => {
      const box = checkbox(container);
      box.checked = false;
      box.dispatchEvent(new Event('change'));
    });

    // A stale VAT id must not ride along on a consumer order.
    expect(applyAttributeChange.mock.calls.map(([change]) => change)).toEqual([
      {key: '__isBusinessCustomer', type: 'updateAttribute', value: ''},
      {key: '__companyName', type: 'updateAttribute', value: ''},
      {key: '__vatId', type: 'updateAttribute', value: ''},
    ]);
  });

  it('writes the company name as the buyer types', async () => {
    stubShopify({initialAttributes: businessAttributes()});
    const {container} = render(<Extension />);
    const [company] = fields(container);

    company.value = 'Globex';
    await act(async () => {
      company.dispatchEvent(new Event('change'));
    });

    expect(applyAttributeChange).toHaveBeenCalledWith({
      key: '__companyName',
      type: 'updateAttribute',
      value: 'Globex',
    });
  });

  it('writes the VAT id as the buyer types', async () => {
    stubShopify({initialAttributes: businessAttributes()});
    const {container} = render(<Extension />);
    const [, vat] = fields(container);

    vat.value = 'DE999';
    await act(async () => {
      vat.dispatchEvent(new Event('change'));
    });

    expect(applyAttributeChange).toHaveBeenCalledWith({
      key: '__vatId',
      type: 'updateAttribute',
      value: 'DE999',
    });
  });

  it('writes an empty string when a field is cleared', async () => {
    stubShopify({initialAttributes: businessAttributes()});
    const {container} = render(<Extension />);
    const [company] = fields(container);

    company.value = '';
    await act(async () => {
      company.dispatchEvent(new Event('change'));
    });

    expect(applyAttributeChange).toHaveBeenCalledWith({
      key: '__companyName',
      type: 'updateAttribute',
      value: '',
    });
  });
});

describe('translations', () => {
  it('uses the buyer language for a regional locale', () => {
    stubShopify({isoCode: 'fr-CA'});

    const {container} = render(<Extension />);

    expect(checkbox(container).getAttribute('label')).toBe(
      'Achat professionnel?',
    );
  });

  it('falls back to hardcoded English when untranslated', () => {
    stubShopify({isoCode: 'de', initialAttributes: businessAttributes()});

    const {container} = render(<Extension />);

    expect(checkbox(container).getAttribute('label')).toBe('Business User?');
    expect(fields(container)[0].getAttribute('label')).toBe('Company Name');
  });

  it('ignores a translations entry belonging to another extension', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {checkbox_label: 'Wrong block'}}, 'order_note'),
        translationEntry(TRANSLATIONS),
      ],
    });

    const {container} = render(<Extension />);

    expect(checkbox(container).getAttribute('label')).toBe(
      'Buying for a business?',
    );
  });
});
