import {readTranslations} from './translations.js';

/**
 * Wire transfer payment instructions: the amount owed plus the merchant's bank
 * details, all of it merchant-configured through the extension's settings.
 *
 * Shared by the checkout and Thank you targets — both are read-only.
 */
export function Extension() {
  const {
    enable = true,
    account,
    owner,
    iban,
    swift_bic,
    example_order_id,
  } = shopify.settings.value;
  const language = shopify.localization.language.value;
  const totalAmount = shopify.cost.totalAmount.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'wire_transfer',
    language,
  });

  // Settings values are typed `string | number | boolean`, so coerce before
  // string work. Both fields are single_line_text_field, so in practice this
  // is the same value either way.
  const IBAN = String(iban || '');
  const BIC = String(swift_bic || '');

  const locale = language?.isoCode || 'en-US';

  const currency = new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: totalAmount.currencyCode,
  });

  if (!enable) return null;

  return (
    <s-stack
      direction="block"
      gap="base"
      justifyContent="start"
      alignItems="start"
      padding="base"
      borderRadius="base"
      border="base"
    >
      {localTranslations?.summary && (
        <s-text>
          {localTranslations?.summary}
        </s-text>
      )}

      <s-stack direction="block" gap="small-400">
        {totalAmount?.amount && (
          <s-text type="strong">
            {localTranslations?.amount}: {currency.format(totalAmount.amount)}
          </s-text>
        )}

        <s-text type="strong">
          {localTranslations?.current_account}:
          {' '}
          <s-text type="strong">
            {account}
          </s-text>
        </s-text>
        <s-text type="strong">
          {localTranslations?.owner}: {owner}
        </s-text>
        <s-text type="strong">
          {localTranslations?.iban}: {IBAN}
        </s-text>
        <s-text>
          ({localTranslations?.iban_no_spaces}): {IBAN?.replace(/\s/g, '')}
        </s-text>
        <s-text>
          {localTranslations?.swift_bic}: {BIC}
        </s-text>
        <s-text type="strong">
          {localTranslations?.transfer_concept}:
        </s-text>
        <s-text>
          {localTranslations?.transfer_instructions}
        </s-text>

        <s-text type="strong">
          {localTranslations?.example}: {example_order_id}
        </s-text>
      </s-stack>
    </s-stack>
  )
}
