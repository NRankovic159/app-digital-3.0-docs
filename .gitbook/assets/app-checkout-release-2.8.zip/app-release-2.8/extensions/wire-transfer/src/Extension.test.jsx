import {cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it} from 'vitest';

import {Extension} from './Extension.jsx';

const KEY = 'wire_transfer';

const translationEntry = (byLanguage) => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key: KEY,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const EN = {
  summary: 'Please deposit the amount below within 48 hours.',
  amount: 'Amount',
  current_account: 'Current account',
  owner: 'Owner',
  iban: 'IBAN',
  iban_no_spaces: 'IBAN without spaces',
  swift_bic: 'SWIFT/BIC',
  transfer_concept: 'Transfer/income concept',
  transfer_instructions: 'Copy your Order Number from the Order Status page.',
  example: 'Example',
};

const SETTINGS = {
  enable: true,
  account: 'ES12 3456',
  owner: 'Topaz Ltd',
  iban: 'ES91 2100 0418 4502 0005 1332',
  swift_bic: 'CAIXESBBXXX',
  example_order_id: '#1234',
};

/**
 * Minimal stand-in for the `shopify` global. `settings` is passed through
 * verbatim so a test can omit keys entirely.
 */
const stubShopify = ({
  settings = SETTINGS,
  appMetafields = [translationEntry({en: EN})],
  isoCode = 'en',
  totalAmount = {amount: 1234.5, currencyCode: 'EUR'},
} = {}) => {
  globalThis.shopify = {
    settings: {value: settings},
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    cost: {totalAmount: {value: totalAmount}},
  };
};

beforeEach(() => {
  stubShopify();
});

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

describe('enable setting', () => {
  it('renders nothing when explicitly disabled', () => {
    stubShopify({settings: {...SETTINGS, enable: false}});

    const {container} = render(<Extension />);

    expect(container.textContent).toBe('');
  });

  it('renders when the setting was never saved, because enable defaults to true', () => {
    // Note this is the opposite default to estimated-shipping-block: wire
    // transfer instructions show unless a merchant turns them off.
    const {enable: _omitted, ...withoutEnable} = SETTINGS;
    stubShopify({settings: withoutEnable});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Current account');
  });
});

describe('bank details', () => {
  it('renders every configured setting', () => {
    const {container} = render(<Extension />);
    const text = container.textContent;

    expect(text).toContain('Current account: ES12 3456');
    expect(text).toContain('Owner: Topaz Ltd');
    expect(text).toContain('IBAN: ES91 2100 0418 4502 0005 1332');
    expect(text).toContain('SWIFT/BIC: CAIXESBBXXX');
    expect(text).toContain('Example: #1234');
  });

  it('renders the IBAN a second time with spaces stripped', () => {
    const {container} = render(<Extension />);

    expect(container.textContent).toContain(
      '(IBAN without spaces): ES9121000418450200051332',
    );
  });

  it('renders empty strings rather than "undefined" when settings are missing', () => {
    stubShopify({settings: {enable: true}});

    const {container} = render(<Extension />);

    expect(container.textContent).not.toContain('undefined');
  });
});

describe('amount', () => {
  it('formats the cart total in the checkout currency and buyer locale', () => {
    const {container} = render(<Extension />);

    // en + EUR: symbol-prefixed, comma thousands separator.
    expect(container.textContent).toContain('Amount: €1,234.50');
  });

  it('formats using the buyer locale conventions', () => {
    stubShopify({
      isoCode: 'de-DE',
      appMetafields: [translationEntry({de: EN})],
    });

    const {container} = render(<Extension />);

    // de-DE: dot thousands separator, comma decimal, trailing symbol.
    expect(container.textContent).toContain('Amount: 1.234,50');
  });

  it('omits the amount line when the total is zero', () => {
    // 0 is falsy, so the old code hid the line — preserved deliberately.
    stubShopify({totalAmount: {amount: 0, currencyCode: 'EUR'}});

    const {container} = render(<Extension />);

    expect(container.textContent).not.toContain('Amount:');
    expect(container.textContent).toContain('Current account');
  });
});

describe('translations', () => {
  it('renders the buyer language, not the default', () => {
    stubShopify({
      isoCode: 'fr-CA',
      appMetafields: [
        translationEntry({
          en: EN,
          fr: {...EN, current_account: 'Compte courant', owner: 'Propriétaire'},
        }),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Compte courant: ES12 3456');
    expect(container.textContent).toContain('Propriétaire: Topaz Ltd');
    expect(container.textContent).not.toContain('Current account');
  });

  it('omits the summary paragraph when it has no translation', () => {
    const {summary: _omitted, ...withoutSummary} = EN;
    stubShopify({appMetafields: [translationEntry({en: withoutSummary})]});

    const {container} = render(<Extension />);

    expect(container.textContent).not.toContain('within 48 hours');
    expect(container.textContent).toContain('Current account');
  });

  it('still renders the settings values when the metafield is missing', () => {
    // Labels disappear but the bank details must not, so a buyer can always
    // see where to send money.
    stubShopify({appMetafields: []});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('ES12 3456');
    expect(container.textContent).toContain('CAIXESBBXXX');
  });

  it('ignores a same-key metafield from another namespace', () => {
    stubShopify({
      appMetafields: [
        {
          target: {type: 'shop', id: 'gid://shopify/Shop/1'},
          metafield: {
            namespace: 'apple',
            key: KEY,
            value: JSON.stringify({value: {en: {owner: 'Wrong app copy'}}}),
            type: 'json',
          },
        },
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).not.toContain('Wrong app copy');
  });
});
