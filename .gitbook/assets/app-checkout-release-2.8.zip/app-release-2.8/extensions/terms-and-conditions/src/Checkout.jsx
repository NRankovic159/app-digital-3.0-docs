import '@shopify/ui-extensions/preact';
import {useSignal} from '@preact/signals';
import {render} from "preact";

import {ALLOW, block, useInterceptor} from './buyerJourney.js';
import {fieldChecked} from './events.js';
import {readTranslations} from './translations.js';

export default async () => {
  render(<Extension />, document.body)
};

/** Shown inline on the checkbox when the buyer tries to continue unchecked. */
export const TERMS_ERROR = 'Please accept the terms and conditions';

/** Passed to the platform for logging; never shown to the buyer. */
export const BLOCK_REASON = 'Missing required fields';

// Exported for unit tests; the bundle only ever uses the default export.
export function Extension() {
  const {enable} = shopify.settings.value;
  const language = shopify.localization.language.value;
  const localTranslations = readTranslations(shopify.appMetafields.value, {
    key: 'terms_conditions',
    language,
  });

  const checked = useSignal(false);
  const error = useSignal('');

  // Registered once. Everything it needs is read live — `checked` from the signal
  // and `enable` from the settings signal — because a value captured here would
  // be stale for the rest of the session, and a stale `enable` would block every
  // checkout on the store.
  useInterceptor(({canBlockProgress}) => {
    error.value = '';

    const {enable: enabled} = shopify.settings.value;
    if (!canBlockProgress || !enabled) return ALLOW;

    if (!checked.value) {
      error.value = TERMS_ERROR;
      return block(BLOCK_REASON);
    }

    return ALLOW;
  });

  if (!enable) return null;

  return (
    <s-stack direction="block" gap="base">
      {localTranslations?.heading && (
        <s-heading>{localTranslations?.heading}</s-heading>
      )}

      {/*
        A rich label goes in the `label` slot — `s-checkbox` takes a plain string
        in its `label` prop, and only an `s-text` (with `s-link` children) is
        allowed as slotted content. This is the pattern in Shopify's own checkbox
        migration guide; the shipped types just omit `children` on the element.

        The suppression has to sit here rather than on the child, because it's the
        element's own prop type that rejects children — which means props on this
        one tag aren't type-checked. `id`, `name`, `checked`, `error` and `onChange`
        are all asserted in Checkout.test.jsx instead.
      */}
      {/* @ts-expect-error `s-checkbox` children are documented but untyped */}
      <s-checkbox
        id="terms-conditions"
        name="terms-conditions"
        checked={checked.value}
        error={error.value}
        onChange={(event) => {
          checked.value = fieldChecked(event);
          error.value = '';
        }}
      >
        <s-text slot="label">
          {localTranslations?.terms_conditions_before_link}
          {localTranslations?.link_text && localTranslations?.link_url && (
            <>
              {' '}
              <s-link href={localTranslations?.link_url}>
                {localTranslations?.link_text}
              </s-link>
              {' '}
            </>
          )}
          {localTranslations?.terms_conditions_after_link}
        </s-text>
      </s-checkbox>
    </s-stack>
  );
}
