import {act, cleanup, render} from '@testing-library/preact';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

import {BLOCK_REASON, Extension, TERMS_ERROR} from './Checkout.jsx';

const translationEntry = (byLanguage, key = 'terms_conditions') => ({
  target: {type: 'shop', id: 'gid://shopify/Shop/1'},
  metafield: {
    namespace: 'sdg:translations',
    key,
    value: JSON.stringify({value: byLanguage}),
    type: 'json',
  },
});

const TRANSLATIONS = {
  en: {
    heading: 'Terms',
    terms_conditions_before_link: 'I agree to the',
    link_text: 'terms and conditions',
    link_url: 'https://example.com/terms',
    terms_conditions_after_link: 'of sale.',
  },
  fr: {
    heading: 'Conditions',
    terms_conditions_before_link: "J'accepte les",
  },
};

let intercept;
let registeredInterceptor;
let teardown;
let settings;

const stubShopify = ({
  initialSettings = {enable: true},
  appMetafields = [translationEntry(TRANSLATIONS)],
  isoCode = 'en',
} = {}) => {
  registeredInterceptor = undefined;
  teardown = vi.fn();
  settings = {value: initialSettings};
  intercept = vi.fn(async (interceptor) => {
    registeredInterceptor = interceptor;
    return teardown;
  });
  globalThis.shopify = {
    settings,
    appMetafields: {value: appMetafields},
    localization: {language: {value: {isoCode}}},
    buyerJourney: {intercept},
  };
};

beforeEach(() => stubShopify());

afterEach(() => {
  cleanup();
  delete globalThis.shopify;
});

const checkbox = (container) => container.querySelector('s-checkbox');

// Registration resolves on a microtask.
const settle = () =>
  act(async () => {
    await Promise.resolve();
    await Promise.resolve();
  });

const tick = (element, checked) => {
  element.checked = checked;
  act(() => {
    element.dispatchEvent(new Event('change'));
  });
};

const run = (props = {canBlockProgress: true}) => registeredInterceptor(props);

describe('the interceptor — blocking branch', () => {
  it('blocks when the box is unchecked', async () => {
    render(<Extension />);
    await settle();

    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});
  });

  it('surfaces an inline error when it blocks', async () => {
    const {container} = render(<Extension />);
    await settle();

    await act(async () => {
      run();
    });

    // The `reason` is not shown to the buyer, so blocking without this would
    // look like checkout silently doing nothing.
    expect(checkbox(container).getAttribute('error')).toBe(TERMS_ERROR);
  });
});

describe('the interceptor — allowing branch', () => {
  it('allows once the box is checked', async () => {
    const {container} = render(<Extension />);
    await settle();

    tick(checkbox(container), true);

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('allows when the extension cannot block progress', async () => {
    // The merchant has not granted block_progress. Blocking here would be
    // ignored by the platform but the buyer would still see an error.
    render(<Extension />);
    await settle();

    expect(run({canBlockProgress: false})).toEqual({behavior: 'allow'});
  });

  it('sets no error when it cannot block progress', async () => {
    const {container} = render(<Extension />);
    await settle();

    await act(async () => {
      run({canBlockProgress: false});
    });

    expect(checkbox(container).getAttribute('error')).toBeFalsy();
  });

  it('allows when the block is disabled, even unchecked', async () => {
    stubShopify({initialSettings: {enable: false}});
    render(<Extension />);
    await settle();

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('clears a previous error on each run', async () => {
    const {container} = render(<Extension />);
    await settle();

    await act(async () => {
      run();
    });
    expect(checkbox(container).getAttribute('error')).toBe(TERMS_ERROR);

    tick(checkbox(container), true);
    await act(async () => {
      run();
    });

    expect(checkbox(container).getAttribute('error')).toBeFalsy();
  });

  it('re-blocks if the buyer unchecks after being allowed', async () => {
    const {container} = render(<Extension />);
    await settle();

    tick(checkbox(container), true);
    expect(run()).toEqual({behavior: 'allow'});

    tick(checkbox(container), false);

    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});
  });
});

describe('the interceptor reads live values', () => {
  // This is the whole risk of the 2026-07 registration model: the interceptor is
  // installed once, so anything captured at registration time is stale forever.
  it('honours a settings change made after registration', async () => {
    render(<Extension />);
    await settle();
    expect(run()).toEqual({behavior: 'block', reason: BLOCK_REASON});

    settings.value = {enable: false};

    expect(run()).toEqual({behavior: 'allow'});
  });

  it('registers exactly once', async () => {
    const {container} = render(<Extension />);
    await settle();

    tick(checkbox(container), true);
    tick(checkbox(container), false);
    await settle();

    expect(intercept).toHaveBeenCalledTimes(1);
  });
});

describe('teardown', () => {
  it('removes the interceptor on unmount', async () => {
    render(<Extension />);
    await settle();

    cleanup();

    expect(teardown).toHaveBeenCalled();
  });

  it('removes an interceptor that resolves after unmount', async () => {
    // Registration is async: unmounting first must not leak an interceptor that
    // can block checkout for the rest of the session.
    let resolveRegistration;
    intercept.mockImplementation(
      () => new Promise((resolve) => (resolveRegistration = resolve)),
    );

    render(<Extension />);
    cleanup();

    await act(async () => {
      resolveRegistration(teardown);
    });

    expect(teardown).toHaveBeenCalled();
  });
});

describe('rendering', () => {
  it('renders nothing when disabled', () => {
    stubShopify({initialSettings: {enable: false}});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders nothing when enable is absent', () => {
    stubShopify({initialSettings: {}});

    const {container} = render(<Extension />);

    expect(container.innerHTML).toBe('');
  });

  it('renders the heading and the rich label with a link', () => {
    const {container} = render(<Extension />);

    expect(container.querySelector('s-heading').textContent).toContain('Terms');
    const label = container.querySelector('s-text[slot="label"]');
    expect(label.textContent).toContain('I agree to the');
    expect(label.textContent).toContain('of sale.');
    const link = label.querySelector('s-link');
    expect(link.getAttribute('href')).toBe('https://example.com/terms');
    expect(link.textContent).toContain('terms and conditions');
  });

  it('omits the link when only one of text and url is set', () => {
    stubShopify({
      appMetafields: [
        translationEntry({
          en: {
            terms_conditions_before_link: 'I agree',
            link_text: 'terms',
          },
        }),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.querySelector('s-link')).toBeNull();
    expect(container.textContent).toContain('I agree');
  });

  it('omits the heading when untranslated', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {terms_conditions_before_link: 'I agree'}}),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.querySelector('s-heading')).toBeNull();
  });

  it('keeps the checkbox id and name for checkout field targeting', () => {
    const {container} = render(<Extension />);

    expect(checkbox(container).getAttribute('id')).toBe('terms-conditions');
    expect(checkbox(container).getAttribute('name')).toBe('terms-conditions');
  });

  it('uses the buyer language for a regional locale', () => {
    stubShopify({isoCode: 'fr-CA'});

    const {container} = render(<Extension />);

    expect(container.textContent).toContain("J'accepte les");
  });

  it('renders an empty label for an untranslated language', () => {
    stubShopify({isoCode: 'de'});

    const {container} = render(<Extension />);

    // No fallback to en — matches pre-migration behaviour. The checkbox is still
    // there and still blocks, so checkout stays completable.
    expect(checkbox(container)).not.toBeNull();
    expect(container.querySelector('s-link')).toBeNull();
  });

  it('ignores a translations entry belonging to another extension', () => {
    stubShopify({
      appMetafields: [
        translationEntry({en: {heading: 'Wrong block'}}, 'order_note'),
        translationEntry(TRANSLATIONS),
      ],
    });

    const {container} = render(<Extension />);

    expect(container.textContent).toContain('Terms');
    expect(container.textContent).not.toContain('Wrong block');
  });
});
