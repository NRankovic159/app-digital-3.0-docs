// @ts-check

/**
 * @typedef {import("../generated/api").Input} RunInput
 * @typedef {import("../generated/api").FunctionRunResult} FunctionRunResult
 */

/**
 * @param {RunInput} input
 * @returns {FunctionRunResult}
 */
export function run(input) {
  const { cart, localization, shop } = input;

  const { isoCode } = localization?.language || 'en';
  const lowerCaseIsoCode = isoCode?.toLowerCase();

  const { metafield } = shop || {};
  const translationJson = JSON.parse(metafield?.value || '{}');
  const translation = translationJson?.[lowerCaseIsoCode] || {};

  const DEFAULT_ERROR = translation?.error_one ?? "Not possible to order more than one of each";
  const DEFAULT_ERROR_MULTIPLE = translation?.error_multiple ?? "Not possible to order more than {quantityLimit} of each";

  const errors = cart.lines
    .filter(({ quantity, merchandise }) => {
      if (merchandise?.__typename !== "ProductVariant") return false;

      const quantityLimit = Number(merchandise?.product?.metafield?.value);

      if (!quantityLimit || isNaN(quantityLimit)) {
        return false;
      }

      return quantity > quantityLimit;
    })
    .map(({ merchandise }) => {
      if (merchandise?.__typename !== "ProductVariant") {
        return {
          localizedMessage: DEFAULT_ERROR,
          target: "cart",
        };
      }

      const quantityLimit = Number(merchandise?.product?.metafield?.value);

      if (!quantityLimit || isNaN(quantityLimit)) {
        return {
          localizedMessage: DEFAULT_ERROR,
          target: "cart",
        };
      }

      return {
        localizedMessage: DEFAULT_ERROR_MULTIPLE.replace('{quantityLimit}', quantityLimit.toString()),
        target: "cart",
      };
    });

  return {
    errors
  }
};
