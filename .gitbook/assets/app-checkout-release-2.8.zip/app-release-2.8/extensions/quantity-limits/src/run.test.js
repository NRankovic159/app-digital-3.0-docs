import { describe, it, expect } from 'vitest';
import { run } from './run';

/**
 * @typedef {import("../generated/api").FunctionRunResult} FunctionRunResult
 */

describe('cart checkout validation function', () => {
  it('returns an error when quantity exceeds one', () => {
    const result = run({
      cart: {
        lines: [
          {
            quantity: 3,
            merchandise: {
              __typename: "ProductVariant",
              product: {
                metafield: {
                  value: "1"
                }
              }
            }
          }
        ]
      }
    });
    const expected = /** @type {FunctionRunResult} */ ({ errors: [
      {
        localizedMessage: "Not possible to order more than 1 of each",
        target: "cart"
      }
    ] });

    expect(result).toEqual(expected);
  });

  it('returns no errors when quantity is one and limit is not defined', () => {
    const result = run({
      cart: {
        lines: [
          {
            quantity: 1
          }
        ]
      }
    });
    const expected = /** @type {FunctionRunResult} */ ({ errors: [] });

    expect(result).toEqual(expected);
  });
});
