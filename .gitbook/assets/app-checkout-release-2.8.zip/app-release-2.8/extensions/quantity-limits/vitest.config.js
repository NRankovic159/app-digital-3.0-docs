import { defineConfig } from 'vitest/config';

// Without a local config, vitest walks up and picks the repo root
// vite.config.js, which pulls in the ESM-only vite-tsconfig-paths and fails to
// load under this extension's CommonJS resolution. This function needs no vite
// config of its own -- an empty one just stops the upward search.
export default defineConfig({});
