function customSlickSlider(opts) {
  const config = {
    dom: {
      sliderArrow: '.slick-arrow',
      slider: '.slick-slider',
      sliderContainer: 'slider-container',
      sliderTrack: '.slick-track',
      slides: '.slick-slide',
    },
    cls: {
      active: '.slick-active',
      cloned: '.slick-cloned',
      current: '.slick-current',
      disabled: '.slick-disabled',
      next: ['next', 'right'],
      prev: ['prev', 'left'],
    },
  };

  const c = $.extend(config, opts);
  const $sliders = document.querySelectorAll(c.dom.slider);

  function init() {
    if ($sliders?.length > 0) {
      $sliders.forEach(($slider) => {
        setInitialSlideVisibility($slider);
        addEvents($slider);
      });
    }
  }

  /**
   * Add events
   * @description Adds events
   * @param {HTMLElement} el - Slider element
   * @return {void}
   */
  function addEvents(el) {
    const $sliderParents = getParents(el);
    const $sliderParent = $sliderParents?.find(($parent) => $parent.classList.contains(c.dom.sliderContainer));
    if (!$sliderParent) return;

    const $slideButtons = Array.from($sliderParent?.querySelectorAll(c.dom.sliderArrow));

    [...$slideButtons].forEach(($button) => {
      $button.addEventListener('click', (e) => {
        const $parents = getParents(e.target);
        const $parent = $parents?.find(($parent) => $parent.classList.contains(c.dom.sliderContainer));
        const $currentSlider = $parent?.querySelector(c.dom.slider);

        if ($currentSlider) setSlideVisibility($currentSlider);
      });
    });
  }

  /**
   * Set Initial Visibility
   * @description Sets the 'aria-hidden' state of slides as they come into the viewport
   * @param {HTMLElement} el - Slider element
   * @return {void}
   */
  function setInitialSlideVisibility(el) {
    const $slides = el.querySelectorAll(c.dom.slides);
    $slides.forEach((slide) => {
      setAttributes(slide, {'aria-hidden': 'false', tabindex: '0'});
      const focusableElements = slide.querySelectorAll('a, button, input, select, img');
      if (focusableElements.length > 0) {
        focusableElements.forEach((focusableEl) => {
          if (focusableEl.tagName === 'IMG') {
            const alt = focusableEl.getAttribute('alt');
            if (alt !== null && alt !== '') {
              setAttributes(focusableEl, {'aria-hidden': 'false', tabindex: '0'});
            }
          } else {
            setAttributes(focusableEl, {'aria-hidden': 'false', tabindex: '0'});
          }
        });
      }
    });
  }

  /**
   * Set Visibility
   * @description Sets the 'aria-hidden' state of slides as they come into the viewport
   * @param {HTMLElement} el - Slider element
   * @return {void}
   */
  function setSlideVisibility(el) {
    const $slides = el.querySelectorAll(c.dom.slides);

    // List of elements to be observed
    const targets = $slides;
    const options = {
      root: null, // null means root is viewport
      rootMargin: '0px',
      threshold: .5 // trigger callback when 50% of the element is visible
    }

    function callback(entries, observer) {
      entries.forEach(entry => {
        const slide = entry.target;

        // Keep the observer live: calling unobserve() here (in either branch) made it
        // one-shot, freezing each slide's aria-hidden/tabindex after its first
        // evaluation so focusability stopped updating as slides scrolled in/out.
        if (entry.isIntersecting) {
          setAttributes(slide, {'aria-hidden': 'false', tabindex: '0'});
          const focusableElements = slide.querySelectorAll('a, button, input, select, img');
          if (focusableElements.length > 0) {
            focusableElements.forEach((focusableEl) => setAttributes(focusableEl, {'aria-hidden': 'false', tabindex: '0'}));
          }
        } else {
          setAttributes(slide, {'aria-hidden': 'true', tabindex: '-1'});
          const focusableElements = slide.querySelectorAll('a, button, input, select, img');
          if (focusableElements.length > 0) {
            focusableElements.forEach((focusableEl) => {
              setAttributes(focusableEl, {'aria-hidden': 'true', tabindex: '-1'});
            });
          }
        }
      });
    };

    let observer = new IntersectionObserver(callback, options);
    [...targets].forEach(target => observer.observe(target));
  }

  return init();
}

customSlickSlider();
