class MainCartStickyFooter extends HTMLElement {
  constructor() {
    super();
    this.scrollPosition = 0;
    this.boundOnScroll = this.onScroll.bind(this);
    this.boundUpdateBodyPadding = this.updateBodyPadding.bind(this);
    this.scrollListenerAttached = false;
  }

  connectedCallback() {
    // add mobile scroll event only if apple pay is supported
    if (window?.ApplePaySession && this.querySelector('.apple-button')) {
      this.classList.add('apple-pay-supported');
      if (this.querySelector('.checkout-button')) {
        this.classList.add('checkout-button-supported');
      }
      this.classList.add('scrolled');
      document.addEventListener('scroll', this.boundOnScroll);
      this.scrollListenerAttached = true;
    }
    this.updateBodyPadding();
    window.addEventListener('resize', this.boundUpdateBodyPadding);
  }

  disconnectedCallback() {
    if (this.scrollListenerAttached) {
      document.removeEventListener('scroll', this.boundOnScroll);
      this.scrollListenerAttached = false;
    }
    window.removeEventListener('resize', this.boundUpdateBodyPadding);
    // Reset the body padding this footer added, so a stale paddingBottom
    // doesn't leave dead whitespace once the sticky footer is removed.
    document.body.style.paddingBottom = '';
  }

  onScroll() {
    if (window.innerWidth < 768) {
      const fromTop = document.documentElement.scrollTop;
      if (fromTop >= this.scrollPosition) {
        this.classList.add('scrolled');
      } else {
        this.classList.remove('scrolled');
      }
      this.scrollPosition = fromTop;
    }
  }

  updateBodyPadding() {
    // update body padding to avoid content hidden behind the sticky footer
    const footerHeight = this.firstElementChild?.offsetHeight || 0;
    document.body.style.paddingBottom = `${footerHeight}px`;
  }
}

customElements.define('main-cart-footer', MainCartStickyFooter);
