class CTOConfigurable extends HTMLElement {
  constructor() {
    super();
    this.variant = null;
    this.selectedOptionNames = {};
  }

  connectedCallback() {
    this.initConfigurable();
    this.initAccordions();
    this.initSelectAccordions();
    this.initAdvancedCustomization();
    this.handleAllOptionsSelected();

    if (window.ctoCollection) {
      this.selectFirstOption();

      if (Object.keys(this.selectedOptionNames).length > 1) {
        setTimeout(() => {
          var storeLocator = document.querySelector('my-store-locator');
          if (storeLocator) {
            storeLocator.init();
          }
          this.resetOptions();
          if (window.ctoCheckAvailability) window.ctoCheckAvailability();
          this.updateAccordion(true);
          this.handleAllOptionsSelected();
          this.handleGreyOutSteps();
          this.updateSelectedOptionsInSummary();
        }, 10); // small delay needed for the check availability function to be binded from cto-configurable.liquid
      } else {
        this.openFirstTwoAccordions();
        this.resetOptions();
        if (window.ctoCheckAvailability) window.ctoCheckAvailability();
      }
    } else {
      this.updateAccordion(true);
    }

    this.handleForcedAdvancedCustomization(true);
    this.handleGreyOutSteps();
    this.initSecondaryOptions();
    this.updateSelectedOptionsInSummary();

    if (!this._loadHandler) {
      this._loadHandler = () => {
        const $advancedCustomizationInputs = this.querySelector('.js-cto-advanced-customization-input:checked');
        const $advancedCustomizationFieldsets = this.querySelectorAll('.js-cto-advanced-customization-fieldset');
        if ($advancedCustomizationInputs && $advancedCustomizationInputs.value === 'continue') {
          $advancedCustomizationFieldsets.forEach(($fieldset) => {
            const $swatchCarousel = $fieldset?.querySelector('.js-cto-swatch-carousel') || null;
            $fieldset.classList.remove('is-hidden');

            if ($fieldset.classList.contains('is-open') && $swatchCarousel) {
              $swatchCarousel?.destroyCarousel();
              // init carousel after the accordion is opened
              setTimeout(() => {
                $swatchCarousel?.initCarousel();
              }, 150);
            }
          });
        }
      };
      window.addEventListener('load', this._loadHandler);
    }

    // remove loading state at the very end to prevent flickering
    if (window.ctoCollection) {
      document.querySelector('collection-cto-app')?.classList.remove('is-loading');
    }

    this.initAllPickupAvailabilityElements();

    window.updateAllCTOPriceDisplays = this.updateAllCTOPriceDisplays;
    window.updateAllPickupAvailabilityElements = this.updateAllPickupAvailabilityElements;
  }

  disconnectedCallback() {
    if (this._loadHandler) {
      window.removeEventListener('load', this._loadHandler);
      this._loadHandler = null;
    }
    if (this._variantChangedHandler) {
      document.removeEventListener('variant:changed', this._variantChangedHandler);
      this._variantChangedHandler = null;
    }
  }

  initConfigurable() {
    this._variantChangedHandler = (e) => {
      const { variant } = e.detail;
      const selectedOptionName = variant.this_clicked.data('label_name');
      this.variant = variant;

      if (selectedOptionName) {
        this.selectedOptionNames[selectedOptionName] = true;
      }
      if (this.variant) {
        this.refreshContent();
        this.refreshSingleSectionContent('.collapsible-content-section-wrapper');
      }
    };
    document.addEventListener('variant:changed', this._variantChangedHandler);

    if (window.ctoCollection) {
      $(document).on('change', '.js-cto-insurance input, .js-cto-trade-in input, .js-cto-financing input, .js-cto-bundle input', () => {
        this.updateAccordion();
        this.handleAllOptionsSelected();
        this.handleGreyOutSteps();
      });

      this.updateHeader(true);

      document.querySelectorAll('.tax-campaign__modal-trigger').forEach(trigger => {
        trigger.addEventListener('click', () => {
          const modal = document.querySelector('.tax-campaign__modal');
          if (modal) {
            modal.click();
          }
        });
      });
    }

    if (!window?.ctoCollection) {
      this.openAdditionalAccordions();
    }
  }

  async refreshContent() {
    const sectionIds = [this.dataset.sectionId];
    $('.js-cto-details-accordion').each(function() {
      var sectionId = $(this).attr('id')?.split('shopify-section-')[1] || null;
      if (sectionId) {
        sectionIds.push(sectionId);
      }
    });

    // add store locator drawer section to update product info
    sectionIds.push('product-ajax-data');

    const ajaxUrl = `${this.variant.viewurl}?view=pdp-2.0&sections=${sectionIds.join(',')}`;

    const html = await fetch(ajaxUrl)
      .then((resp) => resp.json())
      .then((json) => {
        var itemData = Object.values(json).join('');
        return itemData;
      })
      .catch((error) => {
        console.error('CTO refreshContent fetch failed:', error);
        return null;
      });

    if (!html) return;

    let itemData = html;
    const parser = new DOMParser();
    const doc = parser.parseFromString(itemData, 'text/html');

    const selectorsToUpdate = [
      '.js-cto-gallery',
      '.js-cto-header',
      '.js-cto-from-pricing',
      '.js-cto-configurable-title',
      '.js-cto-configurable-active-option',
      '.js-cto-select-accordion-active-option',
      '.js-cto-configurable-accordion-menu',
      '.js-store-locator-product-info',
      '.product__title',
      '.color-name',
      '.band-color-name',
      '.skuAndBarcode',
      '.product__preorder-message',
      '.pricestyle',
      '.product__info-container .product__accordion',
      '.product-custom-media',
      '.product-media-modal__content',
      '.main-accordions',
      '.product-form',
      '.one-pickup',
      '.two-price',
      '#pdp_monthly_price_taxfree_true',
      '#pdp_monthly_price_taxfree_false',
      '#pdp_monthly_price_taxfree_true_2',
      '.cto-insurance',
      '.cto-financing',
      '.js-cto-bundle',
      '.js-gwp-replace',
      '.learn_more_sw',
      '.learn_more_apple',
      '.js-sticky-atc',
      '.js-sticky-atc-mobile',
      '#stickybar_monthlyprice_1',
      '#stickybar_monthlyprice_2',
      '#stickybar_monthlyprice_3',
      '.cto-trade-in',
      '.js-cto-summary-title',
      '.js-cto-summary-image',
      '.js-cto-summary-options',
      '.js-cto-summary-price',
      '.js-cto-summary-financing-price',
      '.js-cto-summary-share',
      '.js-cto-summary-pickup',
      '.js-cto-summary-volume-pricing',
      '.js-cto-details-accordion-overview',
      'form.form',
      '.js-hidden-selected-product-prices',
      '.js-cto-header-sticky',
      '#adobeAnalyticsProductData',
    ];

    selectorsToUpdate.forEach(selector => {
      const sections = doc.querySelectorAll(selector);
      const sectionsToUpdate = document.querySelectorAll(selector);
      sections.forEach((section, index) => {
        // Extract the HTML content without the script tags
        const scripts = section.querySelectorAll('script[src]');
        scripts.forEach(script => script.remove());

        const sectionHtml = section.innerHTML;
        if (selector === '.js-cto-from-pricing') {
          const $dyanmicPricing = doc.querySelector('.js-cto-dynamic-pricing');

          if ($dyanmicPricing) {
            const pricingHtml = $dyanmicPricing.innerHTML;
            $(sectionsToUpdate[index]).html(pricingHtml);
            return;
          }
        }

        // update content
        $(sectionsToUpdate[index]).html(sectionHtml);

        // Extract and execute script tags
        scripts.forEach((script) => {
          const newScript = document.createElement('script');
          newScript.src = script.src;
          newScript.defer = script.defer; // Preserve the defer attribute if present
          document.body.appendChild(newScript);
        });
      });
    });

    // Sync data attributes on the wrapper element so updateAllCTOPriceDisplays() uses fresh values
    const newWrapper = doc.querySelector('.apl-section-product-cto');
    const existingWrapper = document.querySelector('.apl-section-product-cto');
    if (newWrapper && existingWrapper) {
      const attrsToSync = [
        'data-bundle-shipping-message',
        'data-in-stock-shipping-message',
        'data-unavailable-shipping-message',
        'data-shipping-message',
        'data-no-bundle-type',
        'data-variant-available',
        'data-discount-type',
      ];
      attrsToSync.forEach((attr) => {
        if (newWrapper.hasAttribute(attr)) {
          existingWrapper.setAttribute(attr, newWrapper.getAttribute(attr));
        } else {
          existingWrapper.removeAttribute(attr);
        }
      });
    }

    const configInputs = doc.querySelectorAll('.js-cto-configurable-input');
    configInputs.forEach((input) => {
      const configInputToUpdate = document.querySelector(`.js-cto-configurable-input[id="${input.id}"]`);
      if (configInputToUpdate) configInputToUpdate.outerHTML = input.outerHTML;
    });
    const configLabels = doc.querySelectorAll('.js-cto-configurable-label');
    configLabels.forEach((label) => {

      const configLabelToUpdate = document.querySelector(`.js-cto-configurable-label[for="${label.htmlFor}"]`);
      if (configLabelToUpdate) configLabelToUpdate.outerHTML = label.outerHTML;
    });

    // remove the store locator from the response so it doesn't fetch the API each time jQuery is called
    var itemDataNode = new DOMParser().parseFromString(itemData, 'text/html');
    var newStoreLocator = itemDataNode.querySelector('my-store-locator');
    if (newStoreLocator) {
      newStoreLocator.remove();
    }

    itemData = itemDataNode;

    this.initAllPickupAvailabilityElements();

    $(".js-store-locator-product-info").html($(itemData).find('.js-store-locator-product-info').html());
    // init store locator again with new variant details
    var storeLocator = document.querySelector('my-store-locator');
    if (storeLocator) {
      storeLocator.init();
    }

    // charger regulation section
    if ($(itemData)?.find('.js-product-charger-regulation')?.length != 0) {
      $(".js-product-charger-regulation").html($(itemData).find('.js-product-charger-regulation').html());
    } else {
      $(".js-product-charger-regulation").empty();
    }

    // update old product tag html to new product tag html
    var newProductTag = $(itemData).find('.product_tag_display_container').first();
    $('.product_tag_display_container').each(function(index, item){
      if (newProductTag) {
        $(item).html(newProductTag.html().trim());
      } else {
        $(item).html('');
      }
    });

    if (!window.ctoCollection) {
      $(document).attr('title', $(itemData).find('#page_title').val());
      window.history.replaceState("", "", `${this.variant.viewurl}${window.location.search?.includes('view=pdp-2.0') ? '?view=pdp-2.0' : ''}`);
    }

    $('.js-cto-gallery').css('opacity','1');

    $('.tax-campaign__modal-trigger').on('click', function() {
      if ($('.tax-campaign__modal').length) {
        $('.tax-campaign__modal')[0].click();
      }
    });

    $('.js-net-monthly-pricing-pdp-trigger').on('click', function() {
      if ($('.js-net-monthly-pricing-modal-trigger').length) {
        $('.js-net-monthly-pricing-modal-trigger')[0].click();
      }
    });
    window.refreshModals();
    if (window.refreshTradeInModal) window.refreshTradeInModal();
    if (window.initTradeInModals) window.initTradeInModals();
    if (window.refreshNmpAddModalEvents) window.refreshNmpAddModalEvents();
    if (window.refreshCombinationModal) window.refreshCombinationModal();
    if (window.initCombinationModal) window.initCombinationModal();

    // Re-render 'Frequently bought together' for the newly selected product. Patching only
    // the current-product card left the recommendations themselves stale until a refresh.
    if (window.refreshFrequentlyBoughtProducts) window.refreshFrequentlyBoughtProducts(this.variant.product_id);

    const $headerFromPricing = document.querySelectorAll('.js-cto-from-pricing');
    const $headerNoFromPricing = document.querySelectorAll('.js-cto-dynamic-pricing');

    if ($headerFromPricing && $headerNoFromPricing) {
      $headerFromPricing.forEach(($el) => {
        $el.classList.add('is-hidden');
      });

      $headerNoFromPricing.forEach(($el) => {
        $el.classList.remove('is-hidden');
      });
    }

    // close all select accordions
    const $selectAccordions = document.querySelectorAll('.js-cto-select-accordion');
    $selectAccordions.forEach(($selectAccordion) => {
      const $selectAccordionMenu = $selectAccordion.querySelector('.js-cto-select-acc-menu');
      if ($selectAccordionMenu) {
        $($selectAccordionMenu).slideUp(500, "swing", function() {
          $selectAccordion.classList.remove('is-open');
        });
      }
    });

    if (window.hideNonexistentOptions) window.hideNonexistentOptions();

    if (window.updateShareButtonUrlInCollectionView) window.updateShareButtonUrlInCollectionView();

    if (window.addBulletPointsToDetailsAccordion) window.addBulletPointsToDetailsAccordion();

    if (window.ctoCollection) {
      this.resetOptions();
    }

    if (window.ctoCheckAvailability) {
      window.ctoCheckAvailability();
    }

    this.updateAccordion();
    this.handleForcedAdvancedCustomization();
    this.handleAllOptionsSelected();
    this.handleGreyOutSteps();
    this.initSecondaryOptions();
    this.updateHeader(true);
    this.updateSelectedOptionsInSummary();
    // setTimeout to sync with animations
    setTimeout(() => {
      this.activeOptionInView();
    }, 450);

    const updateMessage = SDG.updateMessage();
    if (window.initUpdateMessage) window.initUpdateMessage();
    if (window.updateMessage) updateMessage.openModal(window.updateMessage);
    if (window.location.href.includes('products')) {
      const insuranceInput = document.querySelector('#remove-insurance');
      insuranceInput?.click();
    }
  };

  // Hides/displays the 'From' pricing and show/hides the dynamic pricing
  updateHeader($hideFromPricing = false) {
    const $headerFromPricing = document.querySelectorAll('.js-cto-from-pricing');
    const $headerNoFromPricing = document.querySelectorAll('.js-cto-dynamic-pricing');
    const $headerFromPricingNmp = document.querySelectorAll('.js-cto-from-pricing-nmp');
    const $headerNoFromPricingNmp = document.querySelectorAll('.js-cto-dynamic-pricing-nmp');
    const $summaryFromPricing = document.querySelector('.js-cto-summary-from-pricing');
    const $summaryNoFromPricing = document.querySelector('.js-cto-summary-dynamic-pricing');
    if (!$headerFromPricing || !$headerNoFromPricing) return;

    if ($hideFromPricing) {
      $headerFromPricing.forEach(($el) => {
        $el.classList.add('is-hidden');
      });

      $headerFromPricingNmp.forEach(($el) => {
        $el.classList.add('is-hidden');
      });

      $headerNoFromPricing.forEach(($el) => {
        $el.classList.remove('is-hidden');
      });

      $headerNoFromPricingNmp.forEach(($el) => {
        $el.classList.remove('is-hidden');
      });

      if ($summaryFromPricing) {
        $summaryFromPricing.classList.add('is-hidden');
      }

      if ($summaryNoFromPricing) {
        $summaryNoFromPricing.classList.remove('is-hidden');
      }
    }

    if (!$hideFromPricing) {
      $headerFromPricing.forEach(($el) => {
        $el.classList.remove('is-hidden');
      });

      $headerFromPricingNmp.forEach(($el) => {
        $el.classList.remove('is-hidden');
      });

      $headerNoFromPricing.forEach(($el) => {
        $el.classList.add('is-hidden');
      });

      $headerNoFromPricingNmp.forEach(($el) => {
        $el.classList.add('is-hidden');
      });

      if ($summaryFromPricing) {
        $summaryFromPricing.classList.remove('is-hidden');
      }

      if ($summaryNoFromPricing) {
        $summaryNoFromPricing.classList.add('is-hidden');
      }
    }
  }

  updateSelectedOptionsInSummary() {
    const $summaryOptions = document.querySelectorAll('.js-cto-summary-option-value');
    const $advancedCustomizationInputContinue = document.getElementById('ctoAdvancedCustomizationContinue');
    const advancedCustomizationSelected = $advancedCustomizationInputContinue?.checked;

    $summaryOptions.forEach(($summaryOption) => {
      const { optionName, optionValue, isAdvancedCustomizationOption } = $summaryOption.dataset;

      const optionHasSelectedInput = !!document.querySelector(`.js-cto-configurable-input[name="${optionName}"]:checked`);
      if (optionHasSelectedInput) {
        $summaryOption.classList.remove('is-hidden');
      } else {
        $summaryOption.classList.add('is-hidden');
      }

      if (isAdvancedCustomizationOption === 'true') {
        const $optionWrapper = $summaryOption.closest('.js-cto-summary-option');
        if (advancedCustomizationSelected) {
          $optionWrapper.classList.remove('is-hidden');
        } else {
          $optionWrapper.classList.add('is-hidden');
        }
      }
    });
  }

  initAccordions() {
    const $accordions = this.querySelectorAll('.js-cto-configurable-accordion');

    const initAccordion = ($accordion) => {
      const $btn = $accordion.querySelector('.js-cto-configurable-accordion-btn');
      const $menu = $accordion.querySelector('.js-cto-acc-menu');

      $btn.addEventListener('click', () => {
        const $swatchCarousel = $accordion?.querySelector('.js-cto-swatch-carousel') || null;
        const isHidden = $($menu).css('display') === 'none';

        if ($swatchCarousel) {
          $swatchCarousel?.destroyCarousel();

          setTimeout(() => {
            $swatchCarousel?.initCarousel();
          }, 150);
        }

        if ($menu) {
          if (isHidden) {
            $($menu).css('display','flex').hide();
          }

          $($menu).slideToggle(500, "swing", function() {
            $accordion.classList.toggle('is-open');

            if (!isHidden) {
              $($menu).css('display', 'none');
            }
          });
        }
      });
    };

    $accordions.forEach($accordion => {
      initAccordion($accordion);
    });
  }

  initSelectAccordions() {
    const $accordions = this.querySelectorAll('.js-cto-select-accordion');

    const initAccordion = ($accordion) => {
      const $btn = $accordion.querySelector('.js-cto-select-accordion-btn');
      const $menu = $accordion.querySelector('.js-cto-select-acc-menu');

      $btn.addEventListener('click', () => {
        const isHidden = $($menu).css('display') === 'none';

        if ($menu) {
          $($menu).slideToggle(500, "swing", function() {
            $accordion.classList.toggle('is-open');

            if (!isHidden) {
              $($menu).css('display', 'none');
            }
          });
        }
      });

      $($menu).on('click', '.js-cto-configurable-input', (e) => {
        // close accordion when option is clicked and option is already selected
        const $input = e.target;
        const inputValue = $input.value;
        const activeValue = $accordion.querySelector('.js-cto-select-accordion-active-option')?.innerText;

        if (inputValue === activeValue) {
          $($menu).slideUp(500, "swing", function() {
            $accordion.classList.remove('is-open');
          });
        }
      });
    }

    $accordions.forEach($accordion => {
      initAccordion($accordion);
    });
  }

  initSecondaryOptions() {
    document.querySelectorAll('[id^="Details-"]').forEach((details) => {
      const summary = details.querySelector('summary');
      const hasEvent = summary?.getAttribute('data-cto-event') === 'true';

      if (!hasEvent && summary) {
        summary.addEventListener('click', (event) => {
          event.preventDefault();
          const $accBody = summary.nextElementSibling || null;

          if (details.hasAttribute('open')) {
            $($accBody).slideUp(500, "swing", () => {
              details.removeAttribute('open');
              summary.setAttribute('aria-expanded', 'false');
            });
          } else {
            details.setAttribute('open', 'true');
            $($accBody).css('display', 'none');
            $($accBody).slideDown(500, "swing", () => {
              summary.setAttribute('aria-expanded', 'true');
            });
          }
        });
        summary.setAttribute('data-cto-event', 'true');
      }
    });
  }

  updateAccordion(skipAnimation = false) {
    const animationSpeed = skipAnimation ? 0 : 500;
    const $accordions = this.querySelectorAll('.js-cto-configurable-accordion');
    const isSingleOptionCTO = this.classList.contains('js-cto-single-option');

    // close all accordions that have a selected input
    $accordions.forEach(($accordion) => {
      const hasSelectedInput = !!$accordion.querySelector('.js-cto-configurable-input:checked');
      const $menu = $accordion.querySelector('.js-cto-acc-menu');

      if (hasSelectedInput) {
        const $neighbor = $accordion.nextElementSibling || null;
        const isNeighborChecked = !!$neighbor?.querySelector('.js-cto-configurable-input:checked');
        const isNeighborAdvancedCustomization = !!$neighbor?.classList.contains('js-cto-advanced-customization-wrapper');


        if (isNeighborChecked) {
          if (!$menu) return;

          // small delay for re-rendering
          setTimeout(() => {
            if ($accordion.classList.contains('is-open')) {
              $($menu).slideUp(animationSpeed, "swing", function() {
                $accordion.classList.remove('is-open');
              });
            }
          }, skipAnimation ? 0 : 100);
        }

        // handle advanced customizations
        if (isNeighborAdvancedCustomization) {
          const $next = $neighbor.nextElementSibling || null;
          if ($next && $next.classList.contains('js-cto-configurable-accordion')) {
            const $selectedOption = $next.querySelector('.js-cto-configurable-input:checked');

            if ($selectedOption) {

              if ($menu) {
                // close the accordion
                setTimeout(() => {
                  if ($accordion.classList.contains('is-open')) {
                    $($menu).slideUp(animationSpeed, "swing", function() {
                      $accordion.classList.remove('is-open');
                    });
                  }
                }, skipAnimation ? 0 : 100);
              }
            }
          }
        }
      }

      if (!window.ctoCollection && hasSelectedInput) {
        if (!$menu) return;
        // inherit display style from the accordion menu
        $accordion.classList.add('is-open');

        $($menu).slideUp(0, "swing", function() {
          $accordion.classList.remove('is-open');
        });
      }
    });

    // open the top-most accordion that has no selected input
    let nextAccordionOpened = false;
    let $previousAccordionToOpen;
    $accordions.forEach(($accordion) => {
      if (nextAccordionOpened) return;
      const hasSelectedInput = !!$accordion.querySelector('.js-cto-configurable-input:checked');
      if (!hasSelectedInput) {
        if (!$accordion.classList.contains('is-open')) {
          $accordion.classList.add('is-open');
          const $menu = $accordion.querySelector('.js-cto-acc-menu');
          $($menu).css('display', 'none');
          $($menu).slideDown(animationSpeed, "swing");
        }

        nextAccordionOpened = true;
      } else {
        $previousAccordionToOpen = $accordion;
      }
    });

    // if all configurable options are selected, open the next add on accordion (e.g. AC+/warranty accordion)
    if (window.ctoCollection && this.allOptionsAreSelected()) {
      if ($previousAccordionToOpen) {
        const $menu = $previousAccordionToOpen.querySelector('.js-cto-acc-menu');

        if ($menu) {
          $($menu).slideUp(animationSpeed, "swing", function() {
            $previousAccordionToOpen.classList.remove('is-open');
          });
        }
      }

      // filter out all options without an input
      const $secondaryOptions = Array.from(document.querySelectorAll('.js-cto-insurance, .js-cto-trade-in, .js-cto-financing, .js-cto-bundle')).filter(($option) => !!$option.querySelector('input'));

      // close all accordions that have a selected input
      $secondaryOptions.forEach(($option, idx) => {
        const $optionHasSelectedInput = !!$option.querySelector('input') && !!$option.querySelector('input:checked');
        const $nextOption = $secondaryOptions.slice(idx + 1).find(opt => opt !== $option) || null;
        const nextOptionPendingSelection = $nextOption && $nextOption.classList.contains('cto__grey-out');

        if ($optionHasSelectedInput && !nextOptionPendingSelection) {
          const $optionAccordion = $option.querySelector('details');
          const $optionAccordionBtn = $option.querySelector('summary');

          if ($optionAccordion?.hasAttribute('open') && $optionAccordionBtn) {
            const $menu = $optionAccordionBtn.nextElementSibling || null;
            if ($menu) {
              $($menu).slideUp(animationSpeed, "swing", function() {
                $optionAccordion.removeAttribute('open');
              });
            }
          }
        }
      });

      // open the top-most accordion that has no selected input
      let nextSecondaryOptionAccordionOpened = false;
      let $previousSecondaryAccordionToOpen;
      $secondaryOptions.forEach(($option) => {
        if (nextSecondaryOptionAccordionOpened) return;
        const $optionHasSelectedInput = !!$option.querySelector('input') && !!$option.querySelector('input:checked');
        if (!$optionHasSelectedInput) {
          const $optionAccordion = $option.querySelector('details');
          const $optionAccordionBtn = $option.querySelector('summary');
          if (!$optionAccordion?.hasAttribute('open') && $optionAccordionBtn) {
            $optionAccordionBtn.click();
          }

          if ($previousSecondaryAccordionToOpen) {
            const $prevOptionAccordion = $previousSecondaryAccordionToOpen.querySelector('details');
            const $prevOptionAccordionBtn = $previousSecondaryAccordionToOpen.querySelector('summary');
            if (!$prevOptionAccordion.hasAttribute('open') && $prevOptionAccordionBtn) {
              $prevOptionAccordionBtn.click();
            }
          }

          nextSecondaryOptionAccordionOpened = true;
        } else {
          $previousSecondaryAccordionToOpen = $option;
        }
      });

      if (!nextSecondaryOptionAccordionOpened) {
        if ($previousAccordionToOpen) {
          const $menu = $previousAccordionToOpen.querySelector('.js-cto-acc-menu');

          if (!$menu) return;

          // small delay for re-rendering
          setTimeout(() => {
            $($menu).slideUp(500, "swing", function() {
              $previousAccordionToOpen.classList.remove('is-open');
            });
          }, 100);
        }
      }
    }

    // Opens accordion if only one option is available
    if (isSingleOptionCTO && $accordions?.length === 1) {
      const $menu = $accordions[0].querySelector('.js-cto-acc-menu');

      if ($menu) {
        $($menu).slideToggle(animationSpeed, "swing", function() {
          $accordions[0].classList.toggle('is-open');
        });
      }
    }

    this.checkOutOfStockSelection();
  }

  openFirstTwoAccordions() {
    const $accordions = new Array(...this.querySelectorAll('.js-cto-configurable-accordion')).slice(0, 2);
    $accordions.forEach(($accordion) => {
      $accordion.classList.add('is-open');
    });

    // open secondary options if there are less than 2 accordions open
    const secondaryToOpen = 2 - $accordions.length;
    if (secondaryToOpen > 0) {
      const $secondaryOptions = new Array(...document.querySelectorAll('.js-cto-insurance:not(.hidden), .js-cto-trade-in:not(.hidden), .js-cto-financing, .js-cto-bundle')).slice(0, secondaryToOpen);
      $secondaryOptions.forEach(($secondaryOption) => {
        $secondaryOption.classList.add('visible');
        const $optionAccordion = $secondaryOption.querySelector('details');
        const $optionAccordionBtn = $secondaryOption.querySelector('summary');
        if (!$optionAccordion?.hasAttribute('open') && $optionAccordionBtn) {
          $optionAccordionBtn.click();
        }
      });
    }
  }

  selectFirstOption() {
    const firstInput = document.querySelector('.js-cto-configurable-input');
    if (firstInput) {
      this.selectedOptionNames[firstInput.dataset.label_name] = true;
    }

    // if preselected url parameters are present, also select them
    const urlParams = new URLSearchParams(window.location.search);
    const optionParams = {};
    for (const [key, value] of urlParams.entries()) {
      if (key !== 'pdp-2.0' && key !== 'cto') {
        optionParams[key] = true;
      }
    }

    const configInputs = document.querySelectorAll('.js-cto-configurable-input');
    if (Object.keys(optionParams).length) {
      const handleize = (str) => {
        const normalizedStr = str.normalize('NFD'); // Normalize

        return normalizedStr
          .replace(/\p{Diacritic}/gu, '') // Remove diacritics
          .replace(/[()]/g, '') // Remove parentheses to match Shopify handleize filter functionality
          .replace(/^([^a-zA-Z0-9])*(.*?)/, '$2') // Remove non alphanumeric characters from start and end
          .replace(/([^a-zA-Z0-9])/g, '-') // Replace non alphanumeric characters with hyphen
          .replace(/-+/g, '-') // Replace duplicate hyphens with single hyphen
          .toLowerCase();
      }
      configInputs.forEach((input) => {
        const $menu = input?.closest('.js-cto-acc-menu') || null;
        if (optionParams[handleize(input.dataset.label_name)]) {
          this.selectedOptionNames[input.dataset.label_name] = true;
        }
      });
    } else if (window.ctoPreselectedOptions) {
      // if preselected options are present from the metafield, select them
      configInputs.forEach((input) => {
        const $menu = input?.closest('.js-cto-acc-menu') || null;
        const inputOptionIndex = parseInt(input.dataset.option_count.replace('option', ''));

        if (inputOptionIndex && window.ctoPreselectedOptions.includes(inputOptionIndex)) {
          this.selectedOptionNames[input.dataset.label_name] = true;
        }
      });

      const allOptionNames = configInputs ? Array.from(configInputs).map(input => input.dataset.label_name) : [];
      const uniqueAllOptionNames = [...new Set(allOptionNames)];
      const allOptionNamesAreSelected = uniqueAllOptionNames.every(name => this.selectedOptionNames[name]);
      if (allOptionNames.length > 1 && allOptionNamesAreSelected) {
        window.ctoAllOptionsWerePreselected = true;
      }
    }
  }

  resetOptions() {
    const configInputs = document.querySelectorAll('.js-cto-configurable-input');
    configInputs.forEach((input) => {
      if (!this.selectedOptionNames[input.dataset.label_name]) {
        input.checked = false;
      }
    });

    const activeOptions = document.querySelectorAll('.js-cto-configurable-active-option');
    activeOptions.forEach((activeOption) => {
      const $accordionParent = activeOption.closest('.js-cto-configurable-accordion');
      const hasSelectedInput = !!$accordionParent.querySelector('.js-cto-configurable-input:checked');
      if (!hasSelectedInput) {
        activeOption.innerHTML = '';

        const $selectAccordionActiveOption = $accordionParent.querySelector('.js-cto-select-accordion-active-option');
        if ($selectAccordionActiveOption) {
          $selectAccordionActiveOption.innerHTML = '';
        }
      }
    });
  }

  initAdvancedCustomization() {
    const $advancedCustomizationInputs = this.querySelectorAll('.js-cto-advanced-customization-input');
    const $advancedCustomizationFieldsets = this.querySelectorAll('.js-cto-advanced-customization-fieldset');
    $advancedCustomizationInputs.forEach(($input) => {
      $input.addEventListener('change', () => {
        const value = $input.value;
        if (value === 'continue') {
          $advancedCustomizationFieldsets.forEach(($fieldset) => {
            const $swatchCarousel = $fieldset?.querySelector('.js-cto-swatch-carousel') || null;
            $fieldset.classList.remove('is-hidden');

            if ($fieldset.classList.contains('is-open') && $swatchCarousel) {
              // init carousel after the accordion is opened
              setTimeout(() => {
                $swatchCarousel?.destroyCarousel();
                $swatchCarousel?.initCarousel();
              }, 150);
            }
          });
        } else {
          $advancedCustomizationFieldsets.forEach(($fieldset) => {
            $fieldset.classList.add('is-hidden');
            const isOpen = $fieldset.classList.contains('is-open');
            const $menu = $fieldset.querySelector('.js-cto-acc-menu');


            if (!$menu) return;
            if (!isOpen) {
              // inherit display style from the accordion menu
              $fieldset.classList.add('is-open');

              $($menu).slideUp(0, "swing", function() {
                $fieldset.classList.remove('is-open');
              });
            }
          });

          // When Skip is clicked, reset all advanced customization inputs
          const advancedCustomizationInputs = document.querySelectorAll('.js-cto-configurable-input-advanced-customization');
          let needToChangeProduct = false;
          advancedCustomizationInputs.forEach((input) => {
            if (input.checked) {
              input.checked = false;
              needToChangeProduct = true;
            }
          });
          if (needToChangeProduct) {
            // since advanced customization options have been deselected, need to find new product that does not contain advanced customization
            const selectedInput = document.querySelector('.js-cto-configurable-input:not(.js-cto-configurable-input-advanced-customization):checked');
            if (selectedInput) {
              const event = new Event('change', {
                bubbles: true,
                cancelable: true,
              });
              selectedInput.dispatchEvent(event);
            }
          }
        }
        this.handleAllOptionsSelected(false);
        this.updateAccordion();
        this.handleGreyOutSteps();
      });
    });
  }

  async handleForcedAdvancedCustomization(initialCall = false) {
    const hasInputWithAdvancedCustomization = !!document.querySelector('.js-cto-configurable-input-advanced-customization-smart:checked');
    const $advancedCustomizationInputContinue = document.getElementById('ctoAdvancedCustomizationContinue');
    const $advancedCustomizationInputSkip = document.getElementById('ctoAdvancedCustomizationSkip');
    if (!$advancedCustomizationInputContinue || !$advancedCustomizationInputSkip) return;

    if (initialCall) {
      // Wait for the configurator to finish populating window.ctoAllProductOptions.
      // For ≤250-product base collections this resolves on the next tick; for
      // larger collections it resolves once the AJAX merge in cto-configurable
      // dispatches `cto:configs-fully-loaded`. A 5s safety timeout prevents the
      // accordion from being stuck if the event never fires.
      await new Promise(resolve => {
        if (window.ctoAllProductOptions && window.ctoConfigsTotalPages <= 1) {
          resolve();
          return;
        }
        let settled = false;
        const finish = () => {
          if (settled) return;
          settled = true;
          resolve();
        };
        document.addEventListener('cto:configs-fully-loaded', finish, { once: true });
        setTimeout(finish, 5000);
      });
    }

    let shouldForceAdvancedCustomization = false;
    let shouldClickSkip = false;

    // If a zmpn option that is mixed with regular options is selected, advanced customization is forced
    if (hasInputWithAdvancedCustomization) {
      shouldForceAdvancedCustomization = true;
    }

    // Once all non-advanced options are selected, advanced customization should also be forced if all valid combinations with the current selections are zMPN's
    const allNonAdvancedInputsHaveSelection = document.querySelectorAll('.js-cto-configurable-accordion:not(.js-cto-advanced-customization-fieldset) .js-cto-configurable-input:checked').length === document.querySelectorAll('.js-cto-configurable-accordion:not(.js-cto-advanced-customization-fieldset)').length;
    if (allNonAdvancedInputsHaveSelection && window.ctoAllProductOptions) {
      const activeNonAdvancedOptions = (() => {
        let result = {};
        const $configurableInputsNonAdvanced = document.querySelectorAll('.js-cto-configurable-accordion:not(.js-cto-advanced-customization-fieldset) .js-cto-configurable-input');
        $configurableInputsNonAdvanced.forEach($input => {
          if ($input.checked) {
            const label = $input.dataset.label_name;
            const value = $input.value;
            result[label] = value;
          }
        });

        return result;
      })();

      const allCombinationsWithCurrentSelections = window.ctoAllProductOptions.filter(product => {
        return Object.keys(activeNonAdvancedOptions).every(option => {
          return product.options[option] === activeNonAdvancedOptions[option];
        });
      });

      const combinationsThatAreZmpn = allCombinationsWithCurrentSelections.filter(product => Object.keys(product.options).length !== Object.keys(activeNonAdvancedOptions).length);
      const combinationsThatAreNonZmpn = allCombinationsWithCurrentSelections.filter(product => Object.keys(product.options).length === Object.keys(activeNonAdvancedOptions).length);
      if (combinationsThatAreZmpn.length && !combinationsThatAreNonZmpn.length) {
        shouldForceAdvancedCustomization = true;
      } else if (!combinationsThatAreZmpn.length && combinationsThatAreNonZmpn.length && $advancedCustomizationInputContinue.checked) {
        shouldClickSkip = true;
      }
    }

    if (shouldForceAdvancedCustomization) {
      $advancedCustomizationInputContinue.click();
      $advancedCustomizationInputSkip.disabled = true;
    } else {
      $advancedCustomizationInputSkip.disabled = false;
    }

    if (shouldClickSkip) {
      $advancedCustomizationInputSkip.click();
      if (window.ctoCollection) {
        $advancedCustomizationInputSkip.checked = false;
      }
    }

    if (!window.ctoCollection && initialCall) {
      const hasInputInAdvancedCustomization = !!document.querySelector('.js-cto-configurable-input-advanced-customization:checked');
      if (hasInputWithAdvancedCustomization || hasInputInAdvancedCustomization) {
        $advancedCustomizationInputContinue.click();
      } else {
        $advancedCustomizationInputSkip.click();
      }
    }

    if (initialCall) {
      this.updateSelectedOptionsInSummary();
    }
  }

  activeOptionInView() {
    const $sticky = document.querySelector('sticky-header') || null;
    const $header = document.querySelector('.js-cto-header') || null;
    const $secondaryOptions = Array.from(document.querySelectorAll('.js-cto-insurance, .js-cto-trade-in, .js-cto-financing, .js-cto-bundle')) || [];
    const $accordions = document.querySelectorAll('.js-cto-configurable-accordion') || [];
    const stickyHeight = $sticky?.getBoundingClientRect()?.height || 0;
    const headerHeight = $header?.getBoundingClientRect()?.height || 0;
    const totalHeaderHeight = (stickyHeight + headerHeight);

    let $firstNotCheckdAccordion = null;
    let $secondaryNotCheckdAccordion = null;

    if ($accordions?.length > 0) {
      $firstNotCheckdAccordion = Array.from($accordions).find(($accordion) => {
        return !$accordion.querySelector('.js-cto-configurable-input:checked');
      });
    }

    if ($secondaryOptions?.length > 0) {
      $secondaryNotCheckdAccordion = Array.from($secondaryOptions).find(($option) => {
        return !$option.querySelector('input:checked');
      });
    }

    if ($firstNotCheckdAccordion) {
      const prevSelection = $firstNotCheckdAccordion.previousElementSibling;
      // Get the top position of the previous
      const prevSelectionRect = prevSelection?.getBoundingClientRect();
      const prevSelectionTop = (prevSelectionRect?.top + window.scrollY);

      // Calculate the target scroll position adjusted for header heights
      const targetScrollPosition = (prevSelectionTop - totalHeaderHeight);

      if (targetScrollPosition > window.scrollY) {
        this.smoothScrollTo(window.scrollY, targetScrollPosition, 700);
      }
    }

    if ($secondaryNotCheckdAccordion && !$firstNotCheckdAccordion && !window.ctoAllOptionsWerePreselected) {
      // Get the top position of the previous
      const secondPrevSelectionRect = $secondaryNotCheckdAccordion?.getBoundingClientRect();
      const secondPrevSelectionTop = (secondPrevSelectionRect?.top + window.scrollY);

      // Calculate the target scroll position adjusted for header heights
      const targetScrollPosition = (secondPrevSelectionTop - totalHeaderHeight);

      if (targetScrollPosition > window.scrollY) {
        this.smoothScrollTo(window.scrollY, targetScrollPosition, 700);
      }
    }
  }

  allOptionsAreSelected() {
    const $advancedCustomizationInputContinue = document.getElementById('ctoAdvancedCustomizationContinue');
    const $advancedCustomizationInputSkip = document.getElementById('ctoAdvancedCustomizationSkip');
    const supportsAdvancedCustomization = !!$advancedCustomizationInputContinue && !!$advancedCustomizationInputSkip;

    let allOptionsSelected = false;

    if (!window.ctoCollection) {
      allOptionsSelected = true;
    } else if (supportsAdvancedCustomization) {
      const advancedCustomizationEnabled = $advancedCustomizationInputContinue.checked;
      const advancedCustomizationSkipped = $advancedCustomizationInputSkip.checked;
      if (advancedCustomizationEnabled) {
        allOptionsSelected = Object.keys(this.selectedOptionNames).length >= document.querySelectorAll('.js-cto-configurable-accordion').length;
      } else if (advancedCustomizationSkipped) {
        allOptionsSelected = Object.keys(this.selectedOptionNames).length >= document.querySelectorAll('.js-cto-configurable-accordion:not(.js-cto-advanced-customization-fieldset)').length;
      }
    } else {
      allOptionsSelected = Object.keys(this.selectedOptionNames).length === document.querySelectorAll('.js-cto-configurable-accordion').length;
    }

    return allOptionsSelected;
  }

  allSecondaryOptionsAreSelected() {
    // filter out all options without an input
    const $secondaryOptions = Array.from(document.querySelectorAll('.js-cto-insurance, .js-cto-trade-in, .js-cto-financing, .js-cto-bundle')).filter(($option) => !!$option.querySelector('input'));
    let allSecondaryOptionsSelected = true;

    $secondaryOptions.forEach(($option) => {
      const $optionHasSelectedInput = !!$option.querySelector('input') && !!$option.querySelector('input:checked');
      if (!$optionHasSelectedInput) {
        allSecondaryOptionsSelected = false;
      }
    });

    return allSecondaryOptionsSelected;
  }

  handleAllOptionsSelected(scrollToSummary = true) {
    const allOptionsSelected = this.allOptionsAreSelected();
    const allSecondaryOptionsAreSelected = this.allSecondaryOptionsAreSelected();
    // Cancel any pending checkout-button re-init from a previous evaluation so a
    // stale timer can't reveal the button after the selection state has changed
    // (e.g. user deselects an option within the 600ms window below).
    clearTimeout(this._checkoutBtnInitTimeout);
    const $hideUntilAllOptionsSelected = document.querySelectorAll('.js-cto-hide-until-all-options-selected');
    const $showUntilAllOptionsSelected = document.querySelectorAll('.js-cto-show-until-all-options-selected');
    const hasInputWithAdvancedCustomization = !!document.querySelector('.js-cto-configurable-input-advanced-customization-smart:checked');
    const $ctoShippingMessage = document.querySelectorAll('.js-cto-zpart-shipping-message');
    const $mpnShippingMessage = document.querySelectorAll('.js-cto-mpn-shipping-message');
    const $hideUntilAllOptionsIncludingSecondarySelected = document.querySelectorAll('.js-cto-hide-until-all-options-including-secondary-selected');

    if (allOptionsSelected) {
      $hideUntilAllOptionsSelected.forEach(($el) => {
        $el.classList.add('is-visible')
      });
      $showUntilAllOptionsSelected.forEach(($el) => {
        $el.classList.add('is-hidden');
      });

      if (hasInputWithAdvancedCustomization) {
        // show shipping message with cusomizations
        if ($ctoShippingMessage?.length > 0) {
          $ctoShippingMessage.forEach(($el) => {
            $el.classList.add('is-visible')
          });
        }
      } else {
         // show default shipping message
        if ($mpnShippingMessage?.length > 0) {
          $mpnShippingMessage.forEach(($el) => {
            $el.classList.add('is-visible')
          });
        }
      }
    } else {
      $hideUntilAllOptionsSelected.forEach(($el) => {
        $el.classList.remove('is-visible')
      });
      $showUntilAllOptionsSelected.forEach(($el) => {
        $el.classList.remove('is-hidden');
      });

      // hide shipping message
      if ($mpnShippingMessage?.length > 0) {
        $mpnShippingMessage.forEach(($el) => {
          $el.classList.remove('is-visible')
        });
      }
      if ($ctoShippingMessage?.length > 0) {
        $ctoShippingMessage.forEach(($el) => {
          $el.classList.remove('is-visible')
        });
      }
    }

    if (allOptionsSelected && allSecondaryOptionsAreSelected) {
      $hideUntilAllOptionsIncludingSecondarySelected.forEach(($el) => {
        const $stickyAtc = $el.classList.contains('js-sticky-atc');
        const $stickyAtcMobile = $el.classList.contains('js-sticky-atc-mobile');

        $el.classList.add('is-visible')

        if ($stickyAtcMobile) {
          // small timeout for slide
          setTimeout(() => {
            $el.classList.add('reveal');
          }, 560);
        }

        if ($stickyAtc) {
          // small timeout to align with scroll animation
          setTimeout(() => {
            $el.classList.add('reveal');
          }, 560);
        }
      });

      this.updateHeader(true);

      // Re-init checkout buttons now that they are visible so text/height measurements are accurate
      this._checkoutBtnInitTimeout = setTimeout(() => {
        document.querySelectorAll('.js-cto-hide-until-all-options-including-secondary-selected checkout-button, .js-cto-hide-until-all-options-selected checkout-button').forEach((btn) => {
          btn.init();
        });
      }, 600);

      if (scrollToSummary) {
        // small timeout to align with scroll animation
        setTimeout(() => {
          this.slideToSummary();
        }, 1000);
      }

    } else {
      $hideUntilAllOptionsIncludingSecondarySelected.forEach(($el) => {
        $el.classList.remove('is-visible')
      });
    }

    // Force sticky ATC to always be visible on the non-collection view
    if (!window.ctoCollection) {
      const $stickyAtc = document.querySelector('.js-sticky-atc');
      const $stickyAtcMobile = document.querySelector('.js-sticky-atc-mobile');


      if ($stickyAtcMobile) {
        $stickyAtcMobile.classList.add('is-visible');

        // small timeout for slide
        setTimeout(() => {
          $stickyAtcMobile.classList.add('reveal');
        }, 350);
      }

      if ($stickyAtc) {
        $stickyAtc.classList.add('is-visible');

        // small timeout for slide
        setTimeout(() => {
          $stickyAtc.classList.add('reveal');
        }, 350);
      }
    }
  }

  handleGreyOutSteps() {
    if (!window.ctoCollection) return;

    const $accordions = this.querySelectorAll('.js-cto-configurable-accordion');

    // grey out accordions that have no selected input and that are not open
    $accordions.forEach(($accordion) => {
      const hasSelectedInput = !!$accordion.querySelector('.js-cto-configurable-input:checked');
      if (!hasSelectedInput && !$accordion.classList.contains('is-open')) {
        $accordion.classList.add('cto__grey-out');
      } else {
        $accordion.classList.remove('cto__grey-out');
      }
    });

    // grey out advanced customization if not all options are selected
    const $nonAdvancedAccordions = document.querySelectorAll('.js-cto-configurable-accordion:not(.js-cto-advanced-customization-fieldset)');
    const allNonAdvancedAccordionsHasSelectedInput = Array.from($nonAdvancedAccordions).every(($accordion) => {
      return !!$accordion.querySelector('.js-cto-configurable-input:checked');
    });
    const $advancedCustomizationWrapper = document.querySelector('.js-cto-advanced-customization-wrapper');
    if ($advancedCustomizationWrapper) {
      if (allNonAdvancedAccordionsHasSelectedInput) {
        $advancedCustomizationWrapper.classList.remove('cto__grey-out');
      } else {
        $advancedCustomizationWrapper.classList.add('cto__grey-out');
      }
    }


    // grey out secondary options if not all options are selected or if the secondary options are not selected
    const allOptionsSelected = this.allOptionsAreSelected();
    const allSecondaryOptionsSelected = this.allSecondaryOptionsAreSelected();
    // filter out all options without an input
    const $secondaryOptions = Array.from(document.querySelectorAll('.js-cto-insurance:not(.visible), .js-cto-trade-in:not(.visible), .js-cto-financing:not(.visible), .js-cto-bundle:not(.visible)')).filter(($option) => !!$option.querySelector('input'));
    $secondaryOptions.forEach(($option) => {
      if (!allOptionsSelected) {
        $option.classList.add('cto__grey-out');
      } else {
        const $optionHasSelectedInput = !!$option.querySelector('input:checked');
        const $optionAccordion = $option.querySelector('details');
        if (!$optionHasSelectedInput && !$optionAccordion?.hasAttribute('open')) {
          $option.classList.add('cto__grey-out');
        } else {
          $option.classList.remove('cto__grey-out');
        }
      }
    });

    // grey out summary and frequent products if not all options including secondary options are selected
    const $summary = document.querySelector('.js-cto-summary');
    const $frequentProducts = document.querySelector('.js-cto-frequent-products');


    if (allOptionsSelected && allSecondaryOptionsSelected) {
      if ($summary) $summary.classList.remove('cto__grey-out');
      if ($frequentProducts) $frequentProducts.classList.remove('cto__grey-out');
    } else {
      if ($summary) $summary.classList.add('cto__grey-out');
      if ($frequentProducts) $frequentProducts.classList.add('cto__grey-out');
    }
  }

  slideToSummary() {
    const $summary = document.querySelector('.js-cto-summary') || null;
    if (!$summary) return;
    const $header = document.querySelector('.js-cto-header-sticky') || null;
    const headerHeight = $header ? $header.offsetHeight : 0;
    const summaryTop = $summary.getBoundingClientRect().top + window.scrollY;
    const targetPosition = (summaryTop - headerHeight);
    const isMobile = window.matchMedia(
      "only screen and (max-width: 1023px)"
    ).matches;

    if (isMobile && summaryTop) {

      this.smoothScrollTo(window.scrollY, summaryTop, 1050);
      return;
    }

    if (targetPosition) {
      this.smoothScrollTo(window.scrollY, targetPosition, 1050);
    }
  }

  smoothScrollTo(start, end, duration) {
    const startTime = performance.now();

    function ease(progress) {
      if (!progress || progress < 0) return 0;

      if (progress < 0.5) {
        return 2 * progress * progress;
      }

      return -1 + (4 - 2 * progress) * progress;
    }

    function scrollStep(timestamp) {
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const transition = ease(progress);
      const currentPosition = start + (end - start) * transition;

      window.scrollTo(0, currentPosition);

      if (progress < 1) {
        window.requestAnimationFrame(scrollStep);
      }
    }

    window.requestAnimationFrame(scrollStep);
  }

  openAdditionalAccordions() {
    const $insurance = document.querySelector('.js-cto-insurance') || null;
    const $tradeIn = document.querySelector('.js-cto-trade-in') || null;
    const $financing = document.querySelector('.js-cto-financing') || null;
    const $bundle = document.querySelector('.js-cto-bundle') || null;

    function findAndOpen(sec) {
      if (!sec) return;
      const $acc = sec.querySelector('details');
      const $summary = sec.querySelector('summary');

      if ($acc && $summary) {
        $summary.click();
      }
    }

    if ($insurance) findAndOpen($insurance);
    if ($tradeIn) findAndOpen($tradeIn);
    if ($financing) findAndOpen($financing);
    if ($bundle) findAndOpen($bundle);
  }

  checkOutOfStockSelection() {
    const $oosInput = document.querySelector('.js-cto-configurable-input:checked[data-oos="true"]');

    if (!$oosInput) return;

    const $stickyAtc = document.querySelector('.js-sticky-atc') || null;
    const $stickyAtcMobile = document.querySelector('.js-sticky-atc-mobile') || null;

    if ($stickyAtcMobile) {
      // small timeout for slide
      setTimeout(() => {
        $stickyAtcMobile.classList.add('is-visible');
        $stickyAtcMobile.classList.add('reveal');
      }, 560);
    }

    if ($stickyAtc) {
      // small timeout to align with scroll animation
      setTimeout(() => {
        $stickyAtc.classList.add('is-visible');
        $stickyAtc.classList.add('reveal');
      }, 560);
    }
  }

  // Helper function to chunk the section IDs to bypass the limitation of Section Rendering API
  chunkSectionIDs(array, size) {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  async refreshSingleSectionContent(selector) {
    const sectionIDs = [];
    document.querySelectorAll(selector).forEach(element => {
      sectionIDs.push(element.getAttribute('data-section-id'));
    });

    // Split sectionIDs into chunks of maximum 5 items
    const sectionChunks = this.chunkSectionIDs(sectionIDs, 5);
    // Track the overall index of sections to update
    let sectionIndexToUpdate = 0

    for (const chunk of sectionChunks) {
      const ajaxUrl = `${this.variant.viewurl}?view=pdp-2.0&sections=${chunk.join(',')}`;

      const html = await fetch(ajaxUrl)
        .then((resp) => resp.json())
        .then((json) => {
          let itemData = Object.values(json).join('');
          return itemData;
        })
        .catch((error) => {
          console.error('CTO refreshSingleSectionContent fetch failed:', error);
          return null;
        });

      if (!html) continue;

      let itemData = html;

      const parser = new DOMParser();
      const doc = parser.parseFromString(itemData, 'text/html');

      const sections = doc.querySelectorAll(selector);
      const sectionsToUpdate = document.querySelectorAll(selector);

      sections.forEach(section => {
        // Extract the HTML content without the script tags
        const scripts = section.querySelectorAll('script[src]');
        scripts.forEach(script => script.remove());

        const sectionHtml = section.innerHTML;

        // Update content
        sectionsToUpdate[sectionIndexToUpdate].innerHTML = sectionHtml;

        // Extract and execute script tags
        scripts.forEach((script) => {
          const newScript = document.createElement('script');
          newScript.src = script.src;
          newScript.defer = script.defer; // Preserve the defer attribute if present
          document.body.appendChild(newScript);
        });
        // Increment section index for proper tracking across chunks
        sectionIndexToUpdate++;
      });
    }
  }

  /**
   * Update all price displays based on currently selected options in the CTO app.
   * Includes selected add-ons such as Protection, Trade-In, and Bundles.
   */
  updateAllCTOPriceDisplays() {
    let defaultProductPrice = parseInt(document.querySelector('.js-product-price-with-care-warranty[data-price-raw]')?.dataset.priceRaw) || 0;
    let defaultProductCompareAtPrice = parseInt(document.querySelector('.js-product-compare-at-price[data-compare-at-price-raw]')?.dataset.compareAtPriceRaw) || 0;
    const discountType = document.querySelector('.apl-section-product-cto')?.getAttribute('data-discount-type');

    // If a bundle is selected, override the default product price and compare at price
    const $selectedBundleOption = document.querySelector('input.js-cto-set-price-display:checked');
    const shippingMessageElements = document.querySelectorAll('.apl-section-shipping .cto-shipping-message');
    const ctoSection = document.querySelector('.apl-section-product-cto');
    const shippingMessage = ctoSection?.getAttribute('data-shipping-message');
    const bundleShippingMessage = ctoSection?.getAttribute('data-bundle-shipping-message');
    const inStockShippingMessage = ctoSection?.getAttribute('data-in-stock-shipping-message');
    const unavailableShippingMessage = ctoSection?.getAttribute('data-unavailable-shipping-message');
    const messageType = window.pickupAvailabilityElements?.[0]?.getAttribute('data-default-message-type');

    // Read no-bundle settings: prefer bundle wrapper (main-product.liquid), fall back to CTO section (product-cto.liquid)
    const bundleWrapper = document.querySelector('.cto-bundle-wrapper');
    const hasNoBundleType = bundleWrapper?.hasAttribute('data-no-bundle-type') || ctoSection?.hasAttribute('data-no-bundle-type');
    const noBundleType = bundleWrapper?.getAttribute('data-no-bundle-type') || ctoSection?.getAttribute('data-no-bundle-type');
    const noBundleShippingMessage = bundleWrapper?.getAttribute('data-no-bundle-shipping-message') || shippingMessage;

    if ($selectedBundleOption) {
      defaultProductPrice = parseInt($selectedBundleOption.dataset.priceRawSetAs) || 0;
      defaultProductCompareAtPrice = parseInt($selectedBundleOption.dataset.compareAtPriceRawSetAs) || 0;

      // Shipping depends on global variant availability, not store-specific stock
      const variantAvailable = ctoSection.getAttribute('data-variant-available') === 'true';

      if (variantAvailable) {
        if (shippingMessageElements.length && bundleShippingMessage && shippingMessage) {
          shippingMessageElements.forEach((elem) => {
            elem.innerHTML = bundleShippingMessage
          })
        }
      } else if (shippingMessageElements.length && unavailableShippingMessage) {
        shippingMessageElements.forEach((elem) => {
          elem.innerHTML = unavailableShippingMessage
        })
      }

      window.updateAllPickupAvailabilityElements('cto')
    } else if (hasNoBundleType) {
      // No bundle selected — use the original (no-bundle) message type
      if (shippingMessageElements.length && noBundleShippingMessage && !window.ctoCollection) {
        shippingMessageElements.forEach((elem) => {
          elem.innerHTML = noBundleShippingMessage
        })
      }

      if (noBundleType) {
        window.updateAllPickupAvailabilityElements(noBundleType)
      } else {
        // No-bundle type is empty (e.g. unavailable product) — reset pickup to initial state
        const allLocationsData = window.storeLocatorElement?.allLocationsData;
        const preferredStoreId = window.storeLocatorElement?.preferredStoreId;
        window.pickupAvailabilityElements.forEach((pickup) => {
          pickup.setAttribute('data-message-type', '');
          pickup.renderPreview(allLocationsData?.find((location) => location.id === preferredStoreId));
        })
      }
    } else if (messageType === 'cto') {
      if (shippingMessageElements.length && bundleShippingMessage && !window.ctoCollection) {
        shippingMessageElements.forEach((elem) => {
          elem.innerHTML = bundleShippingMessage
        })
      }

      window.updateAllPickupAvailabilityElements(messageType)
    } else if (messageType === 'in stock') {
      if (shippingMessageElements.length && inStockShippingMessage && !window.ctoCollection) {
        shippingMessageElements.forEach((elem) => {
          elem.innerHTML = inStockShippingMessage
        })
      }

      window.updateAllPickupAvailabilityElements('in stock')
    } else {
      if (shippingMessageElements.length && shippingMessage && !window.ctoCollection) {
        shippingMessageElements.forEach((elem) => {
          elem.innerHTML = shippingMessage
        })
      }

      window.updateAllPickupAvailabilityElements(messageType)
    }

    // All input elements that have a class of "js-cto-modify-price-display" and are checked will modify the price calculation by their [data-price-raw-modify-by] attribute
    const addOnsPrices = [...document.querySelectorAll('input.js-cto-modify-price-display:checked')].map((el) => parseInt(el.dataset.priceRawModifyBy) || 0);

    // trade-in currently excluded from price
    const tradeInIncludedInPrice = false;
    const tradeInPrice = tradeInIncludedInPrice ? (parseFloat(document.getElementById('selected-trade-in-value')?.value) || 0) * -100 : 0;

    const sumOfAllPrices = defaultProductPrice + addOnsPrices.reduce((acc, price) => acc + price, 0) + tradeInPrice;
    const sumOfAllPricesWithoutAddOns = defaultProductPrice + tradeInPrice;
    const sumOfAllCompareAtPrices = defaultProductCompareAtPrice + tradeInPrice;

    const priceCalculation = parseInt(document.querySelector('.js-product-price-with-care-warranty[data-price-calculation]')?.dataset.priceCalculation) || 1;
    const truncateTo2Decimals = (num) => {
      return Math.floor(num * 100) / 100;
    }

    const discountPercent = sumOfAllCompareAtPrices > sumOfAllPricesWithoutAddOns
      ? (sumOfAllCompareAtPrices > 0
        ? (((1 - (sumOfAllPricesWithoutAddOns / sumOfAllCompareAtPrices)) * 100).toFixed(2).replace('.00', ''))
        : 0)
      : 0;

    const discountMoneyValue = sumOfAllCompareAtPrices > sumOfAllPricesWithoutAddOns
      ? (sumOfAllCompareAtPrices > 0
        ? (sumOfAllCompareAtPrices - sumOfAllPricesWithoutAddOns).toFixed(2)
        : 0)
      : 0;

    const showCompareAtPrice = +discountPercent > 0 || +discountMoneyValue > 0;

    // final formatted prices
    const formattedTotalPrice = formatPriceWithCurrency(sumOfAllPrices / 100);
    const formattedFromTotalPrice = SDG.Data.productPriceFrom.replace(`\{\{ price \}\}`, formattedTotalPrice);
    const formattedNmpPrice = formatPriceWithoutCurrency(truncateTo2Decimals(sumOfAllPrices / priceCalculation / 100));
    const formattedTotalCompareAtPrice = formatPriceWithCurrency(sumOfAllCompareAtPrices / 100);
    const formattedDiscountPercent = `-${discountPercent}%`;
    const formattedDiscountMoneyValue = `-${formatPriceWithoutCurrency(discountMoneyValue / 100)}`;
    const $perMonthPrice = document.querySelectorAll('.js-nmp-price') || [];
    let nmpBasePrice = null

    const $priceDisplays = document.querySelectorAll('.js-product-price-with-care-warranty');
    $priceDisplays.forEach(($priceDisplay) => {
      // do not update price with VAT priceRawSetAs
      if ($priceDisplay.classList.contains('js-product-price-with-care-warranty-vat')) {
        const regularPrice = parseInt($priceDisplay.dataset?.priceRaw) || 0;
        const sumOfRegularPrice = regularPrice + addOnsPrices.reduce((acc, price) => acc + price, 0) + tradeInPrice;
        const priceWithVAT = formatPriceWithCurrency(sumOfRegularPrice / 100);
        const formattedNmpWithVAT = formatPriceWithoutCurrency(truncateTo2Decimals(sumOfRegularPrice / priceCalculation / 100));

        if (priceWithVAT) {
          $priceDisplay.innerHTML = priceWithVAT;
          // use regular price for per month calculations
          nmpBasePrice = formattedNmpWithVAT;

          // default to bundle prices if bundle is selected
          if ($selectedBundleOption) {
            $priceDisplay.innerHTML = formattedTotalPrice;
            nmpBasePrice = formattedNmpPrice;
          }
          return;
        }
      }

      const $fromPrice = $priceDisplay.querySelector('.js-cto-from-pricing');
      const $normalPrice = $priceDisplay.querySelector('.js-cto-dynamic-pricing');
      if ($fromPrice || $normalPrice) {
        if ($fromPrice) {
          $fromPrice.innerHTML = formattedFromTotalPrice;
        }
        if ($normalPrice) {
          $normalPrice.innerHTML = formattedTotalPrice;
        }
      } else if ($priceDisplay.closest('.net-monthly-pricing, .js-net-monthly-pricing-pdp-trigger')) {
        $priceDisplay.innerHTML = formattedNmpPrice;
      } else {
        $priceDisplay.innerHTML = formattedTotalPrice;

        if ($selectedBundleOption) {
          const vatBundlePrice = parseInt($selectedBundleOption.dataset.vatPriceRawSetAs) || 0;

          if (vatBundlePrice > 0) {
            const sumOfVatRegularPrice = vatBundlePrice + addOnsPrices.reduce((acc, price) => acc + price, 0) + tradeInPrice;
            const priceWithVATBundle = formatPriceWithCurrency(sumOfVatRegularPrice / 100);
            $priceDisplay.innerHTML = priceWithVATBundle;
          } else {
            // if no VAT price is set, use the regular price
            $priceDisplay.innerHTML = formattedTotalPrice;
          }
        }
      }
    });

    // update per month price displays
    if ($perMonthPrice.length > 0) {
      $perMonthPrice.forEach(($perMonth) => {
        $perMonth.innerHTML = nmpBasePrice || formattedNmpPrice;
      });
    }


    const $compareAtPriceDisplays = document.querySelectorAll('.js-product-compare-at-price');
    $compareAtPriceDisplays.forEach(($compareAtPriceDisplay) => {
      if (showCompareAtPrice) {
        const $compareAtPrice = $compareAtPriceDisplay.querySelector('.js-product-compare-at-price-slash');
        const $discountPercent = $compareAtPriceDisplay.querySelector('.js-product-compare-at-price-percent');
        if ($compareAtPrice) $compareAtPrice.innerHTML = formattedTotalCompareAtPrice;
        if (discountType === 'currency') {
          if ($discountPercent) $discountPercent.innerHTML = formattedDiscountMoneyValue;
        } else {
          if ($discountPercent) $discountPercent.innerHTML = formattedDiscountPercent;
        }
        $compareAtPriceDisplay.classList.remove('hidden');
      } else {
        $compareAtPriceDisplay.classList.add('hidden');
      }
    });
  }

  /**
   * Initialize Pickup availability elements to save them in the context.
   */

  initAllPickupAvailabilityElements() {
    window.pickupAvailabilityElements = document.querySelectorAll('pickup-availability');
    window.storeLocatorElement = document.querySelector('my-store-locator');
  }

  /**
   * Update Pickup availability based on bundle selection.
   */

  updateAllPickupAvailabilityElements(messageType) {
    if(window.pickupAvailabilityElements.length && window.storeLocatorElement && messageType) {
      const allLocationsData = window.storeLocatorElement.allLocationsData;
      const preferredStoreId = window.storeLocatorElement.preferredStoreId

      window.pickupAvailabilityElements.forEach((pickup) => {
        pickup.setAttribute('data-message-type', messageType);
        pickup.renderPreview(allLocationsData?.find((location) => location.id === preferredStoreId))
      })
    }
  }
}

customElements.define('cto-configurable', CTOConfigurable);
