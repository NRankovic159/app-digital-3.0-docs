class CTOGallery extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    if (this.initialized) return;
    this.initialized = true;
    this.initFunction();
  }

  initFunction() {
    this.initThumbsCarousel();
    this.initCarousel();
  }

  initCarousel() {
    $(this).off('init.ctoGallery').on('init.ctoGallery', function() {
      document.querySelectorAll('.slick-cloned img[fetchpriority="high"]').forEach(function(img) {
        img.setAttribute('fetchpriority', 'low');
      });
    });

    $(this).slick({
      prevArrow: `
        <button class="cto-gallery__arrow prev-arrow js-prev-button" type="button">
          <span class="screenreader">${window.SDG?.Data?.sliderPrevious || 'Previous'}</span>
          <svg width="33" height="33" viewBox="0 0 33 33" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="m18.192 23.704 1.016-1.118-5.236-5.764 5.236-5.765-1.016-1.118-6.25 6.883 6.25 6.882Z" fill="#333"/>
          </svg>
        </button>
      `,
      nextArrow: `
        <button class="cto-gallery__arrow next-arrow js-next-button" type="button">
          <span class="screenreader">${window.SDG?.Data?.sliderNext || 'Next'}</span>
          <svg width="33" height="33" viewBox="0 0 33 33" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="m13.957 10.02-1.02 1.124 5.26 5.792-5.26 5.792 1.02 1.124 6.281-6.916-6.28-6.915Z" fill="#333"/>
          </svg>
        </button>
      `,
      dots: true,
      appendArrows: '.js-cto-gallery-navigation',
      appendDots: '.js-cto-gallery-dots',
      asNavFor: '.js-cto-gallery-thumbs',
      infinite: true,
    });

    $(this).on('beforeChange', (slick, currentSlide, nextSlide, slickCurrentSlide) => {
      const slideCount = $(this).slick('getSlick').slideCount || null;
      const $videos = $(this).find('video');

      $videos.each(function(){
        this.pause();
      });

      if (slickCurrentSlide === 0) {
        $('.js-cto-gallery-thumbs').slick('slickGoTo', 0, false);
      } else if (slickCurrentSlide === slideCount - 1) {
        $('.js-cto-gallery-thumbs').slick('slickGoTo', slideCount - 1, false);
      }
    });

    $(this).on('afterChange', (slick, currentSlide, slickCurrentSlide) => {
      const $currentSlideVideo = $(this).find('.slick-current video')[0];

      if ($currentSlideVideo) {
        $currentSlideVideo.pause();
      }
    });
  }

  initThumbsCarousel() {
    // init in center mode for consistant sizing
    $('.js-cto-gallery-thumbs').slick({
      slidesToShow: 3,
      arrows: false,
      centerMode: true,
      focusOnSelect: true,
      asNavFor: this,
      infinite: false,
    });

    $('.js-cto-gallery-thumbs').on('beforeChange', (slick, currentSlide, nextSlide, slickCurrentSlide) => {
      const slideCount = $('.js-cto-gallery-thumbs').slick('getSlick').slideCount || null;
      if (slickCurrentSlide === 0 || slickCurrentSlide === 1) {
        $('.js-cto-gallery-thumbs').addClass('default-start');
        $('.js-cto-gallery-thumbs').removeClass('default-end');
      } else if (slickCurrentSlide === slideCount - 1 || slickCurrentSlide === slideCount - 2) {
        const endTransform = `translate3d(calc(-100% + ${$('.js-cto-gallery-thumbs').width()}px - 34px), 0px, 0px)`;
        $('.js-cto-gallery-thumbs').get(0).style.setProperty('--end-transform', endTransform);
        $('.js-cto-gallery-thumbs').addClass('default-end');
        $('.js-cto-gallery-thumbs').removeClass('default-start');
      } else {
        $('.js-cto-gallery-thumbs').removeClass('default-start');
        $('.js-cto-gallery-thumbs').removeClass('default-end');
      }
    });
  }
}

customElements.define('cto-gallery', CTOGallery);
