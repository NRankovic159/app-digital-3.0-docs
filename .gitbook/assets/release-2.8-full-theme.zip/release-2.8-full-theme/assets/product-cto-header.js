class CTOHeader extends HTMLElement {
  constructor() {
    super();
    this.isMobile = false;
    this.isIntersecting = false;
    this.scrollPos = 0;
    this.handleScroll = this.handleScroll.bind(this);
  }

  connectedCallback() {
    this.addEvents();
    this.updateShareButtonUrlInCollectionView();
    window.updateShareButtonUrlInCollectionView = this.updateShareButtonUrlInCollectionView;
  }

  disconnectedCallback() {
    window.removeEventListener('scroll', this.handleScroll);
    if (this._observer) {
      this._observer.disconnect();
      this._observer = null;
    }
    if (this._headerStickyHandler) {
      document.removeEventListener('headerSticky', this._headerStickyHandler);
      this._headerStickyHandler = null;
    }
  }

  addEvents() {
    this.isMobile = window.matchMedia(
      "only screen and (max-width: 1023px)"
    ).matches;

    const $header = this;
    const $headerSticky = document.querySelector('.js-cto-header-sticky');
    if (!$headerSticky) return;
    const stickyHeight = $headerSticky.offsetHeight
    const opts = {
      root: null,
      rootMargin: `-${stickyHeight}px 0px 0px 0px`,
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          this.isIntersecting = true;
          $headerSticky.classList.remove('is-visible');
        } else {
          this.isIntersecting = false;
          $headerSticky.classList.add('is-visible');
        }
      });
    }, opts);

    this._observer = observer;
    observer.observe($header);

    if (this.isMobile) {
      window.addEventListener('scroll', this.handleScroll, { passive: true });
      this.handleScroll();
    }

    this._headerStickyHandler = (e) => {
      const { isSticky } = e.detail;
      if (isSticky) {
        $headerSticky.classList.add('header-is-sticky');
      } else {
        $headerSticky.classList.remove('header-is-sticky');
      }
    };
    document.addEventListener('headerSticky', this._headerStickyHandler);
  }

  updateShareButtonUrlInCollectionView() {
    if (window.ctoCollection) {
      const $shareButtons = document.querySelectorAll('share-button');
      $shareButtons.forEach(($shareButton) => {
        const $input = $shareButton.querySelector('input');
        if ($input) {
          $input.value = window.location.href;
        }
      });
    }
  }

  handleScroll() {
    if (!this.isMobile) return;
    const $headerSticky = document.querySelector('.js-cto-header-sticky');
    if (!$headerSticky) return;

    const currentTop = document.body.getBoundingClientRect().top;
    const scrollUp = currentTop > this.scrollPos;
    if (scrollUp && !this.isIntersecting) {
      $headerSticky.classList.add('is-visible');
    } else if (!scrollUp && !this.isIntersecting) {
      $headerSticky.classList.remove('is-visible');
    }
    this.scrollPos = currentTop;
  }
}

customElements.define('cto-header', CTOHeader);
