$( document ).ready(function() {
  //quantity input textbox-server error issue - fix
  $("#prodQuantity").keyup(function(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      event.target.blur();
    }

    if (event.target.value === '0' || event.target.value === '') {
      event.target.value = '1';
    }
  });

  function resetErrors() {
    var errorMessage = document?.querySelector('.js-qty-error') || null;
    var qtyInput = document?.querySelector('.js-qty-input') || null;

    // reset error messaging
    if (errorMessage) {
      errorMessage.classList.add('hidden');
    }
    if (qtyInput) {
      qtyInput.classList.remove('quantity--error');
    }
  }

  var prodList=localStorage.getItem("product-click");
  //  localStorage.removeItem("product-click");
  var prevPage= document.referrer;
  if(prevPage.includes("collections")){
    prevPage="PLP :: "+formatString(prevPage.split("/")[prevPage.split("/").length-1]);
  }else if(prevPage.includes("pages")){
    prevPage=prevPage.split("/")[prevPage.split("/").length-1]+"_page";
  }else if(prevPage.includes("search")){
    prevPage="Search Results"
  }else if(prevPage.includes("products")){
    var arr=prevPage.split("/");
    prevPage=arr[arr.length-1].split("?")[0]+"_pdp";
  }else if(prevPage.includes("cart")){
    prevPage="Cart Page";
  }else{
    prevPage="home_page"
  }
  if(prodList){
    document.getElementById("product_list")?.setAttribute('value', prodList);
  }else{
    localStorage.setItem("product-click", prevPage);
    document.getElementById("product_list")?.setAttribute('value', prevPage);
  }
});
