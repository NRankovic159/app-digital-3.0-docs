class CartDrawer extends HTMLElement {
  constructor() {
    super();

    this.addEventListener('keyup', (evt) => evt.code === 'Escape' && this.close());
    this.boundClose = this.close.bind(this);
    this.querySelector('#CartDrawer-Overlay')?.addEventListener('click', this.boundClose);
    this.setHeaderCartIconAccessibility();
    this.addEvents = this.addEvents.bind(this);

    this.addEvents();
  }

  setHeaderCartIconAccessibility() {
    const cartLink = document.querySelector('#cart-icon-bubble');
    if (!cartLink) return;
    cartLink.setAttribute('role', 'button');
    cartLink.setAttribute('aria-haspopup', 'dialog');
    cartLink.addEventListener('click', (event) => {
      event.preventDefault();
      this.open(cartLink);
    });
    cartLink.addEventListener('keydown', (event) => {
      if (event.code.toUpperCase() === 'SPACE') {
        event.preventDefault();
        this.open(cartLink);
      }
    });
  }

  open(triggeredBy) {
    if (triggeredBy) this.setActiveElement(triggeredBy);
    const cartDrawerNote = this.querySelector('[id^="Details-"] summary');
    if (cartDrawerNote && !cartDrawerNote.hasAttribute('role')) this.setSummaryAccessibility(cartDrawerNote);
    // here the animation doesn't seem to always get triggered. A timeout seem to help
    setTimeout(() => {
      this.classList.add('animate', 'active');
    });

    this.addEventListener(
      'transitionend',
      () => {
        const containerToTrapFocusOn = this.classList.contains('is-empty')
          ? this.querySelector('.drawer__inner-empty')
          : document.getElementById('CartDrawer');
        const focusElement = this.querySelector('.drawer__inner') || this.querySelector('.drawer__close');
        trapFocus(containerToTrapFocusOn, focusElement);
      },
      { once: true }
    );

    document.body.classList.add('overflow-hidden');
  }

  close() {
    this.classList.remove('active');
    removeTrapFocus(this.activeElement);
    document.body.classList.remove('overflow-hidden');
  }

  setSummaryAccessibility(cartDrawerNote) {
    cartDrawerNote.setAttribute('role', 'button');
    cartDrawerNote.setAttribute('aria-expanded', 'false');

    if (cartDrawerNote.nextElementSibling?.getAttribute('id')) {
      cartDrawerNote.setAttribute('aria-controls', cartDrawerNote.nextElementSibling.id);
    }

    cartDrawerNote.addEventListener('click', (event) => {
      event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
    });

    cartDrawerNote.parentElement.addEventListener('keyup', onKeyUpEscape);
  }

  renderContents(parsedState) {
    this.querySelector('.drawer__inner').classList.contains('is-empty') &&
      this.querySelector('.drawer__inner').classList.remove('is-empty');
    this.productId = parsedState.id;
    this.getSectionsToRender().forEach((section) => {
      const sectionElement = section.selector
        ? document.querySelector(section.selector)
        : document.getElementById(section.id);
      if (sectionElement) {
        sectionElement.innerHTML = this.getSectionInnerHTML(parsedState.sections[section.id], section.selector);
      }
    });

    setTimeout(() => {
      this.querySelector('#CartDrawer-Overlay').addEventListener('click', this.boundClose);
      this.open();
    });
  }

  getSectionInnerHTML(html, selector = '.shopify-section') {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector)?.innerHTML || '';
  }

  getSectionsToRender() {
    return [
      {
        id: 'cart-drawer',
        selector: '#CartDrawer',
      },
      {
        id: 'cart-icon-bubble',
      },
    ];
  }

  getSectionDOM(html, selector = '.shopify-section') {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector);
  }

  setActiveElement(element) {
    this.activeElement = element;
  }

  updateItems() { 
    fetch(`${window.Shopify.routes.root}cart?view=cart-items`)
    .then((response) => response.text())
    .then((html) => { 
      const $items = this.querySelector('.js-cart-items-body') || null;
      const wasEmpty = this.classList.contains('is-empty');

      if (wasEmpty) { 
        const $emptyDrawer = this.querySelector('.js-empty-drawer') || null;
        const $drawerItems = this.querySelector('cart-drawer-items') || null;

        if ($drawerItems) { 
          const $inner = $drawerItems.querySelector('.js-drawer-inner'); 

          if ($inner) { 
            $inner.innerHTML = html;
            const $items = $inner.querySelector('.js-cart-items-body') || null;
            const $total = this.querySelector('.js-drawer-total') || null;
            if ($items && $total) { 
              const { cartPrice } = $items.dataset

              $total.innerHTML = cartPrice;
              $emptyDrawer.classList.add('hidden');
              $drawerItems.classList.remove('is-empty');
              this.classList.remove('is-empty');

              this.open();
            }
          }
        }
      }

      if ($items) {
        $items.innerHTML = html;
        this.open();
      }
    })
    .catch((error) => console.error({message: 'Error updating items', error: error}));
  }

  addEvents() {
    // Use event delegation + idempotency marker so the listener survives renderContents()
    // (which innerHTML-replaces .ac-modal-trigger elements) and never stacks on the host.
    if (this.__delegateClickBound) return;
    this.__delegateClickBound = true;
    this.addEventListener('click', (event) => {
      const $trigger = event.target.closest('.ac-modal-trigger');
      if (!$trigger || !this.contains($trigger)) return;
      this.close();
    });
  }
}

customElements.define('cart-drawer', CartDrawer);

class CartDrawerItems extends CartItems {
  getSectionsToRender() {
    return [
      {
        id: 'CartDrawer',
        section: 'cart-drawer',
        selector: '.drawer__inner',
      },
      {
        id: 'cart-icon-bubble',
        section: 'cart-icon-bubble',
        selector: '.shopify-section',
      },
    ];
  }
}

customElements.define('cart-drawer-items', CartDrawerItems);
