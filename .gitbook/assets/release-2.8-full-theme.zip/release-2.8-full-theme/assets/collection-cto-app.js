class CollectionCtoApp extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.initContent();
  }

  async fetchAllBaseCollectionProducts(ctoParam) {
    // Without a cto param the collection handle would resolve to `apl-ps-null`,
    // so skip the fetch entirely and let the caller handle the empty result.
    if (!ctoParam) return [];

    const buildUrl = (page) => `${window.Shopify.routes.root}collections/apl-ps-${ctoParam}?section_id=collection-cto-all-products&page=${page}`;

    const parsePage = (html) => {
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');
      const dataHtml = doc.querySelector('#json')?.textContent;
      if (!dataHtml) return null;
      try {
        return JSON.parse(dataHtml);
      } catch (e) {
        return null;
      }
    };

    const firstHtml = await fetch(buildUrl(1))
      .then((r) => (r.ok ? r.text() : null))
      .catch(() => null);
    if (!firstHtml) return [];
    const firstPage = parsePage(firstHtml);
    if (!firstPage || !Array.isArray(firstPage.products)) return [];

    const totalPages = Number(firstPage.pages) || 1;
    if (totalPages <= 1) return firstPage.products;

    const remainingPages = [];
    for (let p = 2; p <= totalPages; p++) remainingPages.push(p);

    const restResults = await Promise.all(
      remainingPages.map((p) =>
        fetch(buildUrl(p))
          .then((r) => (r.ok ? r.text() : null))
          .then((html) => (html ? parsePage(html) : null))
          .catch(() => null)
      )
    );

    const allProducts = firstPage.products.slice();
    restResults.forEach((page) => {
      if (page && Array.isArray(page.products)) {
        page.products.forEach((p) => allProducts.push(p));
      }
    });
    return allProducts;
  }

  async initContent() {
    const urlParams = new URLSearchParams(window.location.search);
    const ctoParam = urlParams.get('pdp-2.0') || urlParams.get('cto');
    const optionParams = {};

    for (const [key, value] of urlParams.entries()) {
      if (key !== 'pdp-2.0' && key !== 'cto') {
        optionParams[key] = value;
      }
    }

    const data = await this.fetchAllBaseCollectionProducts(ctoParam);
    if (!data.length) return;

    let productHandle;
    if (Object.keys(optionParams).length) {
      // find product containing all of the optionParams. Note optionParams may not contain all options
      const foundProduct = data.find((product) => {
        return Object.entries(optionParams).every(([key, value]) => {
          return product.options.some((option) => {
            return option.labelHandle === key && option.valueHandle === value;
          });
        });
      });

      productHandle = foundProduct ? foundProduct.handle : data[0].handle;
    } else {
      productHandle = data[0].handle;
    }

    if (!productHandle) return;

    const ctoTemplateHtml = await fetch(`${window.Shopify.routes.root}products/${productHandle}?view=pdp-2.0`)
      .then((resp) => resp.text());

    if (!ctoTemplateHtml) return;

    const parser = new DOMParser();
    const doc = parser.parseFromString(ctoTemplateHtml, 'text/html');

    // Extract the HTML content without the script tags
    const mainContent = doc.querySelector('#MainContent');
    if (!mainContent) return;
    const scripts = mainContent.querySelectorAll('script[src]');
    scripts.forEach(script => script.remove());

    // Insert the HTML content into the DOM.
    // jQuery `.html()` evaluates any inline <script> in the injected markup; a throw there
    // (e.g. a third-party stripe re-initializing a slider) must not abort the rest of this
    // method, otherwise the CTO's own external scripts below would never be appended.
    try {
      $(this).find('.js-cto-collection-body').html(mainContent.innerHTML);
    } catch (error) {
      console.error('CTO collection content injection error:', error);
    }

    // Replace breadcrumbs with product breadcrumbs from the fetched page
    document.querySelectorAll('.breadcrumbs--mobile, .breadcrumbs--desktop').forEach((nav) => {
      const cls = nav.classList.contains('breadcrumbs--mobile') ? '.breadcrumbs--mobile' : '.breadcrumbs--desktop';
      const replacement = doc.querySelector(cls);
      if (replacement) {
        nav.replaceWith(replacement);
      }
    });

    // update store locator product info
    $(".js-store-locator-product-info").html($(doc).find('.js-store-locator-product-info').html());

    // Extract and execute script tags
    scripts.forEach((script) => {
      const newScript = document.createElement('script');
      newScript.src = script.src;
      newScript.defer = script.defer; // Preserve the defer attribute if present
      document.body.appendChild(newScript);
    });

    var storeLocator = document.querySelector('my-store-locator');
    if (storeLocator) {
      storeLocator.init();
    }

    $('.js-net-monthly-pricing-pdp-trigger').on('click', function() {
      if ($('.js-net-monthly-pricing-modal-trigger').length) {
        $('.js-net-monthly-pricing-modal-trigger')[0].click();
      }
    });
    const $cto = document.querySelector('cto-cart-drawer');
    if ($cto) {
      $cto.classList.remove('hidden');
    }
    if (typeof window.refreshModals === 'function') window.refreshModals();
    if (window.refreshTradeInModal) window.refreshTradeInModal();
    if (window.initTradeInModals) window.initTradeInModals();
    if (window.refreshNmpAddModalEvents) window.refreshNmpAddModalEvents();
    if (window.refreshCombinationModal) window.refreshCombinationModal();
    if (window.initCombinationModal) window.initCombinationModal();

    const updateMessage = (typeof SDG !== 'undefined' && SDG.updateMessage) ? SDG.updateMessage() : null;
    if (window.initUpdateMessage) window.initUpdateMessage();
    if (window.updateMessage && updateMessage) updateMessage.openModal(window.updateMessage);
  }
}

customElements.define('collection-cto-app', CollectionCtoApp);
