class CTOSwatchCarousel extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    if (window.ctoCollection) {
      setTimeout(() => {
        this.init();
      }, 10); // small delay needed in the collection view to prevent carousel initializing before initial load
    } else {
      this.init();
    }
  }

  init() {
    this.initCarousel();
  }

  initCarousel() {
    $(this).slick({
      prevArrow: `
        <button class="cto-gallery__arrow prev-arrow" type="button">
          <span class="screenreader">${window.SDG?.Data?.sliderPrevious || 'Previous'}</span>
          <svg width="33" height="33" viewBox="0 0 33 33" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="m18.192 23.704 1.016-1.118-5.236-5.764 5.236-5.765-1.016-1.118-6.25 6.883 6.25 6.882Z" fill="#333"/>
          </svg>
        </button>
      `,
      nextArrow: `
        <button class="cto-gallery__arrow next-arrow" type="button">
          <span class="screenreader">${window.SDG?.Data?.sliderNext || 'Next'}</span>
          <svg width="33" height="33" viewBox="0 0 33 33" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="m13.957 10.02-1.02 1.124 5.26 5.792-5.26 5.792 1.02 1.124 6.281-6.916-6.28-6.915Z" fill="#333"/>
          </svg>
        </button>
      `,
      dots: true,
      appendArrows:'.js-cto-swatch-carousel-navigation',
      appendDots: '.js-cto-swatch-carousel-dots',
    });

    $(this).on('beforeChange', function(slick, currentSlide, nextSlide){
      const $videos = $(this).find('video');
      $videos.each(function(){
        this.pause();
      });
    });

    $(this).on('afterChange', function(slick, currentSlide){
      const $currentSlideVideo = $(this).find('.slick-current video')[0];
      if ($currentSlideVideo) {
        $currentSlideVideo.pause();
      }
    });
  }

  destroyCarousel() {
    // Guard against unslicking a carousel that was never initialized — calling
    // `.slick('unslick')` on such an element throws "reading 'unslick' of undefined".
    if ($(this).hasClass('slick-initialized')) {
      $(this).slick('unslick');
    }
  }

  // Backwards-compatible alias for the previous misspelled method name.
  destoryCarousel() {
    this.destroyCarousel();
  }
}

customElements.define('cto-swatch-carousel', CTOSwatchCarousel);
