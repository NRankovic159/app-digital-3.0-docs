if (!customElements.get('cto-product-financing')) {
  customElements.define(
    'cto-product-financing',
    class ProductFinancing extends HTMLElement {
      constructor() {
        super();

        const url = window.location.href;

        this.addEvents();

        if (url.includes('products')) {
          const selectDefault = this.querySelector('input#decline-financing');
          const selectDefaultLabel = this.querySelector('label[for="decline-financing"]');
          const selectedDefaultText = this.querySelector('.js-cto-selected-option');
          if (selectDefault && selectedDefaultText && selectDefaultLabel) {
            selectDefault.click();
            selectedDefaultText.innerText = selectDefaultLabel.innerText;
            window.refreshSummaryAriaLabel?.(selectedDefaultText);
          }
        }
      }

      // Delegate from the element root so listeners survive innerHTML replacement
      // when refreshContent() resets `.cto-financing` on variant change.
      addEvents() {
        this.addEventListener('change', (e) => {
          const input = e.target;
          if (!input.classList?.contains('js-cto-financing-input')) return;

          const selectedOption = this.querySelector('.js-cto-selected-option');
          const summarySelectedOption = document.querySelector('.js-cto-summary-financing');
          const summarySelectedFinancingPrice = document.querySelector('.js-cto-summary-financing-price');
          const label = this.querySelector(`label[for="${input.id}"]`);

          if (selectedOption && label) {
            selectedOption.textContent = label.textContent;
            window.refreshSummaryAriaLabel?.(selectedOption);
          }

          // Match on the radio's stable id, not its English `value`, so this
          // keeps working on translated storefronts (the "Pay in full" option
          // is always id="decline-financing" in cto-financing / b2b-cto-financing).
          if (input.id === 'decline-financing') {
            summarySelectedOption?.classList.remove('hidden');
            summarySelectedFinancingPrice?.classList.add('hidden');
          } else {
            summarySelectedOption?.classList.add('hidden');
            summarySelectedFinancingPrice?.classList.remove('hidden');
          }
        });
      }
    }
  );
}
