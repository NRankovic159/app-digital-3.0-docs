function mapPage() {
  const config = {
    dom: {
      map: 'map',
      desktopMapWrapper: 'desktopMapWrapper',
      mobileMapWrapper: 'mobileMapWrapper',
      search: 'search',
      results: 'myLocationResults',
      result: '.js-my-location-result',
      result_button: '.js-make-my-store-btn',
      active_result: '.js-my-location-result:first-child',
      acc_button: '.js-acc-button',
      acc_icon: '.js-acc-icon',
      acc_details: '.js-acc-details',
      result_link: '.js-my-location-link',
      result_details: '.js-my-results-details'
    },
    cls: {
      active: 'is-active',
    }
  };
  const appleToken = SDG?.Data?.mapsToken|| null;
  const googleToken = SDG?.Data?.googleMapsToken|| null;
  const apiProvider = SDG?.Data?.mapProvider  || null;
  const $map = document.getElementById(config.dom.map) || null;
  const $results = document.getElementById(config.dom.results);
  const isAppleMaps  = apiProvider === 'apple_maps';
  const isGoogleMaps = apiProvider === 'google_maps';
  const googleMarkers = [];

  let map = null;

  function init() {
    if (isAppleMaps) {
      if (appleToken && $map) {
        initAppleMaps();
      }
    }

    if (isGoogleMaps) {
      if (googleToken && $map) {
        initGoogleMaps();
      }
    }

    if ($results) {
      checkIfMapShouldBeMoved();
      addEvents();
    }
  }


  function initGoogleMaps() {
    async function initMap() {
      const { Map } = await google.maps.importLibrary('maps');

      map = new Map(document.getElementById('map'), {
        zoom: 4,
      });

      // set default map view based on store country
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode( {'address': SDG.Data.shopCountry}, (results, status) => {
        if (status === 'OK') {
          map.setCenter(results[0].geometry.location);
        }
      });
    }

    initMap();
  }
  /**
   * Initialize Apple Maps
   * @description Initialize Apple Maps
   * @return {void}
   */
  function initAppleMaps() {
    if (!mapkit) return;

    map = new mapkit.Map(config.dom.map);
    
    if (map) { 
      map.cameraDistance = 750;
      map._allowWheelToZoom = true;
    }
  }

  /**
   * Show Location
   * @description updates the map with the passed location
   * @return {void}
   */
  function showLocation($location) {
    if ($location) {
      const { id } = $location.dataset || null;

      if (isAppleMaps) {
        const pin = map.annotations.find((annotation) => annotation.data.id === id);
        // Animate the map to the pin's location
        if (pin) {
          map.showItems([pin], {
            padding: new mapkit.Padding(50, 50, 50, 50)
          });
          map.cameraDistance = 750;
        }
      }

      if (isGoogleMaps) {
        const markerData = googleMarkers.find((marker) => marker.id === id);
        if (markerData) {
          map.panTo(markerData.marker.getPosition());
          map.setZoom(18);
        }
      }
    }
  }

  /**
   * Add Button Events
   * @description adds events to the buttons
   * @return {void}
   */
  function addEvents() {

    function openAcc(el) {
      el.setAttribute('aria-expanded', true)
      el.classList.add(config.cls.active);
    }

    function closeAcc(el) {
      el.setAttribute('aria-expanded', false)
      el.classList.remove(config.cls.active);
    }
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {

        if (mutation?.type === 'childList') {
          const $resultLocations = document.querySelectorAll(config.dom.result) || null;
          const $activeResult = document.querySelector(config.dom.active_result) || null;

          if (mutation?.addedNodes?.length <= 0) {
            return;
          }

          if ($resultLocations?.length > 0) {
            [...$resultLocations].forEach(($resultLocation) => {
              // add events to the result locations
              const hasEvents = $resultLocation.getAttribute('data-events-added') || false;
              if (hasEvents) return;

              addPin($resultLocation);
              $resultLocation.setAttribute('data-events-added', true);
              const $accButton = $resultLocation.querySelector(config.dom.acc_button) || null;
              const $accIcon = $resultLocation.querySelector(config.dom.acc_icon) || null;
              const $accDetails = $resultLocation.querySelector(config.dom.acc_details) || null;

              $resultLocation.addEventListener('click', (e) => {
                const $target = e.currentTarget || null;
                showLocation($target);
              });

              if ($accButton && $accDetails) {
                $accButton.addEventListener('click',() => {
                  if ($accDetails.classList.contains(config.cls.active)) {
                    closeAcc($accDetails);
                    if ($accIcon) closeAcc($accIcon);
                  } else {
                    openAcc($accDetails);
                    if ($accIcon) openAcc($accIcon);
                  }

                  $accButton.setAttribute('data-acc', true)
                });
              }
            });
          }

          if ($activeResult) {
            showLocation($activeResult);
          }
        }
      });
    });

    observer.observe($results, { childList: true });

    // move the map to the correct wrapper on resize
    window.addEventListener('resize', checkIfMapShouldBeMoved);
  }

  /**
   * Check If Map Should Be Moved
   * @description checks if the map should be moved to the mobile or desktop wrapper
   * @return {void}
   */
  function checkIfMapShouldBeMoved() {
    const width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    const $desktopMapWrapper = document.getElementById(config.dom.desktopMapWrapper) || null;
    const $mobileMapWrapper = document.getElementById(config.dom.mobileMapWrapper) || null;
    const $map = document.getElementById(config.dom.map);
    if (!$map) return;

    if (width <= 767) {
      if ($mobileMapWrapper) $mobileMapWrapper.appendChild($map);
    } else {
      if ($desktopMapWrapper) $desktopMapWrapper.appendChild($map);
    }
  }

  /**
   * Add Pin
   * @description adds a pin to the map
   * @param {element} $result
   * @return {void}
   */
  function addPin($result) {
    if (!$result?.dataset || !map) return;
    const { id, latitude: latitudeString, longitude: longitudeString, name, active } = $result.dataset;
    const latitude = parseFloat(latitudeString);
    const longitude = parseFloat(longitudeString);
    const $details = $result?.querySelector(config.dom.result_details) || null;
    const $link = $details?.querySelector(config.dom.result_link) || null;

    const factory = function() {
      const div = document.createElement('div');
      div.className = 'cd-annotation default_icon_color';
      const iconshow = div.appendChild(document.createElement('i'));
      const activeClass = active === 'true' ? ' active' : '';
      iconshow.className = `fa fa-location-dot${activeClass}`;
      return div;
    };

    const options = {
      data: {
        id,
        title: `${name}`,
      }
    };

    if (isAppleMaps) {
      const coordinate = new mapkit.Coordinate(latitude, longitude);
      let pin;

      if ($details) {
        // create the callout with business details
        const calloutDelegate = {
          calloutElementForAnnotation: () => {
            const $wrapper = document.createElement('div');
            $wrapper.className = 'my-location-result__callout my-location-result__callout--apple';
            $wrapper.innerHTML = $details.innerHTML;

            if ($link) {
              $wrapper.innerHTML += $link.innerHTML;
            }

            return $wrapper;
          },
        };

        options.callout = calloutDelegate,
        pin = new mapkit.Annotation(coordinate, factory, options);
      } else {
        options.callout = {
          enabled: true,
          alignment: 'center',
        };
        pin = new mapkit.Annotation(coordinate, factory, options);
      }

      // Remove duplicate annotation from the map
      map.annotations.forEach((annotation) => {
        if (annotation.data.id === id) {
          map.removeAnnotation(annotation);
        }
      });

      // Add the pin to the map
      map.addAnnotation(pin);
    }

    if (isGoogleMaps) {
      const color = active === 'true' ? '#0071e3' : '#1D1D1F';
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="30" height="40" viewBox="0 0 15 20" fill="none">
          <path fill="${color}" fill-rule="evenodd" clip-rule="evenodd" d="M7.95601 0.343032C9.74513 0.436043 11.4364 1.18848 12.7034 2.45513C13.8786 3.63038 14.6141 5.17388 14.7867 6.82694C14.9592 8.48 14.5583 10.1421 13.6511 11.5348L8.61319 19.2686C8.50108 19.4407 8.34779 19.5821 8.16722 19.68C7.98665 19.7779 7.78451 19.8291 7.57912 19.8291C7.37373 19.8291 7.17159 19.7779 6.99102 19.68C6.81046 19.5821 6.65717 19.4407 6.54506 19.2686L1.50727 11.5348C0.529579 10.0335 0.142632 8.22332 0.421112 6.45356C0.699591 4.6838 1.62376 3.07992 3.01524 1.95148C4.40672 0.823033 6.16688 0.250021 7.95601 0.343032ZM6.09693 5.366C6.53546 5.07298 7.05103 4.91658 7.57845 4.91658C8.28545 4.91739 8.96326 5.1986 9.46318 5.69852C9.9631 6.19844 10.2443 6.87625 10.2451 7.58325C10.2451 8.11067 10.0887 8.62624 9.7957 9.06477C9.50269 9.5033 9.08621 9.8451 8.59894 10.0469C8.11167 10.2488 7.57549 10.3016 7.05821 10.1987C6.54093 10.0958 6.06577 9.84181 5.69283 9.46887C5.31989 9.09593 5.06592 8.62077 4.96302 8.10349C4.86013 7.58621 4.91294 7.05003 5.11477 6.56276C5.31661 6.07549 5.6584 5.65902 6.09693 5.366ZM6.80207 6.54574C6.75654 6.56936 6.72618 6.58614 6.72023 6.59004C6.71372 6.59429 6.73632 6.58319 6.80003 6.54886C6.80071 6.54782 6.80139 6.54678 6.80207 6.54574ZM8.08869 6.35141C8.14343 6.37409 8.12507 6.37215 8.06535 6.35802C8.07319 6.35573 8.08097 6.35353 8.08869 6.35141Z"/>
        </svg>`;
      const icon = 'data:image/svg+xml;charset=UTF-8;base64,' + btoa(svg);
      const marker = new google.maps.Marker({
        position: { lat: latitude, lng: longitude },
        map,
        title: name,
        icon,
      });
      const infoWindow = new google.maps.InfoWindow({
        content: `${name}`,
        maxWidth: 300,
      });

      if ($details) {
        const businessDetailsCallout = `
          <div class="my-location-result__callout">
            ${$details.innerHTML}
            ${$link ? $link.innerHTML : ''}
          </div>
        `;

        marker.addListener('click', () => {
          infoWindow.setContent(businessDetailsCallout);
          infoWindow.open(map, marker);
        });
      } else {
        marker.addListener('click', () => {
          infoWindow.open(map, marker);
        });
      }

      // delete existing markers
      googleMarkers.forEach((googleMarker) => {
        if (googleMarker.id === id) {
          googleMarker.marker.setMap(null);
        }
      });

      googleMarkers.push({
        infoWindow,
        marker,
        id,
      });
    }
  }

  return init();
}


mapPage();

