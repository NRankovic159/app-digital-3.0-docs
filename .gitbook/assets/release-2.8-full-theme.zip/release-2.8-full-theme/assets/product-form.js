$(document).ready(function() {
  var $productGrid = document.querySelector('#ProductGridContainer') || null;

  window.initPartnerSlider = function() {
    $('.partner_slider_new').on('init', function(event, slick) {
      const $initPartnerSlider = slick.$slider[0];

      // Timeout needed for slow loading
      setTimeout(() => {
        customSlickSlider();
        setInitialSlideVisibility($initPartnerSlider);
      }, 500);
    });

    $('.partner_slider_new').each(function(key, val) {
      var id1 =  $(this).attr('id');
      var sliderId_1 = '#' + id1;
      if ( $(sliderId_1).hasClass('slick-initialized') ) {
      } else {
        $(sliderId_1).slick({
          slidesToShow: 4,
          slidesToScroll: 3,
          infinite: false,
          prevArrow: $("#l_"+id1),
          nextArrow: $("#r_"+id1),
          variableWidth: true,
          speed: 1000,
          responsive: [
            {
              breakpoint: 1200,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 2,
                infinite: false,
                variableWidth: true,
                speed: 1000,
              }
            },
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                infinite: false,
                variableWidth: true,
                speed: 1000,
              }
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: true,
                variableWidth: true,
                speed: 500,
              }
            },
            {
              breakpoint: 480,
                settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: true,
                variableWidth: true,
                speed: 500,
              }
            }
          ]
        });

        // Remove aria-describedby from slick slides
        setTimeout(() => {
          const slickSlides = $(sliderId_1).find('.slick-list .slick-slide');
          adaFormatSlickSlides(slickSlides);
        }, 250);
      }

      $("#l_"+id1).hide();
      customSlickSlider();
      $(sliderId_1).on('afterChange', function (event, slick, currentSlide) {
        const $partnerSlider = slick.$slider[0];
        setSlideVisibility($partnerSlider);
        if (currentSlide === 0) {
          $("#l_"+id1).hide();
        }
        else {
          $("#l_"+id1).show();
        }
      });
    });
  }
  window.initPartnerSlider();

  /* Starts Product Slider - Karthikeyan */
  //  setInterval(function() {
  window.initProductSlider = function() {
    $('.product-list-contain').on('init', function(event, slick) {
      const $initProductListSlider = slick.$slider[0];

      // Timeout needed for slow loading
      setTimeout(() => {
        customSlickSlider();
        setInitialSlideVisibility($initProductListSlider);
      }, 500);
    });

    $('.product-list-contain').each(function(key, val) {
      var id = $(this).attr('id');
      var sliderId = '#' + id;
      $(sliderId).not('.slick-initialized').slick({
        variableWidth: true,
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        prevArrow: $(this).parent().find('.prev'),
        nextArrow: $(this).parent().find('.next'),
        appendDots: $(this).parent().find('.dots-slider'),
        dotsClass: 'slick-dots apl-section-carousel-dots',
        responsive: [
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 1,
              infinite: true,
              dots: true
            }
          },
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              arrows: false,
            }
          }
        ]
      });

      $('.product-list-contain').on('afterChange', function (event, slick) {
        const $productListSlider = slick.$slider[0];
        setSlideVisibility($productListSlider);
      });

      // Remove aria-describedby from slick slides
      setTimeout(() => {
        const slickSlides = $(sliderId).find('.slick-list .slick-slide');
        adaFormatSlickSlides(slickSlides);
      }, 250);
    })
  }
  window.initProductSlider();
  /* Ends Product Slider - Karthikeyan */

    $(document).on('click', '.freq-select-products', function() {
        if ($(".button-cart-frequent").attr("product-list") == "Cart Page") {
            var productList = "ATTACH :: Cart Page";
        } else {
            var mpn_handle = $("#mpn_handle").val();
            var productList = "Shopify Rec :: " + mpn_handle;
        }
        localStorage.setItem("product-click", productList);
    });

    $(document).on('change', '.frequent-products-checkbox', function() {
        var checkLength = $("input[name='frequent-products-pdp']:checked").length;
        $("#checked-products").text(checkLength);
        if (checkLength == 0) {
            $('#card-button').prop("disabled", true);
        } else {
            $('#card-button').prop("disabled", false);
        }
        var product_id = $(this).val();
        var prodtitle = $("#title_" + product_id).val();
        var prodMPN = $("#product_mpn_handle_" + product_id).val();
        var prodType = $(".card_product_category_" + product_id).val();
        var prodCurrency = $(".card_product_currency_" + product_id).attr("value");
        var prodPrice = $(".card_product_price_" + product_id).attr("value");
        var compareprice = $(".card_product_compare_" + product_id).attr("value");
        var prodSku = $(".card_product_sku_" + product_id).attr("value");
        prodPrice = Number(prodPrice.replace(/[^0-9.-]+/g, ""));
        prodPrice = parseFloat(prodPrice);
        if ($(".button-cart-frequent").attr("product-list") == "Cart Page") {
            var productList = "ATTACH :: Cart Page";
        } else {
            var mpn_handle = $("#mpn_handle").val();
            var productList = "Shopify Rec :: " + mpn_handle;
        }
        localStorage.setItem("product-click", productList);
        dataLayer.push({
            'ecommerce': null
        });
        dataLayer.push({
            'event': 'select_item',
            'ecommerce': {
                'item_list_name': productList,
                'items': [{
                    'item_id': prodSku,
                    'item_name': prodtitle,
                    'item_category': prodType,
                    'price': prodPrice,
                    'quantity': 1,
                }]
            }
        });
    });


    $(document).on('click', '#card-button', function(event) {
        event.preventDefault();
        var $CTOcartDrawer = $('cto-cart-drawer');
        $('.button-cart-frequent').attr('aria-disabled', true);
        $('.button-cart-frequent').addClass('loading');
        $('.loading-overlay__spinner-frequent').removeClass('hidden');
        var frequentProducts = [];
        var frequentProducts_ga = [];
        var tax_total_quantity = 0;
        var quncheck = [];
        var prodLimit = [];
        var value_price = 0;
        var prodCurrency = $("#prod_currency").val();
        $.each($("input[name='frequent-products-pdp']:checked"), function() {
            /* Order Product Limits - Karthikeyan */
            var prodId = $("#product_id_" + $(this).val()).val();
            var prodQuant = 1;
            var prodMaxqut = $("#product_max_quantity_" + $(this).val()).val();
            var prodtitle = $("#title_" + $(this).val()).val();
            var prodMPN = $("#product_mpn_handle_" + $(this).val()).val();
            let prod_handle = $("#card_product_handle_" + $(this).val()).val();
            var prodPreorder = $("#card_product_preorder_" + $(this).val()).val();
            var prodPreorderMessage = $("#card_product_preorder_message_" + $(this).val()).val();
            var prodTradeIn = $("#card_product_tradein_" + $(this).val()).val();
            var isMainProduct = $(this).hasClass('js-is-main-product');
            var prodSku = $(".card_product_sku_" + $(this).val()).val();
            const itemToken = btoa(Date.now() + '' + Math.random()); 
            if (prodMaxqut != "") {
                var maxQuant = checkMaxquantity(prodId);
                if (maxQuant != "") {
                    var max_total_quantity = parseInt(prodQuant) + parseInt(maxQuant);
                } else {
                    var max_total_quantity = parseInt(prodQuant);
                }

                if (max_total_quantity > prodMaxqut) {
                    quncheck.push(1);
                    prodLimit.push(prodMaxqut);
                }
            }
            var taxtags_fb = $("#tags_" + $(this).val()).val();
            var addtaxfree = taxtags_fb.indexOf('taxfree') != -1;
            if (addtaxfree == true) {
                tax_total_quantity++
            }
            var isCTOSku = !!$CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden') && isMainProduct;

            // check if has GWP and on a CTO PDP and add the correct properties to each
            let gwpSku = '';
            let gwpHandle = '';
            let gwpMainProductSku = '';
            let gwpMainProductHandle = '';
            if (isCTOSku) {
              var prodGWPSkus = $("#card_product_gwp_skus_" + $(this).val()).val();
              $.each($("input[name='frequent-products-pdp']:checked"), function() {
                var prodGwpSku = $(".card_product_sku_" + $(this).val()).val();
                var prodGwpHandle = $("#card_product_handle_" + $(this).val()).val();
                if (prodGwpSku && prodGWPSkus?.includes(prodGwpSku)) {
                  var skucomma = gwpSku === '' ? '' : ',';
                  var handledash = gwpHandle === '' ? '' : '-';
                  gwpSku = `${gwpSku}${skucomma}${prodGwpSku}`;
                  gwpHandle = `${gwpHandle}${handledash}${prodGwpHandle}`;
                  prod_handle = `${prod_handle}-${prodGwpHandle}`;
                }
              });
            } else {
              var ctoMainProduct = $("input.js-is-main-product[name='frequent-products-pdp']:checked");
              var hasCtoMain = !!$CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden') && ctoMainProduct.length;
              if (hasCtoMain) {
                var prodGWPSkus = $("#card_product_gwp_skus_" + $(ctoMainProduct).val()).val();
                if (prodGWPSkus?.includes(prodSku)) {
                  gwpMainProductSku = $(".card_product_sku_" + $(ctoMainProduct).val()).val();
                  gwpMainProductHandle = $("#card_product_handle_" + $(ctoMainProduct).val()).val();
                  prod_handle = gwpMainProductHandle;
                  $.each($("input[name='frequent-products-pdp']:checked:not(.js-is-main-product)"), function() {
                    var prodGwpSku = $(".card_product_sku_" + $(this).val()).val();
                    var prodGwpHandle = $("#card_product_handle_" + $(this).val()).val();
                    if (prodGwpSku && prodGWPSkus?.includes(prodGwpSku)) {
                      prod_handle = `${prod_handle}-${prodGwpHandle}`;
                    }
                  });
                }
              }
            }
            var item = {}
            item["quantity"] = 1;
            item["id"] = $(this).val();
            item["properties"] = {
                _uuid: prod_handle,
                ...(prodPreorder === 'true' && { _preOrder: 'true' }),
                ...(prodPreorderMessage && { _preOrderMessage: prodPreorderMessage }),
                ...(prodTradeIn === 'true' && { _tradeInEligible: 'true' }),
                ...(isCTOSku && { _cto_product: 'true' }),
                ...(gwpSku !== '' && { _gwp_sku: gwpSku }),
                ...(gwpHandle !== '' && { _gwp_handle: gwpHandle }),
                ...(gwpMainProductSku !== '' && { _gwp_main_product_sku: gwpMainProductSku }),
                ...(gwpMainProductHandle !== '' && { _gwp_main_product_handle: gwpMainProductHandle }),
                ...(itemToken && { _item_token: itemToken }),
                _added_from_fbt: 'true',
            }

            const productTemplate = document.body.dataset.template;
            if ((
              productTemplate.includes('product') && !productTemplate.includes('pdp-2.0')
              || !productTemplate.includes('pdp-2.0') && !productTemplate.includes('plp-new')
            ) && isMainProduct) {
              item["properties"]["_added_from_pdp"] = "true"
              delete item["properties"]["_cto_product"]
            }

            frequentProducts.push(item);
            var prodType = $(".card_product_category_" + $(this).val()).val();

            var prodPrice = $(".card_product_price_" + $(this).val()).attr("value");
            var prodSku = $(".card_product_sku_" + $(this).val()).attr("value");
            var compareprice = $(".card_product_compare_" + $(this).val()).attr("value");
            var productList = $(".button-cart-frequent").attr("product-list");
            var mpn_handle = $("#mpn_handle").val();
            var shopify_rec = "Shopify Rec :: " + mpn_handle;
            prodPrice = Number(prodPrice.replace(/[^0-9.-]+/g, ""));
            value_price += parseFloat(prodPrice);
            value_price = parseFloat(value_price);
            var productPrice1 = parseFloat(prodPrice);
            var item_ga = {}
            item_ga["item_id"] = prodSku;
            item_ga["item_name"] = prodtitle;
            item_ga["item_category"] = prodType;
            item_ga["item_list_name"] = shopify_rec;
            item_ga["price"] = parseFloat(productPrice1);
            item_ga["quantity"] = 1;
            frequentProducts_ga.push(item_ga);


        });

        if (jQuery.inArray(1, quncheck) !== -1) {
            // One line per distinct limit: each blocked product carries its own limit, so a single
            // shared {limit} could only ever be right for one of them. The product name is left out
            // to match the limit alerts everywhere else in the theme, which makes two products on
            // the same limit collapse into one line.
            var limitMessages = [];
            prodLimit.forEach(function(limit) {
                var message = quantity_limit_error_message.replace('{limit}', limit);
                if (limitMessages.indexOf(message) === -1) {
                    limitMessages.push(message);
                }
            });
            alert(limitMessages.join("\n"));
            $('.button-cart-frequent').attr('aria-disabled', false);
            $('.button-cart-frequent').removeClass('loading');
            $('.loading-overlay__spinner-frequent').addClass('hidden');
            return false;
        }
        /* VAT Product Limits - Karthikeyan */
        if (vat_free_day == true) {
            if (getCookie('total_quantity') == "") {
                var tax_total_quantity = parseInt(tax_total_quantity);
            } else {
                var tax_total_quantity = parseInt(tax_total_quantity) + parseInt(getCookie('total_quantity'));
            }
            if (tax_total_quantity > +vat_free_quantity) {
                alert(vat_free_message);
                $('.button-cart-frequent').attr('aria-disabled', false);
                $('.button-cart-frequent').removeClass('loading');
                $('.loading-overlay__spinner-frequent').addClass('hidden');
                return false;
            }
        }

        const adobeItems = frequentProducts.map(item => {
          return {
            ...item,
            quantity: item.quantity || 1,
          }
        });

        fetch(`${window.Shopify.routes.root}cart/add.js`, {
                method: "post",
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    items: frequentProducts
                }),
            }).then(response => response.text().then(text => {
                let d = null;
                // a 5xx from Shopify comes back as an HTML page, not the usual JSON body
                try { d = JSON.parse(text); } catch (e) {}
                return { ok: response.ok, d };
            }))
            .then(({ ok, d }) => {
                  // cart/add.js is atomic: a rejected line (sold out, quantity limit) leaves the
                  // cart untouched, so the minicart, count bubble and analytics below must not run.
                  // Only a parsed error body proves that - any other failure leaves the cart state
                  // unknown, so those fall through and let the minicart re-read it from the server.
                  if (d && d.status) {
                    console.error('Error:', d.description || d.message);
                    if (d.message) { alert(d.message); }
                    $('.button-cart-frequent').attr('aria-disabled', false);
                    $('.button-cart-frequent').removeClass('loading');
                    $('.loading-overlay__spinner-frequent').addClass('hidden');
                    return;
                  }
                  if (!ok || !d || !d.items) {
                    console.error('Unexpected cart/add.js response:', d);
                  } else {
                    try {
                      var mpn_handle = $("#mpn_handle").val();
                      var shopify_rec = "Shopify Rec :: " + mpn_handle;
                      var exphone_fa = [];
                      try {
                        var parsedCart = JSON.parse(localStorage.getItem("cart"));
                        if (parsedCart != null) exphone_fa = parsedCart;
                      } catch (e) {
                        exphone_fa = [];
                      }
                      for (var i = 0; i < d.items.length; i++) {
                          var item_cart_fa = {}
                          item_cart_fa["cart_item_id"] = d.items[i].key;
                          item_cart_fa["cart_item_list_name"] = shopify_rec;
                          item_cart_fa["cart_item_mpn"] = d.items[i].sku;
                          exphone_fa.push(item_cart_fa);
                      }
                      localStorage.setItem("cart", JSON.stringify(exphone_fa));
                    } catch (e) {
                      console.error('FBT cart list tracking failed:', e);
                    }

                    if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
                      $CTOcartDrawer[0].forceClearCtoItems();
                      $CTOcartDrawer[0].updateItems(d.items);
                    }

                    try {
                      adobeTrackAddToCart({
                        items: adobeItems,
                        context: 'Frequently Bought Together',
                        $trigger: $('#card-button')[0],
                      });
                    } catch (e) {
                      console.error('FBT Adobe add-to-cart tracking failed:', e);
                    }
                  }

                // checkQuantity();
                $.get(`${window.Shopify.routes.root}cart?view=minicart`, function(itemData) {
                    var item_count = jQuery(itemData).find('#cart-notification-button .count').text();
                    if ($('.cart-count-bubble').length > 0) {
                        $('.cart-count-bubble span').text(item_count);
                    } else {
                        $('#cart-icon-bubble').append('<div class="cart-count-bubble"><span></span></div>');
                        $('.cart-count-bubble span').text(item_count);
                    }
                    $("#cart-notification").text("");
                    var textreplace = "<div id='min-cart-replace'></div>";
                    $("#cart-notification").append(textreplace);
                    $("#cart-notification").replaceWith(itemData);
                    if (!$CTOcartDrawer.length || $CTOcartDrawer.hasClass('hidden')) {
                      $('#cart-notification').addClass('minicart-active');
                    }
                });
                dataLayer.push({
                    'ecommerce': null
                });
                dataLayer.push({
                    'event': 'add_to_cart',
                    'ecommerce': {
                        'value': value_price,
                        'currency': prodCurrency,
                        'items': frequentProducts_ga
                    }
                });

                $('.button-cart-frequent').attr('aria-disabled', false);
                $('.button-cart-frequent').removeClass('loading');
                $('.loading-overlay__spinner-frequent').addClass('hidden');
                if (window.location.href.indexOf("/cart") > -1) {
                    window.onCartUpdate();
                }
            })
            .catch((error) => {
                console.error('Error:', error);
                $('.button-cart-frequent').attr('aria-disabled', false);
                $('.button-cart-frequent').removeClass('loading');
                $('.loading-overlay__spinner-frequent').addClass('hidden');
                return false;
            });
        return false;
    });
    /* Ends Frequently add Products Karthikeyan */

    function quickAddEvents() {
      var quickAddButtons = $('.slider-form:not(.event-attached)');
      quickAddButtons.click(function(evt) {
        evt.preventDefault();
        var $CTOcartDrawer = $('cto-cart-drawer');
        var mpn_handle = $("#mpn_handle").val();
        /* Order Product Limits - Karthikeyan */
        var pageName = window.location.href;
        var prodId = $(this).attr("data-productid");
        var prodQuant = 1;
        var prodMaxqut = $(this).attr("data-productmaxquantity");
        var cartpage = $(this).attr("data-cartpage");
        if (cartpage == "Cart Page") {
            var attach = "ATTACH :: Cart Page";
        } else {
            var attach = "ATTACH :: ";
        }
        if (prodMaxqut != "") {
            var maxQuant = checkMaxquantity(prodId);
            if (maxQuant != "") {
                var max_total_quantity = parseInt(prodQuant) + parseInt(maxQuant);
            } else {
                var max_total_quantity = parseInt(prodQuant);
            }
            if (max_total_quantity > prodMaxqut) {
                alert(quantity_limit_error_message.replace('{limit}', prodMaxqut));
                return false;
            }
        }
        var slider_variantid = $(this).attr("data-variantid");
        var slider_tag = $(this).attr("data-tag");
        //souvik code for product list tracking starts
        var collection_name = $(this).attr("data-collection");
        var main_product_sku = $(this).attr("data-productsku");
        if (pageName.includes("products")) {
            var mpn_handle = $("#mpn_handle").val();
            var productList = mpn_handle;
        } else if (pageName.includes("search")) {
          var productList = 'Search Results';
        } else {
          var productList = formatString($(this).attr("data-productlist"));
        }
        var productCategory = $(this).attr("data-producttype");
        var productPrice = $(this).attr("data-productprice");
        var productcomPrice = $(this).attr("data-productcompprice");
        var productCurrency = $(this).attr("data-productcurrency");
        var productTitle = $(this).attr("data-producttitle");
        var productMPN = $(this).attr("data-productMPN");
        var productHandle = $(this).attr("data-producthandle");
        var productPreOrder = $(this).attr("data-productpreorder");
        var productPreOrderMessage = $(this).attr("data-productpreordermessage");
        var productTradeIn = $(this).attr("data-producttradein");
        var gwpData = $(this).find('.js-slider-form-gwp-data');
        var gwpMaximum = $(this).find('.js-slider-form-gwp-data').data('gwp-maximum');
        var hasGwp = gwpData.length > 0;
        const productSku = $(this).attr("data-productsku");
        const productBarcode = $(this).attr("data-productbarcode");
        const itemToken = pageName.includes("products") ? btoa(Date.now() + '' + Math.random()) : null; 
        //souvik code for product list trackingends

        /* VAT Product Limits - Karthikeyan */
        if (vat_free_day == true) {
            var addtaxfree = slider_tag.indexOf('taxfree') != -1;
            if (addtaxfree == true) {
                if (getCookie('total_quantity') >= +vat_free_quantity) {
                    alert(vat_free_message);
                    return false;
                }
            }
        }
        $('#slider-form-' + slider_variantid).attr('aria-disabled', true);
        $('#slider-form-' + slider_variantid).addClass('loading');
        $('.loading-overlay__spinner-frequent').removeClass('hidden');

        var uid = productHandle;
        var gwpKey = btoa(Date.now() + '' + Math.random());

        if (hasGwp) {
          uid = uid + '-' + gwpKey;
        }

        const props = {
          _uuid: uid,
          ...(productPreOrder === 'true' && { _preOrder: 'true' }),
          ...(productPreOrderMessage && { _preOrderMessage: productPreOrderMessage }),
          ...(productTradeIn === 'true' && { _tradeInEligible: 'true' }),
          ...(productSku && { SKU: productSku }),
          ...(productBarcode && { Barcode: productBarcode }),
          ...(itemToken && { _item_token: itemToken })
        };

        if (hasGwp) {
          var gwpSkus = [];
          var gwpHandles = [];
          gwpData.each(function() {
            gwpSkus.push($(this).data('gwp-product-sku'));
            gwpHandles.push($(this).data('gwp-product-handle'));
          });
          props._gwp_sku = gwpSkus.join(',');
          props._gwp_handle = gwpHandles.join('-');
        }

        var items = [{
          id: slider_variantid,
          quantity: 1,
          properties: props,
        }];

        if (hasGwp) {
          gwpData.each(function() {
            items.push({
              id: $(this).data('gwp-id'),
              quantity: Math.min($(this).data('gwp-quantity'), gwpMaximum || 0),
              properties: {
                _gwp_main_product_sku: main_product_sku,
                _gwp_main_product_handle: productHandle,
                _uuid: uid
              }
            });
          });
        }

        const adobeItems = [];
        items.forEach(item => {
          adobeItems.push({
            id: item.id,
            quantity: item.quantity,
          });
        });

        if (cartpage == "Cart Page") {
          var prod_list = attach;
        } else if (pageName.includes("search"))  {
          var prod_list = productList;
        } else  {
          var prod_list = attach + productList;
        }

        fetch(`${window.Shopify.routes.root}cart/add.js`, {
                method: "post",
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({items}),
            }).then(response => {

                response.json().then(d => {
                  if (d.status === 422) {
                    console.error('Error:', d.message);
                    if (d.message) { alert(d.message); }
                    return false;
                  }
                  if (d?.items?.length) {
                    cartCookie(productMPN, d.items[0].key, prod_list);
                  }

                  if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
                    $CTOcartDrawer[0].updateItems(d.items);
                  }
                })

                //checkQuantity();

                removeGwpData(gwpData);

                //souvik code for product list tracking starts
                triggerGAAddToCart(productcomPrice, main_product_sku, productTitle, productCategory, prod_list, productCurrency, productPrice, prodQuant, main_product_sku, slider_variantid);
                //souvik code for product list tracking ends

                try {
                  adobeTrackAddToCart({
                    items: adobeItems,
                    context: 'Quick Add',
                    $trigger: this,
                  });
                } catch (e) {
                  console.error('Quick Add Adobe add-to-cart tracking failed:', e);
                }

                if (cartpage == "Cart Page") {
                    window.onCartUpdate({ scrollToTop: true });
                    return false;
                }
                $.get(`${window.Shopify.routes.root}cart?view=minicart`, function(itemData) {
                    var item_count = jQuery(itemData).find('#cart-notification-button .count').text();
                    if ($('.cart-count-bubble').length > 0) {
                        $('.cart-count-bubble span').text(item_count);
                    } else {
                        $('#cart-icon-bubble').append('<div class="cart-count-bubble"><span></span></div>');
                        $('.cart-count-bubble span').text(item_count);
                    }
                    $("#cart-notification").text("");
                    var textreplace = "<div id='min-cart-replace'></div>";
                    $("#cart-notification").append(textreplace);
                    $("#cart-notification").replaceWith(itemData);
                    if (!$CTOcartDrawer.length || $CTOcartDrawer.hasClass('hidden')) {
                      $('#cart-notification').addClass('minicart-active');
                      $('#cart-notification .minicart_close')?.focus();
                    }
                });
                $('#slider-form-' + slider_variantid).attr('aria-disabled', false);
                $('#slider-form-' + slider_variantid).removeClass('loading');
                $('.loading-overlay__spinner-frequent').addClass('hidden');
            })
            .catch((error) => {
                console.error('Error:', error);
                return false;
            });
        return false;
      });
      quickAddButtons.addClass('event-attached');
    }

    quickAddEvents();
    window.quickAddEvents = quickAddEvents;

    /*Add Applecare on cart page functionality  starts here - added by Hema*/
    $(document).on('click', '.add-cart-apple-care', function(e) {
        // A failed Cart API call must not leave the add-on buttons disabled and the drawer stale
        addApplecareToCart.call(this, e).catch(async (error) => {
          console.error('Add-on add failed — resyncing the cart drawer.', error);
          const $CTOcartDrawer = $('cto-cart-drawer');
          if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
            $CTOcartDrawer[0].updateItems();
          }
          if (window.toggleAddOnButtons) window.toggleAddOnButtons('enable');
          window.onCartUpdate();
        });
    });

    async function addApplecareToCart(e) {
        e.preventDefault();

        var $CTOcartDrawer = $('cto-cart-drawer');
        $(this).prop('disabled', true);
        if (window.toggleAddOnButtons) window.toggleAddOnButtons('disable');
        const add_button_target = $(this);
        const target_additional_flag = add_button_target.data('reference');
        const target_gwp_maximum = add_button_target.data('gwp-maximum');
        const target_gwp_maximum_available = add_button_target.data('gwp-maximum-available') ?? target_gwp_maximum;
        const add_button_target_sku = add_button_target.data('skuaplcr');
        const main_product_target_token = add_button_target.data('tokenparent');
        const main_product_target_sku = add_button_target.data('skuparent');
        // Capture synchronously, before any await — the acceptance interceptor
        // clears this attribute right after re-firing the click.
        const target_customer_accept_terms = add_button_target.attr('data-customer-accept-terms') === 'Y';
        const add_button_selectors = {
            'aplcr': '.apl-section-cto-cart-drawer-applecare',
            'secwr': '.apl-section-cto-cart-drawer-warranty',
            'gwp': '.cto-gwp-items .cto-gwp-item'
        };
        const add_button_target_selector = add_button_selectors[target_additional_flag];
        // retrieve all CTO products added in the same session (have same token)
        // includes items identified either by data-cto-product="true" or data-added-from-pdp="true"
        const token_grouped_cto_items = $CTOcartDrawer.find(
            `.cto-cart-item[data-cto-product="true"][data-sku="${main_product_target_sku}"][data-token="${main_product_target_token}"], ` +
            `.cto-cart-item[data-added-from-pdp="true"][data-sku="${main_product_target_sku}"][data-token="${main_product_target_token}"]`
        );
        // get all line-item-keys for all grouped CTO products
        const grouped_product_keys = token_grouped_cto_items.map(function() {
            return $(this).data('cto-cart-item-key');
        }).get();
        // build dynamic selector for all associated Applecare or SecWarranty buttons
        const aplcr_btn_selector = add_button_target_selector ? grouped_product_keys.map(key => 
            `${add_button_target_selector}[data-cto-cart-item-key="${key}"] .add-cart-apple-care[data-skuaplcr="${add_button_target_sku}"]`
        ).join(', ') : '';
        let aplcr_btns_to_proceed = add_button_target;
        // Check if click was made from the Cart Drawer and if we have valid aplcr btns
        if (aplcr_btn_selector && $CTOcartDrawer && $CTOcartDrawer.length > 0) {
          const associated_addons_btns = $CTOcartDrawer.find(aplcr_btn_selector);

          if (associated_addons_btns.length > 0) {
            if (target_additional_flag === 'gwp' && target_gwp_maximum_available) {
              aplcr_btns_to_proceed = associated_addons_btns.slice(0, target_gwp_maximum_available);
            } else {
              aplcr_btns_to_proceed = associated_addons_btns;
            }
          }
        }

        if (target_additional_flag === 'gwp' && target_gwp_maximum && target_gwp_maximum_available <= 0) {
          alert(gwp_quantity_limit_error_message.replace('{limit}', target_gwp_maximum));
          $(this).prop('disabled', false);
          if (window.toggleAddOnButtons) window.toggleAddOnButtons('enable');
          return;
        }

        let latestKeysCartData = null;
        // Gift units still allowed cart-wide, shared by all grouped lines: a line with quantity > 1
        // adds one gift per unit, so capping each line at gwp_maximum alone can exceed the limit
        let gwp_remaining = parseInt(target_gwp_maximum_available);
        for (const elem of aplcr_btns_to_proceed.get()) {
          const add_button = $(elem);
          var product_id = add_button.data('variantid');
          const main_product_token = add_button.data('tokenparent');
          var main_product_index = add_button.data('forproduct');
          var wp_idx = add_button.data('forwproduct');
          var wp_key = add_button.data('forwkey');
          var wp_idx2 = add_button.data('forwproduct2');
          var wp_key2 = add_button.data('forwkey2');
          var wp_idx_gwp = add_button.data('forwproductgwp');
          var wp_key_gwp = add_button.data('forwkeygwp');
          var previous_uid = add_button.data('uuid');
          var main_product_parent = $('#CartItem-' + main_product_index);
          var has_applcr_sku = main_product_parent.data('applecare_sku')?.trim();
          var has_applcr_handle = main_product_parent.data('applecare_handle');
          var has_sw_sku = main_product_parent.data('secwarranty_sku')?.trim();
          var has_sw_handle = main_product_parent.data('secwarranty_handle');
          var has_gwp_sku = main_product_parent.data('gwp_sku')?.trim();
          var has_gwp_handle = main_product_parent.data('gwp_handle');
          var has_gwp_key = main_product_parent.data('gwp_key');
          var isCTO = main_product_parent.data('cto-product');
          var main_product_quantity = main_product_parent.find('.quantity__input')?.val();
          var main_product_sku = add_button.data('skuparent');
          const main_product_barcode = add_button.data('barcodeparent');
          var main_product_handle = add_button.data('handleparent');
          var main_product_preorder = add_button.data('preorderparent');
          var main_product_preorder_message = add_button.data('preordermessageparent');
          var main_product_trade_in = add_button.data('tradeinparent');
          var main_product_key = add_button.data('keyparent');
          var aplCr_sku = add_button.data('skuaplcr');
          const aplCr_barcode = add_button.data('barcodeaplcr');
          var applecarempn = add_button.data('mpnaplcr');
          var aplCr_handle = add_button.data('handleaplcr');
          var main_mpn_value = add_button.data('mpnparent');
          var additional_flag = add_button.data('reference')
          var gwp_maximum_reached = add_button.data('gwp-maximum-reached');
          var gwp_maximum = add_button.data('gwp-maximum');
          const gwp_maximum_available = add_button.data('gwp-maximum-available');
          var main_product_tags = main_product_parent.find('.cart_tax_tags')?.val();
          var override_quantity = add_button.data('overridequantity');
          const tradeInValue = $(main_product_parent).data('tradeInValue');
          const tradeInDevice = $(main_product_parent).data('tradeInDevice');
          const customBundleId = add_button.data('custom-bundle-id');
          const customBundleName = add_button.data('bundle-name');
          const customBundleHandle = add_button.data('bundle-handle');
          const customBundleProductID = add_button.data('bundle-product-id');
          const customBundleSku = add_button.data('bundle-sku');
          const customBundleBarcode = add_button.data('bundle-barcode');
          const customBundlePrice = add_button.data('bundle-price');
          const customBundleItem1 = add_button.data('bundle-child-item-id-1');
          const customBundleItem2 = add_button.data('bundle-child-item-id-2');
          const customBundleItem3 = add_button.data('bundle-child-item-id-3');
          const customBundleItem1Price = add_button.data('bundle-child-item-1-price');
          const customBundleItem2Price = add_button.data('bundle-child-item-2-price');
          const customBundleItem3Price = add_button.data('bundle-child-item-3-price');

          if (additional_flag === 'gwp' && gwp_maximum_reached) {
            alert(gwp_quantity_limit_error_message.replace('{limit}', gwp_maximum));
            $(this).prop('disabled', false);
            if (window.toggleAddOnButtons) window.toggleAddOnButtons('enable');
            return;
          } else if (additional_flag === 'gwp' && main_product_quantity > gwp_maximum_available) {
            alert(gwp_quantity_limit_error_message.replace('{limit}', gwp_maximum_available));
          }

          const gwp_limit = additional_flag == "gwp" && gwp_maximum
            ? (isNaN(gwp_remaining) ? gwp_maximum : Math.min(gwp_maximum, gwp_remaining))
            : null;
          if (gwp_limit !== null && gwp_limit <= 0) {
            break;
          }

          let add_gwp_skus = [];
          let add_gwp_handles = [];
          $(`.add-cart-apple-care[data-reference="gwp"][data-skuaplcr="${aplCr_sku}"][data-handleaplcr="${aplCr_handle}"], .gwp_dpnd_${main_product_index}`).each(function() {
            let gwp_sku;
            let gwp_handle;
            if ($(this).hasClass('add-cart-apple-care')) {
              gwp_sku = $(this).data('skuaplcr');
              gwp_handle = $(this).data('handleaplcr');
            } else {
              gwp_sku = $(this).find('cart-remove-button').data('gwp-sku');
              gwp_handle = $(this).find('cart-remove-button').data('gwp-handle');
            }

            if (!add_gwp_handles.includes(gwp_handle)) {
              add_gwp_skus.push(gwp_sku);
              add_gwp_handles.push(gwp_handle);
            }
          });


          if (latestKeysCartData && aplcr_btns_to_proceed.length > 1) {
              const refreshedMainProductItem = latestKeysCartData.items.find(item =>
                  item.properties?._uuid === has_gwp_key &&
                  (item.properties?._cto_product === 'true' || item.properties?._added_from_pdp === 'true')
              );

              if (refreshedMainProductItem) {
                  // overwrite previous key if updated
                  main_product_key = refreshedMainProductItem.key;
              } else if (!latestKeysCartData.items.some(item => item.key === main_product_key)) {
                  // This line was already re-created (with the add-on) by an earlier iteration's
                  // split handling, so its DOM key is gone — posting it 400s.
                  continue;
              }
          }

          var data = {
            id: main_product_key,
            quantity: main_product_quantity,
            properties: {},
          };

          if (main_product_preorder) {
            data.properties._preOrder = 'true';
          }

          if (main_product_preorder_message) {
            data.properties._preOrderMessage = main_product_preorder_message;
          }

          if (main_product_trade_in) {
            data.properties._tradeInEligible = 'true';
          }

          if (isCTO) {
            data.properties._cto_product = 'true';
          } else {
            data.properties._added_from_pdp = 'true';
          }

          if (tradeInValue) {
            data.properties._tradeIn_value = tradeInValue.toString().replace('.', '');
          }

          if (tradeInDevice) {
            data.properties._tradeIn_device = tradeInDevice;
          }

          if (main_product_sku) {
            data.properties.SKU = main_product_sku;
          }

          if (main_product_barcode) {
            data.properties.Barcode = main_product_barcode;
          }

          if (main_product_token) {
            data.properties._item_token = main_product_token;
          }

          if (customBundleId) {
            data.properties._bundle_uuid = customBundleId;
            data.properties._bundle_title = customBundleName;
            data.properties._bundle_handle = customBundleHandle;
            data.properties._bundle_product_id = customBundleProductID;
            data.properties._bundle_price = customBundlePrice;
            data.properties._bundle_item_1_id = customBundleItem1;
            data.properties._bundle_item_2_id = customBundleItem2;
            data.properties._bundle_item_3_id = customBundleItem3;
            data.properties._bundle_item_1_price = customBundleItem1Price;
            data.properties._bundle_item_2_price = customBundleItem2Price;
            data.properties._bundle_item_3_price = customBundleItem3Price;

            if (customBundleSku) {
              data.properties.SKU = customBundleSku;
            }

            if (customBundleBarcode) {
              data.properties.Barcode = customBundleBarcode;
            }
          }

          // generate random uuid to avoid collisions
          var uid = main_product_handle + '-' + crypto.randomUUID().slice(0, 8);

          if (additional_flag == "aplcr") {
            uid = uid + '-' + aplCr_handle;
            data.properties._applecare_sku = aplCr_sku;
            data.properties._applecare_handle = aplCr_handle;
          } else if (has_applcr_sku) {
            uid = uid + '-' + has_applcr_handle;
            data.properties._applecare_sku = has_applcr_sku;
            data.properties._applecare_handle = has_applcr_handle;
          }

          if (additional_flag == "secwr") {
            uid = uid + '-' + aplCr_handle;
            data.properties._secWarranty_sku = aplCr_sku;
            data.properties._secWarranty_handle = aplCr_handle;
          } else if (has_sw_sku) {
            uid = uid + '-' + has_sw_handle;
            data.properties._secWarranty_sku = has_sw_sku;
            data.properties._secWarranty_handle = has_sw_handle;
          }

          var gwpKey = btoa(Date.now() + '' + Math.random());
          if (additional_flag == "gwp") {
            uid = uid + '-' + gwpKey;
            data.properties._gwp_sku = add_gwp_skus.join(',');
            data.properties._gwp_handle = add_gwp_handles.join('-');
          } else if (has_gwp_sku) {
            uid = uid + '-' + gwpKey;
            data.properties._gwp_sku = has_gwp_sku;
            data.properties._gwp_handle = has_gwp_handle;
            data.properties._gwp_key = has_gwp_key;
          }

          data.properties._uuid = uid;

          data = JSON.stringify(data);

          if (!has_applcr_sku && !has_sw_sku && !has_gwp_sku) {
            var wp_idx = 0;
            var wp_idx2 = 0;
          }

          // we will use these variables to handle cases when Shopify split
          // identical items after cart/change.js request and adds extra items
          let mainProductItemsSplit = [];
          let extraItemKeysToRemove = [];
          // AppleCare can get removed when we delete the parent product. This variable keeps track of them
          let cartItemsRemovedAfterDeletion = [];

          var oldData = JSON.parse(data);
          var shouldSplitIntoIndividualItems = parseInt(oldData.quantity) > 1 && additional_flag == "gwp";
          if (shouldSplitIntoIndividualItems) {
            // if quantity is more than 1, we need to break up the line items to each individual item with each containing the GWP
            var newLineItemsDataProperties = Array.from(Array(parseInt(oldData.quantity))).map((_, index) => {
              var newUuid = oldData.properties._uuid.replace(`-${gwpKey}`, `-${btoa(Date.now() + '' + Math.random())}`);
              if (gwp_limit !== null && index >= gwp_limit) {
                newUuid = oldData.properties._uuid.replace(`-${gwpKey}`, '');
              }
              
              return {
                ...oldData.properties,
                _uuid: newUuid,
              };
            });
            
            const originalLineItemData = JSON.stringify({...oldData, quantity: 0});
            
            var data = await $.ajax({
              url: `${window.Shopify.routes.root}cart/change.js`,
              type: "POST",
              data: originalLineItemData,
              contentType: "application/json",
              dataType: 'json',
            });
            var allCartItemsBeforeDeletion = data.items;
            const variantId = data.items_removed?.[0]?.variant_id;
            if (!variantId) {
              console.error('GWP split: items_removed empty or missing — aborting individual-item split.', data);
              return;
            }
            var newItemsToAdd = newLineItemsDataProperties.map((properties) => {
              return {
                id: variantId,
                quantity: 1,
                properties,
              };
            });
            var data = await $.ajax({
              url: `${window.Shopify.routes.root}cart/add.js`,
              type: "POST",
              data: JSON.stringify({items: newItemsToAdd}),
              contentType: "application/json",
              dataType: 'json',
            });
            if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
              $CTOcartDrawer[0].updateCurrentItemsAll(data.items);
            }

            // AppleCare can get removed when we delete the parent product. This variable keeps track of them
            cartItemsRemovedAfterDeletion = allCartItemsBeforeDeletion.filter((item) => !data.items.find((newItem) => newItem.key === item.key));
          } else {
            var data = await $.ajax({
                url: `${window.Shopify.routes.root}cart/change.js`,
                type: "POST",
                data: data,
                contentType: "application/json",
                dataType: 'json',
            });

            mainProductItemsSplit = data?.items?.filter(item => {
              return item.properties && item.properties._uuid === uid;
            });
          }
            
          // check if main product split after change properties request (discount applied issue)
          if (mainProductItemsSplit.length > 1) {
            for (const [index, item] of mainProductItemsSplit.entries()) {
              // Iterate over new main products and re-add them with the new UUID
              // Skip the first item, no need to update UUID for it
              if (index === 0) {
                  continue;
              }
              const lineKeyToRemove = item.key;
              const variantId = item.id;
              const originalQuantity = item.quantity;
              const originalProperties = { ...item.properties };
              // Remove the current line item by setting its quantity to 0
              await $.ajax({
                  url: `${window.Shopify.routes.root}cart/change.js`,
                  type: "POST",
                  data: JSON.stringify({ id: lineKeyToRemove, quantity: 0 }),
                  contentType: "application/json",
                  dataType: 'json',
              });

              // Create the new UUID property for the item to re-add
              const newUuid = `${uid}-${index}`;
              const newProperties = { ...originalProperties, _uuid: newUuid };
              // Add the product back to the cart with the new UUID prop
              await $.ajax({
                  url: `${window.Shopify.routes.root}cart/add.js`,
                  type: "POST",
                  data: JSON.stringify({
                      items: [{
                          id: variantId,
                          quantity: originalQuantity,
                          properties: newProperties,
                      }]
                  }),
                  contentType: "application/json",
                  dataType: 'json',
              });
            }
            // Re-fetch the cart to get the correct item keys
            await $.ajax({
                url: `${window.Shopify.routes.root}cart.js`,
                type: 'GET',
                dataType: 'json',
            }).done(function(response) {
                data = response;
            }).fail(function(jqXHR) {
                console.error("Failed to re-fetch the cart. The cart-drawer state may be out of date.");
            });
          }

          if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
            var newCTOItem = data.items?.find((item) => item.properties?._cto_product);
            var newCTOItemKey = newCTOItem?.key;
            var newCTOItemUuid = newCTOItem?.properties?._uuid;
            $CTOcartDrawer[0].updateCtoItemKey(newCTOItemKey);
          }

          var checked = {};
          if (wp_key) {
            var data2;
            if (has_applcr_sku && !checked[has_applcr_sku]) {
              var newWpKey = data.items.find(item => item.properties?._aplcr_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid)?.key || wp_key;
              var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
              var newWpVariantId = data.items.find(item => item.key === newWpKey)?.variant_id;
              // Preserve `_customerAcceptTerms` if it was set on the existing
              // T&L line item — re-linking it to the new main-product uuid
              // would otherwise drop it.
              var existingAcceptTerms = data.items.find(item => item.key === newWpKey)?.properties?._customerAcceptTerms;
              var data2 = {
                line: newWpLine,
                quantity: main_product_quantity,
                properties: {
                  _aplcr_main_product_sku: main_product_sku,
                  _aplcr_main_product_handle: main_product_handle,
                  _uuid: uid,
                  ...(existingAcceptTerms === 'Y' && { _customerAcceptTerms: 'Y' }),
                },
              };
              data2 = JSON.stringify(data2);
              checked[has_applcr_sku] = true;
            } else if (has_sw_sku && !checked[has_sw_sku]) {
              var newWpKey = data.items.find(item => item.properties?._sw_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid)?.key || wp_key;
              var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
              var data2 = {
                line: newWpLine,
                quantity: main_product_quantity,
                properties: {
                  _sw_main_product_sku: main_product_sku,
                  _sw_main_product_handle: main_product_handle,
                  _uuid: uid,
                },
              };
              data2 = JSON.stringify(data2);
              checked[has_sw_sku] = true;
            }

            if (shouldSplitIntoIndividualItems) {
              if (!data2) {
                console.error('wp_key path: data2 unset (no AppleCare/SecWarranty branch matched) — skipping split.', { has_applcr_sku, has_sw_sku, checked });
              } else {
              var oldData = JSON.parse(data2);
              var newLineItemsDataProperties = Array.from(Array(parseInt(newItemsToAdd.length))).map((_, index) => {
                return {
                  ...oldData.properties,
                  _uuid: newItemsToAdd[index].properties._uuid,
                };
              });

              const originalLineItemData = JSON.stringify({...oldData, quantity: 0});
              var data = await $.ajax({
                url: `${window.Shopify.routes.root}cart/change.js`,
                type: "POST",
                data: originalLineItemData,
                contentType: "application/json",
                dataType: 'json',
              });

              const variantId = cartItemsRemovedAfterDeletion.find(item => item.properties?._aplcr_main_product_sku)?.variant_id;
              var newItemsToAdd = newLineItemsDataProperties.map((properties) => {
                return {
                  id: variantId,
                  quantity: 1,
                  properties,
                };
              });
              var data = await $.ajax({
                url: `${window.Shopify.routes.root}cart/add.js`,
                type: "POST",
                data: JSON.stringify({items: newItemsToAdd}),
                contentType: "application/json",
                dataType: 'json',
              });
              if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
                $CTOcartDrawer[0].updateCurrentItemsAll(data.items);
              }
              }
            } else if (data2) {
              var data = await $.ajax({
                url: `${window.Shopify.routes.root}cart/change.js`,
                type: "POST",
                data: data2,
                contentType: "application/json",
                dataType: 'json',
              });
            }
          }

          if (wp_key2) {
            var data2;
            if (has_applcr_sku && !checked[has_applcr_sku]) {
              var newWpKey = data.items.find(item => item.properties?._aplcr_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid)?.key || wp_key2;
              var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
              // Preserve `_customerAcceptTerms` if it was set on the existing
              // T&L line item — re-linking it to the new main-product uuid
              // would otherwise drop it.
              var existingAcceptTerms = data.items.find(item => item.key === newWpKey)?.properties?._customerAcceptTerms;
              var data2 = {
                line: newWpLine,
                quantity: main_product_quantity,
                properties: {
                  _aplcr_main_product_sku: main_product_sku,
                  _aplcr_main_product_handle: main_product_handle,
                  _uuid: uid,
                  ...(existingAcceptTerms === 'Y' && { _customerAcceptTerms: 'Y' }),
                },
              };
              data2 = JSON.stringify(data2);
              checked[has_applcr_sku] = true;
            } else if (has_sw_sku && !checked[has_sw_sku]) {
              var newWpKey = data.items.find(item => item.properties?._sw_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid)?.key || wp_key2;
              var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
              var data2 = {
                line: newWpLine,
                quantity: main_product_quantity,
                properties: {
                  _sw_main_product_sku: main_product_sku,
                  _sw_main_product_handle: main_product_handle,
                  _uuid: uid,
                },
              };
              data2 = JSON.stringify(data2);
              checked[has_sw_sku] = true;
            }

            if (shouldSplitIntoIndividualItems) {
              if (!data2) {
                console.error('wp_key2 path: data2 unset (no AppleCare/SecWarranty branch matched) — skipping split.', { has_applcr_sku, has_sw_sku, checked });
              } else {
              var oldData = JSON.parse(data2);
              var newLineItemsDataProperties = Array.from(Array(parseInt(newItemsToAdd.length))).map((_, index) => {
                return {
                  ...oldData.properties,
                  _uuid: newItemsToAdd[index].properties._uuid,
                };
              });

              const originalLineItemData = JSON.stringify({...oldData, quantity: 0});
              var data = await $.ajax({
                url: `${window.Shopify.routes.root}cart/change.js`,
                type: "POST",
                data: originalLineItemData,
                contentType: "application/json",
                dataType: 'json',
              });

              const variantId = cartItemsRemovedAfterDeletion.find(item => item.properties?._sw_main_product_sku)?.variant_id;
              var newItemsToAdd = newLineItemsDataProperties.map((properties) => {
                return {
                  id: variantId,
                  quantity: 1,
                  properties,
                };
              });
              var data = await $.ajax({
                url: `${window.Shopify.routes.root}cart/add.js`,
                type: "POST",
                data: JSON.stringify({items: newItemsToAdd}),
                contentType: "application/json",
                dataType: 'json',
              });
              }
            } else if (data2) {
              var data = await $.ajax({
                url: `${window.Shopify.routes.root}cart/change.js`,
                type: "POST",
                data: data2,
                contentType: "application/json",
                dataType: 'json',
              });
            }
          }

          if (wp_key_gwp) {
            if (has_gwp_sku && !checked[has_gwp_sku]) {
              var newWpItems = data.items.filter(item => item.properties?._gwp_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid);
              checked[has_gwp_sku] = true;

              for (const newWpItem of newWpItems) {
                var newWpKey = newWpItem?.key;
                var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
                var newWpQuantity = newWpItem?.quantity || 1;
                const skuProp = newWpItem?.properties?.SKU;
                const barcodeProp = newWpItem?.properties?.Barcode;
                var data2 = {
                  line: newWpLine,
                  quantity: newWpQuantity,
                  properties: {
                    _gwp_main_product_sku: main_product_sku,
                    _gwp_main_product_handle: main_product_handle,
                    _uuid: uid,
                    ...(skuProp && { SKU: skuProp }),
                    ...(barcodeProp && { Barcode: barcodeProp }),
                  },
                };
                data2 = JSON.stringify(data2);

                var data = await $.ajax({
                  url: `${window.Shopify.routes.root}cart/change.js`,
                  type: "POST",
                  data: data2,
                  contentType: "application/json",
                  dataType: 'json',
                });
              }
            }
          }

          var itemToAdd = {
            id: product_id,
            quantity: additional_flag == "gwp"
              ? (override_quantity || 1) * main_product_quantity
              : (override_quantity || main_product_quantity),
            properties: {
              _uuid: uid,
              ...(main_product_token && { _item_token: main_product_token }),
            },
          };

          if (gwp_limit !== null) {
            itemToAdd.quantity = Math.min(itemToAdd.quantity, gwp_limit);
          }

          if (additional_flag == "secwr") {
            itemToAdd.properties._sw_main_product_sku = main_product_sku;
            itemToAdd.properties._sw_main_product_handle = main_product_handle;
          } else if (additional_flag == "aplcr") {
            itemToAdd.properties._aplcr_main_product_sku = main_product_sku;
            itemToAdd.properties._aplcr_main_product_handle = main_product_handle;
            if (target_customer_accept_terms) {
              itemToAdd.properties._customerAcceptTerms = 'Y';
            }
          } else if (additional_flag == "gwp") {
            itemToAdd.properties._gwp_main_product_sku = main_product_sku;
            itemToAdd.properties._gwp_main_product_handle = main_product_handle;

            if (aplCr_sku) {
              itemToAdd.properties.SKU = aplCr_sku;
            }

            if (aplCr_barcode) {
              itemToAdd.properties.Barcode = aplCr_barcode;
            }
          }

          let addOnUnitsAdded = itemToAdd.quantity;
          if (shouldSplitIntoIndividualItems) {
            var newGwpLineItemProperties = Array.from(Array(parseInt(itemToAdd.quantity))).map((_, index) => {
              return {
                ...itemToAdd.properties,
                _uuid: newItemsToAdd[index].properties._uuid,
              };
            });

            var newGwpItemsToAdd = newGwpLineItemProperties.map((properties) => {
              return {
                id: product_id,
                quantity: itemToAdd.quantity / newGwpLineItemProperties.length,
                properties,
              };
            });

            var resp = await fetch(`${window.Shopify.routes.root}cart/add.js`, {
              method: "post",
              headers: {
                'content-type': 'application/json'
              },
              body: JSON.stringify({
                items: newGwpItemsToAdd,
              }),
            });
          } else if (mainProductItemsSplit.length > 1) {
              let gwp_split_remaining = gwp_limit;
              const splitItemsToAdd = mainProductItemsSplit.map((mainItem, index) => {
              const current_main_product_quantity = mainItem.quantity;
              const newItem = JSON.parse(JSON.stringify(itemToAdd)); // Deep copy to avoid reference issues
              // Skip the first item,and update UUID for the rest items
              if (index > 0) {
                  newItem.properties._uuid = `${uid}-${index}`;
              }

              // Adjust quantity for this specific line item
              newItem.quantity = additional_flag == "gwp"
                ? (override_quantity || 1) * current_main_product_quantity
                : (override_quantity || current_main_product_quantity);

              if (gwp_split_remaining !== null) {
                  newItem.quantity = Math.min(newItem.quantity, gwp_split_remaining);
                  gwp_split_remaining -= newItem.quantity;
              }

              return newItem;
            }).filter(item => item.quantity > 0);
            addOnUnitsAdded = splitItemsToAdd.reduce((sum, item) => sum + item.quantity, 0);

            var resp = await fetch(`${window.Shopify.routes.root}cart/add.js`, {
              method: "post",
              headers: {
                'content-type': 'application/json'
              },
              body: JSON.stringify({
                items: splitItemsToAdd,
              }),
            });
          } else {
            var resp = await fetch(`${window.Shopify.routes.root}cart/add.js`, {
              method: "post",
              headers: {
                'content-type': 'application/json'
              },
              body: JSON.stringify({
                items: [itemToAdd],
              }),
            });
          }

          if (gwp_limit !== null) {
            gwp_remaining -= addOnUnitsAdded;
          }

          if (aplcr_btns_to_proceed.length > 1) {
            // Re-fetch the cart to get the correct item keys
            await $.ajax({
                url: `${window.Shopify.routes.root}cart.js`,
                type: 'GET',
                dataType: 'json',
            }).done(function(response) {
                latestKeysCartData = response;
            }).fail(function(jqXHR) {
                console.error("Failed to re-fetch the cart. The cart-drawer state may be out of date.");
            });
          }
        }
        if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
          var d = await resp.json();
          // when a gwp adds a discount to the CTO product, the item key for the CTO product may change
          if (d.items?.some((item) => item.discounts?.length)) {
            var cartData = await fetch(`${window.Shopify.routes.root}cart.js`).then((res) => res.json());
            var newCTOItem = cartData.items.find((item) => item.properties?._cto_product && item.properties?._uuid === newCTOItemUuid);
            var newCTOItemKey = newCTOItem?.key;
            $CTOcartDrawer[0].updateCtoItemKey(newCTOItemKey);
          }
          // small delay to ensure CTO cart refresh does not have a race condition with main cart refresh
          window.setTimeout(function(){$CTOcartDrawer[0].updateItems(d.items);},100);
        }

        if (window.toggleAddOnButtons) window.toggleAddOnButtons('enable');
        window.onCartUpdate();
    }
    /*Add Applecare on cart page functionality  ends here - added by Hema*/

    /*
    	Add Trade-In on cart page
    */
    $(document).on('click', '.add-cart-trade-in', function(e) {
      e.preventDefault();
      
      $(this).prop('disabled', true);

      if (window.toggleAddOnButtons) window.toggleAddOnButtons('disable');
      const add_button = $(this);
      const tradeInValue = add_button.data('tradeInValue');
      const tradeInDevice = add_button.data('tradeInDevice');
      const main_product_id = add_button.data('parentId');
      const main_product_index = add_button.data('forproduct');
      const main_product_parent = $(`#${main_product_id}`);
      const main_product_quantity = main_product_parent.find('.quantity__input').val();
      const main_product_sku = add_button.data('skuparent');
      const main_product_barcode = add_button.data('barcodeparent');
      const main_product_handle = add_button.data('handleparent');
      const main_product_preorder = add_button.data('preorderparent');
      const main_product_preorder_message = add_button.data('preordermessageparent');
      const main_product_trade_in = add_button.data('tradeinparent');
      const main_product_key = add_button.data('keyparent');
      const main_mpn_value = add_button.data('mpnparent');
      const additional_flag = add_button.data('reference')
      const main_product_tags = main_product_parent.find('.cart_tax_tags').val();

      let properties = $(this).data('itemProperties');

      if (main_product_preorder) properties._preOrder = 'true';
      if (main_product_preorder_message) properties._preOrderMessage = main_product_preorder_message;
      if (tradeInDevice) properties._tradeInEligible = 'true';
      if (tradeInValue) properties._tradeIn_value = tradeInValue.toString().replace('.', '');
      if (tradeInDevice) properties._tradeIn_device = tradeInDevice;

      if (tradeInDevice && properties._uuid && !properties._uuid.includes('tradein')) {
        properties._uuid = properties._uuid + '-tradein';
      }

      // *** UNCOMMENT AFTER QUANTITY SELECTOR IS ADDED *** //
      // const data_tradeIn = `{
      //   "line": ${main_product_index},
      //   "quantity": ${main_product_quantity,
      //   "properties": ${JSON.stringify(properties)}
      // }`;

      // *** TEMPORARY *** //
      // Remove after quantity selector is added
      const data_tradeIn = `{
        "line": ${main_product_index},
        "quantity": ${main_product_quantity || 1},
        "properties": ${JSON.stringify(properties)}
      }`;

      $.ajax({
        url: `${window.Shopify.routes.root}cart/change.js`,
        type: "POST",
        data: data_tradeIn,
        contentType: "application/json",
        dataType: 'json',
        success: function(data) {
          const oldUuid = properties?._uuid?.split('-tradein')[0];
          const newUuid = properties?._uuid;

          if (!oldUuid || !newUuid || oldUuid === newUuid) return;

          const appleCareProductsThatNeedUpdating = data.items.find(item => item.properties?._aplcr_main_product_sku && item.properties?._uuid === oldUuid);
          const secWarrantyProductsThatNeedUpdating = data.items.find(item => item.properties?._sw_main_product_sku && item.properties?._uuid === oldUuid);
          const gwpProductsThatNeedUpdatingArr = data.items.filter(item => item.properties?._gwp_main_product_sku && item.properties?._uuid === oldUuid);

          async function updateAcSecProducts() {
            if (appleCareProductsThatNeedUpdating) {
              const newProperties = { ...appleCareProductsThatNeedUpdating.properties, _uuid: newUuid };
              const line = data.items.findIndex(item => item.key === appleCareProductsThatNeedUpdating.key) + 1;
              const newData = {
                line,
                quantity: appleCareProductsThatNeedUpdating.quantity,
                properties: newProperties,
              };
              await fetch(`${window.Shopify.routes.root}cart/change.js`, {
                method: "POST",
                headers: {
                  'content-type': 'application/json'
                },
                body: JSON.stringify(newData),
              });
            }

            if (secWarrantyProductsThatNeedUpdating) {
              const newProperties = { ...secWarrantyProductsThatNeedUpdating.properties, _uuid: newUuid };
              const line = data.items.findIndex(item => item.key === secWarrantyProductsThatNeedUpdating.key) + 1;
              const newData = {
                line,
                quantity: secWarrantyProductsThatNeedUpdating.quantity,
                properties: newProperties,
              };
              await fetch(`${window.Shopify.routes.root}cart/change.js`, {
                method: "POST",
                headers: {
                  'content-type': 'application/json'
                },
                body: JSON.stringify(newData),
              });
            }

            if (gwpProductsThatNeedUpdatingArr.length) {
              for (const gwpProductsThatNeedUpdating of gwpProductsThatNeedUpdatingArr) {
                const newProperties = { ...gwpProductsThatNeedUpdating.properties, _uuid: newUuid };
                const line = data.items.findIndex(item => item.key === gwpProductsThatNeedUpdating.key) + 1;
                const newData = {
                  line,
                  quantity: gwpProductsThatNeedUpdating.quantity,
                  properties: newProperties,
                };
                await fetch(`${window.Shopify.routes.root}cart/change.js`, {
                  method: "POST",
                  headers: {
                    'content-type': 'application/json'
                  },
                  body: JSON.stringify(newData),
                });
              }
            }

            location.reload();
          }

          updateAcSecProducts();
        },
        error: function(xhr, status, error) {
          console.error(`Error: ${xhr.responseText}`);
        }
      });
    });

    /* sticky atc on pdp functionality  starts here - added by Hema*/
    $(document).on('click', '#footer-atc', function(evt) {

        evt.preventDefault();
        /* Order Product Limits - Karthikeyan */
        var prodVariantID = $("#main-product-variant").val();
        var prodQuant = $("#prodQuantity").val();
        var total_qty = $("#total_qty_" + prodVariantID).val();
        /* VAT Product Limits - Karthikeyan */
        const isValidQty = checkQty();

        if (!isValidQty) {
            return false;
        }
        if (vat_free_day == true) {
            var taxtags = $("#tax_tags").val();
            var prodQuant = $("#prodQuantity").val();
            var addtaxfree = taxtags.indexOf('taxfree') != -1;
            if (getCookie('total_quantity') == "") {
                var tax_total_quantity = parseInt(prodQuant);
            } else {
                var tax_total_quantity = parseInt(prodQuant) + parseInt(getCookie('total_quantity'));
            }

            if (addtaxfree == true) {
                if (tax_total_quantity > +vat_free_quantity) {
                    alert(vat_free_message);
                    return false;
                } else {
                    addToCart("cart");
                }
            } else {
                addToCart("cart");
            }
        } else {
            addToCart("cart");
        }
        return false;
    });


    $(document).on('click', '.js-checkout-button,.js-checkout-link', function(evt) {
      evt.preventDefault();
      
      //   var tttype = $(".shopify-payment-button__button").attr("type");
      var prodVariantID = $("#main-product-variant").val();
      var mpn_handle = $("#mpn_handle_" + prodVariantID).val();
      const isValidQty = checkQty();

      if (!isValidQty) {
        return false;
      }
      if (vat_free_day == true) {
        var taxtags = $("#tax_tags").val();
        var prodQuant = $("#prodQuantity").val();
        var addtaxfree = taxtags.indexOf('taxfree') != -1;

        if (getCookie('total_quantity') == "") {
          var tax_total_quantity = parseInt(prodQuant);
        } else {
          var tax_total_quantity = parseInt(prodQuant) + parseInt(getCookie('total_quantity'));
        }

        if (addtaxfree == true) {
          if (tax_total_quantity > +vat_free_quantity) {
            alert(vat_free_message);
            return false;
          }
        }
      }
      if ($(".pdp_product_list").attr("value").indexOf("PLP ::") >= 0) {
        var proliststring = $(".pdp_product_list").attr("value");
      } else {
        var proliststring = formatString($(".pdp_product_list").attr("value"));
      }
      var productList = proliststring;
      // cartCookie(mpn_handle, prodVariantID, productList);

      $('.js-checkout-button,.js-checkout-link').attr('disabled', true);
      addToCart("buy");
    });

    /* sticky atc on pdp functionality  ends here - added by Hema*/




    function addToCart(check_buy) {
      var $cartDrawer = document.querySelector('cart-drawer') || null;
      var $CTOcartDrawer = $('cto-cart-drawer');
      var event = window.event;
      var isCTO = event?.target?.dataset.ctoProduct === 'true'
        || event?.target?.closest('.js-checkout-button,.js-checkout-link')?.dataset.ctoProduct === 'true'
        || false;
      var taxtags = $("#tax_tags").val();
      var btn = $(this).find(".BUY_NOW_CLICKED");
      var buy_now_checker = btn.data('submit');
      /* Applecare PDP  starts here - added by Hema*/
      var isCheckedTheftLoss = $('#add-theftloss').is(':checked');
      var isChecked = $('#add-apple-care').is(':checked') || isCheckedTheftLoss;
      var isChecked2 = $('#add-secWarranty').is(':checked');
      var hasGwp = $('.js-gwp-data').length > 0;
      var gwpMaximum = $('.js-gwp-data').data('gwp-maximum');
      let gwpMaximumAvailable = $('.js-gwp-data').data('gwp-maximum-available');
      var hasTradeIn = $('#selected-trade-in-value').val() !== undefined && $('#selected-trade-in-value').val() !== '0' && $("#selected-trade-in-device").val() !== '';
      const tradeInValue = $("#selected-trade-in-value").val() || ''; // Get Trade-In value
      const parsedTradeInValue = hasTradeIn ? parseInt(tradeInValue).toFixed(2).replace('.', '') : null; // Set parsed Trade-In value
      const tradeInDevice = $("#selected-trade-in-device").val() || ''; // Get Trade-In value
      var prodVariantID = $('#main-product-variant').val();
      var mpn_handle = $("#mpn_handle_" + prodVariantID).val();
      var productcomPrice = $("#compr_price_" + prodVariantID).val();
      var uuid = Math.random().toString(36).slice(2);

      const disablePdpButton = (disable) => {
        if (check_buy === 'cart') {
          $('#footer-atc').attr('disabled', disable);
        }
      }

      const adobeTrack = (items) => {
        try {
          adobeTrackAddToCart({
            items,
            context: check_buy === 'cart' ? 'PDP Add to Cart' : 'Check out with Apple Pay',
            $trigger: check_buy === 'cart' ? $('#footer-atc')[0] : null,
            triggerText: check_buy !== 'cart' ? 'Check out with Apple Pay' : null,
            triggerUrl: check_buy !== 'cart' ? `${window.location.origin}${window.Shopify.routes.root}checkout` : null,
            paymentMethod: check_buy !== 'cart' ? 'pdp_apple_pay' : null,
          });
        } catch (e) {
          console.error('PDP Adobe add-to-cart tracking failed:', e);
        }
      }

      disablePdpButton(true);

      var applecareID = isCheckedTheftLoss ? $("#theftloss-care-varid").val() : $("#apple-care-varid").val(); //Getting apple care id
      var applecaresku = isCheckedTheftLoss ? $("#theftloss-product-sku").val() : $("#applecare-product-sku").val(); //Getting apple care sku
      var applecarehandle = isCheckedTheftLoss ? $("#theftloss-product-handle").val() : $("#applecare-product-handle").val(); //Getting apple care handle
      var secWarrantyID = $("#secWarranty-varid").val(); //Getting secWarranty id
      var secWarrantysku = $("#secWarranty-product-sku").val(); //Getting secWarranty sku
      var secWarrantyhandle = $("#secWarranty-product-handle").val(); //Getting secWarranty handle
      var gwpData = $('.js-gwp-data'); //Getting gwp data
      var main_product_sku = $("#main-pro-sku").val(); //Getting MAIN PRODUCT SKU
      var main_product_handle = $("#main-pro-handle").val(); //Getting main product handle
      var main_product_preorder = $("#main-pro-preorder").val(); //Getting main product preorder value
      var main_product_preorder_message = $("#main-pro-preorder-message").val(); //Getting main product preorder message value
      var main_product_trade_in = $("#main-pro-trade-in").val(); //Getting main product trade-in value
      var prodVariantID = $('#main-product-variant').val(); //Getting main product id
      var prodQuant = $("#prodQuantity").val(); //Getting main product QUANTITY
      var uid = main_product_handle;
      var gwpKey = btoa(Date.now() + '' + Math.random());
      const main_product_barcode = $("#main-pro-barcode").val() || $("#main-pro-barcode").text();
      const itemToken = btoa(Date.now() + '' + Math.random()); //Keep identical line items separate after child product removal

      // Replace variant ID with Bundle variant ID if a Bundle product is selected
      const $selectedBundleOption = $('input[name="bundle_option"]:checked');
      const $selectedBundleOptionChild1 = $selectedBundleOption.attr('data-bundle-child-item-id-1');
      const $selectedBundleOptionChild2 = $selectedBundleOption.attr('data-bundle-child-item-id-2');
      const $selectedBundleOptionChild3 = $selectedBundleOption.attr('data-bundle-child-item-id-3');
      const $selectedBundleOptionPrice =  $selectedBundleOption.attr('data-bundle-price');
      const $selectedBundleOptionName =  $selectedBundleOption.attr('data-bundle-name');
      const $selectedBundleOptionHandle =  $selectedBundleOption.attr('data-handle');
      const $selectedBundleOptionSku =  $selectedBundleOption.attr('data-bundle-sku');
      const $selectedBundleOptionBarcode = $selectedBundleOption.attr('data-bundle-barcode');
      const $selectedBundleOptionProductId =  $selectedBundleOption.attr('data-product-id');
      const $selectedBundleOptionChild1Price = $selectedBundleOption.attr('data-bundle-item-1-price');
      const $selectedBundleOptionChild2Price = $selectedBundleOption.attr('data-bundle-item-2-price');
      const $selectedBundleOptionChild3Price = $selectedBundleOption.attr('data-bundle-item-3-price');
      const isBundleValidForDiscount = $selectedBundleOptionChild1 && $selectedBundleOptionChild2;
      const quantityLabel = document.querySelector('.product-form__quantity .quantity__rules-cart');
      const quantityLabelNumber = quantityLabel?.querySelector('.quantity-cart');

      const updateQuantityLabel = (items) => {
        items.forEach(item => {
          const { handle, properties, quantity } = item;
          const bundleHandle = properties?._bundle_handle;

          if (bundleHandle) {
            const bundleTargetItem = document.querySelector(`#bundleForm .js-cto-bundle-option[data-handle="${bundleHandle}"]`);
            
            if (bundleTargetItem) {
              bundleTargetItem.dataset.bundlesQtyAlreadyInCart = (Number(bundleTargetItem.dataset.bundlesQtyAlreadyInCart ?? 0) + quantity);
              document.dispatchEvent(new CustomEvent('bundle:optionQtyInCartUpdated'));
            }
          } else if (handle !== main_product_handle) {
            const bundleOptionByHandle = document.querySelector(`#bundleForm .js-cto-bundle-option[data-handle="${handle}"]`);

            if (bundleOptionByHandle) {
              bundleOptionByHandle.dataset.bundlesQtyAlreadyInCart = (Number(bundleOptionByHandle.dataset.bundlesQtyAlreadyInCart ?? 0) + quantity);
              document.dispatchEvent(new CustomEvent('bundle:optionQtyInCartUpdated'));
            }
          } else {
            if (!quantityLabelNumber) return;
            const ctoProductTargetQty = Number(quantityLabelNumber.dataset.qtyInCartDefault ?? 0) + quantity;

            quantityLabelNumber.dataset.qtyInCartDefault = ctoProductTargetQty;
            if (ctoProductTargetQty > 0) {
              quantityLabel.classList.remove('hidden');
              quantityLabelNumber.innerHTML = ctoProductTargetQty;
            }
          }
        });
      }

      if ($selectedBundleOption.attr('data-bundle-variant-id')) {
        prodVariantID = isBundleValidForDiscount ? $selectedBundleOptionChild1 : $selectedBundleOption.attr('data-bundle-variant-id');
      }

      if (isChecked == true) {
        uid = uid + '-' + uuid + '-' + applecarehandle;
      }
      if (isChecked2 == true) {
        uid = uid + '-' + uuid + '-' + secWarrantyhandle;
      }
      if (hasGwp) {
        uid = uid + '-' + gwpKey;
      }
      if (tradeInDevice && !uid.includes('tradein')) {
        uid = uid + '-tradein';
      }

      const props = {
        _uuid: uid,
        ...(main_product_preorder === 'true' && { _preOrder: 'true' }),
        ...(main_product_preorder_message && { _preOrderMessage: main_product_preorder_message }),
        ...(main_product_trade_in === 'true' && { _tradeInEligible: 'true' }),
        _item_token: itemToken,
      };

      if (isChecked == true) {
        props._applecare_sku = applecaresku;
        props._applecare_handle = applecarehandle;
      }

      if (isChecked2 == true) {
        props._secWarranty_sku = secWarrantysku;
        props._secWarranty_handle = secWarrantyhandle;
      }

      if (isCTO) {
        props._cto_product = 'true';
      } else {
        props._added_from_pdp = 'true';
      }

      if (main_product_sku) {
        props.SKU = main_product_sku;
      }

      if (main_product_barcode) {
        props.Barcode = main_product_barcode;
      }

      if (hasGwp) {
        var gwpSkus = [];
        var gwpHandles = [];
        gwpData.each(function() {
          gwpSkus.push($(this).data('gwp-product-sku'));
          gwpHandles.push($(this).data('gwp-product-handle'));
        });
        props._gwp_sku = gwpSkus.join(',');
        props._gwp_handle = gwpHandles.join('-');
      }

      if (hasTradeIn === true) {
        props._tradeIn_value = parsedTradeInValue;
        props._tradeIn_device = tradeInDevice;
        props._tradeInEligible = 'true';
      }

      if (isBundleValidForDiscount) {
        props._bundle_uuid = uuid + '-bundle';
        props._bundle_title = $selectedBundleOptionName;
        props._bundle_handle = $selectedBundleOptionHandle;
        props._bundle_product_id = $selectedBundleOptionProductId;
        props._bundle_price = $selectedBundleOptionPrice;
        props._bundle_item_1_id = $selectedBundleOptionChild1;
        props._bundle_item_2_id = $selectedBundleOptionChild2;
        props._bundle_item_3_id = $selectedBundleOptionChild3;
        props._bundle_item_1_price = $selectedBundleOptionChild1Price;
        props._bundle_item_2_price = $selectedBundleOptionChild2Price;
        props._bundle_item_3_price = $selectedBundleOptionChild3Price;

        if ($selectedBundleOptionSku) {
          props.SKU = $selectedBundleOptionSku;
          props.Barcode = $selectedBundleOptionBarcode || "";
        }
      }

      var items = [
        {
          id: prodVariantID,
          quantity: prodQuant,
          properties: props
        }
      ];

      if (isChecked == true) {
        var appleCareItemProps = {
          _aplcr_main_product_sku: main_product_sku,
          _aplcr_main_product_handle: main_product_handle,
          _uuid: uid
        };
        // When T&L was added via the Active Acceptance popup, the checkbox has
        // data-customer-accept-terms="Y" — propagate to the T&L line item.
        if (isCheckedTheftLoss && $('#add-theftloss').attr('data-customer-accept-terms') === 'Y') {
          appleCareItemProps._customerAcceptTerms = 'Y';
        }
        items.push({
          id: applecareID,
          quantity: prodQuant,
          properties: appleCareItemProps
        });
      }

      if (isChecked2 == true) {
        items.push({
          id: secWarrantyID,
          quantity: prodQuant,
          properties: {
            _sw_main_product_sku: main_product_sku,
            _sw_main_product_handle: main_product_handle,
            _uuid: uid
          }
        });
      }

      if (hasGwp) {
        if (gwpMaximum && gwpMaximum > 1 && gwpMaximumAvailable < parseInt(prodQuant)) {
          alert(gwp_quantity_limit_error_message.replace('{limit}', gwpMaximum));
        }

        if (gwpMaximum && gwpMaximumAvailable) {
          gwpMaximum = gwpMaximumAvailable;
        }
        gwpData.each(function() {
          const gwpSku = $(this).data('gwp-product-sku');
          const gwpBarcode = $(this).data('gwp-product-barcode');
          const gwpItemId = $(this).data('gwp-id');
          const gwpItemQty = Math.min($(this).data('gwp-quantity') * prodQuant, gwpMaximum || 0);

          gwpMaximumAvailable = gwpMaximumAvailable - gwpItemQty;
          $(this).data('gwp-maximum-available', gwpMaximumAvailable);
          items.push({
            id: gwpItemId,
            quantity: gwpItemQty,
            properties: {
              _gwp_main_product_sku: main_product_sku,
              _gwp_main_product_handle: main_product_handle,
              _uuid: uid,
              ...(gwpSku && { SKU: gwpSku }),
              ...(gwpBarcode && { Barcode: gwpBarcode }),
            }
          });
        });
      }

      const adobeItems = [
        {
          id: secWarrantyID,
          quantity: prodQuant,
        },
        {
          id: applecareID,
          quantity: prodQuant,
        },
        {
          id: prodVariantID,
          quantity: prodQuant,
        }
      ];

      const shouldSplitIntoIndividualItems = parseInt(prodQuant) > 1 && hasGwp;
      const newItemsToAdd = [];
      if (shouldSplitIntoIndividualItems) {
        const newUuids = Array.from(Array(parseInt(prodQuant))).map(() => {
          return uid.replace(`-${gwpKey}`, `-${btoa(Date.now() + '' + Math.random())}`);
        });

        items.forEach((item) => {
          Array.from(Array(parseInt(item.quantity))).forEach((_, index) => {
            let newUuid = newUuids[index];
            if (gwpMaximum && index >= gwpMaximum) {
              newUuid = uid.replace(`-${gwpKey}`, '');
            }
            newItemsToAdd.push({
              id: item.id,
              quantity: 1,
              properties: {
                ...item.properties,
                _uuid: newUuid,
              },
            });
          });
        });
      }

      fetch(`${window.Shopify.routes.root}cart/add.js`, {
        method: "post",
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(shouldSplitIntoIndividualItems ? {items: newItemsToAdd} : {items}),
      })
        .then(response => {
          return response.json().then(d => {
            // error message for B2B quantity rules
            if (d.status === 422 && d.message) {
              setB2BErrors(d.message);
              return;
            } else {
              resetErrors();
            }
            if ($(".pdp_product_list").attr("value").indexOf('PLP ::') >= 0) {
              var proliststring = $(".pdp_product_list").attr("value");
            } else {
              var proliststring = formatString($(".pdp_product_list").attr("value"));
            }
            var productList = proliststring;

            if (!gwpMaximumAvailable || gwpMaximumAvailable < 1) {
              removeGwpData(gwpData);
            }

            if (isChecked == true || isChecked2 == true || hasTradeIn === true) {
              if (isChecked == true && isChecked2 == true) {
                if (d?.items?.length > 2) {
                  cartCookie(mpn_handle, d.items[2].key, productList);
                }
              } else if (isChecked == false && isChecked2 == true) {
                if (d?.items?.length > 1) {
                  cartCookie(mpn_handle, d.items[1].key, productList);
                }
              } else if (isChecked == true && isChecked2 == false) {
                if (d?.items?.length > 1) {
                  cartCookie(mpn_handle, d.items[1].key, productList);
                }
              } else if (hasTradeIn === true) {
                if (d?.items?.length) {
                  cartCookie(mpn_handle, d.items[0].key, productList);
                }
              }
            } else {
              if (d?.items?.length) {
                cartCookie(mpn_handle, d.items[0].key, productList);
              }
            }

            triggerGAAddToCart(productcomPrice, mpn_handle, productTitle, productCategory, productList, productCurrency, productPrice, prodQuant, main_product_sku, prodVariantID);
            if ($cartDrawer) {
              $cartDrawer.updateItems();
            }
            if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden') && check_buy !== 'buy') {
              $CTOcartDrawer[0].updateItems(d.items);
            }

            adobeTrack(adobeItems);

            if (check_buy == "buy") {
              $.get(`${window.Shopify.routes.root}cart?view=minicart`, function(itemData) {
                var item_count = jQuery(itemData).find('#cart-notification-button .count').text();
                if ($('.cart-count-bubble').length > 0) {
                  $('.cart-count-bubble span').text(item_count);
                } else {
                  $('#cart-icon-bubble').append('<div class="cart-count-bubble"><span></span></div>');
                  $('.cart-count-bubble span').text(item_count);
                }
                $("#cart-notification").text("");
                var textreplace = "<div id='min-cart-replace'></div>";
                $("#cart-notification").append(textreplace);
                $("#cart-notification").replaceWith(itemData);
                if (!$CTOcartDrawer.length || $CTOcartDrawer.hasClass('hidden')) {
                  $('#cart-notification').addClass('minicart-active');
                }
                $("#cart-notification").css("visibility", "hidden");
                $(".cart-count-bubble").css("visibility", "hidden");
                window.location.href = `${window.Shopify.routes.root}checkout`;
              });
            } else {
              $.get(`${window.Shopify.routes.root}cart?view=minicart`, function(itemData) {
                var item_count = jQuery(itemData).find('#cart-notification-button .count').text();
                if ($('.cart-count-bubble').length > 0) {
                  $('.cart-count-bubble span').text(item_count);
                } else {
                  $('#cart-icon-bubble').append('<div class="cart-count-bubble"><span></span></div>');
                  $('.cart-count-bubble span').text(item_count);
                }
                $("#cart-notification").text("");
                var textreplace = "<div id='min-cart-replace'></div>";
                $("#cart-notification").append(textreplace);
                $("#cart-notification").replaceWith(itemData);
                if (!$CTOcartDrawer.length || $CTOcartDrawer.hasClass('hidden')) {
                  $('#cart-notification').addClass('minicart-active');
                }
              });
              var main_product_sku = $("#main-pro-sku").val();
              var productCategory = $(".pdp_product_category").attr("value");
              var productCurrency = $(".pdp_product_currency").attr("value");
              var productPrice = $("#prod_price_" + prodVariantID).val();
              var productTitle = $(".pdp_product_title").attr("value");
              var prodQuant = $("#prodQuantity").val();
            }

            updateQuantityLabel(d.items);
          })
        })
        .catch((error) => {
          console.error('Error:', error);
          return false;
        })
        .finally(() => {
          disablePdpButton(false);
        });
    }

    function removeGwpData(gwpData) {
      const metaobjectIds = [];
      gwpData.each(function() {
        metaobjectIds.push($(this).data('gwp-metaobject-id'));
      });

      metaobjectIds.forEach((id) => {
        $(`.js-gwp-data[data-gwp-metaobject-id="${id}"], .js-slider-form-gwp-data[data-gwp-metaobject-id="${id}"]`).remove();
      });
    }

    function cartCookie(mpn_handle, prodVariantID, productList) {
        var prevPage = document.referrer;
        var search_value = '';
        var first_search = '';
        if (prevPage.includes("search")) {
            first_search = localStorage.getItem("search_value");
            search_value = localStorage.getItem("search_value_term");
            if (first_search == null) {
                localStorage.setItem("search_value", search_value);
                var first_search_str = localStorage.getItem("search_value");
                first_search = formatString(first_search_str);
            }
        }
        var exphone = [];
        var item_cart = {}
        item_cart["cart_item_id"] = prodVariantID;
        item_cart["cart_item_list_name"] = productList;
        item_cart["cart_item_mpn"] = mpn_handle;
        item_cart["cart_search_term"] = first_search;
        try {
          var parsedExphone = JSON.parse(localStorage.getItem("cart"));
          if (parsedExphone != null) exphone = parsedExphone;
        } catch (e) {
          exphone = [];
        }
        exphone.push(item_cart);
        localStorage.setItem("cart", JSON.stringify(exphone));
        // console.log(JSON.parse(localStorage.getItem("cart")));
    }

    function triggerGAAddToCart(productcomPrice, mpn, productTitle, productCategory, productList, productCurrency, productPrice, prodQuant, main_product_sku, prod_variantID) {
        var prevPage = document.referrer;
        var search_value = '';
        if (prevPage.includes("search")) {
            var first_search = localStorage.getItem("search_value");
            search_value = localStorage.getItem("search_value_term");
            if (first_search == null) {
                localStorage.setItem("search_value", search_value);
                var first_search_str = localStorage.getItem("search_value");
                first_search = formatString(first_search_str);
            }
        }
        dataLayer.push({
            'ecommerce': null
        });
        productPrice = Number(productPrice?.replace(/[^0-9.-]+/g, ""));
        var value_price = productPrice * parseInt(prodQuant);
        var discount = 0;
        var value_price1 = parseFloat(value_price);
        var productPrice1 = parseFloat(productPrice);
        dataLayer.push({
            'event': 'add_to_cart',
            'search_term': search_value,
            'currency': productCurrency,
            'value': value_price1,
            'ecommerce': {
                'items': [{
                    'item_id': mpn,
                    'item_name': productTitle,
                    'item_category': productCategory,
                    'item_list_name': productList,
                    'price': productPrice1,
                    'quantity': parseInt(prodQuant)
                }]
            }
        });
    }


    function formatString(str) {
      if (!str) return '';
        return str
            .replace(/(\B)[^ ]*/g, match => (match.toLowerCase()))
            .replace(/^[^ ]/g, match => (match.toUpperCase()));
    }

    /* Minicart starts here - added by Hema*/
    function miniCart() {
        $.get(`${window.Shopify.routes.root}cart?view=minicart`, function(itemData) {
            $('cart-notification').replaceWith(itemData);
            $('#cart-notification').addClass('minicart-active');
            $.ajax({
                type: 'GET',
                dataType: 'json',
                url: `${window.Shopify.routes.root}cart.js`,
                success: function(cart) {
                    let total = cart.item_count;
                    $('.cart-count-bubble').text(total);
                }
            });

        });
    }

    if ($productGrid) {
      // Disconnect any prior observer before creating a new one so re-initialisation
      // (jQuery .ready re-fires, AJAX section reloads, etc.) doesn't leak observers.
      if (window.__productGridObserver) {
        try { window.__productGridObserver.disconnect(); } catch (e) {}
      }
      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation?.type === 'childList') {
            // reinit quick add buttons
            quickAddEvents();
          }
        });
      });
      observer.observe($productGrid, { childList: true });
      window.__productGridObserver = observer;
    }

    $("#prodQuantity").on("change", function() {
      debounce(checkQty, 500)();
    });

    function checkQty() {
      var productId = $("#product_id").val();
      var productQty = $("#prodQuantity").val();
      var prodMaxQty = $("#product_max_quantity").val();
      var prodInventoryQuantity = $("#productInventoryQuantity").val();
      var $errorMessage = document.querySelector('.js-qty-error') || null;
      var $pickUpAvailability = document.querySelectorAll('pickup-availability') || null;
      var $storeLocator = document.querySelector('my-store-locator') || null;

      // Update the product if a Bundle product is selected
      const $selectedBundleOption = $('input[name="bundle_option"]:checked');
      if ($selectedBundleOption.length && $selectedBundleOption.attr('id') !== 'bundleOptionNo') {
        productId = $selectedBundleOption.attr('data-product-id') || productId;
        prodInventoryQuantity = $selectedBundleOption.attr('data-qty-limit') || prodInventoryQuantity;
        prodMaxQty = $selectedBundleOption.attr('data-max') || prodMaxQty;
      }

      // B2B quantity-rule limit (variant.quantity_rule.max). Shopify's server-side quantity_rule
      // check and /cart.js do not aggregate units that live inside a bundle, so a shopper can
      // otherwise add up to the max standalone on top of what is already in a bundle. Aggregate via
      // checkMaxquantity rather than the input's data-cart-quantity: that attribute is bundle-aware
      // but render-time only, so it goes stale after any AJAX add on this page. Enforce the limit
      // for the standalone product (no bundle option selected) and surface the B2B error message.
      const isBundleSelected = $selectedBundleOption.length && $selectedBundleOption.attr('id') !== 'bundleOptionNo';
      const $prodQuantityInput = document.querySelector('#prodQuantity');
      if (!isBundleSelected && $prodQuantityInput && $prodQuantityInput.dataset.max) {
        const b2bMax = parseInt($prodQuantityInput.dataset.max, 10);
        const b2bCartQty = checkMaxquantity(productId);
        if (!isNaN(b2bMax) && parseInt(productQty, 10) + b2bCartQty > b2bMax) {
          const b2bText = ($errorMessage && ($errorMessage.getAttribute('data-error-message') || $errorMessage.innerHTML)) || '';
          setB2BErrors(b2bText.replace('{limit}', b2bMax));
          return false;
        }
      }

      if ($storeLocator && $pickUpAvailability?.length > 0 && productQty) {

        [...$pickUpAvailability].forEach((el) => {
          var locationId = $storeLocator.preferredStoreId || null;
          el.dataset.itemQuantity = productQty ? parseInt(productQty) : null;

          if (locationId) {
            var location = $storeLocator?.allLocationsData?.find((loc) => loc.id === locationId) || null;
            if (location) {
              el.renderPreview(location);
            }
          }
        });
      }

      // A bundle is added as one line whose variant is the hero child, so neither Shopify nor the
      // bundle's own data-max can tell that its OTHER children already sit in the cart — from a
      // standalone line, or from another bundle containing the same child. Check each child against
      // its own limit. A bundle holds exactly 1 of each child, so the requested child quantity is
      // the requested bundle quantity.
      if (isBundleSelected) {
        const requestedChildQty = parseInt(productQty, 10) || 0;
        const cartRows = window.CartQuantity.getRows();
        const bundleData = $selectedBundleOption[0]?.dataset ?? {};
        // Read the dataset rather than assuming children 1-3: a bundle may have more components
        // than the three `_bundle_item_N_*` property slots recorded at add-to-cart time.
        const childKeys = Object.keys(bundleData).filter((key) => /^bundleChildProductId\d+$/.test(key));

        for (const childKey of childKeys) {
          const childProductId = bundleData[childKey];
          const childIndex = childKey.replace('bundleChildProductId', '');
          const childMax = parseInt($selectedBundleOption.attr(`data-bundle-child-max-${childIndex}`), 10);
          if (!childProductId || Number.isNaN(childMax)) continue;

          const childInCart = window.CartQuantity.sumByProductId(childProductId, { rows: cartRows });
          if (requestedChildQty + childInCart > childMax) {
            showQtyLimitError(childMax);
            return false;
          }
        }
      }

      const requestedQty = parseInt(productQty);
      // Two aggregates, deliberately: a bundle line only consumes its HERO variant's inventory, so
      // units of the other children count toward their purchase limit but not against stock.
      const maxQtyAllowed = requestedQty + checkMaxquantity(productId);
      const invQtyAllowed = requestedQty + window.CartQuantity.sumByProductId(productId, { includeCtoChildren: false });

      // Note prodMaxQty is the string '/' when the product has no limit (see buy-buttons.liquid);
      // the resulting NaN comparison is false, which is what makes "no limit" mean unlimited.
      if (maxQtyAllowed > prodMaxQty) {
        showQtyLimitError(prodMaxQty);
        return false;
      } else if (invQtyAllowed > parseInt(prodInventoryQuantity)) {
        showQtyLimitError(parseInt(prodInventoryQuantity));
        return false;
      } else {
        resetErrors();
        return true;
      }
    }

    function showQtyLimitError(limit) {
      var $errorMessage = document.querySelector('.js-qty-error') || null;
      var $qtyInput = document.querySelector('.js-qty-input') || null;

      if ($errorMessage) {
        const text = $errorMessage.getAttribute('data-error-message') || $errorMessage.innerHTML;

        if (text) {
          if (text.includes('{limit}')) {
            $errorMessage.innerHTML = text.replace('{limit}', `${limit}`);
          }
          $errorMessage.classList.remove('hidden');
        }
      }
      if ($qtyInput) {
        $qtyInput.classList.add('quantity--error');
      }
    }

    function resetErrors() {
      var $errorMessage = document?.querySelector('.js-qty-error') || null;
      var $errorMessageB2B = document?.querySelector('.js-b2b-qty-error') || null;
      var $qtyInput = document?.querySelector('.js-qty-input') || null;
      var $social =  document?.querySelector('.js-cto-summary-share') || null;

      if ($errorMessage) {
        $errorMessage.classList.add('hidden');
        $errorMessage.innerHTML = $errorMessage.getAttribute('data-error-message');
      }
      if ($errorMessageB2B) {
        $errorMessageB2B.classList.add('hidden');
      }
      if ($qtyInput) {
        $qtyInput.classList.remove('quantity--error');
      }
      if ($social) {
        $social.classList.remove('has-error');
      }
    }

    function setB2BErrors(errorMessage) {
      var $errorMessageB2B = document?.querySelector('.js-b2b-qty-error') || null;
      var $qtyInput = document?.querySelector('.js-qty-input') || null;
      var $social =  document?.querySelector('.js-cto-summary-share') || null;

      if ($errorMessageB2B) {
        $errorMessageB2B.textContent = errorMessage;
        $errorMessageB2B.classList.remove('hidden');
        if ($social) {
          $social.classList.add('has-error');
        }
      }
      if ($qtyInput) {
        $qtyInput.classList.add('quantity--error');
      }
    }

    $('.js-cto-bundle-option').on('change', function() {
      resetErrors();
      debounce(checkQty, 500)();
    });
});
/* Minicart ends here - added by Hema*/


/**
 * Units of a product already in the cart, for quantity-limit checks.
 *
 * Delegates to window.CartQuantity (global.js), which reads the bundle-aware
 * `cart?view=minquant` feed. The previous /cart.js implementation could only ever attribute a
 * custom-bundle line to the *bundle* product id, so units of the bundle's hero and secondary
 * children were invisible and a shopper could add them standalone on top of a full bundle limit.
 *
 * Fails open (returns 0) if the feed can't be read, matching the old behaviour.
 */
function checkMaxquantity(productId) {
  return window.CartQuantity.sumByProductId(productId);
}

function checkQuantity() {
    var total_quantity = 0;
    var cart_key = [];
    $.ajax({
        type: 'GET',
        dataType: 'json',
        url: `${window.Shopify.routes.root}cart.js`,
        success: function(cart) {
            for (var i = 0; i < cart.items.length; i++) {
                var tags = cart.items[i].properties.__taxtags;
                if (tags != undefined) {
                    var list = tags.split(',');
                    var found = false;
                    for (var j = 0; j < list.length; ++j) {
                        cart_key.push(cart.items[i].properties.__taxtags);
                        if (list[j] == 'taxfree') {
                            total_quantity += cart.items[i].quantity;
                        }
                    }
                }
            }
            setCookie('total_quantity', total_quantity, 7);
            setCookie('cart_key', cart_key, 7);
        }
    });
}

function setCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function eraseCookie(name) {
    document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}
