class CTOStickyATC extends HTMLElement {
  constructor() {
    super();
    this.scrollPosition = 0;
  }

  connectedCallback() {
    if (window?.ApplePaySession && this.querySelector('.apple-button')) {
      this.classList.add('apple-pay-supported');
    }

    if (this.querySelector('.checkout-button')) {
      this.classList.add('checkout-button-supported');
    }

    this.classList.add('scrolled');

    // Remove existing listeners to prevent duplicates (e.g., after variant switch re-init)
    if (this._onScroll) {
      document.removeEventListener('scroll', this._onScroll);
    }
    if (this._onResize) {
      window.removeEventListener('resize', this._onResize);
    }

    this._onScroll = this.onScroll.bind(this);
    this._onResize = this.updateBodyPadding.bind(this);

    document.addEventListener('scroll', this._onScroll);
    this.updateBodyPadding();
    window.addEventListener('resize', this._onResize);

    // Re-init checkout-button children (pdp-2.0)
    this.querySelectorAll('checkout-button').forEach(function(btn) {
      if (typeof btn.init === 'function') btn.init();
    });
  }

  disconnectedCallback() {
    if (this._onScroll) {
      document.removeEventListener('scroll', this._onScroll);
    }
    if (this._onResize) {
      window.removeEventListener('resize', this._onResize);
    }
    // Reset the body padding this component added; otherwise the offset persists
    // after the sticky footer is removed on variant switch / section re-render.
    document.body.style.paddingBottom = '';
  }

  onScroll() {
    if (window.innerWidth < 768) {
      const fromTop = document.documentElement.scrollTop;
      if (fromTop >= this.scrollPosition) {
        this.classList.add('scrolled');
      } else {
        this.classList.remove('scrolled');
      }
      this.scrollPosition = fromTop;
    }
  }

  updateBodyPadding() {
    // update body padding to avoid content hidden behind the sticky footer
    const mobileFooterHeight = this.offsetHeight || 0;
    const footerHeight = document.querySelector('.js-sticky-atc')?.offsetHeight || mobileFooterHeight || 0;
    document.body.style.paddingBottom = `${footerHeight}px`;
  }
}

customElements.define('cto-sticky-atc', CTOStickyATC);
