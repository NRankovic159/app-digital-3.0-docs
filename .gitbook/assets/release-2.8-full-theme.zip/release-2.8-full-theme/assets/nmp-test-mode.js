class NMPTestMode extends HTMLElement {
  constructor() {
    super();
    this.config = {
      dom: {
        modal: '.ac-modal-trigger[data-ajax-url], .ac-modal-trigger[data-modal-target]',
        buttons: '.js-nmp-button',
        options: '.js-nmp-option',
        selects: '.js-nmp-select',
        active_price: '.js-nmp-active-price',
        total: '.js-nmp-total-price',
        frequency: '.js-nmp-total-frequency',
        terms: '.js-nmp-terms',
        cto_length: '.js-cto-finance-length',
        cto_bank: '.js-cto-finance-bank',
      },
      cls: {
        active: 'active'
      }
    }
    this.modals = document.querySelectorAll(this.config.dom.modal) || [];

      if (this?.modals?.length > 0) {
        this.addModalEvents();

        window.refreshNmpAddModalEvents = () => {
          this.modals = document.querySelectorAll(this.config.dom.modal) || [];
          this.addModalEvents();
        }
      }
  }

  async getNMPTerms(handle, isCart) {
    let url = isCart ? '/?section_id=nmp-test-mode-plan-cart' : `/products/${handle}?view=nmp`;
    const $appleCareAdded = document.querySelectorAll('input#add-apple-care:checked');
    const $secWarrantyAdded = document.querySelectorAll('input#add-secWarranty:checked');
    const $terms = this.querySelector(this.config.dom.terms) || null;
    const $selectedBundle = document.querySelector('input.js-cto-set-price-display:checked');


    // update terms when bundle products are selected
    if ($selectedBundle) {
      const bundleHandle = $selectedBundle.dataset.handle || '';

      if (bundleHandle) {
        url = `/products/${bundleHandle}?view=nmp`;
      }
    }

    // Detect if add-ons are selected
    const hasAppleCare = $appleCareAdded.length > 0;
    const hasSecWarranty = $secWarrantyAdded.length > 0;

    if (hasAppleCare || hasSecWarranty) {
      const urlRoute = this.getURLRoute({ hasAppleCare, hasSecWarranty });

       if ($selectedBundle) {
        const bundleHandle = $selectedBundle.dataset.handle || '';
        url = `/products/${bundleHandle}?view=${urlRoute}`;
      } else {
        url = `/products/${handle}?view=${urlRoute}`;
      }
    }

    let $html = null;
    try {
      const res = await fetch(url);
      $html = await res.text() || null;
    } catch (error) {
      console.error('getNMPTerms fetch failed:', error);
    }

    if ($terms && $html) $terms.innerHTML = $html;
    this.addSelectEvents();
    this.addButtonsEvents();

    const isPreSale =
      document.querySelector('.apl-section-product-cto')?.dataset.isPreSale === 'true'
      || document.querySelector('.apl-section-main-product .product')?.dataset.isPreSale === 'true'
      || false;

    isPreSale && $terms?.classList.add('is-pre-sale');
  };

  getURLRoute({ hasAppleCare, hasSecWarranty }) {
    if (hasAppleCare && hasSecWarranty) return 'nmp-applecare-secwarranty';
    if (hasAppleCare) return 'nmp-applecare';
    if (hasSecWarranty) return 'nmp-secwarranty';
    return 'nmp';
  }

  addModalEvents() {
    this?.modals?.forEach((modal) => {
      // window.refreshNmpAddModalEvents() may re-run this; guard so each modal
      // only ever gets a single click listener attached.
      if (modal.dataset.nmpModalBound === 'true') return;
      modal.dataset.nmpModalBound = 'true';

      modal.addEventListener('click', () => {
         const { product, price } = modal.dataset || {};
         this.resetState();

         if (product) {
          this.getNMPTerms(product);
         }

         if (price) {
          this.getNMPTerms(null, true);
         }
      });
    });
  }

  addSelectEvents() {
    const $selects = this.querySelectorAll(this.config.dom.selects) || [];

    if ($selects?.length > 0) {
      [...$selects].forEach(($select) => {
        $select.addEventListener('change', () => {
          const { value } = $select || {};
          const $ctoTerms = document.querySelectorAll(this.config.dom.cto_length) || null;

          if (value) {
            const $activeOption = $select.querySelector(`option[value="${value}"]`) || null;

            if ($activeOption) {
              const term = $activeOption.dataset.term || '';
              this.updatePrice(value, term);

              if ($ctoTerms?.length > 0) {
                [...$ctoTerms].forEach(($ctoTerm) => {
                  $ctoTerm.innerHTML = term + ' ';
                });
              }
            }
          }
        });
      });
    }
  }

  addButtonsEvents() {
    const $buttons = this.querySelectorAll(this.config.dom.buttons) || [];

    if ($buttons?.length > 0) {
      [...$buttons].forEach(($button) => {
        $button.addEventListener('click', () => {
          this.setActiveTerms($button);
        });

        $button.addEventListener('keydown', (e) => {
          const buttons = [...this.querySelectorAll(this.config.dom.buttons)];
          const index = buttons.indexOf($button);

          if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            e.preventDefault();
            const next = buttons[(index + 1) % buttons.length];
            next.focus();
            this.setActiveTerms(next);
          } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            e.preventDefault();
            const prev = buttons[(index - 1 + buttons.length) % buttons.length];
            prev.focus();
            this.setActiveTerms(prev);
          }
        });
      });
    }
  }

  resetState() {
    const $buttons = this.querySelectorAll(this.config.dom.buttons) || [];
    const $options = this.querySelectorAll(this.config.dom.options) || [];
    const $selects = this.querySelectorAll(this.config.dom.selects) || [];
    const $ctoBanks = document.querySelectorAll(this.config.dom.cto_bank) || null;
    const $ctoTerms = document.querySelectorAll(this.config.dom.cto_length) || null;

    if ($buttons?.length > 0) {
      [...$buttons].forEach(($button) => {
        $button.classList.remove(this.config.cls.active);
        $button.setAttribute('aria-selected', 'false');
        $button.setAttribute('tabindex', '-1');
      });
    }

    if ($options?.length > 0) {
      [...$options].forEach(($option) => {
        $option.classList.remove(this.config.cls.active);
        $option.setAttribute('aria-hidden', 'true');
      });
    }

    if ($selects?.length > 0) {
      [...$selects].forEach(($select) => {
        $select.selectedIndex = 0;
      });
    }

    if ($ctoBanks?.length > 0) {
      [...$ctoBanks].forEach(($ctoBank) => {
        const initialText = $ctoBank.dataset.initialTitle || '';

        $ctoBank.innerHTML = initialText;
      });
    }

    if ($ctoTerms?.length > 0) {
      [...$ctoTerms].forEach(($ctoTerm) => {
        const initialText = $ctoTerm.dataset.initialTerm || '';

        $ctoTerm.innerHTML = initialText;
      });
    }
  }

  setActiveTerms(el) {
    if (!el) return;

    const $button = el;
    const { id } = $button || {};
    const $ctoBanks = document.querySelectorAll(this.config.dom.cto_bank) || null;
    const $ctoTerms = document.querySelectorAll(this.config.dom.cto_length) || null;

    if (id) {
      this.resetState();

      $button.classList.add(this.config.cls.active);
      $button.setAttribute('aria-selected', 'true');
      $button.setAttribute('tabindex', '0');

      const $terms = document.getElementById(`${id}-option`) || null;
      let activeTerm;

      if ($terms) {
        const $select = $terms.querySelector(this.config.dom.selects) || null;

        if ($select) {
          const $firstOption = $select.querySelector('option') || null;

          if ($firstOption?.value) {
            const term = $firstOption.dataset.term || '';

            activeTerm = term;

            this.updatePrice($firstOption.value, term);
          }
        }

        $terms.classList.add(this.config.cls.active);
        $terms.setAttribute('aria-hidden', 'false');

        if ($ctoBanks?.length > 0) {
          [...$ctoBanks].forEach(($ctoBank) => {
            $ctoBank.innerHTML = $button.innerHTML;
          });
        }

        if ($ctoTerms?.length > 0) {
          [...$ctoTerms].forEach(($ctoTerm) => {
            $ctoTerm.innerHTML = (activeTerm || '') + ' ';
          });
        }
      }
    }
  }

  updatePrice(val, term ='') {
    const $activePrice = this.querySelectorAll(this.config.dom.active_price) || [];
    const $totals = this.querySelectorAll(this.config.dom.frequency) || [];
    const frequencyText = this.dataset.frequency || null;

    if ($activePrice?.length > 0) {
      [...$activePrice].forEach(($price) => {
        $price.innerHTML = val;
      });
    }

    if (frequencyText && $totals?.length > 0) {
      const frequency = frequencyText.replace('{{ per_month }}', term);

     if ($totals?.length > 0) {
        [...$totals].forEach(($total) => {
          $total.innerHTML = frequency;
        });
      }
    }
  }
}

customElements.define("nmp-test-mode", NMPTestMode);
