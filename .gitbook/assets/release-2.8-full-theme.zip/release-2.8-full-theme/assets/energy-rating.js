(function() {
  if (customElements.get('energy-rating')) return;
  class EnergyRating extends HTMLElement {
    constructor() {
      super();
      this.config = {
        dom: {
          actions: '.js-energy-rating-actions',
          divider: '.js-energy-rating-divider',
          wrapped_item: '.js-energy-rating-wrapped-item'
        },
        cls: { 
          hide: 'hidden',
        }
      };
      this._onResize = throttle(() => this.hideDividers(), 150);
    }

    connectedCallback() {
      this.hideDividers();
      window.addEventListener('resize', this._onResize);
    }

    disconnectedCallback() {
      window.removeEventListener('resize', this._onResize);
    }

    hideDividers() {
      const $wrappedItem = this.querySelector(this.config.dom.wrapped_item);
      const $divider = this.querySelector(this.config.dom.divider);

      if (!$wrappedItem || !$divider) return;
      if ($divider.hasAttribute('data-divider-hidden')) return;

      if ($wrappedItem.offsetTop > $divider.offsetTop) {
        $divider.classList.add(this.config.cls.hide);
        return;
      }

      $divider.classList.remove(this.config.cls.hide);;
    }
  }

  customElements.define('energy-rating', EnergyRating);
})();
