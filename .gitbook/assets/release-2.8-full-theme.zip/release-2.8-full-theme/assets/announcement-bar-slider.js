$(document).ready(function(){
  $('.hura-messages.swiper-wrapper').slick({
    arrows: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          dots: false,
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  });
      
  // Remove aria-describedby from slick slides
  setTimeout(() => {
    const huraSlider = $('.hura-messages.swiper-wrapper');
    const slickSlides = $(huraSlider).find('.slick-list .slick-slide');
    adaFormatSlickSlides(slickSlides);
  }, 250);

  $('.hura-messages.swiper-wrapper').show();
  customSlickSlider();
});