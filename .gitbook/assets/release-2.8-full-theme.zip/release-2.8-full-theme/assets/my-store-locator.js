function safeJsonParse(raw, fallback = null) {
  if (raw === null || raw === undefined || raw === '') return fallback;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return fallback;
  }
}

if (!customElements.get('my-store-locator')) {
  customElements.define(
    'my-store-locator',
    class MyStoreLocator extends HTMLElement {
      constructor() {
        super();

        this.dom = {
          mobile: 'my-store-locator-mobile',
          btn: '.js-my-store-locator-btn',
          drawer: 'my-store-locator-drawer',
          drawerBtn: '.js-my-store-locator-drawer-btn',
          info: '.js-my-store-locator-info',
          details: '.js-my-store-locator-details',
          close: '.js-my-store-locator-close',
          location: '.js-my-store-locator-location',
          telephone: '.js-my-store-locator-telephone',
          email: '.js-my-store-locator-email',
          address: '.js-my-store-locator-address',
          hours: '.js-my-store-locator-hours',
          services: '.js-my-store-locator-services',
          distance: '.js-my-store-locator-distance',
          pickupAvailability: 'pickup-availability',
          searchButton: '.js-my-store-locator-search-drawer-launcher',
          filterResults: 'ProductGridContainer',
          filterTag: '.js-my-store-pickup-location-text',
          filterInput: '.js-my-store-pickup-location-input',
          storeLocatorSearch: 'storeLocatorSearch',
        };

        this.mobileLocator = document.querySelector(this.dom.mobile);
        this.button = this.querySelector(this.dom.btn);
        this.drawer = document.querySelector(this.dom.drawer);
        this.drawerBtn = this.querySelector(this.dom.drawerBtn);
        if (this.drawerBtn) this.drawerBtn.addEventListener('click', this.onClickShowStoreSelector.bind(this));
        this.details = this.querySelector(this.dom.details);
        this.detailsClose = this.details?.querySelector(this.dom.close) || null;
        if (this.detailsClose) this.detailsClose.addEventListener('click', this.hideDetails.bind(this));
        this.detailsLocation = this.details?.querySelector(this.dom.location) || null;
        this.detailsTelephone = this.details?.querySelector(this.dom.telephone) || null;
        this.detailsEmail = this.details?.querySelector(this.dom.email) || null;
        this.detailsAddress = this.details?.querySelector(this.dom.address) || null;
        this.detailsHours = this.details?.querySelector(this.dom.hours) || null;
        this.detailsServices = this.details?.querySelector(this.dom.services) || null;
        this.distance = this.details?.querySelector(this.dom.distance) || null;
        this.filterResults = document.getElementById(this.dom.filterResults) || null;
        this.storeLocatorSearch = document.getElementById(this.dom.storeLocatorSearch) || null;

        this.onBodyClick = this.handleBodyClick.bind(this);
        this.onClickRefreshList = this.onClickRefreshList.bind(this);
        this.onClickToggleDetails = this.onClickToggleDetails.bind(this);
        this.onClickShowStoreSelector = this.onClickShowStoreSelector.bind(this);

        this.addEventListener('keyup', (event) => {
          if (event.code.toUpperCase() === 'ESCAPE') this.hideDetails();
        });

        if (this?.filterResults) {
          this.facetsObserver = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {

              if (mutation?.type === 'childList') {
                const $searchButtons = document.querySelectorAll(this.dom.searchButton);
                $searchButtons.forEach(($searchButton) => {
                  $searchButton.addEventListener('click', this.onClickShowStoreSelector);
                });

                this.updateFacets(this.button?.querySelector(this.dom.info)?.innerHTML || '');
              }
            });
          });

          // watch for changes to the filters and add the event listeners
          this.facetsObserver.observe(this.filterResults, { childList: true });
        }

        const $searchButtons = document.querySelectorAll(this.dom.searchButton);
        $searchButtons.forEach(($searchButton) => {
          $searchButton.addEventListener('click', this.onClickShowStoreSelector);
        });

        this.preferredStoreId = null;
        this.myCoords = null;
        this.allLocationsData = [];
        this.itemLocationsData = {};
        this.storeSuggestions = [];

        this.expiry = SDG.Data.locationCookieExpiry || 30;

        this.init();

        window.refreshStoreLocator = this.init.bind(this);
      }

      setSecureCookie(name, value, days) {
        var expires = "";

        if (days) {
          var date = new Date();
          date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
          expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/" + "; secure";
      }

      getCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');

        for (var i = 0; i < ca.length; i++) {
          var c = ca[i];
          while (c.charAt(0) == ' ') c = c.substring(1, c.length);
          if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }

        return null;
      }

      localizeUrl($url) {
        const rootWithoutEndingSlash = Shopify.routes.root.slice(0, -1);
        const urlParts = $url.split('/');
        urlParts[0] = rootWithoutEndingSlash;
        return urlParts.join('/');
      }

      storageAvailable(type) {
        let storage;
        try {
          storage = window[type];
          const x = '__storage_test__';
          storage.setItem(x, x);
          storage.removeItem(x);
          return true;
        } catch (e) {
          return (
            e instanceof DOMException &&
            // everything except Firefox
            (e.code === 22 ||
              // Firefox
              e.code === 1014 ||
              // test name field too, because code might not be present
              // everything except Firefox
              e.name === 'QuotaExceededError' ||
              // Firefox
              e.name === 'NS_ERROR_DOM_QUOTA_REACHED') &&
            // acknowledge QuotaExceededError only if there's something already stored
            storage &&
            storage.length !== 0
          );
        }
      }

      getDistanceFromKm(km) {
        const delimiter = this.dataset.distanceDecimalDelimiter === 'comma' ? ',' : '.';
        let distanceText = '';
        if (this.dataset.distanceUnit === 'km') {
          const parsedKm = parseFloat(km.toFixed(1));
          distanceText = `${parsedKm.toString().replace('.', delimiter)} ${this.dataset.distanceKmLabel}`
        } else {
          const miles = km * 0.621371;
          const parsedMiles = parseFloat(miles.toFixed(1));
          distanceText = `${parsedMiles.toString().replace('.', delimiter)} ${this.dataset.distanceMilesLabel}`
        }
        return distanceText;
      }

      init() {
        function accept(pos, cookie = false) {
          if (cookie && pos) {
            const position = {
              coords: {
                latitude: pos?.coords?.latitude,
                longitude: pos?.coords?.longitude,
              }
            };

            this.setSecureCookie('location_sharing', 'true', this.expiry);
            this.setSecureCookie('location_position', JSON.stringify(position), this.expiry);
          }
          this.fetchLocations(pos);
        }

        function decline(cookie = false) {
          if (cookie) this.setSecureCookie('location_sharing', 'false', this.expiry);

          this.fetchLocations(null, true, () => {
            const hasUpdated = this.updateMyStoreFromPreferredStoreId();

            if (!hasUpdated) this.renderSelectYourStore();
          });
        }

        function getLocation() {
          const enableCookie = SDG.Data.locationCookie || false;

          if (enableCookie) {
            const locationPreference = this.getCookie('location_sharing') || null;

            if (locationPreference && locationPreference === 'false') {
              decline.call(this, false);

              this.hasInitialized = true;
              return;
            }

            if (locationPreference && locationPreference === 'true') {
              const locationPosition = this.getCookie('location_position') || null;

              if (locationPosition) {
                let pos = null;
                try {
                  pos = JSON.parse(locationPosition);
                } catch (e) {
                  pos = null;
                }

                if (pos) accept.call(this, pos, true);
                this.hasInitialized = true;
                return;
              }
            }

            navigator.geolocation.getCurrentPosition((pos) => accept.call(this, pos, true), decline.bind(this));
            this.hasInitialized = true;

            return;
          }

          navigator.geolocation.getCurrentPosition(accept.bind(this), decline.bind(this, false));
          this.hasInitialized = true;
        }

        if (this.dataset.defaultLocationId !== '') {
          this.preferredStoreId = `gid://shopify/Location/${this.dataset.defaultLocationId}`;
        }

        if (this.storageAvailable('localStorage')) {
          const preferredStoreId = localStorage.getItem('preferredStoreId');
          if (preferredStoreId) {
            this.preferredStoreId = preferredStoreId;
          }
        }

        if (!navigator.geolocation) {
          this.fetchLocations(null, true, () => {
            const hasUpdated = this.updateMyStoreFromPreferredStoreId();
            if (!hasUpdated) this.renderSelectYourStore();
          });
        } else {
          getLocation.call(this);
        }
      }

      // update cart attributes
      async updateSelectedLocationAttributes(storeLocation = null) {
        const data = {
          updates: {},
          attributes: {
            _selected_location: storeLocation,
          },
        };
        try {
          const currentCart = await $.ajax({
            type: 'GET',
            url: `${window.Shopify.routes.root}cart.js`,
            dataType: 'json'
          });
          const currentLocationAttr = currentCart.attributes._selected_location || null;
          if (currentLocationAttr === storeLocation) {
            return;
          }
          $.ajax({
            type: 'POST',
            url: `${window.Shopify.routes.root}cart/update.js`,
            data: data,
            error: function(e) {
              console.error(e);
            },
            dataType: 'json'
          });
        } catch (e) {
          console.error('An error occurred while updating cart attributes:', e);
        }
      }

      updateFacets(placeholderText = null) {
        if(!this?.filterResults) return;
        const $placeholder = document.querySelector(`${this.dom.filterInput}[data-location-id="placeholder"]`);
        const $placeholderButton = $placeholder?.closest('li').querySelector(this.dom.searchButton);
        if (placeholderText && $placeholderButton) {
          $placeholderButton.innerText = placeholderText;
        }

        const $prevInput = document.querySelector(`${this.dom.filterInput}.active`);
        const $prevInputChecked = $prevInput?.checked;
        let $visibleInput = null;

        this.allLocationsData.forEach((location) => {
          const $filterTags = document.querySelectorAll(`${this.dom.filterTag}[data-location-id="${location.id}"]`);
          $filterTags.forEach(($filterTag) => {
            $filterTag.innerText = location.name;
          });

          const $filterInputs = document.querySelectorAll(this.dom.filterInput);
          $filterInputs.forEach(($filterInput) => {
            const pickupLocationId = $filterInput.dataset?.locationId;

            // update pickup names
            if (pickupLocationId === location.id) {
              $filterInput.setAttribute('aria-label', location.name);
              const $searchButton = $filterInput.closest('li').querySelector(this.dom.searchButton);
              if ($searchButton) {
                $searchButton.innerText = location.name;
              }
            }
            // set preferred store as visible
            if (pickupLocationId === this.preferredStoreId) {
              $visibleInput = $filterInput;
              $filterInput.disabled = false;
              $filterInput.classList.add('active');
              $filterInput.closest('label').classList.remove('facet-checkbox--disabled');
              $filterInput.closest('li').classList.add('active');
            } else if (pickupLocationId !== 'placeholder') {
              $filterInput.disabled = true;
              $filterInput.checked = false;
              $filterInput.classList.remove('active');
              $filterInput.closest('label').classList.add('facet-checkbox--disabled');
              $filterInput.closest('li').classList.remove('active');
            }
          });
        });

        if ($visibleInput && $prevInput && $visibleInput?.id !== $prevInput?.id && $prevInputChecked) {
          // simulate click to update the active state
          // if the previous preferred store was checked
          const clickEvt = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true,
          });
          $visibleInput.dispatchEvent(clickEvt);
        }

        // show placeholder if preferred store is not an available filter
        if (!$visibleInput && $placeholder) {
          $placeholder.closest('li').classList.add('active');

          //clear active location filter
          const $filterTag = document.querySelector(`${this.dom.filterTag}[data-location-id]`);
          if ($filterTag) {
            const clickEvt = new MouseEvent('click', {
              view: window,
              bubbles: true,
              cancelable: true,
            });
            $filterTag.closest('a').dispatchEvent(clickEvt);
          }
        } else if ($placeholder) {
          $placeholder.closest('li').classList.remove('active');
        }
      }

      updateMyStoreFromPreferredStoreId() {
        let hasUpdated = false;
        let hasLocalStoragePreferredStoreId = false;

        if (this.storageAvailable('localStorage')) {
          const preferredStoreId = localStorage.getItem('preferredStoreId');
          if (preferredStoreId) {
            hasLocalStoragePreferredStoreId = true;
          }
        }

        // set store only if there is a preferred store and no geolocation or it came from localStorage
        if (this.preferredStoreId && (!this.myCoords || hasLocalStoragePreferredStoreId)) {
          const preferredLocation = this.allLocationsData.find(
            (location) => location.id === this.preferredStoreId
          );
          if (preferredLocation) {
            this.updateMyStoreWithLocation(preferredLocation);
            hasUpdated = true;
          }
        }
        return hasUpdated;
      }

      locationsQuery(productQueryIds = []) {
        const rawLang = SDG?.Data?.language || 'EN';
        const activeLang = /^[A-Z]{2,3}$/.test(rawLang) ? rawLang : 'EN';

        const locationQuery = `
          id
          name
          address {
            formatted
            address1
            city
            province
            provinceCode
            zip
            country
            phone
            latitude
            longitude
          }
          enableToggles: metafield(namespace: "apple", key: "apl_EnableToggles") {
            value
          }
          pickupMessages: metafield(namespace: "apple", key: "apl_PickupMessages") {
            value
          }
          phoneOverride: metafield(namespace: "apple", key: "apl_PhoneOverride") {
            value
          }
          email: metafield(namespace: "apple", key: "apl_Email") {
            value
          }
          hours: metafield(namespace: "apple", key: "apl_Hours") {
            value
          }
          services: metafield(namespace: "apple", key: "apl_ServicesContent") {
            value
          }
          image: metafield(namespace: "apple", key: "apl_StoreImage") {
            reference {
              ... on MediaImage {
                image {
                  originalSrc
                }
              }
            }
          }
        `;
        const getNearestQuery = `
          getNearestPickupLocations($first: Int!, $location: GeoCoordinateInput, $sortKey: LocationSortKeys) @inContext(language: ${activeLang}){
            locations(near: $location, first: $first, sortKey: $sortKey) {
              edges {
                node {
                  ${locationQuery}
                }
              }
            }
          }
        `;
        if (productQueryIds.length > 0) {
          let productsQuery = '';
          let productIds = '';
          let selectedOptions = '';

          productQueryIds.forEach((key) => {
            productIds += `$productId${key}: ID!,`;
            selectedOptions += `$selectedOptions${key}: [SelectedOptionInput!]!,`;
            productsQuery += `
              product${key}: product(id: $productId${key}) {
                id
                variantBySelectedOptions(selectedOptions: $selectedOptions${key}) {
                  storeAvailability(first: $first) {
                    edges {
                      node {
                        available
                        pickUpTime
                        quantityAvailable
                        location {
                          ${locationQuery}
                        }
                      }
                    }
                  }
                }
              }
            `;
          });
          return `
            query Products(${productIds} ${selectedOptions} $first: Int!, $location: GeoCoordinateInput, $sortKey: LocationSortKeys) @inContext(language: ${activeLang}){
              ${productsQuery}
              locations(near: $location, first: $first, sortKey: $sortKey) {
                edges {
                  node {
                    ${locationQuery}
                  }
                }
              }
            }
          `;
        }
        return `
          query ${getNearestQuery}
        `;
      }

      async fetchLocations(position = null, setDataOnly = false, cb = null) {
        const queryVariables = {
          first: parseInt(this.dataset.numberOfLocationsToFetch),
          sortKey: 'NAME',
        };
        if (position?.coords) {
          this.myCoords = position.coords;
          const latitude = position.coords.latitude;
          const longitude = position.coords.longitude;

          if (latitude && longitude) {
            queryVariables.sortKey = 'DISTANCE';
            queryVariables.location = {
              latitude,
              longitude,
            };
          }
        }
        let isCart = false;
        const pickupAvailabilities = document.querySelectorAll(this.dom.pickupAvailability);
        const productQueryIds = [];
        if (pickupAvailabilities.length > 0) {
          [...pickupAvailabilities].forEach((pickupAvailability, i) => {
            const itemKey = pickupAvailability?.dataset?.itemKey;
            const productId = pickupAvailability?.dataset?.productId;
            const selectedOptionsRaw = pickupAvailability?.dataset?.selectedOptions;
            if (productId && selectedOptionsRaw) {
              let parsedOptions;
              try {
                parsedOptions = JSON.parse(selectedOptionsRaw);
              } catch (e) {
                parsedOptions = null;
              }
              if (!Array.isArray(parsedOptions)) return;
              const selectedOptions = parsedOptions.map((option) => {
                return {
                  name: option.name,
                  value: option.selected_value ? option.selected_value : option.values[0],
                };
              });
              // if it is a cart item, use the itemKey as the key
              if (itemKey) {
                productQueryIds.push(itemKey);
                queryVariables[`productId${itemKey}`] = `gid://shopify/Product/${productId}`;
                queryVariables[`selectedOptions${itemKey}`] = selectedOptions;
                isCart = true;
              } else {
                // else use the index as the key
                productQueryIds.push(i);
                queryVariables[`productId${i}`] = `gid://shopify/Product/${productId}`;
                queryVariables[`selectedOptions${i}`] = selectedOptions;
              }
            }
          });
        }

        const query = this.locationsQuery(productQueryIds);
        let locationsData;
        try {
          locationsData = await this.fetchStorefrontApi(query, queryVariables);
        } catch (e) {
          // network error, timeout or API error: show the retry state; cb is skipped so it can't replace it
          console.warn('Store locator: unable to load locations', e);
          this.renderError();
          return;
        }
        if (locationsData) {
          // get locations sorted by distance
          if (locationsData.locations?.edges?.length) {
            locationsData.locations.edges.forEach((location) => {
              // parse the services rich text
              if (location?.node?.services?.value) {
                let parsed;
                try {
                  parsed = JSON.parse(location.node.services.value);
                } catch (e) {
                  parsed = null;
                }
                if (parsed) {
                  const markup = this.serializeRichText(parsed);
                  // add the markup to the location object
                  location.node.services_html = markup;
                }
              }

              if (location?.node?.image?.reference?.image?.originalSrc) {
                location.node.image_url = location.node.image.reference.image.originalSrc;
              }
            });

            // set all locations data
            this.allLocationsData = locationsData.locations.edges.map((location) => {
              const locationData = location.node;
              // set the available flag to false if we are on the PDP or cart page
              // to be overwriten later if the location is available
              if (locationsData.hasOwnProperty('product0')) {
                locationData.available = false;
                locationData.productPickupOfferedAtLocation = false;
              }
              locationData.distance = this.calculateStoreDistance(locationData.address);
              return locationData;
            }).filter((location) => {
              // filter out locations that are not enabled on the store locator page
              return safeJsonParse(location.enableToggles?.value)?.storeLocatorEnabled !== false;
            });
          }

          this.locationsData = Object.entries(locationsData)
            .filter(([key, value]) => key !== 'locations' && value)
            .map(([key, value]) => {
              return {
                productId: value.id,
                locationData: (value.variantBySelectedOptions?.storeAvailability?.edges || []).map(item => {
                  return {
                    available: item.node.available,
                    quantityAvailable: item.node.quantityAvailable,
                    ...item.node.location
                  }
                })
              }
            });

          // find the main PDP product key by matching the hero product ID from the DOM
          let mainProductKey = null;
          if (!isCart) {
            const mainProductId = document.querySelector('[data-main-product-id]')?.dataset?.mainProductId;
            if (mainProductId) {
              [...pickupAvailabilities].forEach((pickupAvailability, i) => {
                if (mainProductKey === null && pickupAvailability?.dataset?.productId === mainProductId && queryVariables[`productId${i}`]) {
                  mainProductKey = `product${i}`;
                }
              });
            }
          }
          // fallback to product0
          if (!mainProductKey) {
            mainProductKey = 'product0';
          }

          if (mainProductKey && locationsData[mainProductKey]?.variantBySelectedOptions?.storeAvailability?.edges?.length) {
            const locationsPDPData = locationsData[mainProductKey].variantBySelectedOptions.storeAvailability.edges;
            // update location data to incorporate the product data
            this.allLocationsData = this.allLocationsData.map((location) => {
              const locationPDPData = locationsPDPData.find((locationPDP) => locationPDP.node.location.id === location.id);
              if (locationPDPData) {
                const locationData = {
                  ...location,
                  available: locationPDPData.node.available,
                  pickUpTime: locationPDPData.node.pickUpTime,
                  quantityAvailable: locationPDPData.node.quantityAvailable,
                  productPickupOfferedAtLocation: true,
                };
                return locationData;
              }
              return location;
            });
          // check if there are cart products
          } else if (isCart) {
            // reset the itemLocationsData object
            this.itemLocationsData = {};
            const locationKeys = Object.keys(locationsData);
            locationKeys.forEach((key) => {
              if (key.includes('product')) {
                const itemKey = key.replace('product', '');
                const lineItem = locationsData[key];
                const locationsItemData = lineItem?.variantBySelectedOptions?.storeAvailability?.edges || [];
                // set the cart item specfic locations
                const lineItemLocations = this.allLocationsData.map((location) => {
                  const locationItemData = locationsItemData.find((locationItem) => locationItem.node.location.id === location.id);
                  if (locationItemData) {
                    const locationData = {
                      ...location,
                      available: locationItemData.node.available,
                      pickUpTime: locationItemData.node.pickUpTime,
                      quantityAvailable: locationItemData.node.quantityAvailable,
                      productPickupOfferedAtLocation: true,
                    };
                    return locationData;
                  }
                  const locationData = {
                    ...location,
                    available: false,
                  };
                  return locationData;
                });
                // add the rest to another object to be used on the cart page
                this.itemLocationsData[itemKey] = lineItemLocations;
              }
            });
          }
          this.storeSuggestions = [];
          this.allLocationsData.forEach((location) => {
            this.storeSuggestions.push(
              location.address.city,
              location.address.province,
              location.address.zip,
              location.address.country,
            );
          });
          if (!setDataOnly) {
            const hasUpdated = this.updateMyStoreFromPreferredStoreId();
            if (!hasUpdated) {
              const firstLocation = this.allLocationsData.find((location) => safeJsonParse(location.enableToggles?.value)?.checkoutEnabled !== false);
              this.updateMyStoreWithLocation(firstLocation);
            }
          }
          if (this.drawer) {
            let allLocationsData = this.allLocationsData;
            if (this.drawer.selectedItemLocationsKey) {
              const selectedItemLocationsData = this.itemLocationsData[this.drawer.selectedItemLocationsKey];
              if (selectedItemLocationsData) {
                allLocationsData = selectedItemLocationsData;
              }
            }

            let searchLocation = this.storeLocatorSearch?.value || '';
            searchLocation = searchLocation.trim();
            this.drawer.updateStoreDetails(allLocationsData, searchLocation);
          }
        }
        if (cb) {
          cb();
        }
      }

      serializeRichText(richText) {
        let html = '';
        switch (richText.type) {
          case 'root':
            richText.children.forEach(child => {
              html += this.serializeRichText(child);
            });
            break;
          case 'list':
            html += `<ul>`;
            richText.children.forEach(child => {
              html += this.serializeRichText(child);
            });
            html += `</ul>`;
            break;
          case 'list-item':
            html += `<li>`;
            richText.children.forEach(child => {
              html += this.serializeRichText(child);
            });
            html += `</li>`;
            break;
          case 'text':
            html += String(richText.value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
            break;
          case 'link':
            const safeUrl = (() => {
              try {
                const u = new URL(richText.url, window.location.origin);
                if (u.protocol !== 'http:' && u.protocol !== 'https:' && u.protocol !== 'mailto:' && u.protocol !== 'tel:') return '#';
                return u.href.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
              } catch (e) {
                return '#';
              }
            })();
            html += `<a href="${safeUrl}">`;
            richText.children.forEach(child => {
              html += this.serializeRichText(child);
            });
            html += `</a>`;
            break;
          case 'paragraph':
            html += `<p>`;
            richText.children.forEach(child => {
              html += this.serializeRichText(child);
            });
            html += `</p>`;
            break;
          default:
            break;
        }
        return html;
      }

      onClickRefreshList(evt) {
        evt.currentTarget.disabled = true;
        this.renderLoading();
        this.init();
      }

      onClickToggleDetails() {
        if (this.details.hasAttribute('open')) {
          this.hideDetails();
        } else {
          this.showDetails();
        }
      }

      onClickShowStoreSelector(evt) {
        this.drawer.show(evt.currentTarget);
        this.hideDetails();
        trapFocus(this.drawer);
      }

      handleBodyClick(evt) {
        const target = evt.target;
        if (
          target != this.details &&
          !target.closest(this.dom.btn) &&
          !target.closest(this.dom.details)
        ) {
          this.hideDetails();
        }
      }

      hideDetails() {
        this.details.removeAttribute('open');
        this.details.hidden = true;
        document.body.removeEventListener('click', this.onBodyClick);
        removeTrapFocus(this.focusElement);
        this.details?.closest('.my-store-locator').querySelector(this.dom.btn)?.focus();
      }

      showDetails(focusElement) {
        this.focusElement = focusElement;
        this.details.setAttribute('open', '');
        this.details.hidden = false;
        document.body.addEventListener('click', this.onBodyClick);
        trapFocus(this.details);
      }

      removeButtonEvents() {
        this.button.removeEventListener('click', this.onClickRefreshList);
        this.button.removeEventListener('click', this.onClickToggleDetails);
        this.button.removeEventListener('click', this.onClickShowStoreSelector);
      }

      renderLoading() {
        if (!this.button) return;
        this.button.disabled = true;
        const info = this.button.querySelector(this.dom.info);
        if (info) info.innerHTML = `${this.dataset.loadingText} <i class="fa fa-spinner fa-spin"></i>`;

        if (this.mobileLocator) {
          this.mobileLocator.renderLoading(this.dataset.loadingText);
        }
      }

      renderError() {
        this.removeButtonEvents();
        if (!this.button) return;
        this.button.disabled = false;
        const info = this.button.querySelector(this.dom.info);
        if (info) info.innerHTML = this.dataset.errorText;
        this.button.addEventListener('click', this.onClickRefreshList);

        // hide the drawer spinner in case the failed request came from the drawer
        this.drawer?.loading?.classList.add('hidden');

        if (this.mobileLocator) {
          this.mobileLocator.renderError();
        }

        const pickupAvailabilities = document.querySelectorAll(this.dom.pickupAvailability);
        if (pickupAvailabilities.length > 0) {
          pickupAvailabilities.forEach((pickupAvailability) => {
            pickupAvailability.renderError();
          });
        }

        this.updateFacets(this.dataset.errorText);
      }

      renderSelectYourStore() {
        this.removeButtonEvents();
        if (!this.button) return;
        this.button.disabled = false;
        const info = this.button.querySelector(this.dom.info);
        if (info) info.innerHTML = this.dataset.selectText;
        this.button.addEventListener('click', this.onClickShowStoreSelector);

        this.drawer.loading.classList.add('hidden');

        if (this.mobileLocator) {
          this.mobileLocator.renderSelectYourStore();
        }

        const pickupAvailabilities = document.querySelectorAll(this.dom.pickupAvailability);
        if (pickupAvailabilities.length > 0) {
          pickupAvailabilities.forEach((pickupAvailability) => {
            pickupAvailability.renderPreview();
          });
        }

        this.updateFacets(this.dataset.selectText);
      }

      updateMyStoreWithLocation(location) {
        if (!location) return;
        this.removeButtonEvents();
        const {
          name,
          address,
          email,
          hours,
          phoneOverride,
          id,
          distance,
        } = location;
        this.preferredStoreId = id;
        this.button.disabled = false;
        this.button.querySelector(this.dom.info).textContent = name;
        this.button.addEventListener('click', this.onClickToggleDetails);

        function resetValue(element, attribute = false) {
          if (!element) return;

          element.value = '';
          if (attribute) {
            element.setAttribute(attribute, '');
          }
        }

        this.updateFacets(name);
        this.updateSelectedLocationAttributes(name);

        this.details.querySelector('.my-store-locator__details-title').textContent = name;
        this.detailsLocation.textContent = address?.city && address?.provinceCode ? (`${address.city}, ${address.provinceCode}`) : (`${address.city}`);
        if (address?.phone && address?.phone !== '') {
          this.detailsTelephone.classList.remove('hidden');
          const phoneLink = this.detailsTelephone.querySelector('a');
          phoneLink.href = `tel:${address.phone}`;
          phoneLink.textContent = address.phone;
        } else {
          const phoneLink = this.detailsTelephone.querySelector('a');
          resetValue(phoneLink, 'href');
          this.detailsTelephone.classList.add('hidden');
        }
        if (phoneOverride?.value && phoneOverride?.value !== '') {
          this.detailsTelephone.classList.remove('hidden');
          const phoneLink = this.detailsTelephone.querySelector('a');
          phoneLink.href = `tel:${phoneOverride.value}`;
          phoneLink.textContent = phoneOverride.value;
        }
        if (address?.address1 && address?.address1 !== '') {
          this.detailsAddress.classList.remove('hidden');
          const apiProvider = SDG?.Data?.mapProvider  || null;
          const addressLink = this.detailsAddress.querySelector('a');
          addressLink.textContent = address.address1;
          const encodedName = encodeURIComponent(name);
          const latitude = address.latitude;
          const longitude = address.longitude;

          if (apiProvider === 'google_maps') {
            const href = `https://www.google.com/maps/search/?api=1&query=${encodedName}`;
            addressLink.href = href;
          }

          if (apiProvider === 'apple_maps') {
            const encodedAddress = encodeURIComponent(address.formatted);
            const href = `https://maps.apple.com/place?q=${encodedName}&address=${encodedAddress}&ll=${latitude},${longitude}`;
            addressLink.href = href;
          }
        } else {
          const addressLink = this.detailsAddress.querySelector('a');
          resetValue(addressLink, 'href');
          this.detailsAddress.classList.add('hidden');
        }
        if (email?.value && email?.value !== '') {
          this.detailsEmail.classList.remove('hidden');
          const emailLink = this.detailsEmail.querySelector('a');
          emailLink.href = `mailto:${email.value}`;
          emailLink.textContent = email.value;
        } else {
          const emailLink = this.detailsEmail.querySelector('a');
          resetValue(emailLink, 'href');
          this.detailsEmail.classList.add('hidden');
        }
        if (hours?.value && hours?.value !== '') {
          this.detailsHours.classList.remove('hidden');
          const hoursSpan = this.detailsHours.querySelector('span');
          hoursSpan.textContent = hours.value;
        } else {
          const hoursSpan = this.detailsHours.querySelector('span');
          resetValue(hoursSpan);
          this.detailsHours.classList.add('hidden');
        }
        if (location?.services_html) {
          const parser = new DOMParser();
          const servicesHtml = parser.parseFromString(location.services_html, "text/html");
          const servicesLinks = servicesHtml.querySelectorAll('a');
          let localizedServices;

          // Update url with locale
          if (servicesLinks && servicesLinks.length > 0) {
            Array.from(servicesLinks).forEach((link) => {
              const href = link.getAttribute('href');
              const slashIndex = href.indexOf('/');

              if (slashIndex === 0) {
                const localizedUrl = this.localizeUrl(href);
                link.setAttribute('href', localizedUrl);
                link.classList.add('apl-section-stores-locator-store-services-link');
              }
            });
          }

          localizedServices = servicesHtml.body.innerHTML;

          this.detailsServices.classList.remove('hidden');
          this.detailsServices.innerHTML = `
            <button class="my-location-result__services-btn js-acc-button apl-section-stores-locator-store-services-btn" type="button">
              <span class="underlined-text">${SDG?.Data?.storeServiceTrigger ? SDG.Data.storeServiceTrigger : 'View store services'}</span>
              <i class="js-acc-icon myarrow fa fa-chevron-down my-location-result__services-icon" aria-hidden="true"></i>
            </button>
            <div class="my-location-result__services js-acc-details" aria-expanded="false">${localizedServices}</div>
          `;
          const $accButton = this.detailsServices.querySelector('.js-acc-button');
          const $accDetails = this.detailsServices.querySelector('.js-acc-details');
          const $accIcon = this.detailsServices.querySelector('.js-acc-icon');

          function openAcc(el) {
            el.setAttribute('aria-expanded', 'true')
            el.classList.add('is-active');
          }

          function closeAcc(el) {
            el.setAttribute('aria-expanded', 'false')
            el.classList.remove('is-active');
          }

          $accButton.addEventListener('click', () => {
            if ($accDetails.classList.contains('is-active')) {
              closeAcc($accDetails);
              if ($accIcon) closeAcc($accIcon);
            } else {
              openAcc($accDetails);
              if ($accIcon) openAcc($accIcon);
            }
          });
        } else {
          this.detailsServices.classList.add('hidden');
        }

        this.updateMyStoreDistance(distance);

        if (this.mobileLocator) {
          this.mobileLocator.updateMyStoreWithLocation(location);
        }

        const pickupAvailabilities = document.querySelectorAll(this.dom.pickupAvailability);
        if (pickupAvailabilities.length > 0) {
          pickupAvailabilities.forEach((pickupAvailability) => {
            pickupAvailability.renderPreview(location);
          });
        }
      }

      updateMyStoreDistance(distance) {
        if (distance) {
          this.distance.textContent = distance;
          this.distance.classList.remove('hidden');
          if (this.mobileLocator?.distance) {
            this.mobileLocator.distance.textContent = distance;
            this.mobileLocator.distance.classList.remove('hidden');
          }
        } else {
          this.distance.classList.add('hidden');
          if (this.mobileLocator?.distance) {
            this.mobileLocator.distance.classList.add('hidden');
          }
        }
      }

      // https://stackoverflow.com/questions/27928/calculate-distance-between-two-latitude-longitude-points-haversine-formula
      getDistanceFromLatLon(lat1, lon1, lat2, lon2) {
        var R = 6371; // Radius of the earth in km
        var dLat = this.deg2rad(lat2-lat1);
        var dLon = this.deg2rad(lon2-lon1);
        var a =
          Math.sin(dLat/2) * Math.sin(dLat/2) +
          Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) *
          Math.sin(dLon/2) * Math.sin(dLon/2)
          ;
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        var d = R * c; // Distance in km
        return this.getDistanceFromKm(d);
      }

      deg2rad(deg) {
        return deg * (Math.PI/180)
      }

      calculateStoreDistance(locationAddress) {
        if (
          this.myCoords?.latitude &&
          this.myCoords?.longitude &&
          locationAddress?.latitude &&
          locationAddress?.longitude
        ) {
          return this.getDistanceFromLatLon(
            this.myCoords.latitude,
            this.myCoords.longitude,
            locationAddress.latitude,
            locationAddress.longitude,
          );
        } else {
          return null;
        }
      }

      /**
       * Fetch data from Shopify Storefront API
       */
      async fetchStorefrontApi(query, variables = {}) {
        const endpoint = `https://${Shopify.shop}/api/2024-07/graphql.json`;
        // abort a request that gets no response so the caller can show the error state
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);

        try {
          const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Shopify-Storefront-Access-Token': this.dataset.storefrontApiAccessToken,
            },
            body: JSON.stringify({ query, variables }),
            signal: controller.signal,
          });

          const { data, errors } = await response.json();

          if (errors) {
            throw new Error(errors[0]?.message || 'Storefront API error');
          }

          return data;
        } finally {
          clearTimeout(timeoutId);
        }
      }

      disconnectedCallback() {
        this.facetsObserver?.disconnect();
        document.body.removeEventListener('click', this.onBodyClick);
      }
    }
  );
}

if (!customElements.get('my-store-locator-mobile') ) {
  customElements.define(
    'my-store-locator-mobile',
    class MyStoreLocatorMobile extends HTMLElement {
      constructor() {
        super();

        this.dom = {
          desktop: 'my-store-locator',
          btn: '.js-my-store-locator-btn',
          drawerBtn: '.js-my-store-locator-drawer-btn',
          info: '.js-my-store-locator-info',
          details: '.js-my-store-locator-details',
          close: '.js-my-store-locator-close',
          location: '.js-my-store-locator-location',
          telephone: '.js-my-store-locator-telephone',
          email: '.js-my-store-locator-email',
          address: '.js-my-store-locator-address',
          hours: '.js-my-store-locator-hours',
          services: '.js-my-store-locator-services',
          distance: '.js-my-store-locator-distance',
        };

        this.desktopLocator = document.querySelector(this.dom.desktop);
        this.button = this.querySelector(this.dom.btn);
        this.drawerBtn = this.querySelector(this.dom.drawerBtn);
        if (this.drawerBtn) this.drawerBtn.addEventListener('click', this.onClickShowStoreSelector.bind(this));
        this.details = this.querySelector(this.dom.details);
        this.detailsClose = this.details?.querySelector(this.dom.close) || null;
        if (this.detailsClose) this.detailsClose.addEventListener('click', this.hideDetails.bind(this));
        this.detailsLocation = this.details?.querySelector(this.dom.location) || null;
        this.detailsTelephone = this.details?.querySelector(this.dom.telephone) || null;
        this.detailsEmail = this.details?.querySelector(this.dom.email) || null;
        this.detailsAddress = this.details?.querySelector(this.dom.address) || null;
        this.detailsHours = this.details?.querySelector(this.dom.hours) || null;
        this.detailsServices = this.details?.querySelector(this.dom.services) || null;
        this.distance = this.details?.querySelector(this.dom.distance) || null;

        this.onBodyClick = this.handleBodyClick.bind(this);
        this.onClickRefreshList = this.onClickRefreshList.bind(this);
        this.onClickToggleDetails = this.onClickToggleDetails.bind(this);
        this.onClickShowStoreSelector = this.onClickShowStoreSelector.bind(this);

        this.addEventListener('keyup', (event) => {
          if (event.code.toUpperCase() === 'ESCAPE') this.hideDetails();
        });
      }

      localizeUrl($url) {
        const rootWithoutEndingSlash = Shopify.routes.root.slice(0, -1);
        const urlParts = $url.split('/');
        urlParts[0] = rootWithoutEndingSlash;
        return urlParts.join('/');
      }

      onClickRefreshList(evt) {
        evt.currentTarget.disabled = true;
        this.desktopLocator.renderLoading();
        this.desktopLocator.init();
      }

      onClickToggleDetails() {
        if (this.details.hasAttribute('open')) {
          this.hideDetails();
        } else {
          this.showDetails();
        }
      }

      onClickShowStoreSelector(evt) {
        document.querySelector('my-store-locator-drawer').show(evt.currentTarget);
      }

      handleBodyClick(evt) {
        const target = evt.target;
        if (
          target != this.details &&
          !target.closest(this.dom.btn) &&
          !target.closest(this.dom.details)
        ) {
          this.hideDetails();
        }
      }

      hideDetails() {
        this.details.removeAttribute('open');
        this.details.hidden = true;
        document.body.removeEventListener('click', this.onBodyClick);
        removeTrapFocus(this.focusElement);
        this.details?.closest('.my-store-locator').querySelector(this.dom.btn)?.focus();
      }

      showDetails(focusElement) {
        // hide mobile menu if open
        const menuDrawer = document.getElementById('Details-menu-drawer-container');
        if (menuDrawer && menuDrawer?.hasAttribute('open')) {
          menuDrawer.querySelector('summary').click();
        }
        this.focusElement = focusElement;
        this.details.setAttribute('open', '');
        this.details.hidden = false;
        document.body.addEventListener('click', this.onBodyClick);
        trapFocus(this.details);
      }

      removeButtonEvents() {
        this.button.removeEventListener('click', this.onClickRefreshList);
        this.button.removeEventListener('click', this.onClickToggleDetails);
        this.button.removeEventListener('click', this.onClickShowStoreSelector);
      }

      renderLoading(loadingText) {
        if (!this.button) return;
        this.button.disabled = true;
        const info = this.button.querySelector(this.dom.info);
        if (info) info.innerHTML = `${loadingText} <i class="fa fa-spinner fa-spin"></i>`;
      }

      renderError() {
        this.removeButtonEvents();
        if (!this.button) return;
        this.button.disabled = false;
        const info = this.button.querySelector(this.dom.info);
        if (info) info.innerHTML = this.dataset.errorText;
        this.button.addEventListener('click', this.onClickRefreshList);
      }

      renderSelectYourStore() {
        this.removeButtonEvents();
        if (!this.button) return;
        this.button.disabled = false;
        const info = this.button.querySelector(this.dom.info);
        if (info) info.innerHTML = this.dataset.selectText;
        this.button.addEventListener('click', this.onClickShowStoreSelector);
      }

      updateMyStoreWithLocation(location) {
        this.removeButtonEvents();
        const { name, address, email, hours, phoneOverride } = location;
        this.button.disabled = false;
        this.button.querySelector(this.dom.info).textContent = name;
        this.button.addEventListener('click', this.onClickToggleDetails);

        function resetValue(element, attribute = false) {
          if (!element) return;

          element.value = '';
          if (attribute) {
            element.setAttribute(attribute, '');
          }
        }

        this.details.querySelector('.my-store-locator__details-title').textContent = name;
        this.detailsLocation.textContent = address?.city && address?.provinceCode ? (`${address.city}, ${address.provinceCode}`) : (`${address.city}`);
        if (address?.phone && address?.phone !== '') {
          this.detailsTelephone.classList.remove('hidden');
          const phoneLink = this.detailsTelephone.querySelector('a');
          phoneLink.href = `tel:${address.phone}`;
          phoneLink.textContent = address.phone;
        } else {
          const phoneLink = this.detailsTelephone.querySelector('a');
          resetValue(phoneLink, 'href');
          this.detailsTelephone.classList.add('hidden');
        }
        if (phoneOverride?.value && phoneOverride?.value !== '') {
          this.detailsTelephone.classList.remove('hidden');
          const phoneLink = this.detailsTelephone.querySelector('a');
          phoneLink.href = `tel:${phoneOverride.value}`;
          phoneLink.textContent = phoneOverride.value;
        }
        if (address?.address1 && address?.address1 !== '') {
          this.detailsAddress.classList.remove('hidden');
          const apiProvider = SDG?.Data?.mapProvider  || null;
          const addressLink = this.detailsAddress.querySelector('a');
          addressLink.textContent = address.address1;
          const encodedName = encodeURIComponent(name);
          const latitude = address.latitude;
          const longitude = address.longitude;

          if (apiProvider === 'google_maps') {
            const href = `https://www.google.com/maps/search/?api=1&query=${encodedName}`;
            addressLink.href = href;
          }

          if (apiProvider === 'apple_maps') {
            const encodedAddress = encodeURIComponent(address.formatted);
            const href = `https://maps.apple.com/place?q=${encodedName}&address=${encodedAddress}&ll=${latitude},${longitude}`;
            addressLink.href = href;
          }
        } else {
          const addressLink = this.detailsAddress.querySelector('a');
          resetValue(addressLink, 'href');
          this.detailsAddress.classList.add('hidden');
        }
        if (email?.value && email?.value !== '') {
          this.detailsEmail.classList.remove('hidden');
          const emailLink = this.detailsEmail.querySelector('a');
          emailLink.href = `mailto:${email.value}`;
          emailLink.textContent = email.value;
        } else {
          const emailLink = this.detailsEmail.querySelector('a');
          resetValue(emailLink, 'href');
          this.detailsEmail.classList.add('hidden');
        }
        if (hours?.value && hours?.value !== '') {
          this.detailsHours.classList.remove('hidden');
          const hoursSpan = this.detailsHours.querySelector('span');
          hoursSpan.textContent = hours.value;
        } else {
          const hoursSpan = this.detailsHours.querySelector('span');
          resetValue(hoursSpan);
          this.detailsHours.classList.add('hidden');
        }

        if (location?.services_html) {
          const parser = new DOMParser();
          const servicesHtml = parser.parseFromString(location.services_html, "text/html");
          const servicesLinks = servicesHtml.querySelectorAll('a');
          let localizedServices;

          // Update url with locale
          if (servicesLinks && servicesLinks.length > 0) {
            Array.from(servicesLinks).forEach((link) => {
              const href = link.getAttribute('href');
              const slashIndex = href.indexOf('/');

              if (slashIndex === 0) {
                const localizedUrl = this.localizeUrl(href);
                link.setAttribute('href', localizedUrl);
                link.classList.add('apl-section-stores-locator-store-services-link');
              }
            });
          }

          localizedServices = servicesHtml.body.innerHTML;

          this.detailsServices.classList.remove('hidden');
          this.detailsServices.innerHTML = `
            <button class="my-location-result__services-btn js-acc-button apl-section-stores-locator-store-services-btn" type="button">
              <span class="underlined-text">${SDG?.Data?.storeServiceTrigger ? SDG.Data.storeServiceTrigger : 'View store services'}</span>
              <i class="js-acc-icon myarrow fa fa-chevron-down my-location-result__services-icon" aria-hidden="true"></i>
            </button>
            <div class="my-location-result__services js-acc-details" aria-expanded="false">${localizedServices}</div>
          `;
          const $accButton = this.detailsServices.querySelector('.js-acc-button');
          const $accDetails = this.detailsServices.querySelector('.js-acc-details');
          const $accIcon = this.detailsServices.querySelector('.js-acc-icon');

          function openAcc(el) {
            el.setAttribute('aria-expanded', 'true')
            el.classList.add('is-active');
          }

          function closeAcc(el) {
            el.setAttribute('aria-expanded', 'false')
            el.classList.remove('is-active');
          }

          $accButton.addEventListener('click', () => {
            if ($accDetails.classList.contains('is-active')) {
              closeAcc($accDetails);
              if ($accIcon) closeAcc($accIcon);
            } else {
              openAcc($accDetails);
              if ($accIcon) openAcc($accIcon);
            }
          });
        } else {
          this.detailsServices.classList.add('hidden');
        }
      }
    }
  );
}

if (!customElements.get('my-store-locator-drawer') ) {
  customElements.define(
    'my-store-locator-drawer',
    class MyStoreLocatorDrawer extends HTMLElement {
      constructor() {
        super();

        this.dom = {
          storeLocatorSearch: 'storeLocatorSearch',
          form: 'storeLocatorSearchForm',
          storeLocator: 'my-store-locator',
          suggestions: '.js-store-locator-search-suggestions',
          error: '.js-store-locator-search-error',
          loading: 'storeLocatorDrawerLoading',
          results: 'myLocationResults',
          resultsCount: '.js-store-locator-results-count',
          activeResult: '.js-my-location-result[data-active="true"]',
          close: '.js-store-locator-drawer-close',
          useLocationBtn: '.js-store-locator-use-location-btn',
          resultsDistance: '.js-store-locator-results-distance',
          selectBtn: '.js-store-locator-select-btn',
          productInfo: '.js-store-locator-product-info',
          acc_button: '.js-acc-button',
          acc_icon: '.js-acc-icon',
          acc_details: '.js-acc-details',
        };
        this.cls = {
          active: 'is-active',
        };

        this.form = document.getElementById(this.dom.form);
        this.results = document.getElementById(this.dom.results);
        this.resultsCount = this.querySelector(this.dom.resultsCount);
        this.resultsDistance = this.querySelector(this.dom.resultsDistance);
        this.storeLocatorSearch = document.getElementById(this.dom.storeLocatorSearch);
        this.storeLocator = document.querySelector(this.dom.storeLocator);
        this.suggestions = this.querySelector(this.dom.suggestions);
        this.error = this.querySelector(this.dom.error);
        this.loading = document.getElementById(this.dom.loading);
        this.close = this.querySelector(this.dom.close);
        this.useLocationBtn = this.querySelector(this.dom.useLocationBtn);
        this.selectBtn = this.querySelector(this.dom.selectBtn);

        this.onBodyClick = this.handleBodyClick.bind(this);

        this._isKeyboardUser = false;
        this._onDocMousedown = () => { this._isKeyboardUser = false; };
        this._onDocKeydown = () => { this._isKeyboardUser = true; };
        // Listeners are attached in connectedCallback (and removed in disconnectedCallback)
        // so that the lifecycle is symmetric and reconnects don't duplicate them.

        this.close.addEventListener('click', () => {
          this.hide();
        });

        this.useLocationBtn.addEventListener('click', () => {
          this.useLocation();
        });

        this.selectBtn.addEventListener('click', this.selectPreferredLocation.bind(this));

        this.addEventListener('keyup', (event) => {
          if (event.code.toUpperCase() === 'ESCAPE') this.hide();
        });

        this.init();
      }

      connectedCallback() {
        if (this._onDocMousedown) document.addEventListener('mousedown', this._onDocMousedown);
        if (this._onDocKeydown) document.addEventListener('keydown', this._onDocKeydown);
      }

      disconnectedCallback() {
        if (this._onDocMousedown) document.removeEventListener('mousedown', this._onDocMousedown);
        if (this._onDocKeydown) document.removeEventListener('keydown', this._onDocKeydown);
      }

      init() {
        // update title for CTO pages
        const urlParams = new URLSearchParams(window.location.search);
        const ctoParam = urlParams.get('pdp-2.0') || urlParams.get('cto');
        if (ctoParam) {
          const $myStoreLocatorDrawerHeading = document.getElementById('MyStoreLocatorDrawerHeading');
          if ($myStoreLocatorDrawerHeading?.dataset?.availabilityTitle && $myStoreLocatorDrawerHeading?.dataset?.availabilityTitle !== '') {
            $myStoreLocatorDrawerHeading.innerText = $myStoreLocatorDrawerHeading.dataset.availabilityTitle;
          }
        }

        this.form.addEventListener('submit', (event) => {
          event.preventDefault();
          this.searchLocations();
        });

        this.resultsDistance.addEventListener('change', () => {
          this.searchLocations(true);
        });

        this.storeLocatorSearch.onkeyup = debounce(this.storeLocatorSearchOnKeyUp.bind(this), 200);

        // Hide suggestions when the input loses focus
        this.storeLocatorSearch.onblur = () => {
          setTimeout(() => {
            if (!this.suggestions.contains(document.activeElement)) {
              this.suggestions.classList.add('hidden');
            }
          }, 500);
        };
      }

      async storeLocatorSearchOnKeyUp(e) {
        const userData = e.target.value;
        let emptyArray = [];
        if(userData && e.code.toUpperCase() !== 'ENTER'){
          emptyArray = await this.getPlaceSuggestions(userData);
          if(emptyArray.length > 0){
            this.suggestions.replaceChildren();
            emptyArray.forEach((data) => {
              const button = document.createElement('button');
              if (typeof data === 'object') {
                button.dataset.latitude = data.latitude;
                button.dataset.longitude = data.longitude;
                button.textContent = data.title;
              } else {
                button.textContent = data;
              }
              button.addEventListener('click', (e) => {
                this.selectSuggestion(e.target);
              });
              this.suggestions.appendChild(button);
            });
            this.suggestions.classList.remove('hidden');
          } else {
            this.suggestions.classList.add('hidden');
          }
        } else{
          this.suggestions.classList.add('hidden');
        }
      }

      localizeUrl($url) {
        const rootWithoutEndingSlash = Shopify.routes.root.slice(0, -1);
        const urlParts = $url.split('/');
        urlParts[0] = rootWithoutEndingSlash;
        return urlParts.join('/');
      }

      getPlaceSuggestions(address) {
        const apiProvider = SDG?.Data?.mapProvider || null;
        const countriesLimit = this.storeLocator.dataset.limitSearchToCountries;
        if (apiProvider === 'google_maps') {
          return new Promise((resolve, reject) => {
            const componentRestrictions = countriesLimit !== '' ? {
              country: countriesLimit.split(',')
            } : null;
            const autocompleteService = new google.maps.places.AutocompleteService();
            const request = {
              input: address,
              types: ["(regions)"],
              componentRestrictions,
            };

            autocompleteService.getPlacePredictions(request, (predictions, status) => {
              if (status === google.maps.places.PlacesServiceStatus.OK) {
                const suggestions = predictions.map((prediction) => prediction.description);
                resolve(suggestions);
              } else {
                resolve([]);
              }
            });
          });
        } else if (apiProvider === 'apple_maps') {
          return new Promise((resolve, reject) => {
            const limitToCountries = countriesLimit !== '' ? countriesLimit : null;
            const search = new mapkit.Search({
              getsUserLocation: true,
              includeAddresses: true,
              includePointsOfInterest: false,
              includeQueries: false,
              limitToCountries,
            });
            search.autocomplete(address, (error, data) => {
              if (!error) {
                const suggestions = data?.results?.map((result) => {
                  return {
                    title: result.displayLines[0],
                    latitude: result.coordinate.latitude,
                    longitude: result.coordinate.longitude,
                  }
                });
                resolve(suggestions);
              } else {
                resolve([]);
              }
            });
          });
        }
      }

      selectPreferredLocation() {
        const activeResult = this.querySelector(this.dom.activeResult);
        if (activeResult) {
          const id = activeResult.dataset.id;
          if (this.storeLocator.allLocationsData) {
            const location = this.storeLocator.allLocationsData.find((location) => location.id === id);
            if (location) {
              if (this.storeLocator.storageAvailable('localStorage')) {
                localStorage.setItem('preferredStoreId', location.id);
              }
              this.storeLocator.updateMyStoreWithLocation(location);
              // reset the drawer
              this.searchLocations(true);
              this.hide();
              // clear cached bopis location selected option on the checkout
              localStorage.removeItem("__ui");
            }
          }
        }
      }

      useLocation() {
        this.storeLocatorSearch.value = '';
        this.loading.classList.remove('hidden');
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            this.updateDrawerStoreDetails.bind(this),
            this.updateDrawerStoreDetails.bind(this)
          );
        } else {
          this.updateDrawerStoreDetails();
        }
      }

      updateDrawerStoreDetails(position) {
        if (position) {
          this.storeLocator.setSecureCookie('location_sharing', 'true', this.storeLocator.expiry);
          this.storeLocator.setSecureCookie('location_position', JSON.stringify(position), this.storeLocator.expiry);
        }
        this.storeLocator.fetchLocations(position, false, () => {
          this.loading.classList.add('hidden');
        });
      }

      selectSuggestion(element){
        let selectData = element.textContent;
        this.storeLocatorSearch.value = selectData.trim();
        this.suggestions.classList.add('hidden');
        this.searchLocations(false, element.dataset);
      }

      getObjects(obj, key, val) {
        const objects = obj.filter((location) => {
          const locationData = location.address;
          if(locationData && locationData[key]){
            return locationData[key].toLowerCase() === val?.toLowerCase();
          } else {
            return null;
          }
        });
        return objects;
      }

      async searchLocations(noErrors = false, dataset = null) {
        let allLocationsData = this.storeLocator.allLocationsData;
        // check if any selected item locations exist
        if (this.selectedItemLocationsKey) {
          const selectedItemLocationsData = this.storeLocator.itemLocationsData[this.selectedItemLocationsKey];
          if (selectedItemLocationsData) {
            allLocationsData = selectedItemLocationsData;
          }
        }
        let searchLocation = this.storeLocatorSearch.value;
        searchLocation = searchLocation.trim();
        if (noErrors) {
          this.error.classList.add('hidden');
        } else {
          if(searchLocation === '') {
            this.error.classList.remove('hidden');
            return;
          } else {
            this.error.classList.add('hidden');
          }
        }
        this.loading.classList.add('hidden');

        // check if clicked on location with latitude and longitude
        if (dataset && dataset.latitude && dataset.longitude) {
          this.updateDrawerStoreDetails({
            coords: {
              latitude: parseFloat(dataset.latitude),
              longitude: parseFloat(dataset.longitude),
            }
          });
          return;
        }
        const geocodedPosition = await this.geocodePosition(searchLocation);
        if (geocodedPosition) {
          this.updateDrawerStoreDetails(geocodedPosition);
        } else {
          let storeDetails = [];
          let searchCity = this.getObjects(allLocationsData, 'city', searchLocation);
          let searchZipcode = this.getObjects(allLocationsData, 'zip', searchLocation);
          let searchProvince = this.getObjects(allLocationsData, 'province', searchLocation);
          let country = this.getObjects(allLocationsData, 'country', searchLocation);
          // check if search value matches a location exactly
          if(searchCity.length > 0 || searchZipcode.length > 0 || searchProvince.length > 0 || country.length > 0 ){
            if(searchCity.length > 0){
              storeDetails = searchCity;
            }else if(searchProvince.length > 0){
              storeDetails = searchProvince;
            }else if(searchZipcode.length > 0){
              storeDetails = searchZipcode;
            }else if(country.length > 0){
              storeDetails = country;
            }
            this.updateStoreDetails(storeDetails, searchLocation);
          } else {
            // If we have a suggestion, use the first one
            if (!this.suggestions.classList.contains('hidden')) {
              const firstSuggestion = this.suggestions.querySelector('button') || null;
              if (firstSuggestion) {
                this.selectSuggestion(firstSuggestion);
                return;
              }
            }

            // if coming from distance filter, use all locations
            if (noErrors) {
              storeDetails = allLocationsData;
            }

            if (searchLocation) {
              this.updateStoreDetails([], searchLocation);
            } else {
              this.updateStoreDetails(storeDetails, searchLocation);
            }
          }
        }
      }

      geocodePosition(address) {
        const apiProvider = SDG?.Data?.mapProvider  || null;
        if (apiProvider === 'google_maps') {
          return new Promise((resolve, reject) => {
            const geocoder = new google.maps.Geocoder();
            geocoder.geocode({ address }, (results, status) => {
              if (status === 'OK') {
                const latitude = results?.[0]?.geometry?.location?.lat();
                const longitude = results?.[0]?.geometry?.location?.lng();
                if (latitude && longitude) {
                  const position = {
                    coords: {
                      latitude,
                      longitude,
                    },
                    timestamp: Date.now(),
                  }
                  resolve(position);
                }
              }
              resolve(null);
            });
          });
        } else if (apiProvider === 'apple_maps') {
          return new Promise((resolve, reject) => {
            const geocoder = new mapkit.Geocoder();
            geocoder.lookup(address, (error, data) => {
              if (!error) {
                const result = data?.results?.[0];
                const latitude = result?.coordinate?.latitude;
                const longitude = result?.coordinate?.longitude;
                if (latitude && longitude) {
                  const position = {
                    coords: {
                      latitude,
                      longitude,
                    },
                    timestamp: Date.now(),
                  };
                  resolve(position);
                }
              }
              resolve(null);
            });
          });
        }
      }

      updateStoreDetails(locationData, nearbyValue) {
        let resultCount = 0;
        const { mapPage } = SDG.Data || false;

        // move active location to top of list
        const activeIndex = locationData.findIndex(location => location.id === this.storeLocator.preferredStoreId);
        if (activeIndex > -1) {
          locationData.splice(0, 0, locationData.splice(activeIndex, 1)[0]);
        }

        this.results.innerHTML = '';

        const escapeHtml = (value) =>
          String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

        function setCityAndStateHTML(location) {
          const { address } = location || null;
          let html;

          if (!address) return;

          if (address?.city && address?.provinceCode) {
            html = `${escapeHtml(address.city)}, ${escapeHtml(address.provinceCode)}`
            return html;
          }

          if (address?.city && !address?.provinceCode) {
            html = `${escapeHtml(address.city)}`;
            return html;
          }
        }

        locationData.forEach((location) => {
          // check if location is within distance
          if (location.distance) {
            this.resultsDistance.classList.remove('hidden');
            if (this.resultsDistance.value !== 'all') {
              // location.distance is a locale-formatted display string (e.g. "5,3 km");
              // normalize a comma decimal to a dot so parseFloat doesn't truncate at the comma
              const parsedLocationDistance = parseFloat(String(location.distance).replace(',', '.'));
              const parsedDistance = parseFloat(this.resultsDistance.value);
              if (parsedLocationDistance > parsedDistance) {
                return;
              }
            }
          } else {
            this.resultsDistance.classList.add('hidden');
          }

          let bundleAvailable = true;

          const selectedBundle = document.querySelector('input.js-cto-set-price-display:checked')

          if (selectedBundle) {
            if (!location.available) {
              bundleAvailable = false;
            }

            const selectedBundleSecondaryProductId = selectedBundle.dataset.pairedProductId;

            const selectedBundleSecondaryProductLocationData = this.storeLocator.locationsData
              ?.find((item) => item.productId.includes(selectedBundleSecondaryProductId))?.locationData;

            const selectedBundleSecondaryProductLocation = selectedBundleSecondaryProductLocationData
              ?.find((item) => item.id === location.id)

            if ((selectedBundleSecondaryProductLocation && !selectedBundleSecondaryProductLocation.available) || !selectedBundleSecondaryProductLocation) {
              bundleAvailable = false;
            }
          }

          if (window.location.href.includes('/cart') && this.selectedItemLocationsKey) {
            const itemKey = this.selectedItemLocationsKey;
            const bundleSecondaryProductElement = document.querySelector(`[data-item-key="secondary${itemKey}"]`);

            if(bundleSecondaryProductElement) {
              if (!location.available) {
                bundleAvailable = false;
              }

              const bundleSecondaryProductKey = bundleSecondaryProductElement.dataset.itemKey;

              const bundleSecondaryProductLocationsData = this.storeLocator.itemLocationsData[bundleSecondaryProductKey];

              const bundleSecondaryProductLocation = bundleSecondaryProductLocationsData.find((itemLocation) => itemLocation.id === location.id);

              if ((bundleSecondaryProductLocation && !bundleSecondaryProductLocation.available) || !bundleSecondaryProductLocation) {
                bundleAvailable = false;
              }
            }

            const gwpProductElements = document.querySelectorAll(`[data-item-key^="gwp${itemKey}_"]`);
            if (gwpProductElements.length > 0) {
              if (!location.available) {
                bundleAvailable = false;
              }
              gwpProductElements.forEach((gwpEl) => {
                const gwpKey = gwpEl.dataset.itemKey;
                const gwpLocationsData = this.storeLocator.itemLocationsData[gwpKey];
                const gwpLocation = gwpLocationsData?.find((itemLocation) => itemLocation.id === location.id);
                if ((gwpLocation && !gwpLocation.available) || !gwpLocation) {
                  bundleAvailable = false;
                }
              });
            }
          }

          const isActive = location.id === this.storeLocator.preferredStoreId;
          let availabilityHtml = '';

          const $ctoPickupElement = this.selectedItemLocationsKey
            ? document.querySelector(`pickup-availability[data-message-type][data-item-key="${this.selectedItemLocationsKey}"]`)
            : document.querySelector('pickup-availability[data-message-type]')
          let overridePickupMessage = $ctoPickupElement?.dataset?.overridePickupMessage;
          const messageType = $ctoPickupElement?.dataset?.messageType;
          if (!overridePickupMessage && messageType) {
            const languageKey = SDG.Data.language?.toLowerCase() || 'en';
            const pickupMessagesJson = safeJsonParse(location.pickupMessages?.value);
            const pickupMessages = pickupMessagesJson?.[languageKey] || pickupMessagesJson?.['en'];
            switch(messageType) {
              case 'cto':
                overridePickupMessage = pickupMessages?.cto;
                break;
              case 'preorder':
                overridePickupMessage = pickupMessages?.preOrder;
                break;
              case 'in stock':
                overridePickupMessage = pickupMessages?.inStock;
                break;
            }
          }

          let isPreSale;
          try {
            isPreSale = JSON.parse(this.querySelector(this.dom.productInfo)?.dataset?.isPreSale || 'false');
          } catch (e) {
            isPreSale = false;
          }

          if (safeJsonParse(location.enableToggles?.value)?.checkoutEnabled === false) {
            const overrideUnavailableMessage = $ctoPickupElement?.dataset?.overrideUnavailableMessage;
            availabilityHtml = `
              <div class="my-location-result__availability">
                ${overrideUnavailableMessage ? `<span>${overrideUnavailableMessage}</span>` : this.storeLocator.dataset.unavailableText}
              </div>
            `;
          } else if (overridePickupMessage && location.productPickupOfferedAtLocation && !(messageType === 'in stock' && !location.available) && bundleAvailable && isPreSale === false) {
            availabilityHtml = `
              <div class="my-location-result__availability">
                <div class="my-location-result__availability-time my-location-result__availability-time--overridden">${overridePickupMessage}</div>
              </div>
            `;
          } else if (location.available && bundleAvailable && isPreSale === false) {
            let stockHtml = '';

            let pickUpTimeTranslated = '';
            if (location.pickUpTime) {
              const key = location.pickUpTime;
              const languageKey = SDG.Data.language?.toLowerCase() || 'en';
              pickUpTimeTranslated = window.deliveryOptionsStrings?.[languageKey]?.[key] || location.pickUpTime;
            }

            if (location.quantityAvailable < 10) {
              const stockText = this.storeLocator.dataset.lowStockHtml.replace('{{ quantity }}', location.quantityAvailable);
              stockHtml = `
                <div class="my-location-result__availability-stock">${stockText}</div>
              `;
            }
            availabilityHtml = `
              <div class="my-location-result__availability">
                <div class="my-location-result__availability-time">${pickUpTimeTranslated}</div>
                ${stockHtml}
              </div>
            `;
          } else if (location.available === false || bundleAvailable === false || isPreSale === true) {
            const overrideUnavailableMessage = $ctoPickupElement?.dataset?.overrideUnavailableMessage;
            availabilityHtml = `
              <div class="my-location-result__availability">
                ${overrideUnavailableMessage ? `<span>${overrideUnavailableMessage}</span>` : this.storeLocator.dataset.unavailableText}
              </div>
            `;
          }
          let itemKeyAttr = '';
          if (location.itemKey) {
            itemKeyAttr = `data-item-key="${location.itemKey}"`;
          }
          let resultHtml;
          const { address, name } = location || null;
          const apiProvider = SDG?.Data?.mapProvider  || null;

          if (!address) return;
          const { latitude, longitude } = address || null;

          let locationImageHtml = '';
          let serviceHtml = '';
          let telephoneVal = null;
          let calloutHref = null;
          let addressHref = null;
          let url = window.location.href;

          if (location?.services_html) {
            const parser = new DOMParser();
            const servicesHtml = parser.parseFromString(location.services_html, "text/html");
            const servicesLinks = servicesHtml.querySelectorAll('a');
            let localizedServices;

            // Update url with locale
            if (servicesLinks && servicesLinks.length > 0) {
              Array.from(servicesLinks).forEach((link) => {
                const href = link.getAttribute('href');
                const slashIndex = href.indexOf('/');

                if (slashIndex === 0) {
                  const localizedUrl = this.localizeUrl(href);
                  link.setAttribute('href', localizedUrl);
                  link.classList.add('apl-section-stores-locator-store-services-link');
                }
              });
            }

            localizedServices = servicesHtml.body.innerHTML;

            if (url.includes('store-locator')) {
              serviceHtml = `
                <button class="my-location-result__services-btn js-acc-button apl-section-stores-locator-store-services-btn" type="button">
                  <span class="underlined-text">${SDG?.Data?.storeServiceTrigger ? SDG.Data.storeServiceTrigger : 'View store services'}</span>
                  <i class="myarrow fa fa-chevron-down my-location-result__services-icon js-acc-icon" aria-hidden="true"></i>
                </button>
                <div class="my-location-result__services js-acc-details" aria-expanded="false">${localizedServices}</div>
              `;
            } else {
              serviceHtml = `
                <li>
                  <button class="my-location-result__services-btn js-acc-button apl-section-stores-locator-store-services-btn" type="button">
                    <span class="underlined-text">${SDG?.Data?.storeServiceTrigger ? SDG.Data.storeServiceTrigger : 'View store services'}</span>
                    <i class="myarrow fa fa-chevron-down my-location-result__services-icon js-acc-icon" aria-hidden="true"></i>
                  </button>
                </li>
                <li class="my-location-result__services js-acc-details" aria-expanded="false">${localizedServices}</li>
              `;
            }
          }

          if (location?.image_url) {
            locationImageHtml = `
              <div class="my-location-result__image apl-section-stores-locator-store-image">
                <img src="${location.image_url}" alt="${escapeHtml(name)}" />
              </div>
            `;
          }

          if (location?.address?.phone) {
            telephoneVal = location.address.phone;
          }

          if (location?.phoneOverride?.value) {
            telephoneVal = location.phoneOverride.value;
          }

          const encodedName = encodeURIComponent(name);
          if (apiProvider === 'apple_maps') {
            const encodedAddress = encodeURIComponent(address.formatted);
            addressHref = `https://maps.apple.com/place?q=${encodedName}&address=${encodedAddress}&ll=${latitude},${longitude}`;
            calloutHref = `https://maps.apple.com/place?q=${encodedName}&address=${encodedAddress}&ll=${latitude},${longitude}`;
          }

          if (apiProvider === 'google_maps') {
            addressHref = `https://www.google.com/maps/search/?api=1&query=${encodedName}`;
            calloutHref = `https://www.google.com/maps/search/?api=1&query=${encodedName}`;
          }

          if (mapPage) {
            resultHtml = `
            <div
              class="js-my-location-result my-location-result apl-section-stores-locator-result"
              data-active="${isActive}"
              data-id="${location.id}"
              data-name="${escapeHtml(name)}"
              data-latitude="${latitude}"
              data-longitude="${longitude}"
              role="group"
              ${itemKeyAttr}
            >
              <div class="my-location-result__my-store apl-section-stores-locator-store-label">${SDG.Data.myStore}</div>
              ${locationImageHtml}
              <section class="js-my-results-details">
                <div class="my-location-result__details">
                  <div class="my-location-result__name apl-section-stores-locator-store-name">${escapeHtml(location.name)}</div>
                  <div class="my-store-locator__details-distance apl-section-stores-locator-store-distance">${location?.distance ? location.distance : ''}</div>
                </div>
                <div class="my-location-result__address my-location-result__location apl-section-stores-locator-store-address">
                  ${setCityAndStateHTML(location)}
                </div>
                <ul class="list-unstyled my-location-result__business">
                  ${location?.address?.address1 ? (
                    `<li class="my-location-result__address apl-section-stores-locator-store-address-1">
                      <span>${SDG.Data.storeAddress || 'Address'}: </span>
                      <a href="${calloutHref}" target="_blank">${escapeHtml(location.address.formatted.join(', '))}</a>
                    </li>`
                  ) : ''}
                  ${telephoneVal ? (
                    `<li class="my-location-result__address apl-section-stores-locator-store-address-phone">
                      <span>${SDG.Data.storePhone || 'Telephone'}: </span>
                      <a href="tel:${escapeHtml(telephoneVal)}">${escapeHtml(telephoneVal)}</a>
                    </li>`
                  ) : ''}
                  ${location?.email?.value ? (
                    `<li class="my-location-result__address apl-section-stores-locator-store-address-email">
                      <span>${SDG.Data.storeEmail || 'E-Mail'}: </span>
                      <a href="mailto:${escapeHtml(location.email.value)}">${escapeHtml(location.email.value)}</a>
                    </li>`
                  ) : ''}
                  ${location.hours?.value  ? (
                    `<li class="my-location-result__address apl-section-stores-locator-store-address-hours">
                      <span>${SDG.Data.storeHours || 'Hours'}: </span>
                      <span>${escapeHtml(location.hours.value)}</span>
                    </li>`
                  ) : ''}
                </ul>
                <div class="my-location-result__link js-my-location-link visually-hidden">
                  <a href="${calloutHref}" target="_blank" rel="noopener noreferrer">${SDG.Data.getDirections || 'Get Directions'}</a>
                </div>
              </section>
              ${serviceHtml}
              ${safeJsonParse(location.enableToggles?.value)?.checkoutEnabled !== false ? (`
                <button class="js-make-my-store-btn button button--secondary button--full-width my-location-result__make-my-store-btn apl-section-stores-locator-store-set-store">
                  ${SDG.Data.makeThisMyStore}
                </button>
              `) : ''}
            </div>`;
            const resultNode = new DOMParser().parseFromString(resultHtml, 'text/html').body.childNodes[0];
            resultNode.querySelector('.js-make-my-store-btn')?.addEventListener('click', (e) => {
              const activeResult = this.querySelector(this.dom.activeResult);
              if (activeResult) {
                activeResult.dataset.active = 'false';
              }
              e.currentTarget.parentNode.dataset.active = 'true';

              this.selectPreferredLocation();
            });

            this.results.append(resultNode);
            resultCount++;
          } else {
            resultHtml = `
            <div
              class="js-my-location-result my-location-result my-location-result--drawer apl-section-stores-locator-result"
              data-active="${isActive}"
              data-id="${location.id}"
              data-name="${escapeHtml(name)}"
              data-latitude="${latitude}"
              data-longitude="${longitude}"
              role="group"
              ${itemKeyAttr}
            >
              <div class="my-location-result-details">
                <div class="my-location-result__my-store apl-section-stores-locator-store-label">${SDG.Data.myStore}</div>
                <section class="js-my-results-details">
                  <div class="my-location-result__details">
                    <div class="my-location-result__name apl-section-stores-locator-store-name">${escapeHtml(location.name)}</div>
                    <div class="my-store-locator__details-distance apl-section-stores-locator-store-distance">${location?.distance ? location.distance : ''}</div>
                  </div>
                  <div class="my-location-result__address apl-section-stores-locator-store-address">
                  ${setCityAndStateHTML(location)}
                  </div>
                  ${availabilityHtml}
                </section>
              </div>
              <ul class="list-unstyled my-location-result-details--contact">
                ${location?.address?.address1 ? (
                  `<li class="my-location-result__address apl-section-stores-locator-store-address-1">
                    <span>${SDG.Data.storeAddress || 'Address'}: </span>
                    <a href="${addressHref}" target="_blank" rel="noopener noreferrer">${escapeHtml(location.address.formatted.join(', '))}</a>
                  </li>`
                ) : ''}
                ${telephoneVal ? (
                  `<li class="my-location-result__address apl-section-stores-locator-store-address-phone">
                    <span>${SDG.Data.storePhone || 'Telephone'}: </span>
                    <a href="tel:${escapeHtml(telephoneVal)}">${escapeHtml(telephoneVal)}</a>
                  </li>`
                ) : ''}
                ${location?.email?.value ? (
                  `<li class="my-location-result__address apl-section-stores-locator-store-address-email">
                    <span>${SDG.Data.storeEmail || 'E-Mail'}: </span>
                    <a href="mailto:${escapeHtml(location.email.value)}">${escapeHtml(location.email.value)}</a>
                  </li>`
                ) : ''}
                ${location.hours?.value  ? (
                  `<li class="my-location-result__address apl-section-stores-locator-store-address-hours">
                    <span>${SDG.Data.storeHours || 'Hours'}: </span>
                    <span>${escapeHtml(location.hours.value)}</span>
                  </li>`
                ) : ''}
                ${serviceHtml}
              </ul>
            </div>`;
            const openAcc = (el) => {
              el.setAttribute('aria-expanded', 'true')
              el.classList.add(this.cls.active);
            }
            const closeAcc = (el) => {
              el.setAttribute('aria-expanded', 'false')
              el.classList.remove(this.cls.active);
            }
            const resultNode = new DOMParser().parseFromString(resultHtml, 'text/html').body.childNodes[0];

            const $accButton = resultNode?.querySelector(this.dom.acc_button) || null;
            const $accIcon = resultNode?.querySelector(this.dom.acc_icon) || null;
            const $accDetails = resultNode?.querySelector(this.dom.acc_details) || null;

            resultNode.addEventListener('click', (e) => {
              const activeResult = this.querySelector(this.dom.activeResult);
              if (activeResult) {
                activeResult.dataset.active = 'false';
              }
              e.currentTarget.dataset.active = 'true';

              if (safeJsonParse(location.enableToggles?.value)?.checkoutEnabled !== false) {
                this.selectBtn.disabled = false;
              } else {
                this.selectBtn.disabled = true;
              }
            });

            if ($accButton && $accDetails) {
              $accButton.addEventListener('click',() => {
                if ($accDetails.classList.contains(this.cls.active)) {
                  closeAcc($accDetails);
                  if ($accIcon) closeAcc($accIcon);
                } else {
                  openAcc($accDetails);
                  if ($accIcon) openAcc($accIcon);
                }

                $accButton.setAttribute('data-acc', true)
              });
            }

            this.results.append(resultNode);
            resultCount++;
          }
        });
        let resultsText = '';
        if(nearbyValue === '') {
          if (this.storeLocator.myCoords) {
            if (resultCount > 1 || resultCount === 0) {
              resultsText = this.resultsCount.dataset.resultsNearYou;
            } else {
              resultsText = this.resultsCount.dataset.resultNearYou;
            }
          } else {
            if (resultCount > 1 || resultCount === 0) {
              resultsText = this.resultsCount.dataset.results;
            } else {
              resultsText = this.resultsCount.dataset.result;
            }
          }
        } else {
          const escapedNearbyValue = String(nearbyValue).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
          if (resultCount > 1 || resultCount === 0) {
            resultsText = `${this.resultsCount.dataset.resultsNear} "${escapedNearbyValue}"`;
          } else {
            resultsText = `${this.resultsCount.dataset.resultNear} "${escapedNearbyValue}"`;
          }
        }
        this.resultsCount.innerHTML = `${resultCount} ${resultsText}`;
        if (resultCount === 0) {
          this.results.innerHTML = `
            <div class="my-location-result">
              <div class="my-location-result__address apl-section-stores-locator-store-address">${this.resultsCount.dataset.noResultsFound}</div>
            </div>
          `;
        }
        this.loading.classList.add('hidden');
        this.results.scrollTop = 0;
      }

      handleBodyClick(evt) {
        const target = evt.target;

        if (target.classList.contains('js-my-store-locator-search-drawer-launcher')) {
          return;
        }
        if (
          target !== this &&
          !target.closest('my-store-locator-drawer') &&
          !target.closest('.js-my-store-locator-btn') &&
          !target.closest('.js-my-store-locator-drawer-btn') &&
          !target.classList.contains('js-my-store-locator-btn') &&
          !target.classList.contains('js-my-store-locator-drawer-btn')
        ) {
          this.hide();
        }
        this.suggestions.classList.add('hidden');
      }

      hide() {
        const wasStoreLocatorOpen = this.hasAttribute('open');
        this.removeAttribute('open');
        document.body.removeEventListener('click', this.onBodyClick);
        document.documentElement.classList.remove('overflow-hidden');

        const finishStoreLocatorDrawerHide = () => {
          removeTrapFocus(this.focusElement);

          // Keyboard users only: the element that opened the drawer is often re-rendered
          // while the drawer is open (renderPreview() replaces the pickup-availability
          // button), leaving focus on a detached node — fall back to the visible locator
          // button so the tab order is not lost. Skipped for pointer users because the
          // locator button lives in the header, and focusing it scrolls the page to the top.
          if (this._isKeyboardUser) {
            const storeLocatorvisibleBtn = Array.from(document.querySelectorAll('.js-my-store-locator-btn'))
              .find(btn => btn.offsetParent !== null);
            storeLocatorvisibleBtn?.focus();
          }
        };

        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
        if (!wasStoreLocatorOpen || reducedMotion.matches) {
          finishStoreLocatorDrawerHide();
          return;
        }

        const onTransitionEnd = (event) => {
          if (event.target !== this) return;
          this.removeEventListener('transitionend', onTransitionEnd);
          finishStoreLocatorDrawerHide();
        };
        this.addEventListener('transitionend', onTransitionEnd);
      }

      show(focusElement) {
        // show and hide product data and locations based on itemKey
        if (focusElement.dataset?.itemKey) {
          const productsInfo = document.querySelectorAll(this.dom.productInfo);
          productsInfo.forEach((productInfo) => {
            if (productInfo.dataset.itemKey === focusElement.dataset.itemKey) {
              productInfo.classList.remove('hidden');
            } else {
              productInfo.classList.add('hidden');
            }
          });
        } else if (focusElement.dataset?.productInfo === 'false') {
          const productsInfo = document.querySelectorAll(this.dom.productInfo);
          productsInfo.forEach((productInfo) => {
            productInfo.classList.add('hidden');
          });
        }

        this.setAttribute('data-hide-availability', focusElement.dataset?.hideAvailability || false);

        this.focusElement = focusElement;
        this.setAttribute('open', '');
        this.removeAttribute('aria-hidden');
        document.body.addEventListener('click', this.onBodyClick);
        document.documentElement.classList.add('overflow-hidden');

        // Defer focus until the drawer's open transition finishes — mobile screen readers
        // (notably iOS VoiceOver) won't move accessibility focus to an element still at
        // opacity 0 / off-screen, so calling trapFocus immediately drops the focus.
        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
        const addTrapFocus = (event) => {
          if (event && event.target !== this) return;
          this.removeEventListener('transitionend', addTrapFocus);
          trapFocus(this);
        };
        if (reducedMotion.matches) {
          addTrapFocus();
        } else {
          this.addEventListener('transitionend', addTrapFocus);
        }
      }
    }
  );
}