class CartRemoveButton extends HTMLElement {
  constructor() {
    super();

    this.addEventListener('click', async (event) => {
      event.preventDefault();
      var $CTOcartDrawer = $('cto-cart-drawer');
      // const cartItems = this.closest('cart-items') || this.closest('cart-drawer-items');
      // cartItems.updateQuantity(this.dataset.index, 0);
      //this.closest('cart-items').updateQuantity(this.dataset.index, 0);
      //return false;

      if ($(this).hasClass('force-disabled')) {
        return;
      }

      var type_of_btn = $(this).data('typeofbutton');
      var qty = 0;
      let main_key  = $(this).data('cartkey');
      var gwpKey = btoa(Date.now() + '' + Math.random());
      if (type_of_btn != 'aplcr' && type_of_btn != 'swremove' && type_of_btn != 'gwpremove') {
        let aplcr_rmv_btn_chk_indx = $(this).data('mnprdctidx');
        var main_product = $('#CartItem-' + aplcr_rmv_btn_chk_indx);
        let sub_key = $(this).data('cartkey');
        var main_product_quantity = main_product.find('.quantity__input').val();
        var main_product_mpn = main_product.find('.cart_mpn').val();
        var main_product_varid = main_product.find('.cart_varid').val();
        var main_product_title = main_product.find('.cart_title').val();
        var main_product_price = main_product.find('.cart_price').val();
        var main_productcpm_price = main_product.find('.cart_cpmprice').val();
        var shop_currency= main_product.find('.cart_currency').val();
        var cartProducts_ga = [];
        var item_cart = {};
        var exphone = [];
        var discount = 0;
        var productPrice = main_product_price;
        var productcomPrice = main_productcpm_price;
        var prodQuant = main_product_quantity;
        prodQuant = parseInt(prodQuant);
        productPrice = Number((productPrice || '').replace(/[^0-9.-]+/g, ""));
        var value_price = productPrice * parseInt(prodQuant);
        if (productcomPrice) {
          productcomPrice = Number(productcomPrice.replace(/[^0-9.-]+/g, ""));
          if (productcomPrice > productPrice) {
            discount = parseFloat(productcomPrice) - parseFloat(productPrice);
            discount = parseFloat(discount);
            //   productPrice = productcomPrice;
          }
        }
        var value_price1 = parseFloat(value_price);
        var productPrice1 = parseFloat(productPrice);
        item_cart = {};
        item_cart["item_id"] = main_product_mpn;
        item_cart['item_name'] = main_product_title;
        item_cart['quantity'] = parseInt(prodQuant);
        item_cart['price'] = productPrice1;
        var storedCart = null;
        try { storedCart = JSON.parse(localStorage.getItem("cart")); } catch (e) { storedCart = null; }
        if (storedCart != null) {
          exphone = storedCart;
          if (exphone != null) {
            for (var i = 0; i < exphone.length; i++) {
              if (exphone[i]['cart_item_id'] == item_cart["variant_id"]) {
                item_cart["item_list_name"] = exphone[i]['cart_item_list_name'];
              }
            }
          }
        }
        cartProducts_ga.push(item_cart);
        dataLayer.push({
          'ecommerce': null
        });
        dataLayer.push({
          'event': 'remove_from_cart',
          'ecommerce': {
            'currency':shop_currency,
            'value':value_price1,
            'items': cartProducts_ga
          }
        });
      }
      if(type_of_btn == 'main_product') {
        if (window.toggleAddOnButtons) window.toggleAddOnButtons('disable');
        let aple_care_selector  = '.cart_' + $(this).data('careproducthandle');
        let subkey_finder = '.aplcr_dpnd_' +this.dataset.index;
        let sub_keyq  = jQuery(subkey_finder).find('cart-remove-button');
        let sub_key =	sub_keyq.data('cartkey');
        let sw_subkey_finder = '.sw_dpnd_' +this.dataset.index;
        let sw_sub_keyq  = jQuery(sw_subkey_finder).find('cart-remove-button');
        let sw_sub_key =	sw_sub_keyq.data('cartkey');
        let gwp_subkey_finder = '.gwp_dpnd_' +this.dataset.index;
        let gwp_sub_keyq  = jQuery(gwp_subkey_finder).find('cart-remove-button');

        const gwp_sub_keys_obj = {};
        gwp_sub_keyq.each(function(){
          gwp_sub_keys_obj[$(this).data('cartkey')] = true;
        });
        const gwp_sub_keys = Object.keys(gwp_sub_keys_obj);

        var data = { updates: {} };
        data.updates[main_key] = qty;
        if(sub_key){
          data.updates[sub_key] = qty;
        }
        if(sw_sub_key){
          data.updates[sw_sub_key] = qty;
        }
        if(gwp_sub_keys.length){
          gwp_sub_keys.forEach((key) => {
            data.updates[key] = qty;
          });
        }

        $.ajax({
          type: 'POST',
          url: `${window.Shopify.routes.root}cart/update.js`,
          data: data,
          success: function(d){
            window.setTimeout(function(){window.onCartUpdate()},1000)
          },
          dataType: 'json'
       });
      } else if(type_of_btn == 'aplcr') {
        if (window.toggleAddOnButtons) window.toggleAddOnButtons('disable');
        let aplcr_rmv_btn_chk_indx = $(this).data('mnprdctidx');
        var main_product = $('#CartItem-'+aplcr_rmv_btn_chk_indx);
        var isCTO = main_product.data('cto-product');
        let sub_key  = $(this).data('cartkey');
        var main_product_quantity = main_product.find('.quantity__input').val();
        var main_product_tags = main_product.find('.cart_tax_tags').val();
        var main_product_mpn = main_product.find('.cart_mpn').val();
        let main_product_sku = main_product.data('sku')
        let main_product_handle = main_product.data('handle')
        let main_product_barcode = main_product.data('barcode')
        let main_product_preorder = main_product.data('preorder')
        let main_product_preordermessage = main_product.data('preordermessage')
        let main_product_trade_in = main_product.data('tradein')
        let applecare_sku = main_product.data('applecare_sku');
        let applecare_handle  =  main_product.data('applecare_handle');
        let secWarranty_sku = main_product.data('secwarranty_sku');
        let secWarranty_handle  =  main_product.data('secwarranty_handle');
        let gwp_sku = main_product.data('gwp_sku');
        let gwp_handle  =  main_product.data('gwp_handle');
        let wp_key = $('.sw_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('cartkey');
        let previous_uid = $('.sw_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('uuid');
        let previous_uid_2 = $('.gwp_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('uuid');

        const tradeInValue = $(main_product).data('tradeInValue');
        const tradeInDevice = $(main_product).data('tradeInDevice');

        const customBundleUUID = $(this).data('bundle-uuid');
        const customBundleName = $(this).data('bundle-name');
        const customBundleHandle = $(this).data('bundle-handle');
        const customBundleProductID = $(this).data('bundle-product-id');
        const customBundleSku = $(this).data('bundle-sku');
        const customBundleBarcode = $(this).data('bundle-barcode');
        const customBundlePrice = $(this).data('bundle-price');
        const customBundleChild1Id = $(this).data('bundle-child-item-id-1');
        const customBundleChild2Id = $(this).data('bundle-child-item-id-2');
        const customBundleChild33Id = $(this).data('bundle-child-item-id-3');
        const customBundleChild1Price = $(this).data('bundle-item-1-price');
        const customBundleChild2Price = $(this).data('bundle-item-2-price');
        const customBundleChild3Price = $(this).data('bundle-item-3-price');

        var data_ap = {
          line: aplcr_rmv_btn_chk_indx,
          quantity: main_product_quantity,
          properties: {},
        };

        if (main_product_preorder) {
          data_ap.properties._preOrder = 'true';
        }

        if (main_product_preordermessage) {
          data_ap.properties._preOrderMessage = main_product_preordermessage;
        }

        if (main_product_trade_in) {
          data_ap.properties._tradeInEligible = 'true';
        }

        if (tradeInValue) {
          data_ap.properties._tradeIn_value = tradeInValue.toString().replace('.', '');
        }

        if (tradeInDevice) {
          data_ap.properties._tradeIn_device = tradeInDevice;
        }

        if (customBundleUUID && customBundlePrice && customBundleChild1Id) {
          data_ap.properties._bundle_uuid = customBundleUUID;
          data_ap.properties._bundle_title = customBundleName;
          data_ap.properties._bundle_handle = customBundleHandle;
          data_ap.properties._bundle_product_id = customBundleProductID;
          data_ap.properties._bundle_price = customBundlePrice;
          data_ap.properties._bundle_item_1_id = customBundleChild1Id;
          data_ap.properties._bundle_item_2_id = customBundleChild2Id;
          data_ap.properties._bundle_item_3_id = customBundleChild33Id;
          data_ap.properties._bundle_item_1_price = customBundleChild1Price;
          data_ap.properties._bundle_item_2_price = customBundleChild2Price;
          data_ap.properties._bundle_item_3_price = customBundleChild3Price;

          if (customBundleBarcode) {
            data_ap.properties.Barcode = customBundleBarcode;
          }

          if (customBundleSku) {
            data_ap.properties.SKU = customBundleSku;
          }
        }

        var uid = main_product_handle;
        if (secWarranty_handle) {
          uid = uid + '-' + secWarranty_handle;
          data_ap.properties._secWarranty_sku = secWarranty_sku;
          data_ap.properties._secWarranty_handle = secWarranty_handle;
        }
        if (gwp_handle) {
          uid = uid + '-' + gwpKey;
          data_ap.properties._gwp_sku = gwp_sku;
          data_ap.properties._gwp_handle = gwp_handle;
        }
        if (tradeInDevice && !uid.includes('-tradein')) {
          uid = uid + '-tradein';
        }

        data_ap.properties._uuid = uid;

        if (isCTO) {
          data_ap.properties._cto_product = 'true';
        } else {
          data_ap.properties._added_from_pdp = 'true';
        }

        if (main_product_sku) {
          data_ap.properties.SKU = main_product_sku;
        }

        if (main_product_barcode) {
          data_ap.properties.Barcode = main_product_barcode;
        }

        var data_ap = JSON.stringify(data_ap);

        var data2 = { updates: {} };
        data2.updates[sub_key] = qty;

        var data = await $.ajax({
          url: `${window.Shopify.routes.root}cart/change.js`,
          type: "POST",
          data: data_ap,
          contentType: "application/json",
          dataType: 'json',
        });

        if (secWarranty_handle) {
          var newWpKey = data.items.find(item => item.properties?._sw_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid)?.key || wp_key;
          var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
          var data3 = {
            line: newWpLine,
            quantity: main_product_quantity,
            properties: {
              _sw_main_product_sku: main_product_sku,
              _sw_main_product_handle: main_product_handle,
              _uuid: uid,
            },
          };
          var data3 = JSON.stringify(data3);
          var data = await $.ajax({
            url: `${window.Shopify.routes.root}cart/change.js`,
            type: "POST",
            data: data3,
            contentType: "application/json",
            dataType: 'json',
          });
        }

        if (gwp_handle) {
          var newWpItems = data.items.filter(item => item.properties?._gwp_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid_2);
          for (const newWpItem of newWpItems) {
            var newWpKey = newWpItem?.key;
            var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
            var newWpQuantity = newWpItem?.quantity || 1;
            const skuProp = newWpItem?.properties?.SKU;
            const barcodeProp = newWpItem?.properties?.Barcode;
            var data3 = {
              line: newWpLine,
              quantity: newWpQuantity,
              properties: {
                _gwp_main_product_sku: main_product_sku,
                _gwp_main_product_handle: main_product_handle,
                _uuid: uid,
                ...(skuProp && { SKU: skuProp }),
                ...(barcodeProp && { Barcode: barcodeProp }),
              },
            };
            var data3 = JSON.stringify(data3);
            var data = await $.ajax({
              url: `${window.Shopify.routes.root}cart/change.js`,
              type: "POST",
              data: data3,
              contentType: "application/json",
              dataType: 'json',
            });
          }
        }

        var data = await $.ajax({
          type: 'POST',
          url: `${window.Shopify.routes.root}cart/update.js`,
          data: data2,
          dataType: 'json',
        });

        window.setTimeout(function(){window.onCartUpdate()},1000);
      } else if(type_of_btn == 'swremove') {
        if (window.toggleAddOnButtons) window.toggleAddOnButtons('disable');
        let aplcr_rmv_btn_chk_indx = $(this).data('mnprdctidx');
        var main_product = $('#CartItem-'+aplcr_rmv_btn_chk_indx);
        let sub_key  = $(this).data('cartkey');
        var main_product_quantity = main_product.find('.quantity__input').val();
        var main_product_tags = main_product.find('.cart_tax_tags').val();
        var isCTO = main_product.data('cto-product');
        var main_product_mpn = main_product.find('.cart_mpn').val();
        let main_product_sku = main_product.data('sku')
        let main_product_handle = main_product.data('handle')
        let main_product_preorder = main_product.data('preorder')
        let main_product_barcode = main_product.data('barcode')
        let main_product_preordermessage = main_product.data('preordermessage')
        let main_product_trade_in = main_product.data('tradein')
        let applecare_sku = main_product.data('applecare_sku');
        let applecare_handle  =  main_product.data('applecare_handle');
        let secWarranty_sku = main_product.data('secwarranty_sku');
        let secWarranty_handle  =  main_product.data('secwarranty_handle');
        let gwp_sku = main_product.data('gwp_sku');
        let gwp_handle  =  main_product.data('gwp_handle');
        let wp_key = $('.aplcr_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('cartkey');
        let previous_uid = $('.aplcr_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('uuid');
        let wp_key_2 = $('.gwp_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('cartkey');
        let previous_uid_2 = $('.gwp_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('uuid');
        const tradeInValue = $(main_product).data('tradeInValue');
        const tradeInDevice = $(main_product).data('tradeInDevice');

        const customBundleUUID = $(this).data('bundle-uuid');
        const customBundleName = $(this).data('bundle-name');
        const customBundleHandle = $(this).data('bundle-handle');
        const customBundleProductID = $(this).data('bundle-product-id');
        const customBundleSku = $(this).data('bundle-sku');
        const customBundleBarcode = $(this).data('bundle-barcode');
        const customBundlePrice = $(this).data('bundle-price');
        const customBundleChild1Id = $(this).data('bundle-child-item-id-1');
        const customBundleChild2Id = $(this).data('bundle-child-item-id-2');
        const customBundleChild3Id = $(this).data('bundle-child-item-id-3');
        const customBundleChild1Price = $(this).data('bundle-child-item-1-price');
        const customBundleChild2Price = $(this).data('bundle-child-item-2-price');
        const customBundleChild3Price = $(this).data('bundle-child-item-3-price');

        var data_ap = {
          line: aplcr_rmv_btn_chk_indx,
          quantity: main_product_quantity,
          properties: {},
        };

        if (main_product_preorder) {
          data_ap.properties._preOrder = 'true';
        }

        if (main_product_preordermessage) {
          data_ap.properties._preOrderMessage = main_product_preordermessage;
        }

        if (main_product_trade_in) {
          data_ap.properties._tradeInEligible = 'true';
        }

        if (tradeInValue) {
          data_ap.properties._tradeIn_value = tradeInValue.toString().replace('.', '');
        }

        if (tradeInDevice) {
          data_ap.properties._tradeIn_device = tradeInDevice;
        }

        if (customBundleUUID && customBundlePrice && customBundleChild1Id) {
          data_ap.properties._bundle_uuid = customBundleUUID;
          data_ap.properties._bundle_title = customBundleName;
          data_ap.properties._bundle_handle = customBundleHandle;
          data_ap.properties._bundle_product_id = customBundleProductID;
          data_ap.properties._bundle_price = customBundlePrice;
          data_ap.properties._bundle_item_1_id = customBundleChild1Id;
          data_ap.properties._bundle_item_2_id = customBundleChild2Id;
          data_ap.properties._bundle_item_3_id = customBundleChild3Id;
          data_ap.properties._bundle_item_1_price = customBundleChild1Price;
          data_ap.properties._bundle_item_2_price = customBundleChild2Price;
          data_ap.properties._bundle_item_3_price = customBundleChild3Price;

          if (customBundleBarcode) {
            data_ap.properties.Barcode = customBundleBarcode;
          }

          if (customBundleSku) {
            data_ap.properties.SKU = customBundleSku;
          }
        }

        var uid = main_product_handle;
        if (applecare_handle) {
          uid = uid + '-' + applecare_handle;
          data_ap.properties._applecare_sku = applecare_sku;
          data_ap.properties._applecare_handle = applecare_handle;
        }
        if (gwp_handle) {
          uid = uid + '-' + gwpKey;
          data_ap.properties._gwp_sku = gwp_sku;
          data_ap.properties._gwp_handle = gwp_handle;
        }
        if (tradeInDevice && !uid.includes('-tradein')) {
          uid = uid + '-tradein';
        }
        if (isCTO) {
          data_ap.properties._cto_product = 'true';
        } else {
          data_ap.properties._added_from_pdp = 'true';
        }

        data_ap.properties._uuid = uid;

        if (main_product_sku) {
          data_ap.properties.SKU = main_product_sku;
        }

        if (main_product_barcode) {
          data_ap.properties.Barcode = main_product_barcode;
        }

        var data_ap = JSON.stringify(data_ap);

        var data2 = { updates: {} };
        data2.updates[sub_key] = qty;

        var data = await $.ajax({
          url: `${window.Shopify.routes.root}cart/change.js`,
          type: "POST",
          data: data_ap,
          contentType: "application/json",
          dataType: 'json',
        });

        if(applecare_handle) {
          var newWpKey = data.items.find(item => item.properties?._aplcr_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid)?.key || wp_key;
          var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
          var existingAcceptTerms = data.items.find(item => item.key === newWpKey)?.properties?._customerAcceptTerms;
          var data3 = {
            line: newWpLine,
            quantity: main_product_quantity,
            properties: {
              _aplcr_main_product_sku: main_product_sku,
              _aplcr_main_product_handle: main_product_handle,
              _uuid: uid,
              ...(existingAcceptTerms === 'Y' && { _customerAcceptTerms: 'Y' }),
            },
          };
          var data3 = JSON.stringify(data3);
          var data = await $.ajax({
            url: `${window.Shopify.routes.root}cart/change.js`,
            type: "POST",
            data: data3,
            contentType: "application/json",
            dataType: 'json',
          });
        }

        if (gwp_handle) {
          var newWpItems = data.items.filter(item => item.properties?._gwp_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid_2);
          for (const newWpItem of newWpItems) {
            var newWpKey = newWpItem?.key || wp_key_2;
            var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
            var newWpQuantity = newWpItem?.quantity || 1;
            var data3 = {
              line: newWpLine,
              quantity: newWpQuantity,
              properties: {
                _gwp_main_product_sku: main_product_sku,
                _gwp_main_product_handle: main_product_handle,
                _uuid: uid,
              },
            };
            var data3 = JSON.stringify(data3);
            var data = await $.ajax({
              url: `${window.Shopify.routes.root}cart/change.js`,
              type: "POST",
              data: data3,
              contentType: "application/json",
              dataType: 'json',
            });
          }
        }

        var data = await $.ajax({
          type: 'POST',
          url: `${window.Shopify.routes.root}cart/update.js`,
          data: data2,
          dataType: 'json',
        });

        window.setTimeout(function(){window.onCartUpdate()},1000);
      } else if (type_of_btn == 'gwpremove') {
        if (window.toggleAddOnButtons) window.toggleAddOnButtons('disable');
        let gwp_button_target_initial = $(this);
        const gwp_button_target_sku = gwp_button_target_initial.data('gwp-sku');
        let main_product_token = gwp_button_target_initial.data('tokenparent');
        let main_product_index_target = gwp_button_target_initial.data('mnprdctidx');
        var main_product_target = $('#CartItem-'+main_product_index_target);
        const main_product_target_sku = main_product_target.data('sku');
        let gwp_btns_to_proceed = gwp_button_target_initial; // default the single button that was clicked

        // Check if click from the CartDrawer and removal action for grouped products is needed
        if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
          const cto_grouped_number = main_product_target.find('.js-cart-item-qty').data('item-qty-grouped');
          const gwp_btns_to_proceed_selector = `cart-remove-button[data-skuparent="${main_product_target_sku}"][data-tokenparent="${main_product_token}"][data-gwp-sku="${gwp_button_target_sku}"]`;
          const gwp_btns_to_proceed_list = $CTOcartDrawer.find(gwp_btns_to_proceed_selector);
          
          if (cto_grouped_number > 1 && gwp_btns_to_proceed_list.length > 1) {
            gwp_btns_to_proceed = gwp_btns_to_proceed_list;
          }
        }

        let latestKeysCartData = null;
        for (const buttonElement of gwp_btns_to_proceed.get()) {
          const gwp_button_target = $(buttonElement);
          let aplcr_rmv_btn_chk_indx = gwp_button_target.data('mnprdctidx');
          var main_product = $('#CartItem-'+aplcr_rmv_btn_chk_indx);
          let main_product_key = main_product.data('cto-cart-item-key');
          let main_product_target_uid = main_product.data('gwp_key');
          var isCTO = main_product.data('cto-product');
          const isAddedFromPDP = main_product.data('added-from-pdp');
          let sub_key  = gwp_button_target.data('cartkey');
          var main_product_quantity = main_product.find('.quantity__input').val();
          var main_product_tags = main_product.find('.cart_tax_tags').val();
          var main_product_mpn = main_product.find('.cart_mpn').val();
          let main_product_sku = main_product.data('sku')
          let main_product_handle = main_product.data('handle')
          let main_product_barcode = main_product.data('barcode')
          let main_product_preorder = main_product.data('preorder')
          let main_product_preordermessage = main_product.data('preordermessage')
          let main_product_trade_in = main_product.data('tradein')
          let applecare_sku = main_product.data('applecare_sku');
          let applecare_handle  =  main_product.data('applecare_handle');
          let secWarranty_sku = main_product.data('secwarranty_sku');
          let secWarranty_handle  =  main_product.data('secwarranty_handle');
          let gwp_sku = main_product.data('gwp_sku');
          let gwp_handle  =  main_product.data('gwp_handle');
          let wp_key = $('.aplcr_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('cartkey');
          let previous_uid = $('.aplcr_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('uuid');
          let wp_key_2 = $('.sw_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('cartkey');
          let previous_uid_2 = $('.sw_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('uuid');

          if (latestKeysCartData) {
              const refreshedMainProductItem = latestKeysCartData.items.find(item =>
                  item.properties?._uuid === main_product_target_uid &&
                  (item.properties?._cto_product === 'true' || item.properties?._added_from_pdp === 'true')
              );

              if (refreshedMainProductItem) {
                  // overwrite previous key if updated
                  main_product_key = refreshedMainProductItem.key; 
              }
          }

          if (isCTO || isAddedFromPDP) {
            previous_uid = $('.aplcr_dpnd_'+aplcr_rmv_btn_chk_indx).data('uuid');
            previous_uid_2 = $('.sw_dpnd_'+aplcr_rmv_btn_chk_indx).data('uuid');
          }

          let remaining_gwp_skus = [];
          let remaining_gwp_handles = [];
          $('.gwp_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').each(function(){
            const gwp_sku = $(this).data('gwp-sku');
            const gwp_handle = $(this).data('gwp-handle');
            if ($(this).data('cartkey') !== sub_key && !remaining_gwp_handles.includes(gwp_handle)) {
              remaining_gwp_skus.push(gwp_sku);
              remaining_gwp_handles.push(gwp_handle);
            }
          });
          let previous_uid_3 = $('.gwp_dpnd_'+aplcr_rmv_btn_chk_indx).find('cart-remove-button').data('uuid');

          const tradeInValue = $(main_product).data('tradeInValue');
          const tradeInDevice = $(main_product).data('tradeInDevice');

          var data_ap = {
            id: main_product_key,
            quantity: main_product_quantity,
            properties: {},
          };

          if (main_product_preorder) {
            data_ap.properties._preOrder = 'true';
          }

          if (main_product_preordermessage) {
            data_ap.properties._preOrderMessage = main_product_preordermessage;
          }

          if (main_product_trade_in) {
            data_ap.properties._tradeInEligible = 'true';
          }

          if (tradeInValue) {
            data_ap.properties._tradeIn_value = tradeInValue.toString().replace('.', '');
          }

          if (tradeInDevice) {
            data_ap.properties._tradeIn_device = tradeInDevice;
          }

          // Unique per grouped line: lines left without gifts would otherwise share a bare-handle
          // _uuid, and Shopify merges identical lines into one line with quantity > 1
          var uid = main_product_handle + '-' + crypto.randomUUID().slice(0, 8);
          if (applecare_handle) {
            uid = uid + '-' + applecare_handle;
            data_ap.properties._applecare_sku = applecare_sku;
            data_ap.properties._applecare_handle = applecare_handle;
          }
          if (secWarranty_handle) {
            uid = uid + '-' + secWarranty_handle;
            data_ap.properties._secWarranty_sku = secWarranty_sku;
            data_ap.properties._secWarranty_handle = secWarranty_handle;
          }
          if (remaining_gwp_handles.length) {
            uid = uid + '-' + btoa(Date.now() + '' + Math.random());
            data_ap.properties._gwp_sku = remaining_gwp_skus.join(',');
            data_ap.properties._gwp_handle = remaining_gwp_handles.join('-');
          }
          if (tradeInDevice && !uid.includes('-tradein')) {
            uid = uid + '-tradein';
          }
          if (isCTO) {
            data_ap.properties._cto_product = 'true';
          } else {
            data_ap.properties._added_from_pdp = 'true';
          }

          if (main_product_sku) {
            data_ap.properties.SKU = main_product_sku;
          }

          if (main_product_barcode) {
            data_ap.properties.Barcode = main_product_barcode;
          }

          if (main_product_token) {
            data_ap.properties._item_token = main_product_token;
          }

          data_ap.properties._uuid = uid;

          var data_ap = JSON.stringify(data_ap);

          var data2 = { updates: {} };
          data2.updates[sub_key] = qty;

          var data = await $.ajax({
            url: `${window.Shopify.routes.root}cart/change.js`,
            type: "POST",
            data: data_ap,
            contentType: "application/json",
            dataType: 'json',
          });

          if(applecare_handle) {
            var newWpKey = data.items.find(item => item.properties?._aplcr_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid)?.key || wp_key;
            var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
            var existingAcceptTerms = data.items.find(item => item.key === newWpKey)?.properties?._customerAcceptTerms;
            var data3 = {
              line: newWpLine,
              quantity: main_product_quantity,
              properties: {
                _aplcr_main_product_sku: main_product_sku,
                _aplcr_main_product_handle: main_product_handle,
                _uuid: uid,
                ...(existingAcceptTerms === 'Y' && { _customerAcceptTerms: 'Y' }),
              },
            };
            var data3 = JSON.stringify(data3);
            var data = await $.ajax({
              url: `${window.Shopify.routes.root}cart/change.js`,
              type: "POST",
              data: data3,
              contentType: "application/json",
              dataType: 'json',
            });
          }

          if (secWarranty_handle) {
            var newWpKey = data.items.find(item => item.properties?._sw_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid_2)?.key || wp_key_2;
            var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
            var data3 = {
              line: newWpLine,
              quantity: main_product_quantity,
              properties: {
                _sw_main_product_sku: main_product_sku,
                _sw_main_product_handle: main_product_handle,
                _uuid: uid,
              },
            };
            var data3 = JSON.stringify(data3);
            var data = await $.ajax({
              url: `${window.Shopify.routes.root}cart/change.js`,
              type: "POST",
              data: data3,
              contentType: "application/json",
              dataType: 'json',
            });
          }

          var data = await $.ajax({
            type: 'POST',
            url: `${window.Shopify.routes.root}cart/update.js`,
            data: data2,
            dataType: 'json',
          });

          if (remaining_gwp_handles.length) {
            var newWpItems = data.items.filter(item => item.properties?._gwp_main_product_sku === main_product_sku && item.properties?._uuid === previous_uid_3);
            for (const newWpItem of newWpItems) {
              var newWpKey = newWpItem?.key;
              var newWpLine = data.items.findIndex(item => item.key === newWpKey) + 1;
              var newWpQuantity = newWpItem?.quantity || 1;
              var data3 = {
                line: newWpLine,
                quantity: newWpQuantity,
                properties: {
                  _gwp_main_product_sku: main_product_sku,
                  _gwp_main_product_handle: main_product_handle,
                  _uuid: uid,
                },
              };
              var data3 = JSON.stringify(data3);
              var data = await $.ajax({
                url: `${window.Shopify.routes.root}cart/change.js`,
                type: "POST",
                data: data3,
                contentType: "application/json",
                dataType: 'json',
              });
            }
          }

          latestKeysCartData = data;
        }

        if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
          var newCTOItemKey = data?.items?.find((item) => item.properties?._cto_product || item.properties?._added_from_pdp)?.key;
          $CTOcartDrawer[0].updateCtoItemKey(newCTOItemKey);
          // small delay to ensure CTO cart refresh does not have a race condition with main cart refresh
          window.setTimeout(function(){$CTOcartDrawer[0].updateItems();},1100);
        }

        window.setTimeout(function(){window.onCartUpdate()},1000);
      } else if(type_of_btn == 'tradeIn') {
        if (window.toggleAddOnButtons) window.toggleAddOnButtons('disable');
        const tradeIn_rmv_btn_chk_indx = $(this).data('mnprdctidx');
        const main_product = $(`#CartItem-${tradeIn_rmv_btn_chk_indx}`);
        const main_product_quantity = main_product.find('.quantity__input').val();
        const main_product_preorder = main_product.data('preorder');
        const main_product_preordermessage = main_product.data('preordermessage')
        const main_product_trade_in = main_product.data('tradein');

        let properties = $(this).data('itemProperties');

        if (main_product_preorder) properties._preOrder = 'true';
        if (main_product_preordermessage) properties._preOrderMessage = main_product_preordermessage;
        if (main_product_trade_in) properties._tradeInEligible = 'true';
        if (properties._tradeIn_value) delete properties._tradeIn_value;
        if (properties._tradeIn_device) delete properties._tradeIn_device;

        if (properties._uuid) {
          properties._uuid = properties._uuid.split('-tradein')[0];
        }

        const data_tradeIn = JSON.stringify({
          line: Number(tradeIn_rmv_btn_chk_indx),
          quantity: Number(main_product_quantity),
          properties: properties
        });

        $.ajax({
          url: `${window.Shopify.routes.root}cart/change.js`,
          type: "POST",
          data: data_tradeIn,
          contentType: "application/json",
          dataType: 'json',
          success: function(data) {
            const oldUuid = properties?._uuid + '-tradein';
            const newUuid = properties?._uuid;

            if (!oldUuid || !newUuid || oldUuid === newUuid) return;

            const appleCareProductsThatNeedUpdating = data.items.find(item => item.properties?._aplcr_main_product_sku && item.properties?._uuid === oldUuid);
            const secWarrantyProductsThatNeedUpdating = data.items.find(item => item.properties?._sw_main_product_sku && item.properties?._uuid === oldUuid);
            const gwpProductsThatNeedUpdatingArr = data.items.filter(item => item.properties?._gwp_main_product_sku && item.properties?._uuid === oldUuid);

            async function updateAcSecProducts() {
              if (appleCareProductsThatNeedUpdating) {
                const newProperties = { ...appleCareProductsThatNeedUpdating.properties, _uuid: newUuid };
                const line = data.items.findIndex(item => item.key === appleCareProductsThatNeedUpdating.key) + 1;
                const newData = {
                  line,
                  quantity: appleCareProductsThatNeedUpdating.quantity,
                  properties: newProperties,
                };
                await fetch(`${window.Shopify.routes.root}cart/change.js`, {
                  method: "POST",
                  headers: {
                    'content-type': 'application/json'
                  },
                  body: JSON.stringify(newData),
                });
              }

              if (secWarrantyProductsThatNeedUpdating) {
                const newProperties = { ...secWarrantyProductsThatNeedUpdating.properties, _uuid: newUuid };
                const line = data.items.findIndex(item => item.key === secWarrantyProductsThatNeedUpdating.key) + 1;
                const newData = {
                  line,
                  quantity: secWarrantyProductsThatNeedUpdating.quantity,
                  properties: newProperties,
                };
                await fetch(`${window.Shopify.routes.root}cart/change.js`, {
                  method: "POST",
                  headers: {
                    'content-type': 'application/json'
                  },
                  body: JSON.stringify(newData),
                });
              }

              if (gwpProductsThatNeedUpdatingArr.length) {
                for (const gwpProductsThatNeedUpdating of gwpProductsThatNeedUpdatingArr) {
                  const newProperties = { ...gwpProductsThatNeedUpdating.properties, _uuid: newUuid };
                  const line = data.items.findIndex(item => item.key === gwpProductsThatNeedUpdating.key) + 1;
                  const newData = {
                    line,
                    quantity: gwpProductsThatNeedUpdating.quantity,
                    properties: newProperties,
                  };
                  await fetch(`${window.Shopify.routes.root}cart/change.js`, {
                    method: "POST",
                    headers: {
                      'content-type': 'application/json'
                    },
                    body: JSON.stringify(newData),
                  });
                }
              }

              window.onCartUpdate()
            }

            updateAcSecProducts();
          },
          error: function(xhr, status, error) {
            console.error(`Error: ${xhr.responseText}`);
            // Re-enable the add-on buttons on failure so the cart UI isn't left
            // stuck disabled (mirrors the toggleAddOnButtons('disable') at branch start).
            if (window.toggleAddOnButtons) window.toggleAddOnButtons('enable');
          }
        });
      } else {
        const cartItems = this.closest('cart-items') || null;
        const drawerItems = this.closest('cart-drawer-items') || null;

        if (cartItems) {
          cartItems?.updateQuantity(this.dataset.index, 0);
        }
        if (drawerItems) {
          drawerItems?.updateQuantity(this.dataset.index, 0);
        }
      }

      // Safety net: the authoritative re-enable happens in onCartUpdate's
      // customCallback once the cart has refreshed. This deferred call only
      // covers edge paths that never reach a cart refresh (e.g. tradeIn uuid
      // no-op early return or an AJAX error), and fires after the cart-mutation
      // window so it can't race the in-flight update (see R15-059).
      window.setTimeout(function () {
        if (window.toggleAddOnButtons) window.toggleAddOnButtons('enable');
      }, 1200);
    });
  }
}

customElements.define('cart-remove-button', CartRemoveButton);

class CartItems extends HTMLElement {
  constructor() {
    super();
    this.lineItemStatusElement =
      document.getElementById('shopping-cart-line-item-status') || document.getElementById('CartDrawer-LineItemStatus');

    const debouncedOnChange = debounce((event) => {
      this.onChange(event);
    }, ON_CHANGE_DEBOUNCE_TIMER);

    // Disable add-on buttons immediately when a quantity value commits, so the
    // debounce window before the cart-update AJAX can't race with a Remove click.
    this.addEventListener('change', (event) => {
      if (event.target?.dataset?.index) {
        this.toggleAddOnButtons('disable');
      }
    });
    this.addEventListener('change', debouncedOnChange.bind(this));

    window.onCartUpdate = this.onCartUpdate.bind(this);
    window.toggleAddOnButtons = this.toggleAddOnButtons.bind(this);

    // Debounced so holding the quantity +/- doesn't queue one fetch per click.
    this.debouncedRefreshCartRecommendations = debounce(
      this.refreshCartRecommendationSections.bind(this),
      ON_CHANGE_DEBOUNCE_TIMER
    );
  }

  cartUpdateUnsubscriber = undefined;

  connectedCallback() {
    if (this.cartUpdateUnsubscriber) {
      this.cartUpdateUnsubscriber();
    }
    this.cartUpdateUnsubscriber = subscribe(PUB_SUB_EVENTS.cartUpdate, (event) => {
      if (event.source === 'cart-items') {
        return;
      }
      window.onCartUpdate();
    });
  }

  disconnectedCallback() {
    if (this.cartUpdateUnsubscriber) {
      this.cartUpdateUnsubscriber();
    }
  }

  toggleAddOnButtons(action = 'disable') {
    // AC+, Second Warranty, and Trade In add buttons
    const $addOnButtons = document.querySelectorAll(`.add-cart-apple-care, .add-cart-trade-in`) || null
    // AC+, Second Warranty, and Trade In remove buttons
    const $removeButtons = document.querySelectorAll(`
        cart-remove-button[data-typeofbutton="aplcr"],
        cart-remove-button[data-typeofbutton="swremove"],
        cart-remove-button[data-typeofbutton="gwpremove"],
        cart-remove-button[data-typeofbutton="tradeIn"]
      `) || null;
    const $viewCartButtons = document.querySelectorAll('.js-cart-items-footer') || null;

    if (action === 'disable') {
      if ($addOnButtons) {
        $addOnButtons.forEach(($button) => {
          $button.classList.add('force-disabled');
          $button.disabled = true;
        });
      }
      if ($removeButtons) {
        $removeButtons.forEach(($button) => {
          $button.classList.add('force-disabled');
          $button.disabled = true;
        });
      }
      if ($viewCartButtons) {
        $viewCartButtons.forEach(($button) => {
          $button.classList.add('force-disabled');
          $button.disabled = true;
        });
      }
    }

    if (action === 'enable') {
     if ($addOnButtons) {
        $addOnButtons.forEach(($button) => {
          $button.classList.remove('force-disabled');
          $button.disabled = false;
        });
      }
      if ($removeButtons) {
        $removeButtons.forEach(($button) => {
          $button.classList.remove('force-disabled');
          $button.disabled = false;
        });
      }
      if ($viewCartButtons) {
        $viewCartButtons.forEach(($button) => {
          $button.classList.remove('force-disabled');
          $button.disabled = false;
        });
      }
    }
  }

  onChange(event) {
    // Added code for Applecare Quantity syncup - Hema
    let main_item_index = event.target.dataset.index;
    let const_selector_id = "#CartItem-" + main_item_index;
    let main_key = $(const_selector_id).find('cart-remove-button').data('cartkey');
    // let subkey_finder = '.cart_' +$(const_selector_id).find('cart-remove-button').data('careproducthandle');
    let subkey_finder = '.aplcr_dpnd_' +event.target.dataset.index;
    let sub_key  = jQuery(subkey_finder).find('cart-remove-button').data('cartkey');
    let sw_subkey_finder = '.sw_dpnd_' +event.target.dataset.index;
    let sw_sub_key  = jQuery(sw_subkey_finder).find('cart-remove-button').data('cartkey');
    let gwp_subkey_finder = '.gwp_dpnd_' +event.target.dataset.index;
    let gwp_sub_key  = jQuery(gwp_subkey_finder).find('cart-remove-button').data('cartkey');
    var qty = event.target.value;
    var plusorminus = document.activeElement.getAttribute('name');
    var main_product_quantity = $(const_selector_id).find('.quantity__input').val();
    var main_product_mpn = $(const_selector_id).find('.cart_mpn').val();
    var main_product_title= $(const_selector_id).find('.cart_title').val();
    var main_product_price= $(const_selector_id).find('.cart_price').val();
    var main_productcpm_price= $(const_selector_id).find('.cart_cpmprice').val();
    var main_product_tags = $(const_selector_id).find('.cart_tax_tags').val();
     var shop_currency= $(const_selector_id).find('.cart_currency').val();
    var main_product_varid= $(const_selector_id).find('.cart_varid').val();
    var main_product_type= $(const_selector_id).find('.cart_type').val();
    var main_product_handle = $(const_selector_id).data('handle')
    var main_product_preorder = $(const_selector_id).data('preorder')
    var main_product_preordermessage = $(const_selector_id).data('preordermessage')
    var main_product_trade_in = $(const_selector_id).data('tradein')
    var main_product_cto_product = $(const_selector_id).data('cto-product')
    var variant_id = event.target.dataset.quantityVariantId;
    /* Order Product Limits - Karthikeyan */
    var cartqun;
    var maxqun;
    var total_cart_qun = 0;
    var total_cart_qun_max = 0;
    var total_max_qun = 0;
    var total_inv_qun = 0;
    var current_qun = 0;
    var product_id = '';
    var inc_or_dec1;

    /* Custom Bundle Properties */
    const isCustomBundle =  $(const_selector_id).data('bundle-uuid');
    let bundleProperties = {};

    if (isCustomBundle) {
      const customBundleName = $(const_selector_id).data('bundle-name');
      const customBundleHandle = $(const_selector_id).data('bundle-handle');
      const customBundleProductID = $(const_selector_id).data('bundle-product-id');
      const customBundlePrice = $(const_selector_id).data('bundle-price');
      const customBundleItem1Id = $(const_selector_id).data('bundle-child-item-id-1');
      const customBundleItem2Id = $(const_selector_id).data('bundle-child-item-id-2');
      const customBundleItem3Id = $(const_selector_id).data('bundle-child-item-id-3');
      const customBundleItem1Price = $(const_selector_id).data('bundle-item-1-price');
      const customBundleItem2Price = $(const_selector_id).data('bundle-item-2-price');
      const customBundleItem3Price = $(const_selector_id).data('bundle-item-3-price');

      bundleProperties = {
        _bundle_uuid: isCustomBundle, // The bundle's UUID
        _bundle_title: customBundleName,
        _bundle_handle: customBundleHandle,
        _bundle_product_id: customBundleProductID,
        _bundle_price: customBundlePrice,

        ...(customBundleItem1Id && { _bundle_item_1_id: customBundleItem1Id }),
        ...(customBundleItem1Price && { _bundle_item_1_price: customBundleItem1Price }),
        ...(customBundleItem2Id && { _bundle_item_2_id: customBundleItem2Id }),
        ...(customBundleItem2Price && { _bundle_item_2_price: customBundleItem2Price }),
        ...(customBundleItem3Id && { _bundle_item_3_id: customBundleItem3Id }),
        ...(customBundleItem3Price && { _bundle_item_3_price: customBundleItem3Price }),
      };
    }

    function setErrorMessage(maxAmount) {
      var $cartItem = document.querySelector(const_selector_id);
      if (!$cartItem) return;

      var $errorMessage = $cartItem?.querySelector('.js-qty-error') || null;
      var $qtyInput = $cartItem?.querySelector('.js-qty-input') || null;
      var $newItemMessage = $cartItem?.querySelector('.js-cart-new-item-message') || null;

      if ($errorMessage) {
        const text = $errorMessage.getAttribute('data-error-message') || $errorMessage.innerHTML;

        if (text) {
          if (text.includes('{limit}')) {
            $errorMessage.innerHTML = text.replace(/\{limit\}/g, `${maxAmount}`);
            $errorMessage.classList.remove('hidden');
          } else {
            $errorMessage.classList.remove('hidden');
          }

          if ($newItemMessage) {
            $newItemMessage.classList.add('hidden');
          }
        }
      }

      if ($qtyInput) {
        $qtyInput.classList.add('quantity--error');
      }
      // The early `return false` blocks the AJAX cart update, but the #cart form's Checkout
      // button (button[type="submit"][form="cart"]) posts updates[] with the raw input value
      // straight to /cart — and Shopify's server-side quantity_rule does not aggregate units
      // that already live inside a bundle's item_components. Leaving the stale over-limit
      // value in the field would let the shopper carry it past the limit into checkout, so we
      // revert to the last valid quantity here (mirrors the add.js / updateQuantity error paths).
      if (event.target) {
        event.target.value = event.target.getAttribute('value');
      }

      return false;
    }
    this.toggleAddOnButtons('disable');

    // Parsed minquant rows, hoisted so the bundle child-limit check below (which runs after
    // this synchronous fetch) can inspect every line — including the synthetic
    // `bundle-component-*` / `bundle-cto-child-*` rows emitted for bundle children
    // (see cart.minquant.liquid).
    var minquantRows = [];

    $.ajax({
      type: 'GET',
      url: `${window.Shopify.routes.root}cart?view=minquant`,
      async: false,
      success: function(itemData){
        const { isCtoChildRow, isAddOnRow, parseRows } = window.CartQuantity;
        minquantRows = parseRows(itemData);

        for (const row of minquantRows) {
          if (isAddOnRow(row)) continue;
          if (main_key == row[3]) {
            product_id = row[0];
            total_inv_qun = parseInt(row[6]);
            current_qun = parseInt(row[1]);
          }
        }

        for (const row of minquantRows) {
          if (isAddOnRow(row)) continue;
          if (product_id != row[0]) continue;

          const rowQty = parseInt(row[1], 10) || 0;
          // Two aggregates: units inside a custom bundle count toward the product's purchase limit,
          // but a custom-bundle line only consumes its HERO variant's inventory, so those units
          // must not inflate the inventory sum.
          total_cart_qun_max += rowQty;
          if (!isCtoChildRow(row)) total_cart_qun += rowQty;

          // Tightest non-blank limit wins, and never overwrite with NaN. A synthetic row for a
          // child with no limit would otherwise blank out the real line's limit — parseInt('') is
          // NaN and every later comparison against NaN is false, silently removing this check.
          // Taking the minimum also makes row order irrelevant, which matters because the order is
          // cart.items order and not controllable. 0 stays the "no limit" sentinel.
          const rowMax = parseInt(row[2], 10);
          if (!Number.isNaN(rowMax) && (total_max_qun === 0 || rowMax < total_max_qun)) total_max_qun = rowMax;
        }
      }
    });
    if(parseInt(event.target.defaultValue) < parseInt(qty)){
      inc_or_dec1 = 1;
    }else{
      inc_or_dec1 = 0;
    }

    var qty_new = total_cart_qun - current_qun + parseInt(qty);
    var qty_new_max = total_cart_qun_max - current_qun + parseInt(qty);

    if(inc_or_dec1 == 1){
      if(total_inv_qun < qty_new){
        setErrorMessage(total_inv_qun);
        return false;
      }

      if(total_max_qun != 0){
        if(total_max_qun <= total_cart_qun_max || total_max_qun < qty_new_max){
          setErrorMessage(total_max_qun);
          return false;
        }
      }

      // Bundle line edit: increasing the bundle scales its child quantities, so each child
      // product's cross-cart total (its standalone lines + every bundle that contains it) must
      // still fit that child's own limit. minquant emits one row per child, keyed
      // `bundle-component-{bundleKey}-{index}` for native bundles and
      // `bundle-cto-child-{bundleKey}-{index}` for custom (CTO) bundles; only the edited bundle's
      // own children carry main_key, so a non-bundle line matches nothing here and is a no-op.
      if (current_qun > 0) {
        const { ctoChild, nativeComponent } = window.CartQuantity.KEY_PREFIX;
        var childPrefixes = [`${nativeComponent}${main_key}-`, `${ctoChild}${main_key}-`];

        for (var ci = 0; ci < minquantRows.length; ci++) {
          var childCols = minquantRows[ci];
          if (!childPrefixes.some((prefix) => childCols[3]?.startsWith(prefix))) continue;

          var childProductId = childCols[0];
          var childQtyInBundle = parseInt(childCols[1]) || 0;
          var childMax = parseInt(childCols[2]);
          if (isNaN(childMax)) continue;

          // A native component's `quantity` is the line total (per-bundle units × current bundle
          // qty), so scale it to the requested bundle quantity. A CTO child row carries the line
          // quantity itself (1 child per bundle), so the scaling degenerates to exactly `qty`.
          var newChildInBundle = Math.round((childQtyInBundle / current_qun) * parseInt(qty));

          // Units of this child living anywhere else: all rows for the child product, minus this
          // bundle's own component contribution (standalone lines + other bundles' components).
          var childElsewhere = 0;
          for (var cj = 0; cj < minquantRows.length; cj++) {
            if (minquantRows[cj][0] == childProductId) {
              childElsewhere += parseInt(minquantRows[cj][1]) || 0;
            }
          }
          childElsewhere -= childQtyInBundle;

          if (childElsewhere + newChildInBundle > childMax) {
            setErrorMessage(childMax);
            return false;
          }
        }
      }
    }
    /* VAT Product Limits - Karthikeyan */
    if(typeof vat_free_day !== 'undefined' && vat_free_day == true){
      var addtaxfreecheck = main_product_tags.indexOf('taxfree') != -1;
      if(addtaxfreecheck == true) {
        if(parseInt(event.target.defaultValue) < parseInt(qty)){
          var previous_quy = parseInt(qty) - parseInt(event.target.defaultValue);
          var total_vat_quantity = previous_quy  + parseInt(getCookie('total_quantity'));
          var inc_or_dec = 1;
        }else{
          var inc_or_dec = 0;
        }

        if(total_vat_quantity  > +vat_free_quantity){
          if(inc_or_dec == 1){
            alert(vat_free_message);
            window.onCartUpdate();
            return false;
          }
        }
        if(inc_or_dec == 1){
          if(+qty > +vat_free_quantity){
            alert(vat_free_message);
            window.onCartUpdate();
            return false;
          }
        }
      }
    }

    var cartProducts_ga = [];
    var item_cart = {};
    var exphone = [];
    var discount = 0;
    var productPrice = main_product_price;
    var productcomPrice = main_productcpm_price;

    if(parseInt(event.target.defaultValue) < parseInt(qty)){
      var prodQuant = parseInt(qty) - parseInt(event.target.defaultValue);
    }else{
      var prodQuant =  parseInt(event.target.defaultValue) - parseInt(qty);
    }
    prodQuant = parseInt(prodQuant);
    productPrice = Number((productPrice || '').replace(/[^0-9.-]+/g, ""));
    var value_price = productPrice * parseInt(prodQuant);
    if (productcomPrice) {
      productcomPrice = Number(productcomPrice.replace(/[^0-9.-]+/g, ""));
      if (productcomPrice > productPrice) {
        discount = parseFloat(productcomPrice) - parseFloat(productPrice);
        discount = parseFloat(discount);
        //  productPrice = productcomPrice;
      }
    }
    var value_price1 = parseFloat(value_price);
    var productPrice1 = parseFloat(productPrice);
    item_cart ["item_id"] = main_product_mpn;
    item_cart['item_name'] = main_product_title;
    item_cart['quantity'] = parseInt(prodQuant);
    item_cart['price'] = productPrice1;
    var storedCart = null;
    try { storedCart = JSON.parse(localStorage.getItem("cart")); } catch (e) { storedCart = null; }
    if(storedCart != null){
      exphone = storedCart;
    }
    cartProducts_ga.push(item_cart);
    if(parseInt(event.target.defaultValue) < parseInt(qty)){
      dataLayer.push({ 'ecommerce': null });
      dataLayer.push({
      'event': 'add_to_cart',
      'ecommerce': {
        'currency':shop_currency,
        'value':value_price1,
        'items': cartProducts_ga
          }
        });
    } else {
      dataLayer.push({ 'ecommerce': null });
      dataLayer.push({
        'event': 'remove_from_cart',
        'ecommerce': {
          'currency':shop_currency,
          'value':value_price1,
          'items': cartProducts_ga
        }
      });
    }
    
    const self = this;

    if(sub_key || sw_sub_key || gwp_sub_key) {
      var new_qty = parseInt(qty) - current_qun;

      if (new_qty > 0) {
        // if incrementing a product with apple care / warranty / gwp, add only the product to the cart without apple care / warranty
        var data = { items: [] };
        data.items.push({
          id: variant_id,
          quantity: new_qty,
          properties: {
            _uuid: main_product_handle,
            ...(main_product_preorder && { _preOrder: 'true' }),
            ...(main_product_preordermessage && { _preOrderMessage: main_product_preordermessage }),
            ...(main_product_trade_in && { _tradeInEligible: 'true' }),
            ...(main_product_cto_product && { _cto_product: 'true' }),
            ...bundleProperties
          }
        });

        $.ajax({
          type: 'POST',
          url: `${window.Shopify.routes.root}cart/add.js`,
          data: data,
          success: function(d) {
            var new_item_key = d.items[0].key;
            localStorage.setItem('cart_new_item_key', new_item_key);
            window.onCartUpdate({scrollToTop: true});
          },
          error: function(xhr) {
            const errorMessage = window.cartStrings?.quantityError?.replace('[quantity]', qty) || xhr.responseJSON?.description || xhr.responseJSON?.message || window.cartStrings?.error;
            event.target.value = event.target.getAttribute('value');
            self.updateLiveRegions(main_item_index, errorMessage);
            self.toggleAddOnButtons('enable');
          },
          dataType: 'json'
        });
      } else {
        // otherwise, if decrementing a product with apple care / warranty / gwp, remove the product as well as the associated apple care / warranty / gwp
        var data = { updates: {} };
        data.updates[main_key] = qty;
        if (sub_key && sw_sub_key) {
          data.updates[sub_key] = qty;
          data.updates[sw_sub_key] = qty;
        } else if (sub_key) {
          data.updates[sub_key] = qty;
        } else if (sw_sub_key) {
          data.updates[sw_sub_key] = qty;
        } else if (gwp_sub_key) {
          data.updates[gwp_sub_key] = qty;
        }

        $.ajax({
          type: 'POST',
          url: `${window.Shopify.routes.root}cart/update.js`,
          data: data,
          success: function(d) {
            window.onCartUpdate();
          },
          dataType: 'json'
        });
      }
    } else {
      this.updateQuantity(event.target.dataset.index, event.target.value, document.activeElement.getAttribute('name'));
    }
  }

  onCartUpdate(opts) {
    const {
      scrollToTop = false,
      forceRerenderSections = true,
    } = opts || {};
    const $notificationDrawer = document.querySelector('cart-notification') || null;

    const customCallback = () => {
      if (SDG.Data.bagCheckNewItemAdded) SDG.Data.bagCheckNewItemAdded();
      if (window.refreshModals) window.refreshModals();
      if (window.refreshStoreLocator) window.refreshStoreLocator();
      if (window.refreshNmpAddModalEvents) window.refreshNmpAddModalEvents();
      if (window.refreshTradeInModal) window.refreshTradeInModal();
      if (window.initTradeInModals) window.initTradeInModals();

      $('[data-modal-target="modal-net-monthly-pricing-modal"]:not(.js-net-monthly-pricing-modal-trigger)').on('click', function() {
        if ($('.js-net-monthly-pricing-modal-trigger').length) {
          $('.js-net-monthly-pricing-modal-trigger')[0].click();
        }
      });

      document.querySelectorAll('.tax-campaign__modal-trigger:not([data-tax-campaign-init])').forEach(trigger => {
        trigger.setAttribute('data-tax-campaign-init', '');
        trigger.addEventListener('click', () => {
          const modal = document.querySelector('.tax-campaign__modal');
          if (modal) {
            modal.click();
          }
        });
      });

      if (scrollToTop) {
        window.scrollTo(0, 0);
      }

      // update notification drawer
      if ($notificationDrawer) {
        $.get(`${window.Shopify.routes.root}cart?view=minicart`, function(itemData) {
          var item_count = jQuery(itemData).find('#cart-notification-button .count').text();

          if ($('.cart-count-bubble').length > 0) {
              $('.cart-count-bubble span').text(item_count);
          } else {
            if (item_count?.length > 0) {
              $('#cart-icon-bubble').append('<div class="cart-count-bubble"><span></span></div>');
              $('.cart-count-bubble span').text(item_count);
            }
          }
          $("#cart-notification").text("");
          var textreplace = "<div id='min-cart-replace'></div>";
          $("#cart-notification").append(textreplace);
          $("#cart-notification").replaceWith(itemData);
        });
      }

      // Re-enable add-on buttons only once the cart has finished refreshing, so a
      // Remove click can't re-enable them mid-update (see R15-059). The synchronous
      // enable in the CartRemoveButton handler is now just a deferred safety net.
      if (window.toggleAddOnButtons) window.toggleAddOnButtons('enable');

      // Last and fire-and-forget: nothing above may depend on a cosmetic refresh completing.
      this.debouncedRefreshCartRecommendations?.();
    }

    if (forceRerenderSections) {
      // WIP need to pass the updated cart items to the drawer to update correctly
      // const $CTOcartDrawer = $('cto-cart-drawer');
      // if ($CTOcartDrawer.length && !$CTOcartDrawer.hasClass('hidden')) {
      //   $CTOcartDrawer[0].updateItems();
      // }
      const sections = this.getSectionsToRender().map((section) => section.section).join(',');
      fetch(`${routes.cart_url}?sections=${sections}`)
        .then((response) => response.json())
        .then((parsedSections) => {
          this.getSectionsToRender().forEach((section) => {
            const elementToReplace =
              document.getElementById(section.id)?.querySelector(section.selector) || document.getElementById(section.id);
            if (!elementToReplace) return;
            elementToReplace.innerHTML = this.getSectionInnerHTML(
              parsedSections[section.section],
              section.selector
            );
          });

          const cartIsEmpty = document.getElementById('cartIsEmpty')?.dataset?.isEmpty === 'true';
          this.classList.toggle('is-empty', cartIsEmpty);
          const cartDrawerWrapper = document.querySelector('cart-drawer');
          const cartFooter = document.getElementById('main-cart-footer');
          const cartPaymentBlocks = document.getElementById('main-cart-payment-blocks');
          if (cartFooter) cartFooter.classList.toggle('is-empty', cartIsEmpty);
          if (cartDrawerWrapper) cartDrawerWrapper.classList.toggle('is-empty', cartIsEmpty);
          if (cartPaymentBlocks) cartPaymentBlocks.classList.toggle('is-empty', cartIsEmpty);

          customCallback();
        })
        .catch((e) => {
          console.error(e);
        });
    } else if (this.tagName === 'CART-DRAWER-ITEMS') {
      return fetch(`${routes.cart_url}?section_id=cart-drawer`)
        .then((response) => response.text())
        .then((responseText) => {
          const html = new DOMParser().parseFromString(responseText, 'text/html');
          const selectors = ['cart-drawer-items', '.cart-drawer__footer'];
          for (const selector of selectors) {
            const targetElement = document.querySelector(selector);
            const sourceElement = html.querySelector(selector);
            if (targetElement && sourceElement) {
              targetElement.replaceWith(sourceElement);
            }
          }

          customCallback();
        })
        .catch((e) => {
          console.error(e);
        });
    } else {
      return fetch(`${routes.cart_url}?section_id=main-cart-items`)
        .then((response) => response.text())
        .then((responseText) => {
          const html = new DOMParser().parseFromString(responseText, 'text/html');
          const sourceQty = html.querySelector('cart-items');
          if (sourceQty) this.innerHTML = sourceQty.innerHTML;

          customCallback();
        })
        .catch((e) => {
          console.error(e);
        });
    }
  }

  getSectionsToRender() {
    return [
      {
        id: 'main-cart-items',
        section: document.getElementById('main-cart-items')?.dataset?.id || null,
        selector: '.js-contents',
      },
      {
        id: 'cart-icon-bubble',
        section: 'cart-icon-bubble',
        selector: '.shopify-section',
      },
      {
        id: 'cart-live-region-text',
        section: 'cart-live-region-text',
        selector: '.shopify-section',
      },
      {
        id: 'main-cart-footer',
        section: document.getElementById('main-cart-footer')?.dataset?.id || null,
        selector: '.js-contents',
      },
      {
        id: 'main-cart-payment-blocks',
        section: document.getElementById('main-cart-items')?.dataset?.id || null,
        selector: '.cart-payment-blocks',
      },
    ];
  }

  // conversion-module and product-recommendations-cart are rendered from the cart
  // server-side but are not in getSectionsToRender(), so without this they keep showing
  // recommendations for lines that were already removed until the shopper reloads.
  refreshCartRecommendationSections() {
    if (!document.getElementById('main-cart-items')) return;

    // Shopify prefixes JSON-template section wrappers with the template id,
    // so match on the trailing key.
    const sectionKeys = ['conversion-module', 'product-recommendations-cart'];
    const wrappers = [...document.querySelectorAll('[id^="shopify-section-"]')].filter((wrapper) =>
      sectionKeys.some((key) => wrapper.id === `shopify-section-${key}` || wrapper.id.endsWith(`__${key}`))
    );

    wrappers.forEach((wrapper) => {
      if (wrapper.querySelector('lazyload-section .collection_slider_loading')) return;

      const sectionId = wrapper.id.split('shopify-section-')[1];
      if (!sectionId) return;

      fetch(`${window.location.pathname}?section_id=${encodeURIComponent(sectionId)}`)
        .then((response) => response.text())
        .then((responseText) => {
          // Exact id, so a non-section response is ignored rather than injected into the slot.
          const freshSection = new DOMParser()
            .parseFromString(responseText, 'text/html')
            .getElementById(wrapper.id);
          if (!freshSection) return;

          $(wrapper).html(freshSection.innerHTML);

          if (window.refreshModals) window.refreshModals();
          if (window.initProductSlider) window.initProductSlider();
          if (window.quickAddEvents) window.quickAddEvents();
        })
        .catch((error) => {
          console.error(`Cart recommendation refresh failed for ${sectionId}:`, error);
        });
    });
  }

  updateQuantity(line, quantity, name, variantId) {
    this.enableLoading(line);

    const body = JSON.stringify({
      line,
      quantity,
      sections: this.getSectionsToRender().map((section) => section.section),
      sections_url: window.location.pathname,
    });

    fetch(`${routes.cart_change_url}`, { ...fetchConfig(), ...{ body } })
      .then((response) => {
        return response.text();
      })
      .then((state) => {
        const parsedState = JSON.parse(state);
        const quantityElement =
          document.getElementById(`Quantity-${line}`) || document.getElementById(`Drawer-quantity-${line}`);
        const items = document.querySelectorAll('.cart-item');

        if (parsedState.errors) {
          if (quantityElement) {
            quantityElement.value = quantityElement.getAttribute('value');
          }
          const errorMessage = window.cartStrings?.quantityError?.replace('[quantity]', quantityElement?.value) || (Array.isArray(parsedState.errors) ? parsedState.errors.join(', ') : parsedState.errors);
          this.updateLiveRegions(line, errorMessage);
          this.toggleAddOnButtons('enable');
          return;
        }

        this.classList.toggle('is-empty', parsedState.item_count === 0);
        const cartDrawerWrapper = document.querySelector('cart-drawer');
        const cartFooter = document.getElementById('main-cart-footer');
        const cartPaymentBlocks = document.getElementById('main-cart-payment-blocks');

        if (cartFooter) cartFooter.classList.toggle('is-empty', parsedState.item_count === 0);
        if (cartDrawerWrapper) cartDrawerWrapper.classList.toggle('is-empty', parsedState.item_count === 0);
        if (cartPaymentBlocks) cartPaymentBlocks.classList.toggle('is-empty', parsedState.item_count === 0);

        this.getSectionsToRender().forEach((section) => {
          const elementToReplace =
            document.getElementById(section.id)?.querySelector(section.selector) || document.getElementById(section.id);
          if (!elementToReplace) return;
          elementToReplace.innerHTML = this.getSectionInnerHTML(
            parsedState.sections[section.section],
            section.selector
          );
        });
        const updatedValue = parsedState.items[line - 1] ? parsedState.items[line - 1].quantity : undefined;
        let message = '';
        if (items.length === parsedState.items.length && updatedValue !== parseInt(quantityElement.value)) {
          if (typeof updatedValue === 'undefined') {
            message = window.cartStrings.error;
          }
        }
        this.updateLiveRegions(line, message);

        const lineItem =
          document.getElementById(`CartItem-${line}`) || document.getElementById(`CartDrawer-Item-${line}`);
        if (lineItem && lineItem.querySelector(`[name="${name}"]`)) {
          cartDrawerWrapper
            ? trapFocus(cartDrawerWrapper, lineItem.querySelector(`[name="${name}"]`))
            : lineItem.querySelector(`[name="${name}"]`).focus();
        } else if (parsedState.item_count === 0 && cartDrawerWrapper) {
          trapFocus(cartDrawerWrapper.querySelector('.drawer__inner-empty'), cartDrawerWrapper.querySelector('a'));
        } else if (document.querySelector('.cart-item') && cartDrawerWrapper) {
          trapFocus(cartDrawerWrapper, document.querySelector('.cart-item__name'));
        }

        publish(PUB_SUB_EVENTS.cartUpdate, { source: 'cart-items', cartData: parsedState, variantId: variantId });
        window.onCartUpdate({ forceRerenderSections: false});
      })
      .catch((error) => {
        console.error('Cart updateQuantity failed:', error);
        this.querySelectorAll('.loading-overlay').forEach((overlay) => overlay.classList.add('hidden'));
        const errors = document.getElementById('cart-errors') || document.getElementById('CartDrawer-CartErrors');
        if (errors) {
          errors.textContent = window.cartStrings.error;
        }
      })
      .finally(() => {
        this.disableLoading(line);
      });
  }

  updateLiveRegions(line, message) {
    const lineItemError =
      document.getElementById(`Line-item-error-${line}`) || document.getElementById(`CartDrawer-LineItemError-${line}`);
    if (lineItemError) lineItemError.querySelector('.cart-item__error-text').textContent = message;

    this.lineItemStatusElement?.setAttribute('aria-hidden', 'true');

    const cartStatus =
      document.getElementById('cart-live-region-text') || document.getElementById('CartDrawer-LiveRegionText');
    if (!cartStatus) return;
    cartStatus.setAttribute('aria-hidden', 'false');

    setTimeout(() => {
      cartStatus.setAttribute('aria-hidden', 'true');
    }, 1000);
  }

  getSectionInnerHTML(html, selector) {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector)?.innerHTML || '';
  }

  enableLoading(line) {
    const mainCartItems = document.getElementById('main-cart-items') || document.getElementById('CartDrawer-CartItems');
    mainCartItems?.classList.add('cart__items--disabled');

    const cartItemElements = this.querySelectorAll(`#CartItem-${line} .loading-overlay`);
    const cartDrawerItemElements = this.querySelectorAll(`#CartDrawer-Item-${line} .loading-overlay`);

    [...cartItemElements, ...cartDrawerItemElements].forEach((overlay) => overlay.classList.remove('hidden'));

    document.activeElement.blur();
    this.lineItemStatusElement.setAttribute('aria-hidden', 'false');
  }

  disableLoading(line) {
    const mainCartItems = document.getElementById('main-cart-items') || document.getElementById('CartDrawer-CartItems');
    mainCartItems?.classList.remove('cart__items--disabled');

    const cartItemElements = this.querySelectorAll(`#CartItem-${line} .loading-overlay`);
    const cartDrawerItemElements = this.querySelectorAll(`#CartDrawer-Item-${line} .loading-overlay`);

    cartItemElements.forEach((overlay) => overlay.classList.add('hidden'));
    cartDrawerItemElements.forEach((overlay) => overlay.classList.add('hidden'));
  }
}

customElements.define('cart-items', CartItems);

if (!customElements.get('cart-note')) {
  customElements.define(
    'cart-note',
    class CartNote extends HTMLElement {
      constructor() {
        super();

        this.addEventListener(
          'change',
          debounce((event) => {
            const body = JSON.stringify({ note: event.target.value });
            fetch(`${routes.cart_update_url}`, { ...fetchConfig(), ...{ body } });
          }, ON_CHANGE_DEBOUNCE_TIMER)
        );
      }
    }
  );
}
