if (!customElements.get('quantity-popover')) {
  customElements.define(
    'quantity-popover',
    class QuantityPopover extends HTMLElement {
      constructor() {
        super();
        this.mql = window.matchMedia('(min-width: 990px)');
        this.mqlTablet = window.matchMedia('(min-width: 750px)');
        this.infoButtonDesktop = this.querySelector('.quantity-popover__info-button--icon-only');
        this.infoButtonMobile = this.querySelector('.quantity-popover__info-button--icon-with-label');
        this.popoverInfo = this.querySelector('.quantity-popover__info');
        this.closeButton = this.querySelector('.button-close');
        this.variantInfo = this.querySelector('.quantity-popover-container');
        this.eventMouseEnterHappened = false;

        // Keep bound handler references so listeners can be removed in disconnectedCallback.
        this.boundClosePopover = this.closePopover.bind(this);
        this.boundTogglePopover = this.togglePopover.bind(this);

        if (this.closeButton) {
          this.closeButton.addEventListener('click', this.boundClosePopover);
        }

        if (this.popoverInfo && this.infoButtonDesktop && this.mql.matches) {
          this.popoverInfo.addEventListener('mouseenter', this.boundClosePopover);
        }

        if (this.infoButtonDesktop) {
          this.infoButtonDesktop.addEventListener('click', this.boundTogglePopover);
          this.infoButtonDesktop.addEventListener('focusout', this.boundClosePopover);
        }

        if (this.infoButtonMobile) {
          this.infoButtonMobile.addEventListener('click', this.boundTogglePopover);
          this.infoButtonMobile.addEventListener('focusout', this.boundClosePopover);
        }

        if (this.infoButtonDesktop && this.mqlTablet.matches) {
          this.variantInfo.addEventListener('mouseenter', this.boundTogglePopover);
          this.variantInfo.addEventListener('mouseleave', this.boundClosePopover);
        }
      }

      disconnectedCallback() {
        if (this.closeButton) {
          this.closeButton.removeEventListener('click', this.boundClosePopover);
        }

        if (this.popoverInfo && this.infoButtonDesktop && this.mql.matches) {
          this.popoverInfo.removeEventListener('mouseenter', this.boundClosePopover);
        }

        if (this.infoButtonDesktop) {
          this.infoButtonDesktop.removeEventListener('click', this.boundTogglePopover);
          this.infoButtonDesktop.removeEventListener('focusout', this.boundClosePopover);
        }

        if (this.infoButtonMobile) {
          this.infoButtonMobile.removeEventListener('click', this.boundTogglePopover);
          this.infoButtonMobile.removeEventListener('focusout', this.boundClosePopover);
        }

        if (this.infoButtonDesktop && this.mqlTablet.matches) {
          this.variantInfo.removeEventListener('mouseenter', this.boundTogglePopover);
          this.variantInfo.removeEventListener('mouseleave', this.boundClosePopover);
        }
      }

      togglePopover(event) {
        event.preventDefault();
        if (event.type === 'mouseenter') {
          this.eventMouseEnterHappened = true;
        }

        if (event.type === 'click' && this.eventMouseEnterHappened) return;

        const button = this.infoButtonDesktop && this.mql.matches ? this.infoButtonDesktop : this.infoButtonMobile;
        const isExpanded = button.getAttribute('aria-expanded') === 'true';

        button.setAttribute('aria-expanded', !isExpanded);

        this.popoverInfo.toggleAttribute('hidden');

        const isOpen = button.getAttribute('aria-expanded') === 'true';

        button.classList.toggle('quantity-popover__info-button--open');

        if (isOpen && event.type !== 'mouseenter') {
          button.focus();
        }
      }

      closePopover(event) {
        event.preventDefault();
        const isChild = this.variantInfo.contains(event.relatedTarget);

        const button = this.infoButtonDesktop && this.mql.matches ? this.infoButtonDesktop : this.infoButtonMobile;

        if (!event.relatedTarget || !isChild) {
          button.setAttribute('aria-expanded', 'false');
          button.classList.remove('quantity-popover__info-button--open');
          this.popoverInfo.setAttribute('hidden', '');
        }

        this.eventMouseEnterHappened = false;
      }
    }
  );
}
