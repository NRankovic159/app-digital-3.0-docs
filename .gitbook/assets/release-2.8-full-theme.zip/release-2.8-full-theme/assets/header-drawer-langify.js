function displayLangifySwitcher() { 
  const config = { 
    dom: { 
      langifySwitcher: '.ly-switcher-wrapper.ly-breakpoint-1', 
      langWrapper: 'localizationWrapper' 
    },
    cls: { 
      active: 'menu-drawer__localization--active',
      translateAdaptLocalization: 'translate-adapt-localization'
    }
  }

  function appendSwitcher({ switcher, wrapper }) {
    if (!wrapper || !switcher) return;

    wrapper.appendChild(switcher);
    wrapper.classList.add(config.cls.active);
  }

  function init() {
    if (SDG?.Data?.languageSelector == 'translate_adapt') return;

    const $langifySwitcher = document.querySelector(config.dom.langifySwitcher) || null;
    const $wrapper = document.getElementById(config.dom.langWrapper) || null;

    if ($langifySwitcher && $wrapper) {
      appendSwitcher({ switcher: $langifySwitcher, wrapper: $wrapper });

      return;
    } 

    if (!$langifySwitcher || !$wrapper) {
      // if the switcher is not found, we observe the DOM to watch for injection
      const observer = new MutationObserver(function (mutations) {
        mutations.forEach(function () {
          const $langifyEle = document.querySelector(config.dom.langifySwitcher) || null;
  
          if ($langifyEle) {
            const $langWrapper = document.getElementById(config.dom.langWrapper) || null;
            
            if ($langWrapper) {
              appendSwitcher({ switcher: $langifyEle, wrapper: $langWrapper });
  
              observer.disconnect();
              clearTimeout(observerTimeout);

              return;
            }
          }
        });
      });
  
      observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true,
      });

      // Safety timeout: stop observing after 30s to avoid leaked observers
      // when the wrapper is never injected.
      const observerTimeout = setTimeout(() => {
        observer.disconnect();
      }, 30000);
    }
  }

  init();
}

document.addEventListener('DOMContentLoaded', function() {
  displayLangifySwitcher();
});
