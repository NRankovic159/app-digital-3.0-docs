if (!customElements.get('pickup-availability')) {
  customElements.define(
    'pickup-availability',
    class PickupAvailability extends HTMLElement {
      constructor() {
        super();

        this.errorHtml = this.querySelector('template')?.content.firstElementChild.cloneNode(true);
        this.info = this.querySelector('.js-pickup-availability-info');
        this.pickupAvailabilityConfirmStore = this.querySelector('.pickup-availability__confirm-store');
        this.storeLocator = document.querySelector('my-store-locator');
        this.storeLocatorDrawer = document.querySelector('my-store-locator-drawer');
        this.storeConfirmationMessage = window.cartStrings.storeConfirmationMessage;
      }

      escapeHtml(value) {
        return String(value ?? '')
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#39;');
      }

      renderError() {
        // CTO pickup icons (data-cto) have no info container to render the error into
        if (!this.info) return;
        this.info.innerHTML = '';
        if (this.errorHtml) this.info.append(this.errorHtml);
      }

      renderLoading() {
        this.info.innerHTML = '';
        if (this.pickupAvailabilityConfirmStore) this.pickupAvailabilityConfirmStore.innerHTML = '';
        const loadingHtml = `
          <p class="caption">
            ${this.storeLocator.dataset.loadingText} <i class="fa fa-spinner fa-spin"></i>
          </p>
        `;
        const loadingNode = new DOMParser().parseFromString(loadingHtml, 'text/html').body.childNodes[0];
        this.info.append(loadingNode);
      }

      renderPreview(location) {
        if (this.dataset?.cto) {
          if (location?.available) {
            this.classList.add('is-active');
          } else {
            this.classList.remove('is-active');
          }
          return;
        }

        if (this.dataset?.itemKey && location) {
          const itemLocationsData = this.storeLocator.itemLocationsData[this.dataset.itemKey];
          if (itemLocationsData) {
            const itemLocation = itemLocationsData.find((itemLocation) => itemLocation.id === location.id);
            if (itemLocation) {
              location = itemLocation;
            }
          }
        }

        let bundleAvailable = true;

        const selectedBundle = document.querySelector('input.js-cto-set-price-display:checked')

        if (selectedBundle) {
          if (!location?.available) {
            bundleAvailable = false;
          }

          const selectedBundleSecondaryProductId = selectedBundle.dataset.pairedProductId;

          const selectedBundleSecondaryProductLocationData = this.storeLocator.locationsData
            ?.find((item) => item.productId.includes(selectedBundleSecondaryProductId))?.locationData;

          const selectedBundleSecondaryProductLocation = selectedBundleSecondaryProductLocationData
            ?.find((item) => item.id === location.id)

          if ((selectedBundleSecondaryProductLocation && !selectedBundleSecondaryProductLocation.available) || !selectedBundleSecondaryProductLocation) {
            bundleAvailable = false;
          }
        }

        if (window.location.href.includes('/cart') && this.dataset?.itemKey) {
          const itemKey = this.dataset?.itemKey;
          const bundleSecondaryProductElement = document.querySelector(`[data-item-key="secondary${itemKey}"]`)

          if(bundleSecondaryProductElement) {
            if (!location?.available) {
              bundleAvailable = false;
            }

            const bundleSecondaryProductKey = bundleSecondaryProductElement.dataset.itemKey;
            const bundleSecondaryProductLocationsData = this.storeLocator.itemLocationsData[bundleSecondaryProductKey];
            const bundleSecondaryProductLocation = bundleSecondaryProductLocationsData?.find((itemLocation) => itemLocation.id === location.id);

            if ((bundleSecondaryProductLocation && !bundleSecondaryProductLocation.available) || !bundleSecondaryProductLocation) {
              bundleAvailable = false;
            }
          }

          const gwpProductElements = document.querySelectorAll(`[data-item-key^="gwp${itemKey}_"]`);
          if (gwpProductElements.length > 0) {
            if (!location?.available) {
              bundleAvailable = false;
            }
            gwpProductElements.forEach((gwpEl) => {
              const gwpKey = gwpEl.dataset.itemKey;
              const gwpLocationsData = this.storeLocator.itemLocationsData[gwpKey];
              const gwpLocation = gwpLocationsData?.find((itemLocation) => itemLocation.id === location.id);
              if ((gwpLocation && !gwpLocation.available) || !gwpLocation) {
                bundleAvailable = false;
              }
            });
          }
        }

        this.info.innerHTML = '';
        if (this.pickupAvailabilityConfirmStore) this.pickupAvailabilityConfirmStore.innerHTML = '';
        let buttonText = this.storeLocator.dataset.viewStoreAvailabilityText;
        let unavailableHtml = '';
        let timeHtml = '';
        let stockHtml = '';
        let messageOverridden = false;

        if (location) {
          const itemsAdded = this.dataset?.itemQuantity ? parseInt(this.dataset.itemQuantity) : null;

          buttonText = location.name;

          let pickUpTimeTranslated = '';
          if (location.pickUpTime) {
            const key = location.pickUpTime;
            const languageKey = SDG.Data.language?.toLowerCase() || 'en';
            pickUpTimeTranslated = window.deliveryOptionsStrings?.[languageKey]?.[key] || location.pickUpTime;
          }

          let overridePickupMessage = this.dataset?.overridePickupMessage;
          const messageType = this.dataset?.messageType;
          if (!overridePickupMessage && messageType) {
            const languageKey = SDG.Data.language?.toLowerCase() || 'en';
            let pickupMessagesJson = null;
            const rawPickupMessages = location.pickupMessages?.value;
            if (rawPickupMessages) {
              try {
                pickupMessagesJson = JSON.parse(rawPickupMessages);
              } catch (e) {
                pickupMessagesJson = null;
              }
            }
            const pickupMessages = pickupMessagesJson?.[languageKey] || pickupMessagesJson?.['en'];
            switch(messageType) {
              case 'cto':
                overridePickupMessage = pickupMessages?.cto;
                break;
              case 'preorder':
                overridePickupMessage = pickupMessages?.preOrder;
                break;
              case 'in stock':
                overridePickupMessage = pickupMessages?.inStock;
                break;
            }
          }

          let isPreSale;
          try {
            isPreSale = JSON.parse(this.dataset?.isPreSale || 'false');
          } catch (e) {
            isPreSale = false;
          }

          if (overridePickupMessage && location.productPickupOfferedAtLocation && !(messageType === 'in stock' && !location.available) && bundleAvailable && isPreSale === false) {
            timeHtml = `
              <p class="caption">
                <span class="pickup-availability__time apl-section-pickup-availability-time">
                  ${overridePickupMessage}
                </span>
              </p>
            `;
            if (window.location.href.includes('/cart') && this.pickupAvailabilityConfirmStore) {
              this.pickupAvailabilityConfirmStore.innerHTML = this.storeConfirmationMessage;
            }
            messageOverridden = true;
          } else if (location.available && bundleAvailable && isPreSale === false) {
            this.dataset.quantityAvailable = location.quantityAvailable;

            timeHtml = `
              <p class="caption">
                <span class="pickup-availability__time apl-section-pickup-availability-time">
                  ${pickUpTimeTranslated}
                </span>
              </p>
            `;
            if (location.quantityAvailable < 10) {
              const stockText = this.storeLocator.dataset.lowStockHtml.replace('{{ quantity }}', location.quantityAvailable);
              stockHtml = `
                <p class="caption">
                  <span class="pickup-availability__stock apl-section-pickup-availability-stock">
                    ${stockText}
                  </span>
                </p>
              `;
            }
            if (itemsAdded && itemsAdded > location.quantityAvailable) {
              timeHtml = `
                <p class="caption">
                <span class="pickup-availability__error apl-section-pickup-availability-error">
                  ${this.escapeHtml(this.dataset.error)}
                </span>
                </p>
              `;
            }
            if (window.location.href.includes('/cart') && this.pickupAvailabilityConfirmStore) {
              this.pickupAvailabilityConfirmStore.innerHTML = this.storeConfirmationMessage;
            }
          } else if (location.available === false || bundleAvailable === false || isPreSale === true) {
            const overrideUnavailableMessage = this.dataset?.overrideUnavailableMessage;
            unavailableHtml = `
              <p class="caption unavailable apl-section-pickup-availability-unavailable">
                ${overrideUnavailableMessage ? (`<span class="pickup-availability__unavailable-override">${overrideUnavailableMessage}</span>`) : this.storeLocator.dataset.unavailableText}
              </p>
            `;
            messageOverridden = !!overrideUnavailableMessage;
          }

        }

        const infoHtml = `
          <div class="pickup-availability-info-details apl-section-pickup-availability">
            ${unavailableHtml}
            ${timeHtml}
            ${stockHtml}
            <button
              class="js-my-store-locator-drawer-btn pickup-availability-button link link--text apl-section-pickup-availability-cta"
              aria-haspopup="dialog"
              ${this.dataset?.itemKey ? `data-item-key="${this.dataset.itemKey}"` : ''}
            >
              <span class="underlined-text">${buttonText}</span>
              <i class="fa-solid fa-chevron-right cto-chevron"></i>
            </button>
          </div>
        `;

        const infoNode = new DOMParser().parseFromString(infoHtml, 'text/html').body.childNodes[0];
        this.info.append(infoNode);

        if (messageOverridden) {
          this.classList.add('is-overridden');
        } else {
          this.classList.remove('is-overridden');
        }

        const button = this.querySelector('button');
        if (button) {
          button.addEventListener('click', (evt) => {
            evt.preventDefault();
            // set the location data to the item specific location data if it exists
            this.storeLocatorDrawer.selectedItemLocationsKey = null;
            if (this.dataset?.itemKey) {
              const selectedItemLocationsData = this.storeLocator.itemLocationsData[this.dataset.itemKey];
              if (selectedItemLocationsData) {
                this.storeLocatorDrawer.selectedItemLocationsKey = this.dataset.itemKey;
                this.storeLocatorDrawer.updateStoreDetails(selectedItemLocationsData, '');
              }
            }
            this.storeLocatorDrawer.show(evt.currentTarget);
          });
        }
      }
    }
  );
}
