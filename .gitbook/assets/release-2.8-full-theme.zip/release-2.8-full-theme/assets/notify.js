function notify() {
  const config = {
    dom: {
      modal: 'notifyModal',
      modal_cancel_button: 'notifyModalCancel',
      modal_close_button: 'notifyModalClose',
      modal_cto: 'cto-notify-modal',
      modal_open_button: '.js-notify-modal-open_button',
      modal_copy: '.js-notify-content',
      modal_title: '.js-notify-title',
      modal_success: '.js-notify-title-success',
      modal_success_button: '.js-notify-success-button',
      modal_input: '.js-notify-input',
      modal_submit: '.js-notify-submit',
      modal_overlay: '.js-notify-overlay',
      modal_error: '.js-notify-error',
      modal_error_text: '.js-notify-general-error-text',
      modal_duplicate_error_text: '.js-notify-duplicate-request-error-text',
      modal_email_format_error: '.js-notify-error-request-error-text',
      update_message: '.cto-update-message',
    },
    cls: {
      active: 'is-visible',
      error: 'modal__input--error',
      hidden: 'hide',
    },
  };

  const $modal = document.getElementById(config.dom.modal);
  const $closeButton = document.getElementById(config.dom.modal_close_button);
  const $cancelButton = document.getElementById(config.dom.modal_cancel_button);
  const $triggers = document.querySelectorAll(config.dom.modal_open_button) || [];
  const $isCto = $modal?.classList.contains(config.dom.modal_cto);
  const $input = $modal?.querySelector(config.dom.modal_input) || null;
  const $submit = $modal?.querySelector(config.dom.modal_submit) || null;
  const $overlay = $modal?.querySelector(config.dom.modal_overlay) || null;

  // success ui
  const $successButton = $modal?.querySelector(config.dom.modal_success_button) || null;
  const $heading = $modal?.querySelector(config.dom.modal_title) || null;
  const $success = $modal?.querySelector(config.dom.modal_success) || null;
  const $content = $modal?.querySelector(config.dom.modal_copy) || null;
  const $updateMessage = document.querySelector(config.dom.update_message);

  const subscriber = {
    email: null,
    variant: null,
    product: null,
  };

  // Element that opened the modal, so focus can be returned to it on close (WCAG 2.4.3).
  let openerElement = null;

  function init() {
    if ($modal && $closeButton && $input && $triggers?.length > 0) {
      addEvents();
    }

    window.initNotifyModal = init;
    window.refreshNotifyModal = resetModalState;
  }

  /**
   * Add events
   * @description Adds events
   * @return {void}
   */
  function addEvents() {
    [...$triggers].forEach(($trigger) => {
      $trigger.addEventListener('click', (e) => {
        e.preventDefault();
        openModal(e);
      });
    });

    $closeButton.addEventListener('click', (e) => {
      e.preventDefault();
      closeModal(e);
    });

    if ($cancelButton) {
      $cancelButton.addEventListener('click', (e) => {
        e.preventDefault();
        closeModal(e);
      });
    }

    $input.addEventListener('input', (e) => {
      clearError();

      subscriber.email = e.target.value;
    });

    if ($submit) {
      const { notifyEvent } = $submit.dataset || false;
      if (notifyEvent === 'true') return;

      $submit.setAttribute('data-notify-event', true);
      $submit.addEventListener('click', (e) => {
        e.preventDefault();

        subscribe();
      });
    }

    if ($overlay) {
      $overlay.addEventListener('click', (e) => {
        e.preventDefault();
        closeModal();
      });
    }

    if ($successButton) {
      $successButton.addEventListener('click', (e) => {
        e.preventDefault();
        closeModal();
      });
    }
  }

  /**
   * Open Modal
   * @description Opens modal
   * @param {Event} e - Event
   * @return {void}
   */
  function openModal(e) {
    const { variant, product } = e?.currentTarget?.dataset || {};

    // Remember the trigger so focus can be returned to it when the modal closes.
    if (e?.currentTarget instanceof HTMLElement) {
      openerElement = e.currentTarget;
    }

    if (variant && product) {
      subscriber.variant = variant;
      subscriber.product = product;
    }

    if ($isCto) {
      $cancelButton.classList.remove(config.cls.hidden);
      setCTOProductDetails();
    }

    $modal.classList.add(config.cls.active);
    $modal.setAttribute('aria-hidden', false);

    // small timeout to allow modal to open before trapping focus
    setTimeout(() => {
      trapFocus($modal);
    }, 550);
  }

  /**
   * Close Modal
   * @description Closes modal
   * @return {void}
   */
  function closeModal() {
    $modal.classList.remove(config.cls.active);
    $modal.setAttribute('aria-hidden', true);

    if (trapFocusKeydownHandler) {
      $modal.removeEventListener('keydown', trapFocusKeydownHandler);
      trapFocusKeydownHandler = null;
    }

    resetModalState();
    if ($updateMessage && window.updateMessage) {
      const updateMessage = SDG.updateMessage();
      updateMessage.openModal(window.updateMessage);
    }

    // Return focus to the element that opened the modal (WCAG 2.4.3).
    if (openerElement && typeof openerElement.focus === 'function') {
      openerElement.focus();
    }
    openerElement = null;
  }

  /**
   * Reset Modal State
   * @description Resets modal state
   * @return {void}
   */
  function resetModalState() {
    $input.value = '';
    subscriber.email = null;
    subscriber.variant = null;
    subscriber.product = null;

    clearError();
    resetSuccessUI();
  }

  /**
   * Trap Focus
   * @description Traps focus within modal
   * @param {HTMLElement} element - Element to trap focus within
   * @return {void}
   */
  let trapFocusKeydownHandler = null;

  function trapFocus(element) {
    const focusableEls = element.querySelectorAll(
      'a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])'
    );
    if (!focusableEls?.length) return;

    const firstFocusableEl = focusableEls[0];
    const lastFocusableEl = focusableEls[focusableEls.length - 1];

    if (!firstFocusableEl || !lastFocusableEl) return;

    $input.focus();

    if (trapFocusKeydownHandler) {
      element.removeEventListener('keydown', trapFocusKeydownHandler);
    }

    trapFocusKeydownHandler = (e) => {
      const isTabPressed = e.key === 'Tab';
      const isEscape = e.key === 'Escape';
      const isEnter = e.key === 'Enter';

      if (isEnter) {
        e.preventDefault();
        $submit.click();
      }

      if (isEscape) {
        closeModal();
      }

      if (!isTabPressed) {
        return;
      }

      if (e.shiftKey) {
        /* shift + tab */ if (document.activeElement === firstFocusableEl) {
          lastFocusableEl.focus();
          e.preventDefault();
        }
      } /* tab */ else {
        if (document.activeElement === lastFocusableEl) {
          firstFocusableEl.focus();
          e.preventDefault();
        }
      }
    };

    element.addEventListener('keydown', trapFocusKeydownHandler);
  }

  /**
   * Subscribe
   * @description Subscribes to product via Back in stock
   * @return {void}
   */
  function subscribe() {
    if (!window?.BIS) {
      closeModal();

      console.error({ message: 'There was an error subscribing to the product.', error: 'BIS is not defined.' });
      return;
    }

    if (!subscriber.variant || !subscriber.product) return;

    const isValid = validateEmail();

    if (isValid) {
      $submit.disabled = true;

      BIS.create(subscriber.email, subscriber.variant, subscriber.product).then((resp) => {
        const { errors } = resp || null;

        if (errors) {
          if (errors?.base?.length > 0 && errors.base[0].includes('already registered')) {
            setError('duplicate');
          } else {
            setError();
          }
          console.error({ message: 'There was an error subscribing to the product.', error: resp.errors });
        } else {
          $submit.disabled = false;
          clearError();
          onSuccess();
        }
      }).catch((error) => {
        $submit.disabled = false;
        setError();
        console.error({ message: 'There was an error subscribing to the product.', error });
      });
    }

    if (!isValid) {
      setError('email');
    }
  }

  /**
   * Set Error
   * @description Sets error state
   * @param {string} errorType - Type of error optional
   * @return {void}
   */
  function setError(errorType = 'server') {
    const $errorWrapper = $modal?.querySelector(config.dom.modal_error) || null;
    const $errorText = $modal?.querySelector(config.dom.modal_error_text) || null;
    const $duplicateErrorText = $modal?.querySelector(config.dom.modal_duplicate_error_text) || null;
    const $emailError = $modal?.querySelector(config.dom.modal_email_format_error) || null;

    if ($errorWrapper && $errorText && $duplicateErrorText && $emailError) {
      if (errorType === 'server') {
        $emailError.classList.add(config.cls.hidden);
        $duplicateErrorText.classList.add(config.cls.hidden);
        $errorText.classList.remove(config.cls.hidden);
      }

      if (errorType === 'duplicate') {
        $errorText.classList.add(config.cls.hidden);
        $emailError.classList.add(config.cls.hidden);
        $duplicateErrorText.classList.remove(config.cls.hidden);
      }

      if (errorType === 'email') {
        $errorText.classList.add(config.cls.hidden);
        $duplicateErrorText.classList.add(config.cls.hidden);
        $emailError.classList.remove(config.cls.hidden);
      }

      $errorWrapper.classList.remove(config.cls.hidden);
    }


    $input.classList.add(config.cls.error);
    $submit.disabled = true;
  }

  /**
   * Clear Error
   * @description Clears error state
   * @return {void}
   */
  function clearError() {
    const $errorWrapper = $modal?.querySelector(config.dom.modal_error) || null;
    const $errorText = $modal?.querySelector(config.dom.modal_error_text) || null;
    const $duplicateErrorText = $modal?.querySelector(config.dom.modal_duplicate_error_text) || null;
    const $emailError = $modal?.querySelector(config.dom.modal_email_format_error) || null;

    if ($errorWrapper && $errorText && $duplicateErrorText && $emailError) {
      $errorWrapper.classList.add(config.cls.hidden);
      $errorText.classList.add(config.cls.hidden);
      $duplicateErrorText.classList.add(config.cls.hidden);
      $emailError.classList.add(config.cls.hidden);
    }

    $input.classList.remove(config.cls.error);
    $submit.disabled = false;
  }

  /**
   * On Success
   * @description Sets success state
   * @return {void}
   */
  function onSuccess() {
    if ($heading && $success) {
      $heading.classList.add(config.cls.hidden);
      $success.classList.remove(config.cls.hidden);

      if ($content) {
        $content.classList.add(config.cls.hidden);
      }

      if ($isCto && $successButton) {
        $cancelButton.classList.add(config.cls.hidden);
      }

      if ($successButton) {
        $submit.classList.add(config.cls.hidden);
        $successButton.classList.remove(config.cls.hidden);
      }

      if ($input) {
        $input.value = '';
        $input.classList.add(config.cls.hidden);
      }

      if ($isCto) {
        window.updateMessage = (window.SDG && SDG.Data && SDG.Data.stockNotificationMessageCto) || 'You will be notified when your selection is in stock';
        closeModal();
      }
    }
  }

  /**
   * Reset Success UI
   * @description Resets success state
   * @return {void}
   */
  function resetSuccessUI() {
    if ($heading && $success) {
      $heading.classList.remove(config.cls.hidden);
      $success.classList.add(config.cls.hidden);

      if ($content) {
        $content.classList.remove(config.cls.hidden);
      }

      if ($successButton) {
        $submit.classList.remove(config.cls.hidden);
        $successButton.classList.add(config.cls.hidden);
      }

      if ($input) {
        $input.classList.remove(config.cls.hidden);
      }
    }
  }

  /**
   * Validate Email
   * @description Validates email
   * @return {boolean}
   */
  function validateEmail() {
    const email = $input.value;

    if (!email) return false;
    const isEmailFormat = /\S+@\S+\.\S+/;

    return isEmailFormat.test(email);
  }

  /**
   * Set CTO Product Details
   * @description Sets the CTO product details
   * @return {void}
   */
  function setCTOProductDetails() {
    const $ctoProductConfigurables = document.querySelectorAll('.js-cto-configurable-accordion');
    const $selectedConfigurables = document.querySelector('.js-notify-cto-product-details');
    if (!$selectedConfigurables) return;
    $selectedConfigurables.innerHTML = '';

    if (!$ctoProductConfigurables?.length) return;

    $ctoProductConfigurables.forEach(($ctoProductConfigurable) => {
      const $configurableLabel = $ctoProductConfigurable.querySelector('.cto-configurable__legend-label');
      const $configurableActiveOption = $ctoProductConfigurable.querySelector('.js-cto-configurable-active-option');
      if (!$configurableLabel || !$configurableActiveOption) return;

      // Build nodes with textContent so label/option values are escaped by construction
      // (avoids HTML injection) and append once per item (avoids innerHTML += reparsing
      // the whole list on every iteration).
      const $listItem = document.createElement('li');
      const $label = document.createElement('span');
      $label.className = 'cto-product-modal__label';
      $label.textContent = $configurableLabel.innerText;
      const $selection = document.createElement('span');
      $selection.className = 'cto-product-modal__selection';
      $selection.textContent = $configurableActiveOption.innerText;
      $listItem.append($label, $selection);
      $selectedConfigurables.appendChild($listItem);
    });
  }

  return init();
}

notify();
