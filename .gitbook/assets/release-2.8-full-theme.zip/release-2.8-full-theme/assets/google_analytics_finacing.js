/* Parul Check Google Analytics Click Response for Financing Options */

function onApplyFinanceClick() {
    var financeUrl = 'https://www.davivienda.com/wps/portal/personas/nuevo#6cf69528-bd3a-46c7-bfd6-a66d69ee8896';
    document.location = financeUrl;
  }

  function onApplyFinanceStickyBar(){
    var financeUrl = 'https://www.davivienda.com/wps/portal/personas/nuevo#6cf69528-bd3a-46c7-bfd6-a66d69ee8896';
    document.location = financeUrl;
  }
  /* Parul Check Google Analytics Click Response for Financing Options End */