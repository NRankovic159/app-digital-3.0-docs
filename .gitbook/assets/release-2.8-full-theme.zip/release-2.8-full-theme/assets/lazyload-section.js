class LazyloadSection extends HTMLElement {
  constructor() {
    super();
    if (this.dataset.renderOnLoad) {
      this.renderSection();
    } else {
      this.addEvents();
    }
  }

  addEvents() {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          this.renderSection();
          observer.disconnect();
        }
      });
    }, {
      rootMargin: '1000px', // offset to load the section before it's visible to prevent pop-in
    });

    observer.observe(this);
  }

  renderSection() {
    var sectionSelector = '[id^=shopify-section]';
    // use section rendering api
    const sectionId = this.closest(sectionSelector)?.id?.split('shopify-section-')[1] || null;
    if (!sectionId) return;

    fetch(`${window.location.pathname}?section_id=${sectionId}`)
      .then(res => res.text())
      .then(html => {
        // DOM parser
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        if (this.dataset.selectors) {
          let selectors;
          try {
            selectors = JSON.parse(this.dataset.selectors);
          } catch (e) {
            selectors = null;
          }
          if (Array.isArray(selectors)) {
            selectors.forEach(selector => {
              const sections = doc.querySelectorAll(selector);
              const sectionsToUpdate = this.querySelectorAll(selector);
              sections.forEach((section, index) => {
                const sectionHtml = section.innerHTML;
                $(sectionsToUpdate[index]).html(sectionHtml);
              });
            });
          }
        } else {
          const section = this.dataset.selector ? doc.querySelector(this.dataset.selector) : doc.querySelector(sectionSelector)
          if (!section) return;
          const sectionHtml = this.dataset.selector ? section.outerHTML : section.innerHTML;
          $(this).html(sectionHtml);
        }
        if (this.dataset.callback) {
          const matches = this.dataset.callback.match(/window\.(\w+)\s*\(\s*\)/g) || [];
          const fnNames = new Set(matches.map((call) => call.match(/window\.(\w+)/)[1]));
          fnNames.forEach((fnName) => {
            if (typeof window[fnName] === 'function') {
              try {
                window[fnName]();
              } catch (e) {
                console.error('lazyload-section callback failed:', fnName, e);
              }
            }
          });
        }
      })
      .catch((error) => {
        console.error('lazyload-section fetch failed:', error);
      })
  }
}

customElements.define('lazyload-section', LazyloadSection);
