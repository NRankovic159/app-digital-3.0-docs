if (!customElements.get('checkout-button')) {
  customElements.define(
    'checkout-button',
    class Button extends HTMLElement {
      constructor() {
        super();
        this.config = {
          dom: {
            button: '.apple-button--cto',
            link: '.checkout-button__link',
            stickyFooterAddBtn: '#footer-atc',
            textWrapper: '.apl-section-expeditedcheckout-button .apple-button--cto__text',
            textElement: '.apl-section-expeditedcheckout-button .apple-button-text',
            applePayIcon: '.apl-section-expeditedcheckout-button .apple-button--cto__icon',
            safariBrowserText: '[data-safari-browser]',
            otherBrowserText: '[data-other-browser]'
          },
          cls: {
            hidden: 'visually-hidden'
          }
        };
        this.buttonType = this?.dataset?.type || 'apple_pay';
        this.init();
      }

      init() {
        this.showButton();

        setTimeout(() => {
          this.updateTextAppearance();
        }, 100)
      }

      showButton() {
        this.classList.remove(this.config.cls.hidden);

        setTimeout(() => {
          const stickyFooterAddBtn = document.querySelector(this.config.dom.stickyFooterAddBtn);
          const stickyFooterAddBtnHeight = stickyFooterAddBtn?.getBoundingClientRect().height;

          if (stickyFooterAddBtnHeight > 0 && this.querySelector(this.config.dom.button)) {
            this.querySelector(this.config.dom.button).style.height = `${stickyFooterAddBtnHeight}px`;
          }
        }, 100)

        if (!window?.ApplePaySession) {
          const checkoutBtns = document.querySelectorAll(this.tagName);

          checkoutBtns.forEach((btn) => {
            const checkoutLink = btn.querySelector(this.config.dom.link);
            const safariBrowserText = btn.querySelector(this.config.dom.safariBrowserText);
            const otherBrowserText = btn.querySelector(this.config.dom.otherBrowserText);

            if (checkoutLink) checkoutLink.style.display = 'none';
            if (safariBrowserText) safariBrowserText.classList.add('visually-hidden');
            if (otherBrowserText) otherBrowserText.classList.remove('visually-hidden');

            // Hide on the cart page. Use the template name (set in theme.liquid) rather
            // than URL sniffing: `location.href.includes('cart')` both misses localized
            // routes and false-positives on any URL containing the substring "cart"
            // (e.g. a product handle like /products/cart-organizer).
            if (window.themeJsData?.templateName === 'cart') {
              btn.style.display = 'none';
            }
          })
        }
      }

      updateTextAppearance() {
        if (window?.ApplePaySession) {
          const textElements = document.querySelectorAll(this.config.dom.textElement)

          textElements.forEach((element) => {
            const elementHeight = element.getBoundingClientRect().height;

            if (elementHeight > 30) {
              const icon = element.closest(this.config.dom.textWrapper)?.querySelector(this.config.dom.applePayIcon)
              icon?.classList.add('apple-button--cto__icon--no-margin');
              element.style.display = 'none';
            }
          })
        }
      }
    }
  );
}
