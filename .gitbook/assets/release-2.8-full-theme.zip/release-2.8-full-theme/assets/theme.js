$(document).ready(function () {
  function setCookie(name, value, days) {
    var expires = '';
    if (days) {
      var date = new Date();
      date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
      expires = '; expires=' + date.toUTCString();
    }
    document.cookie = name + '=' + (value || '') + expires + '; path=/';
  }
});

$(document).ready(function () {
  if ($.fn.fancybox) {
    $('.iframe').fancybox({
      modal: true,
      toolbar: true,
      smallBtn: true,
      preload: false,
      infocus: true,
      autoFocus: false,
      showCloseButton: true,
      closeBtn: '<a title="Close" class="fancybox-item fancybox-close" href="javascript:;"></a>',
      ajax: {
        preload: false,
      },
    });
  }
});

$(document).ready(function() {
  if (window.themeJsData.templateName !== 'product') {
    localStorage.removeItem("product-click");
  }
  localStorage.setItem("checkout-value",1);
  if (window.themeJsData.cartItemCount <= 0) {
    localStorage.setItem("cart",null);
    localStorage.removeItem("cart_updated");
    localStorage.removeItem("search_value");
  }
  var pageName=window.location.href;
  $(document).on("click", ".disable-btn", function(event) {
    event.preventDefault()
  });
  $(document).on("click", ".product-scratch-list", function(e) {
    var item_id = $(this).find('.frequent-products-mpn').val();
    var item_name = $(this).find('.frequent-products-tittlr').val();
    var item_category = $(this).find('.item_category').val();
    if (pageName.includes("products")) {
      var mpn_handle = $("#mpn_handle").val();
      var item_list_page = "ATTACH :: " + mpn_handle;
    } else if (pageName.includes("cart")) {
      var item_list_page = "ATTACH :: Cart Page";
    } else {
      var item_list_page = "ATTACH :: " + formatString($(this).find('.item_list_page').val());
    }
    var currency = $(this).find('.item_currency').val();
    var price = $(this).find('.item_price').val();
    var item_sku = $(this).find('.list-sku').val();
    var productcomPrice = $(this).find('.item_compare_price').val();
    localStorage.setItem("product-click", item_list_page);
    var productPrice = Number(price.replace(/[^0-9.-]+/g, ""));
    var  discount = 0;
    if (productcomPrice) {
      productcomPrice = Number(productcomPrice.replace(/[^0-9.-]+/g, ""));
      if (productcomPrice > productPrice) {
        discount = parseFloat(productcomPrice) - parseFloat(productPrice);
        discount = parseFloat(discount);
        //  productPrice = productcomPrice;
      }
    }
    dataLayer.push({
      'ecommerce': null
    });
    dataLayer.push({
      'event': 'select_item',
      'ecommerce': {
        'item_list_name': item_list_page,
        'items': [{
          'item_id': item_sku,
          'item_name': item_name,
          'item_category': item_category,
          'item_list_name': item_list_page,
          'price': parseFloat(productPrice),
          'quantity': 1
        }]
      }
    });
  });

  $(document).on("click", ".predictive-search__results-list .predictive-search__list-item--product", function(e) {
    localStorage.setItem("product-click", "Search Quick View");
  });

  $(document).on("click", ".predictive-search__search-for-button, .predictive-search__results-list .predictive-search__list-item--suggestions", function(e) {
    localStorage.setItem("product-click", "Search Results");
  });

  $(document).on("click", ".plp_page_ga", function(e) {
    localStorage.setItem("product-click", "PLP :: " + formatString(pageName.split("/")[pageName.split("/").length - 1]));
  });


  var attch_prod = [];
  $('.product-list-contain').each(function(key, val) {
    var id = $(this).attr('id');
    var sliderId = '#' + id;
    var item_list_name = "";
    var productPrice = 0;
    var discount = 0;
    var prodQuant = 1;
    $(sliderId + " li").each(function(key1, val) {
      var item_ga = {}
      productPrice = $(this).find('.item_price').val()
      var productcomPrice = $(this).find('.item_compare_price').val();
      if (productPrice) productPrice = Number(productPrice.replace(/[^0-9.-]+/g, ""));
      discount = 0;
      if (productcomPrice) {
        productcomPrice = Number(productcomPrice.replace(/[^0-9.-]+/g, ""));
        if (productcomPrice > productPrice) {
          discount = parseFloat(productcomPrice) - parseFloat(productPrice);
          discount = parseFloat(discount);
          let value_price = productcomPrice * parseInt(prodQuant);
          //productPrice = productcomPrice;
        }
      }
      item_ga["item_id"] = $(this).find('.list-sku').val();
      item_ga["item_name"] = $(this).find('.frequent-products-tittlr').val();
      item_ga["item_category"] = $(this).find('.item_category').val();

      if (pageName.includes("products")) {
        var mpn_handle = $("#mpn_handle").val();
        item_list_name = "ATTACH :: " + mpn_handle;
      } else if (pageName.includes("cart")) {
        item_list_name = "ATTACH :: Cart Page";
      } else {
        item_list_name = "ATTACH :: " + formatString($(this).find('.item_list_page').val());
      }
      item_ga["item_list_name"] = item_list_name;
      item_ga["price"] = parseFloat(productPrice);
      item_ga["quantity"] = 1;
      attch_prod.push(item_ga);

    });
    if (attch_prod.length != 0) {
      dataLayer.push({
        'ecommerce': null
      });
      dataLayer.push({
        'event': 'view_item_list',
        'ecommerce': {
          'item_list_name': item_list_name,
          'items': attch_prod
        }
      });
    }
    attch_prod = [];
  });

  $("#cart-notification").hide();
  $('#cart-notification').removeClass('minicart-active');
  $('#cart-icon-bubble').click(function(evt){
    evt.preventDefault(); // open the minicart modal instead of navigating to the cart page (href is kept as an accessible fallback)
    evt.stopPropagation();
    $('#cart-notification').toggle();
    $('#cart-notification').toggleClass('minicart-active');
    $('#cart-notification .minicart_close')?.focus();
  });
  $('#close-cart').click(function(evt){
    $("#cart-notification").hide();
    $('#cart-notification').removeClass('minicart-active');
  });
});

window.mobileSearchNormalLayout = true;
window.autocompleteFormSelector = '.mob_search:visible, .search-modal__form:visible';

$(document).on('click', '.card-slider-buttons_2', function (e) {
  e.preventDefault(); // stops the buttons behavior
  /* Order Product Limits - Karthikeyan */
  var prodId = $(this).attr('data-productid');
  var prodQuant = 1;
  var prodMaxqut = $(this).attr('data-productmaxquantity');
  if (prodMaxqut != '') {
    var maxQuant = checkMaxquantity(prodId);
    if (maxQuant != '') {
      var max_total_quantity = parseInt(prodQuant) + parseInt(maxQuant);
    } else {
      var max_total_quantity = parseInt(prodQuant);
    }
    if (max_total_quantity > prodMaxqut) {
      alert(quantity_limit_error_message.replace('{limit}', prodMaxqut));
      return false;
    }
  }
  var slider_variantid = $('.prod_details_' + prodId)
    .find(':selected')
    .val();
  var slider_tag = $(this).attr('data-tag');
  var main_product_sku = $(this).attr('data-productsku');
  var productList = $(this).attr('data-productlist');
  var productCategory = $(this).attr('data-producttype');
  var productPrice = $(this).attr('data-productprice');
  var productCurrency = $(this).attr('data-productcurrency');
  var productTitle = $(this).attr('data-producttitle');
  var prohandle = $(this).attr('data-producthandle');
  var mpnHandle = $(this).attr('data-productMPN');
  var mpnHandleVariant = '';
  /* VAT Product Limits - Karthikeyan */
  if (vat_free_day == true) {
    var addtaxfree = slider_tag.indexOf('taxfree') != -1;
    if (addtaxfree == true) {
      if (getCookie('total_quantity') >= +vat_free_quantity) {
        alert(vat_free_message);
        return false;
      }
    }
  }
  $('#slider-form-' + slider_variantid).attr('aria-disabled', true);
  $('#slider-form-' + slider_variantid).addClass('loading');
  $('.loading-overlay__spinner-frequent').removeClass('hidden');
  var viewurl = `${window.Shopify.routes.root}products/${prohandle}?variant=${slider_variantid}&view=mpn`;
  $.ajax({
    type: 'GET',
    url: viewurl,
    async: false,
    success: function (itemData) {
      let arrprod = itemData.split('|');
      if (mpnHandle.length == 0) {
        if (arrprod[1] != '') {
          mpnHandleVariant = arrprod[1];
        } else {
          mpnHandleVariant = arrprod[0];
        }
      } else {
        mpnHandleVariant = mpnHandle;
      }
      productPrice = arrprod[2];
    },
  });
  mpnHandleVariant = mpnHandleVariant.trim();
  fetch(`${window.Shopify.routes.root}cart/add.js`, {
    method: 'post',
    headers: {
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      items: [
        {
          id: slider_variantid,
          quantity: 1,
          properties: {
            _uuid: prohandle,
          },
        },
      ],
    }),
  })
    .then((response) => {
      response.json().then((d) => {
        var productList = 'Search Results';
        cartCookie(mpnHandleVariant, d.items[0].key, productList);
      });
      checkQuantity();

      //souvik code for product list tracking starts
      triggerGAAddToCart(
        mpnHandleVariant,
        productTitle,
        productCategory,
        productList,
        productCurrency,
        productPrice,
        prodQuant,
        main_product_sku,
        slider_variantid
      );
      //souvik code for product list tracking ends
      $.get(`${window.Shopify.routes.root}cart?view=minicart`, function (itemData) {
        var item_count = jQuery(itemData).find('#cart-notification-button .count').text();
        if ($('.cart-count-bubble').length > 0) {
          $('.cart-count-bubble span').text(item_count);
        } else {
          $('#cart-icon-bubble').append('<div class="cart-count-bubble"><span></span></div>');
          $('.cart-count-bubble span').text(item_count);
        }
        $('#cart-notification').text('');
        var textreplace = "<div id='min-cart-replace'></div>";
        $('#cart-notification').append(textreplace);
        $('#cart-notification').replaceWith(itemData);
        $('#cart-notification').addClass('minicart-active');
      });
      $('#slider-form-' + slider_variantid).attr('aria-disabled', false);
      $('#slider-form-' + slider_variantid).removeClass('loading');
      $('.loading-overlay__spinner-frequent').addClass('hidden');
    })
    .catch((error) => {
      console.error('Error:', error);
      return false;
    });
  return false;
});
//localStorage.clear();
//localStorage.removeItem('cart');
//localStorage.removeItem("search_value");
var pageName = window.location.href;
// Declared with a safe default so cartCookie()/triggerGAAddToCart() don't read a hoisted
// `undefined` (which would store the literal string "undefined") on non-search pages.
var first_search = null;
var search_term = '';
if (pageName.includes('search')) {
  var urlParams = new URLSearchParams(window.location.search);
  var search_term_str = urlParams.get('q');
  search_term = formatString(search_term_str);
  localStorage.setItem('search_value_term', search_term);
  var first_search = localStorage.getItem('search_value');
  $('.product-grid').each(function (key, val) {
    var item_list_name = 'Search Results';
    var productPrice = 0;
    var discount = 0;
    var prodQuant = 1;
    $('.product-grid li').each(function (key1, val) {
      var item_ga = {};
      productPrice = $(this).find('.item_price').val();
      var productcomPrice = $(this).find('.item_compare_price').val();
      if (productPrice) productPrice = Number(productPrice.replace(/[^0-9.-]+/g, ''));
      discount = 0;
      if (productcomPrice) {
        productcomPrice = Number(productcomPrice.replace(/[^0-9.-]+/g, ''));
        if (productcomPrice > productPrice) {
          discount = parseFloat(productcomPrice) - parseFloat(productPrice);
          discount = parseFloat(discount);
          let value_price = productcomPrice * parseInt(prodQuant);
          //productPrice = productcomPrice;
        }
      }
      item_ga['item_id'] = $(this).find('.list-sku').val();
      item_ga['item_name'] = $(this).find('.frequent-products-tittlr').val();
      item_ga['item_category'] = $(this).find('.item_category').val();
      item_ga['item_list_name'] = item_list_name;
      item_ga['price'] = parseFloat(productPrice);
      item_ga['quantity'] = 1;
      dataLayer.push({
        event: 'view_item_list',
        ecommerce: {
          search_term: search_term,
          item_list_name: 'Search Results',
          items: [item_ga],
        },
      });
    });
  });
}
function formatString(str) {
  if (!str) return str;
  return str
    .replace(/(\B)[^ ]*/g, (match) => match.toLowerCase())
    .replace(/^[^ ]/g, (match) => match.toUpperCase());
}

function cartCookie(mpnHandleVariant, prodVariantID, productList) {
  if (first_search == null) {
    localStorage.setItem('search_value', search_term);
    var first_search_str = localStorage.getItem('search_value');
    first_search = formatString(first_search_str);
  }

  var exphone = [];
  var item_cart = {};
  item_cart['cart_item_id'] = prodVariantID;
  item_cart['cart_item_list_name'] = productList;
  item_cart['cart_search_term'] = first_search;
  item_cart['cart_item_mpn'] = mpnHandleVariant;
  try {
    var parsedExphone = JSON.parse(localStorage.getItem('cart'));
    if (parsedExphone != null) exphone = parsedExphone;
  } catch (e) {
    exphone = [];
  }
  exphone.push(item_cart);
  localStorage.setItem('cart', JSON.stringify(exphone));
}

//souvik code for sending product List starts
function triggerGAAddToCart(
  prodVariantID,
  productTitle,
  productCategory,
  productList,
  productCurrency,
  productPrice,
  prodQuant,
  main_product_sku,
  slider_variantid
) {
  if (first_search == null) {
    localStorage.setItem('search_value', search_term);
    var first_search_str = localStorage.getItem('search_value');
    first_search = formatString(first_search_str);
  }
  if (productPrice) productPrice = Number(productPrice.replace(/[^0-9.-]+/g, ''));
  var discount = 0;
  var prodQuant = 1;
  var productCurrency = window.themeJsData.shopCurrency;
  var value_price = productPrice * parseInt(prodQuant);
  var value_price1 = parseFloat(value_price);
  var productPrice1 = parseFloat(productPrice);
  dataLayer.push({ ecommerce: null });
  dataLayer.push({
    event: 'add_to_cart',
    ecommerce: {
      search_term: search_term,
      value: value_price1,
      item_list_name: 'Search Results',
      currency: window.themeJsData.shopCurrency,
      items: [
        {
          item_id: main_product_sku,
          item_name: productTitle,
          item_category: productCategory,
          price: productPrice,
          quantity: 1,
        },
      ],
    },
  });
}

//souvik code for sending product List ends

$(document).ready(function () {
  function eraseCookie(name) {
    document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  }
  var template1 = window.themeJsData.templateStrip;
  // erase 4th variant option cookies and cookie array, if template isnot product
  if (template1 != 'product') {
    eraseCookie('option1select');
    eraseCookie('option2select');
    eraseCookie('option3select');
    eraseCookie('optionPIDlist');
  }
});
