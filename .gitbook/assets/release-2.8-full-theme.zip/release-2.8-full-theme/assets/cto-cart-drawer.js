class CTOCartDrawer extends HTMLElement {
  constructor() {
    super();

    this.addEventListener('keyup', (evt) => evt.code === 'Escape' && this.close());
    this.querySelector('#CTOCartDrawer-Overlay')?.addEventListener('click', this.close.bind(this));
    this.addEvents = this.addEvents.bind(this);
    this.$footer = this.querySelector('.js-cart-items-footer');
    this.scrollPosition = 0;
    // add mobile scroll event only if apple pay is supported
    if (window?.ApplePaySession && this.$footer?.querySelector('.apple-button')) {
      this.$footer.classList.add('apple-pay-supported');
      if (this.$footer.querySelector('.checkout-button')) {
        this.$footer.classList.add('checkout-button-supported');
      }
      this.$footer.classList.add('scrolled');
      this.querySelector('cart-items')?.addEventListener('scroll', this.onScroll.bind(this));
    }

    this.ctoItemKey = null;
    this.currentItemsSkus = {};
    this.currentItemsAll = {};
    this.currentSkuKeyPair = {};

    this._isKeyboardUser = false;
    this._onDocMousedown = () => { this._isKeyboardUser = false; };
    this._onDocKeydown = () => { this._isKeyboardUser = true; };
    // Listeners are attached in connectedCallback (and removed in disconnectedCallback)
    // so that the lifecycle is symmetric and reconnects don't duplicate them.
  }

  connectedCallback() {
    document.addEventListener('mousedown', this._onDocMousedown);
    document.addEventListener('keydown', this._onDocKeydown);
  }

  disconnectedCallback() {
    document.removeEventListener('mousedown', this._onDocMousedown);
    document.removeEventListener('keydown', this._onDocKeydown);
  }

  onScroll(event) {
    if (window.innerWidth < 768) {
      if (event.target.scrollTop >= this.scrollPosition) {
        this.$footer.classList.add('scrolled');
      } else {
        this.$footer.classList.remove('scrolled');
      }
      this.scrollPosition = event.target.scrollTop;
    }
  }

  open(triggeredBy) {
    if (triggeredBy) this.setActiveElement(triggeredBy);
    // here the animation doesn't seem to always get triggered. A timeout seem to help
    setTimeout(() => {
      this.classList.add('animate', 'active');
      this.removeAttribute('aria-hidden');
      // scroll to top of the cart items
      const cartItems = this.querySelector('cart-items');
      if (cartItems) cartItems.scrollTop = 0;
      this.querySelector('.drawer__inner').scrollTop = 0;
      this.scrollPosition = 0;
      this.$footer.classList.add('scrolled');
    });

    this.addEventListener(
      'transitionend',
      () => {
        const containerToTrapFocusOn = this.classList.contains('is-empty')
          ? this.querySelector('.drawer__inner-empty')
          : document.getElementById('CTOCartDrawer');
        const focusElement = this.querySelector('.drawer__inner') || this.querySelector('.drawer__close');
        trapFocus(containerToTrapFocusOn, focusElement);
      },
      { once: true }
    );
  }

  close() {
    this.classList.remove('active');
    this.setAttribute('aria-hidden', 'true');
    removeTrapFocus(this.activeElement);
    this.currentSkuKeyPair = {};
    this.currentItemsAll = {};

    const drawerInner = this.querySelector('.drawer__inner--cto');
    const focusTarget = drawerInner || this;
    focusTarget.addEventListener(
      'transitionend',
      (evt) => {
        if (evt.propertyName !== 'transform') return;
        // Keyboard users only: removeTrapFocus() above already returned focus to the element
        // that opened the drawer, so this is just a fallback for when that element is gone.
        // Skipped for pointer users because #cart-icon-bubble lives in the header, and
        // focusing it scrolls the page to the top.
        if (this._isKeyboardUser) {
          document.getElementById('cart-icon-bubble')?.focus();
        }
      },
      { once: true }
    );
  }

  setSummaryAccessibility(cartDrawerNote) {
    cartDrawerNote.setAttribute('role', 'button');
    cartDrawerNote.setAttribute('aria-expanded', 'false');

    if (cartDrawerNote.nextElementSibling.getAttribute('id')) {
      cartDrawerNote.setAttribute('aria-controls', cartDrawerNote.nextElementSibling.id);
    }

    cartDrawerNote.addEventListener('click', (event) => {
      event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
    });

    cartDrawerNote.parentElement.addEventListener('keyup', onKeyUpEscape);
  }

  setActiveElement(element) {
    this.activeElement = element;
  }

  getInnerHTML(html, selector) {
    return new DOMParser().parseFromString(html, 'text/html').querySelector(selector)?.innerHTML ?? '';
  }

  groupValidItemsBySku = (cartDrawerElement) => {
    const currentSkuMap = {};

    Object.keys(this.currentSkuKeyPair).forEach((key) => {
      const sku = this.currentSkuKeyPair[key];
      const $item = cartDrawerElement.querySelector(`.cto-cart-item[data-sku="${sku}"][data-cto-cart-item-key="${key}"]`);

      if ($item) {
        let itemQty = parseInt($item.querySelector('.quantity__input')?.value, 10) || 1;
        // initialize this data object if new SKU found
        if (!currentSkuMap[sku]) {
          currentSkuMap[sku] = {
            keys: [],
            quantity: 0
          };
        }

        // Add the key to the list and increment the pre-calculated quantity.
        currentSkuMap[sku].keys.push(key);
        currentSkuMap[sku].quantity += itemQty;
      }
    });

    return currentSkuMap;
  };

  updateLatestCartItems() {
    const $items = this.querySelectorAll(`.cto-cart-item[data-cto-cart-item-key="${this.ctoItemKey}"]`);

    if ($items?.length) {
      $items.forEach(($item) => {
        $item.classList.add('active');
      });
    }

    // Show insurance section if there are active insurance items
    const $insuranceSection = this.querySelector('.js-cto-insurance')
    const $insuranceItems = $insuranceSection?.querySelectorAll(`.cto-cart-item.active`);
    if ($insuranceItems?.length) {
      $insuranceSection.classList.remove('hidden');
    }

    // Show GWP section if there are active items
    const $gwpSection = this.querySelector('.js-cto-gwp')
    const $gwpItems = $gwpSection?.querySelectorAll(`.cto-cart-item.active`);
    if ($gwpItems?.length) {
      $gwpSection.classList.remove('hidden');
    }

    const $offerSection = this.querySelector('.js-cto-offers');
    const $offerItems = $offerSection?.querySelector(`.cto-cart-item.active`)|| null;
      if ($offerItems) {
        this.refreshCarouselEvents();
      }

    const $mainCartItems = this.querySelectorAll('.js-cart-items-body > .cart-items .cto-cart-item');
    const $mainCartItemsWrapper = this.querySelector('.js-cart-items-body > .cart-items');
    $mainCartItems.forEach(($item) => {
      $item.classList.remove('active');
    });
    const ctoGwpItems = $gwpSection?.querySelectorAll('.cto-gwp-item');
    const currentSkuMap = this.groupValidItemsBySku($mainCartItemsWrapper);

    Object.keys(currentSkuMap).forEach((sku) => {
      const itemSkuData = currentSkuMap[sku];
      const itemQty = itemSkuData.quantity;
      let itemKey = itemSkuData.keys[0]; // get first available key to show in the Drawer
      
      if (itemQty > 1) {
        let longestGwpSkuLength = -1;
        // Update the item-qty-grouped data attr for grouped items with the same SKU (itemSkuData.keys).
        itemSkuData.keys.forEach(groupedKey => {
          const elem = $mainCartItemsWrapper.querySelector(`.cto-cart-item[data-sku="${sku}"][data-cto-cart-item-key="${groupedKey}"]`);
          if (!elem) return;
          const groupedItemQtyElem = elem.querySelector('.js-cart-item-qty');
          const itemAplcrElems = elem.querySelectorAll('.cart-item__row--care');
          const currentGwpKey = elem?.dataset.gwp_key;
          const currentGwpSkuDataset = elem?.dataset.gwp_sku;
          const currentGwpSkuLength = currentGwpSkuDataset?.length ?? -1;

          groupedItemQtyElem?.setAttribute('data-item-qty-grouped', itemQty);

          if (currentGwpSkuLength && currentGwpSkuLength > longestGwpSkuLength) {
            const currentGwpSku = currentGwpSkuDataset?.split(',')[0];  // get first available SKU if multiple SKUs
            const isGwpItemValid = $mainCartItemsWrapper.querySelector(`.cto-cart-item[data-sku="${currentGwpSku}"][data-gwp_key="${currentGwpKey}"]`);

            if (isGwpItemValid) {
              longestGwpSkuLength = currentGwpSkuLength;
              itemKey = groupedKey;
            }
          }
           // update Addon grouped products qty
          itemAplcrElems.forEach(aplcr => {
            const aplcrQtyElem = aplcr.querySelector('.js-cart-item-qty');
            if (aplcrQtyElem) {
              aplcrQtyElem.textContent = `(${itemQty})`;
              aplcrQtyElem.setAttribute('data-item-qty-grouped', itemQty);
            }
          });
        });
        
        // update gwpOffers with relavant CTO grouped active item
        const isGwpItemValidKey = Array.from(ctoGwpItems)?.some(gwp_item => gwp_item.dataset.ctoCartItemKey === itemKey);
        if (isGwpItemValidKey) {
          ctoGwpItems.forEach(gwp_item => {
            gwp_item.classList.toggle('active', gwp_item.dataset.ctoCartItemKey === itemKey);
          });
        }

        if ($gwpItems?.length) {
          $gwpSection.classList.remove('hidden');
        } else {
          $gwpSection.classList.add('hidden');
        }
      }

      const item = $mainCartItemsWrapper.querySelector(`.cto-cart-item[data-sku="${sku}"][data-cto-cart-item-key="${itemKey}"]`);

      if (item) {
        item.classList.add('active');

        const itemQtyElem = item.querySelector('.js-cart-item-qty');
        if (itemQtyElem) {
          itemQtyElem.textContent = `(${itemQty})`;
          itemQtyElem.setAttribute('data-item-qty-grouped', itemQty);
        }

        const $bundleItems = $mainCartItemsWrapper.querySelectorAll(`.cto-cart-item[data-parent-bundle-key="${itemKey}"]`);
        $bundleItems.forEach(($bundleItem) => {
          $bundleItem.classList.add('active');
        });

        // Update cart-drawer heading message (single/multiple)
        const itemActiveElements = $mainCartItemsWrapper.querySelectorAll('.cto-cart-item.active');
        const cartDrawerHeading = this.querySelector('.js-cto-cart-drawer-heading');
        const itemSingleInCartText = cartDrawerHeading?.dataset.singleItemText;
        const itemMultipleInCartText = cartDrawerHeading?.dataset.multipleItemsText;

        if ((itemActiveElements.length > 1 || itemQty > 1) && itemMultipleInCartText) {
          cartDrawerHeading.textContent = itemMultipleInCartText;
        } else if (cartDrawerHeading) {
          itemSingleInCartText && (cartDrawerHeading.textContent = itemSingleInCartText);
        }

        cartDrawerHeading?.focus();
      }
    });
  }

  updateItems(itemsData) {
    this.updateCurrentItemsSkus(itemsData);
    this.updateCurrentItemsAll(itemsData);
    fetch(`${window.Shopify.routes.root}cart?view=cto-cart-drawer-items`)
    .then((response) => response.text())
    .then((html) => {
      const $items = this.querySelector('.js-cart-items-body') || null;
      if ($items && this.$footer) {
        $items.innerHTML = this.getInnerHTML(html, '.js-cart-items-body');
        this.$footer.innerHTML = this.getInnerHTML(html, '.js-cart-items-footer');

        if (this.isFbtAddWithoutCtoProduct(itemsData)) {
          // Focus the drawer on the line this add created, so its own protection/offers/GWP cards
          // are the ones revealed. Looking the CTO item up in the DOM below would find the hero line
          // of an EARLIER add, whose GWP cards are keyed by that hero's line key and would surface
          // as if the gift had just been added again. On non-pdp-2.0 templates the hero checked in
          // FBT is flagged `_added_from_pdp` (product-form.js), so prefer it when present.
          const focusItem = itemsData.find((item) => item.properties?._added_from_pdp) || itemsData[0];
          this.updateCtoItemKey(focusItem.key);
        } else {
          // get new cto item key from updated liquid
          const productTemplate = document.body.dataset.template || '';

          const ctoProductAttrs = (productTemplate.includes('pdp-2.0') || productTemplate.includes('plp-new'))
            ? ['[data-cto-product="true"]', '[data-added-from-pdp="true"]']
            : ['[data-added-from-pdp="true"]', '[data-cto-product="true"]'];

          const ctoProductAttr =
            ctoProductAttrs.find((attr) => this.querySelector(`.cto-cart-item${attr}`)) || ctoProductAttrs[0];

          const newCto = this.querySelector(`.cto-cart-item${ctoProductAttr}`);

          const {ctoCartItemKey} = newCto?.dataset || {};

          if (ctoCartItemKey) {
            this.updateCtoItemKey(ctoCartItemKey);
          }

          const {token} = newCto?.dataset || {};
          const newCtoItems = this.querySelectorAll(`.cto-cart-item${ctoProductAttr}[data-token="${token}"]`);
          const ctoItemKeys = Array.from(newCtoItems)
            .map(item => item.dataset.ctoCartItemKey);
          if (ctoItemKeys.length > 0) {
            this.updateSkuKeyPair(ctoItemKeys, itemsData);
          } else if (ctoCartItemKey) {
            this.updateSkuKeyPair([ctoCartItemKey], itemsData);
          }
        }

        this.updateLatestCartItems();
        this.addEvents();
        this.open();
      }

      // scroll to top
      this.querySelector('cart-items')?.scroll(0, 0);
    })
    .catch((error) => console.error({message: 'Error updating items', error: error}));
  }

  /**
   * SKU the drawer row renders in data-sku. A Shopify Bundles variant can have no SKU of its own,
   * so its line is identified by the hero SKU stored in its SKU property (same fallback as Liquid).
   */
  getItemSku(item) {
    return item?.sku || item?.properties?.SKU || '';
  }

  updateCurrentItemsSkus(itemsData) {
    const ctoItem = itemsData?.find((item) => item.properties?._cto_product || item.properties?._added_from_pdp);
    const ctoItemSku = this.getItemSku(ctoItem);
    if (!ctoItemSku) {
      itemsData?.forEach((item) => {
        this.currentItemsSkus[this.getItemSku(item)] = true;
        this.currentSkuKeyPair[item.key] = this.getItemSku(item);
      });
    } else {
      this.updateCtoItemKey(ctoItem.key);
      this.currentItemsSkus = {};
      this.currentSkuKeyPair = {};
      itemsData?.forEach((item) => {
        this.currentItemsSkus[this.getItemSku(item)] = true;
        this.currentSkuKeyPair[item.key] = this.getItemSku(item);
      });
    }
  }

  updateCurrentItemsAll(itemsData) {
    itemsData?.forEach((item) => {
      this.currentItemsAll[item.key] = item;
    });
  }

  updateCtoItemKey(ctoItemKey) {
    this.ctoItemKey = ctoItemKey;
  }

  /**
   * True when this add came only from the FBT section and did not include the CTO hero product
   * (see `_added_from_fbt` in product-form.js). Such an add must not be attributed to a hero line
   * already in the cart, or that hero's GWP/protection/offers cards resurface as "just added".
   */
  isFbtAddWithoutCtoProduct(itemsData) {
    return itemsData?.length > 0 && itemsData.every(item =>
      !item.properties?._cto_product &&
      item.properties?._added_from_fbt === 'true'
    );
  }

  updateSkuKeyPair(ctoItemKeys, itemsData) {
    const isFbtWithoutCtoProduct = this.isFbtAddWithoutCtoProduct(itemsData);

    ctoItemKeys.forEach(ctoItemKey => {
      const item = this.querySelector(`.cto-cart-item[data-cto-cart-item-key="${ctoItemKey}"]`);
      const itemSku = item?.getAttribute('data-sku');
      const itemUuid = item?.getAttribute('data-gwp_key');
      const itemGwpSku = item?.getAttribute('data-gwp_sku');
      const isPrimaryProduct = itemsData?.some(product => this.getItemSku(product) === itemSku);

      // A line with no SKU at all still renders data-sku="" and must stay visible;
      // only a missing row or attribute is skipped.
      if (itemSku != null && !isPrimaryProduct && !isFbtWithoutCtoProduct) {
        this.currentSkuKeyPair[ctoItemKey] = itemSku;
      }

      if (!isPrimaryProduct && itemUuid && itemGwpSku) {
        const itemGwpSkuList = itemGwpSku.split(',').map(sku => sku.trim());

        itemGwpSkuList.forEach(gwpSku => {
          if (gwpSku) {
            const ctoItemGwpKeyNew =  this.querySelector(`.cto-cart-item[data-sku="${gwpSku}"][data-gwp_key="${itemUuid}"]`)?.getAttribute('data-cto-cart-item-key');
            this.currentSkuKeyPair[ctoItemGwpKeyNew] = gwpSku;
          }
        });
      }
    });
  }

  forceClearCtoItems() {
    this.ctoItemKey = null;
    this.currentItemsSkus = {};
    this.currentSkuKeyPair = {};
  }

  addEvents() {
    const $nmpTriggers = document.querySelectorAll('.js-net-monthly-pricing-modal-trigger');

    // Use event delegation + idempotency marker so repeated addEvents() calls (constructor +
    // updateItems()) don't stack listeners on persistent triggers or on the host element.
    if (!this.__delegateClickBound) {
      this.__delegateClickBound = true;
      this.addEventListener('click', (event) => {
        const $trigger = event.target.closest('.ac-modal-trigger');
        if (!$trigger || !this.contains($trigger)) return;
        const currentNmpTriggers = document.querySelectorAll('.js-net-monthly-pricing-modal-trigger');
        if ($trigger.classList.contains('cart-payment-blocks__link') && currentNmpTriggers?.length) {
          currentNmpTriggers[0].click();
        }
      });
    }

    if (window.refreshModals) window.refreshModals();
  }

  refreshCarouselEvents() {
    const $offerSection = this.querySelector('.js-cto-offers');
    const $offerItems = $offerSection?.querySelector(`.cto-cart-item.active`)|| null;
    const $alsoLikeCarousel = $offerItems?.querySelector('.js-also-like-carousel') || null;
    const $accessoriesCarousel = $offerItems?.querySelector('.js-product-accessories-carousel') || null;

    $offerSection?.classList.remove('hidden');
    // small timeout to make sure the carousel is rendered
    setTimeout(() => {
      if ($alsoLikeCarousel) {
        this.addCaouselEvents($alsoLikeCarousel, 'js-you-also-like-carousel');
      }

      if ($accessoriesCarousel) {
        this.addCaouselEvents($accessoriesCarousel, 'js-accessories-carousel');
      }
    }, 100);
  }

  addCaouselEvents(el, selector) {
    if (!el || !selector) return;
    const $atcButtons = el.querySelectorAll('.slider-form:not(.event-attached)');

    if ($atcButtons?.length > 0) {
      window.quickAddEvents();
    }

    if ($(`.${selector}`).hasClass('slick-initialized')) {
      $(`.${selector}`).slick('unslick');
    }
    $(`.${selector}`).slick({
      slidesToShow: 3,
      slidesToScroll: 1,
      infinite: false,
      variableWidth: true,
      responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1.45,
            infinite: false,
            variableWidth: false,
          }
        },
      ]
    });
  }
}

customElements.define('cto-cart-drawer', CTOCartDrawer);