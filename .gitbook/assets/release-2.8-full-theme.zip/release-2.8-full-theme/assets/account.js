class Order extends HTMLElement {
  constructor() {
    super();
    this.config = {
      dom: {
        store_name: '.js-pickup-store',
        store_locator: 'my-store-locator'
      },
      cls: {
        store_class: 'order-history__value order-history__store'
      }
    }
    this.storeName = this.querySelector(this.config.dom.store_name);
    this.storeLocator = document.querySelector(this.config.dom.store_locator);

    if (this.storeName) {
      const { enabled } = this.dataset || null;
      const { store: storeName } = this.storeName.dataset || null;
      const isEnabled = enabled === 'true' || false;

      if (storeName && isEnabled) this.setLocation(storeName);
    }
  }

  async setLocation(storeName) {
    if (!this.storeLocator) return;
    await this.storeLocator.fetchLocations(null, true);
    const myStore = this.storeLocator.allLocationsData.find((store) => {
      return store.name === storeName;
    }) || null;

    if (myStore) this.buildStoreElement(myStore);
  }

  buildStoreElement(store) {
    const apiProvider = SDG?.Data?.mapProvider  || null;
    const { name, address } = store || {};
    const { latitude, longitude } = address || {};

    if (!latitude || !longitude || !name) return;

    if (apiProvider === 'google_maps') {
      const encodedName = encodeURIComponent(name);
      const href = `https://www.google.com/maps/search/?api=1&query=${encodedName}&query_place_id=${latitude},${longitude}`;
      const link = document.createElement('a');
      link.href = href;
      link.target = '_blank';
      link.className = this.config.cls.store_class;
      link.textContent = name;
      this.storeName.replaceChildren(link);
    }

    if (apiProvider === 'apple_maps') {
      const { formatted } = address || {};
      if (!formatted || !latitude || !longitude) return;
      const encodedName = encodeURIComponent(name);
      const encodedAddress = encodeURIComponent(formatted);
      const href = `https://maps.apple.com/place?q=${encodedName}&address=${encodedAddress}&ll=${latitude},${longitude}`;
      const link = document.createElement('a');
      link.href = href;
      link.target = '_blank';
      link.className = this.config.cls.store_class;
      link.textContent = name;
      this.storeName.replaceChildren(link);
    }
  }
}

customElements.define("account-order", Order);
