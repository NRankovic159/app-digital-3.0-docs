class DetailsAccordion extends HTMLElement {
  constructor() {
    super();
    this.handleClick = this.handleClick.bind(this);
  }

  connectedCallback() {
    this.details = this.querySelectorAll('.js-details-accordion');
    this.details.forEach($detail => {
      const $summary = $detail?.querySelector('.js-details-accordion-summary') || null;
      
      if ($summary) {
        $summary.addEventListener('click', this.handleClick);
        $summary.setAttribute('aria-expanded', 'false');
      }
    });
  }

  disconnectedCallback() {
    this.details.forEach($detail => {
      const $summary = $detail.querySelector('.js-details-accordion-summary');
      if ($summary) {
        $summary.removeEventListener('click', this.handleClick);
      }
    });
  }

  handleClick(event) {
    event.preventDefault();
    const $summary = event.currentTarget;
    const $details = $summary.parentElement;
    const $content = $summary.nextElementSibling;

    if ($details.hasAttribute('open')) {
      $summary.setAttribute('aria-expanded', 'false');
      $($content).slideUp(500, 'swing', () => {
        $details.removeAttribute('open');
      });
    } else {
      $details.setAttribute('open', 'true');
      $summary.setAttribute('aria-expanded', 'true');
      $($content).hide().slideDown(500, 'swing');
    }
  }
}

if (!customElements.get('details-accordion')) {
  customElements.define('details-accordion', DetailsAccordion);
}