document.addEventListener("DOMContentLoaded", function () {
  // store modals
  const modals = {};

  // create modals
  Array.from(document.getElementsByClassName("ac-modal")).forEach((modalElement) => {
    // modal
    const modal = modalElement

    // store in dictionary
    const modalId = modalElement.getAttribute("id");
    modals[modalId] = modal;
  });

  // open modal
  Array.from(document.querySelectorAll(".ac-modal-trigger[data-ajax-url], .ac-modal-trigger[data-modal-target]")).forEach((trigger) => {
    ensureModalTriggerSemantics(trigger);
    bindModalTriggerKeyboardActivation(trigger);
    const targetModalId = trigger.getAttribute("data-modal-target");
    const modal = modals[targetModalId];
    if (modal) {
      // open corresponding modal
      trigger.addEventListener("click", () => {
        onModalTriggerClick(trigger, modal);
      });
      onModalClose(trigger, modal);
    }
  });

  fixModalDialogLabelledBy();
});

const _origRefreshModals = window.refreshModals;
window.refreshModals = function () {
  if (typeof _origRefreshModals === 'function') _origRefreshModals();
  fixModalDialogLabelledBy();
};

// The global ac-modal init sets a generic aria-labelledby="modal-headline" on every
// modal overlay, which collides across modals on the same page. Repoint each overlay
// to the modal's own visual heading so screen readers announce the correct accessible name.
function fixModalDialogLabelledBy() {
  Array.from(document.querySelectorAll('.apple-care-modal__heading[id], .apple-care-acceptance-modal__heading[id]')).forEach((heading) => {
    const overlay = heading.closest('[data-modal-element-overlay]');
    if (overlay) overlay.setAttribute('aria-labelledby', heading.id);
  });
}

// The ac-modal-trigger <a> variants (including CMS-authored MoreInfoLink anchors)
// have no href and only open a dialog. Expose them as buttons to AT.
function ensureModalTriggerSemantics(trigger) {
  if (!trigger) return;
  const tag = trigger.tagName;
  const isAnchorWithoutHref = tag === 'A' && !trigger.hasAttribute('href');
  if (isAnchorWithoutHref && !trigger.hasAttribute('role')) {
    trigger.setAttribute('role', 'button');
  }
  if ((isAnchorWithoutHref || tag === 'BUTTON') && !trigger.hasAttribute('aria-haspopup')) {
    trigger.setAttribute('aria-haspopup', 'dialog');
  }
  // <a> without href is not in the tab order, so keyboard users can't reach it (and the
  // Enter/Space binding below never fires). Make it focusable like a native button.
  if (isAnchorWithoutHref && !trigger.hasAttribute('tabindex')) {
    trigger.setAttribute('tabindex', '0');
  }
}

// <a> without href has no native keyboard activation, so Enter/Space don't fire click
// in Safari (Chrome is more lenient). Bind explicit Enter/Space → click for these so
// the modal opens via keyboard / VoiceOver. <button> already activates natively.
function bindModalTriggerKeyboardActivation(trigger) {
  if (!trigger || trigger.dataset.modalKeyboardBound) return;
  if (trigger.tagName !== 'A' || trigger.hasAttribute('href')) return;
  trigger.dataset.modalKeyboardBound = 'true';
  trigger.addEventListener('keydown', function (event) {
    if (event.key !== 'Enter' && event.key !== ' ' && event.key !== 'Spacebar') return;
    event.preventDefault();
    trigger.click();
  });
}

async function onModalTriggerClick(trigger, modal) {
  if (!trigger || !modal) return;
  if (trigger.dataset.ajaxLoaded) return;

  const ajaxUrl       = trigger.getAttribute('data-ajax-url') || '';
  const ajaxIframe    = trigger.getAttribute('data-ajax-iframe') === 'true';
  const customCompare = trigger.getAttribute('data-custom-compare') === 'true';
  const txtUrl        = trigger.getAttribute('data-txt-url') || '';
  const txtPlain      = trigger.getAttribute('data-txt-plain') || 'false';

  // Prioritize txtUrl whenever it's present; otherwise fall back to ajaxUrl
  const contentUrl = txtUrl || ajaxUrl;
  const isFullPageFallback = !txtUrl && ajaxUrl;

  if (!contentUrl) {
    console.warn('No contentUrl (missing data-ajax-url and data-txt-url) on trigger:', trigger);
    return;
  }

  if (!isSafeNavigationHref(contentUrl)) {
    console.warn('Refusing to load modal content from an unsafe URL:', contentUrl);
    return;
  }

  toggleLoadingState(modal, true);

  let html;

  try {
    const response = await fetch(contentUrl);
    if (!response.ok) {
      throw new Error('Failed to load content: ' + response.status);
    }

    let txt = await response.text();

    if (txtPlain === 'true') {
      // treat as text -> basic HTML
      html = txt
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/\r\n|\r|\n/g, '<br>');
    } else {
      // When falling back to full page URL, extract only main content (no header/footer)
      if (isFullPageFallback) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(txt, 'text/html');
        const mainContent = doc.getElementById('MainContent');
        if (mainContent && mainContent.innerHTML) {
          // Parse the main content and remove title bar elements (page name, modal headline)
          const contentDoc = parser.parseFromString(mainContent.innerHTML.trim(), 'text/html');
          const body = contentDoc.body;

          contentDoc.getElementById('modal-headline')?.remove();
          body.querySelectorAll('#modal-headline, .main-page-title, .page-title, h1.visually-hidden').forEach((el) => el.remove());

          // Remove first h1 if present (theme often puts page title as first element in main)
          const firstH1 = body.querySelector('h1');
          if (firstH1) {
            const parent = firstH1.parentElement;
            firstH1.remove();
            if (parent && parent !== body && !parent.textContent.trim()) parent.remove();
          }

          // If first element is main-page section (title + .rte), replace it with only the .rte content to remove title bar wrapper/padding
          const mainPageSection = body.querySelector('.apl-section-main-page, .shopify-section.apl-section-main-page');
          if (mainPageSection) {
            const rte = mainPageSection.querySelector('.rte');
            if (rte) {
              mainPageSection.replaceWith(rte.cloneNode(true));
            }
          }

          // Remove any first child that is empty (leftover title bar wrapper)
          let first = body.firstElementChild;
          while (first && first !== body && !first.textContent.trim()) {
            const next = first.nextElementSibling;
            first.remove();
            first = next;
          }

          html = body.innerHTML.trim();
        } else {
          html = txt;
        }
      } else {
        html = txt;
      }
    }
  } catch (error) {
    console.error('Error in onModalTriggerClick fetch:', error);
    toggleLoadingState(modal, false);
    return;
  }

  if (!html) {
    toggleLoadingState(modal, false);
    return;
  }

  if (ajaxIframe) {
    let iframe = modal.querySelector('iframe');
    if (!iframe) {
      iframe = document.createElement('iframe');
      iframe.style.width = '100%';
      iframe.style.height = '100%';
      iframe.style.border = 'none';
      modal.appendChild(iframe);
    }

    if (typeof openLinkInNewTab === 'function') {
      openLinkInNewTab(iframe);
    }

    iframe.srcdoc = html;
  } else {
    const template = SDG?.Data?.template || '';

    modal.innerHTML = html;

    // Re-execute all script tags (scripts don't execute when using innerHTML)
    executeScripts(modal);

    // Special handling for collection.plp templates
    if (template?.includes('collection.plp') && customCompare && modal) {
      setTimeout(() => {
        const $scripts = modal.querySelectorAll('script') || [];

        if ($scripts.length > 0) {
          $scripts.forEach(script => {
            if (script.textContent.includes('channelCompare')) {
              let scriptContent = script.textContent.replace(/const reorderDOM/g, 'var reorderDOM');
              const $compareHeader = modal.querySelectorAll('#interactive-compare-header');
              const newScript = document.createElement('script');
              newScript.textContent = scriptContent;
              modal.appendChild(newScript);

              if ($compareHeader && typeof channelCompare !== 'undefined' && channelCompare?.init) {
                channelCompare.init();
              }
            }
          });
        }
      }, 500);
    }
  }

  trigger.dataset.ajaxLoaded = 'true';
  toggleLoadingState(modal, false);
}



/**
 * Re-execute script tags in an element
 * Scripts don't execute when using innerHTML, so we need to extract and re-inject them
 * @param {Node} element - The element containing scripts to re-execute
 */
function executeScripts(element) {
  if (!element) return;

  const scripts = element.querySelectorAll('script');
  if (!scripts || scripts.length === 0) return;

  scripts.forEach((oldScript) => {
    const newScript = document.createElement('script');
    
    // Copy all attributes from the old script
    Array.from(oldScript.attributes).forEach((attribute) => {
      newScript.setAttribute(attribute.name, attribute.value);
    });
    
    // Copy the script content (for inline scripts)
    if (oldScript.textContent) {
      newScript.appendChild(document.createTextNode(oldScript.textContent));
    }
    
    // Replace the old script with the new one (this triggers execution)
    oldScript.parentNode.replaceChild(newScript, oldScript);
  });
}

/**
 * Allow only http(s) and relative URLs for navigation, rejecting dangerous
 * schemes such as javascript: and data: that could be injected via link hrefs.
 * @param {String} href - The href value to validate
 * @return {Boolean}
 */
function isSafeNavigationHref(href) {
  try {
    const url = new URL(href, window.location.href);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (e) {
    return false;
  }
}

function openLinkInNewTab(iframe) {
  iframe.onload = function () {
    var iframeDocument = iframe.contentWindow.document;
    var links = iframeDocument.querySelectorAll('a');
    for (var i = 0; i < links.length; i++) {
      // Check if the link already has a target attribute
      if (!links[i].getAttribute('target')) {
        // If not, add target="_blank"
        links[i].setAttribute('target', '_parent');
      }

      links[i].addEventListener('click', function (event) {
        event.preventDefault();
        var href = this.getAttribute('href');

        if (href && isSafeNavigationHref(href)) {
          window.open(href, '_parent'); // Open the link in a new tab
        }
      });
    }

    // adobe tracking
    setTimeout(() => {
      window.adobeTrackMarketingPageIframeCtaClick(iframe);
      window.adobeTrackMarketingPageIframeScroll(iframe);
    }, 10);
  };
}

/**
 * toggle loading state for modal
 * @param {Node} $modal
 * @param {Boolean} isLoading
 */
function toggleLoadingState($modal, isLoading) {
  const $modalSpinner = $modal.querySelector('.ac-progress-indicator');
  const $modalSpinnerParent = $modalSpinner?.parentNode;
  if (isLoading) {
    $modal.classList.add('is-loading');
  } else {
    $modal.classList.remove('is-loading');
    if ($modalSpinnerParent) $modal.removeChild($modalSpinnerParent);
  }
}

/**
 * on modal close
 * @param  {Node} $trigger trigger element
 * @param  {Node} $modal modal element
 */
function onModalClose($trigger, $modal) {
  const $modalRoot = $modal.closest('.modal');
  if (!$modalRoot) return;
  // Multiple triggers can target the same modal; only attach one close-observer
  // per modal root so observers don't stack (each would otherwise re-run the
  // teardown and leak for the page lifetime).
  if ($modalRoot.dataset.closeObserverBound === 'true') return;
  $modalRoot.dataset.closeObserverBound = 'true';

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if(mutation.attributeName == 'class'){
            const isOpen = mutation.target.classList.contains('modal-open');
            // clear modal content if modal is closed
            if (!isOpen) {
              window.pauseAllMedia();
              // The observer binds only once per modal root (guard above), but a
              // root can be reached by more than one trigger (responsive duplicate
              // triggers, or duplicate modal ids that collapse in the modals map).
              // Resolve the ajax modal(s) and their triggers from the DOM on each
              // close instead of relying on the single $trigger captured at bind
              // time — otherwise only that first trigger is cleared and reopening
              // any other trigger for the same modal shows an empty (reset) modal.
              const $ajaxContents = Array.from(mutation.target.querySelectorAll('.ac-modal')).filter(($content) => {
                const id = $content.getAttribute('id');
                // Only reset modals whose trigger has a NON-EMPTY data-ajax-url (i.e. genuine
                // ajax modals that re-fetch on next open). Content modals (e.g. AppleCare Learn
                // More) render their content inline but still carry an empty data-ajax-url="";
                // a bare [data-ajax-url] presence selector matches that empty value and would
                // wipe their server-rendered content to the spinner with nothing to refetch,
                // leaving the modal empty on reopen.
                return id && document.querySelector(`.ac-modal-trigger[data-modal-target="${id}"][data-ajax-url]:not([data-ajax-url=""])`);
              });
              if ($ajaxContents.length) {
                setTimeout(() => {
                  $ajaxContents.forEach(($modalContent) => {
                  $modalContent.innerHTML = `
                    <div class="seedkit-component-standalone">
                      <div class="ac-progress-indicator">
                        <div data-progress-indicator="" class="progress-indicator progress-indicator-indeterminate progress-indicator-immediate progress-indicator-curtain progress-indicator-visible">
                          <svg class="progress-indicator-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 56 56" aria-hidden="true">
                              <g class="progress-indicator-spokes">
                                  <path class="progress-indicator-spoke" d="M28,8.5A2.5,2.5,0,0,1,30.5,11v7a2.5,2.5,0,0,1-5,0V11A2.5,2.5,0,0,1,28,8.5Z"></path>
                                  <path class="progress-indicator-spoke" d="M41.79,14.21a2.52,2.52,0,0,1,0,3.54L36.84,22.7a2.5,2.5,0,0,1-3.54-3.54l5-4.95A2.52,2.52,0,0,1,41.79,14.21Z"></path>
                                  <path class="progress-indicator-spoke" d="M47.5,28A2.5,2.5,0,0,1,45,30.5H38a2.5,2.5,0,0,1,0-5h7A2.5,2.5,0,0,1,47.5,28Z"></path>
                                  <path class="progress-indicator-spoke" d="M41.79,41.79a2.52,2.52,0,0,1-3.54,0l-5-4.95a2.5,2.5,0,0,1,3.54-3.54l4.95,5A2.52,2.52,0,0,1,41.79,41.79Z"></path>
                                  <path class="progress-indicator-spoke" d="M28,47.5A2.5,2.5,0,0,1,25.5,45V38a2.5,2.5,0,0,1,5,0v7A2.5,2.5,0,0,1,28,47.5Z"></path>
                                  <path class="progress-indicator-spoke" d="M14.21,41.79a2.52,2.52,0,0,1,0-3.54l4.95-5a2.5,2.5,0,0,1,3.54,3.54l-4.95,4.95A2.52,2.52,0,0,1,14.21,41.79Z"></path>
                                  <path class="progress-indicator-spoke" d="M8.5,28A2.5,2.5,0,0,1,11,25.5h7a2.5,2.5,0,0,1,0,5H11A2.5,2.5,0,0,1,8.5,28Z"></path>
                                  <path class="progress-indicator-spoke" d="M14.21,14.21a2.52,2.52,0,0,1,3.54,0l4.95,4.95a2.5,2.5,0,0,1-3.54,3.54l-4.95-4.95A2.52,2.52,0,0,1,14.21,14.21Z"></path>
                              </g>
                          </svg>
                        </div>
                      </div>
                    </div>
                  `;
                  const id = $modalContent.getAttribute('id');
                  document
                    .querySelectorAll(`.ac-modal-trigger[data-modal-target="${id}"]`)
                    .forEach(($t) => $t.removeAttribute('data-ajax-loaded'));
                  });
                }, 500);
              } else {
                // stop video if modal is closed
                const $video = mutation.target.querySelector('video');
                if ($video) {
                  $video.pause();
                  $video.currentTime = 0;
                }
              }
            }
        }
    });
  });
  observer.observe($modalRoot, { attributes: true, attributeFilter: ['class'] });
}
