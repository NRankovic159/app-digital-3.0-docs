function getFocusableElements(container) {
  return Array.from(
    container.querySelectorAll(
      "summary, a[href], button:enabled, [tabindex]:not([tabindex^='-']), [draggable], area, input:not([type=hidden]):enabled, select:enabled, textarea:enabled, object, iframe"
    )
  );
}

// Safari/VoiceOver caches the accessible name from descendant text and doesn't refresh it
// when nested innerHTML mutates. Mirroring the visible label into aria-label on the <summary>
// forces WebKit to recompute the AX name on next focus.
window.refreshSummaryAriaLabel = function (elementInsideSummary) {
  const node = elementInsideSummary?.jquery ? elementInsideSummary[0] : elementInsideSummary;
  if (!node) return;
  const summary = node.tagName === 'SUMMARY' ? node : node.closest?.('summary');
  if (!summary) return;
  summary.setAttribute('aria-label', summary.textContent.replace(/\s+/g, ' ').trim());
};

const CART_QTY_SEPARATORS = { row: ',#', col: '<--split-->' };
const CART_QTY_KEY_PREFIX = { ctoChild: 'bundle-cto-child-', nativeComponent: 'bundle-component-' };

/**
 * Cart quantity aggregation shared by every add-to-cart / checkout quantity-limit gate.
 *
 * Source of truth is the `cart?view=minquant` row feed rather than /cart.js, because units that
 * live inside a bundle are invisible to /cart.js: a custom (CTO) bundle is a single line whose
 * variant is the hero child (the other children exist only as `_bundle_item_N_id` properties),
 * and a native Shopify bundle keeps its children in `item_components`. minquant emits a synthetic
 * row per bundle child so those units can be aggregated by product id.
 *
 * See theme/templates/cart.minquant.liquid for the row format and key taxonomy.
 */
window.CartQuantity = (() => {
  let rowsCache = null;

  const parseRows = (text) =>
    String(text)
      .trim()
      .split(CART_QTY_SEPARATORS.row)
      .filter((chunk) => chunk.trim() !== '')
      .map((chunk) => chunk.split(CART_QTY_SEPARATORS.col).map((col) => col.trim()));

  // Tolerates an untrimmed row, since a caller may hand over a raw String.split() result.
  const isCtoChildRow = (row) =>
    Array.isArray(row) && typeof row[3] === 'string' && row[3].trim().startsWith(CART_QTY_KEY_PREFIX.ctoChild);

  const isAddOnRow = (row) => row?.[7] === 'AppleCare' || row?.[7] === 'SecondWarranty';

  /**
   * Blocking on purpose: every caller is a synchronous add-to-cart / checkout gate that must
   * decide before the click proceeds. Memoised for the CURRENT SYNCHRONOUS TURN ONLY (dropped on
   * the next microtask, which flushes before any network callback or subsequent event), so a gate
   * that inspects many products — the frequently-bought-together loop, or every child of a bundle
   * — issues one request instead of N, yet can never act on a snapshot from an earlier turn.
   */
  const getRows = () => {
    if (rowsCache) return rowsCache;

    let rows = [];
    try {
      $.ajax({
        type: 'GET',
        async: false,
        url: `${window.Shopify.routes.root}cart?view=minquant`,
        success: (data) => {
          rows = parseRows(data);
        },
      });
    } catch (e) {
      rows = [];
    }

    rowsCache = rows;
    Promise.resolve().then(() => {
      rowsCache = null;
    });
    return rows;
  };

  /**
   * Total units of a product across the whole cart.
   *
   * @param {number|string} productId
   * @param {Object} [options]
   * @param {boolean} [options.includeCtoChildren=true] `true` for MAX-limit checks: units sitting
   *   inside a CTO bundle count toward the product's purchase limit. `false` for INVENTORY checks:
   *   a CTO bundle line only consumes the hero variant's inventory, never the other children's, so
   *   counting them there would invent a restriction that no stock level backs.
   * @param {Array[]} [options.rows] Pre-fetched rows, to keep a multi-product gate at one request.
   */
  const sumByProductId = (productId, { includeCtoChildren = true, rows } = {}) => {
    if (productId === undefined || productId === null || productId === '') return 0;

    return (rows ?? getRows()).reduce((total, row) => {
      // Loose equality: minquant columns arrive as strings, callers pass numbers or strings.
      if (row[0] != productId) return total;
      if (!includeCtoChildren && isCtoChildRow(row)) return total;
      return total + (parseInt(row[1], 10) || 0);
    }, 0);
  };

  return { KEY_PREFIX: CART_QTY_KEY_PREFIX, parseRows, isCtoChildRow, isAddOnRow, getRows, sumByProductId };
})();

document.querySelectorAll('[id^="Details-"] summary').forEach((summary) => {
  summary.setAttribute('aria-expanded', summary.parentNode.hasAttribute('open'));

  summary.addEventListener('click', (event) => {
    event.currentTarget.setAttribute('aria-expanded', !event.currentTarget.closest('details').hasAttribute('open'));
  });

  if (summary.closest('header-drawer, menu-drawer')) return;
  summary.parentElement.addEventListener('keyup', onKeyUpEscape);
});

const trapFocusHandlers = {};

function trapFocus(container, elementToFocus = container) {
  var elements = getFocusableElements(container);
  var first = elements[0];
  var last = elements[elements.length - 1];

  removeTrapFocus();

  trapFocusHandlers.focusin = (event) => {
    if (event.target !== container && event.target !== last && event.target !== first) return;

    document.addEventListener('keydown', trapFocusHandlers.keydown);
  };

  trapFocusHandlers.focusout = function () {
    document.removeEventListener('keydown', trapFocusHandlers.keydown);
  };

  trapFocusHandlers.keydown = function (event) {
    if (event.code.toUpperCase() !== 'TAB') return; // If not TAB key
    // On the last focusable element and tab forward, focus the first element.
    if (event.target === last && !event.shiftKey) {
      event.preventDefault();
      first.focus();
    }

    //  On the first focusable element and tab backward, focus the last element.
    if ((event.target === container || event.target === first) && event.shiftKey) {
      event.preventDefault();
      last.focus();
    }
  };

  document.addEventListener('focusout', trapFocusHandlers.focusout);
  document.addEventListener('focusin', trapFocusHandlers.focusin);

  elementToFocus.focus();

  if (
    elementToFocus.tagName === 'INPUT' &&
    ['search', 'text', 'email', 'url'].includes(elementToFocus.type) &&
    elementToFocus.value
  ) {
    elementToFocus.setSelectionRange(0, elementToFocus.value.length);
  }
}

// Here run the querySelector to figure out if the browser supports :focus-visible or not and run code based on it.
try {
  document.querySelector(':focus-visible');
} catch (e) {
  focusVisiblePolyfill();
}

function focusVisiblePolyfill() {
  const navKeys = [
    'ARROWUP',
    'ARROWDOWN',
    'ARROWLEFT',
    'ARROWRIGHT',
    'TAB',
    'ENTER',
    'SPACE',
    'ESCAPE',
    'HOME',
    'END',
    'PAGEUP',
    'PAGEDOWN',
  ];
  let currentFocusedElement = null;
  let mouseClick = null;

  window.addEventListener('keydown', (event) => {
    if (navKeys.includes(event.code.toUpperCase())) {
      mouseClick = false;
    }
  });

  window.addEventListener('mousedown', (event) => {
    mouseClick = true;
  });

  window.addEventListener(
    'focus',
    () => {
      if (currentFocusedElement) currentFocusedElement.classList.remove('focused');

      if (mouseClick) return;

      currentFocusedElement = document.activeElement;
      currentFocusedElement.classList.add('focused');
    },
    true
  );
}

function pauseAllMedia() {
  // YouTube
  document.querySelectorAll('.js-youtube').forEach((video) => {
    if (video?.contentWindow) {
      video.contentWindow.postMessage(JSON.stringify({
        event: "command",
        func: "pauseVideo",
        args: ""
      }), 'https://www.youtube.com');
    }
  });

  // Vimeo
  document.querySelectorAll('.js-vimeo').forEach((video) => {
    if (video?.contentWindow) {
      video.contentWindow.postMessage(JSON.stringify({
        method: "pause"
      }), 'https://player.vimeo.com');
    }
  });
  document.querySelectorAll('video:not(video[autoplay][muted])').forEach((video) => video.pause());
  document.querySelectorAll('product-model').forEach((model) => {
    if (model.modelViewerUI) model.modelViewerUI.pause();
  });
}

function removeTrapFocus(elementToFocus = null) {
  document.removeEventListener('focusin', trapFocusHandlers.focusin);
  document.removeEventListener('focusout', trapFocusHandlers.focusout);
  document.removeEventListener('keydown', trapFocusHandlers.keydown);

  if (elementToFocus) elementToFocus.focus();
}

function onKeyUpEscape(event) {
  if (event.code.toUpperCase() !== 'ESCAPE') return;

  const openDetailsElement = event.target.closest('details[open]');
  if (!openDetailsElement) return;

  const summaryElement = openDetailsElement.querySelector('summary');
  openDetailsElement.removeAttribute('open');
  summaryElement.setAttribute('aria-expanded', false);
  summaryElement.focus();
}

class QuantityInput extends HTMLElement {
  constructor() {
    super();
    this.input = this.querySelector('input');
    this.changeEvent = new Event('change', { bubbles: true });
    this.input.addEventListener('change', this.onInputChange.bind(this));
    this.querySelectorAll('button').forEach((button) =>
      button.addEventListener('click', this.onButtonClick.bind(this))
    );
  }

  quantityUpdateUnsubscriber = undefined;

  connectedCallback() {
    this.validateQtyRules();
    this.quantityUpdateUnsubscriber = subscribe(PUB_SUB_EVENTS.quantityUpdate, this.validateQtyRules.bind(this));
  }

  disconnectedCallback() {
    if (this.quantityUpdateUnsubscriber) {
      this.quantityUpdateUnsubscriber();
    }
  }

  onInputChange(event) {
    this.validateQtyRules();
  }

  onButtonClick(event) {
    event.preventDefault();
    const previousValue = this.input.value;

    event.target.name === 'plus' ? this.input.stepUp() : this.input.stepDown();
    if (previousValue !== this.input.value) this.input.dispatchEvent(this.changeEvent);
  }

  validateQtyRules() {
    const value = parseInt(this.input.value);

    if (value === 0 || isNaN(value)) {
      this.input.value = '1';
    }

    // Both bounds are recomputed unconditionally. Guarding on the presence of `min`/`max` left the
    // button's styling frozen at whatever the last bound produced: the CTO bundle scripts drop `max`
    // when the shopper picks "No bundle", so a plus button disabled under the bundle's lower limit
    // stayed greyed out while still stepping the quantity up. An absent or non-numeric bound (`max`
    // is rendered as the string "null" on some PDPs) simply means "no bound", never "keep as-is".
    const buttonMinus = this.querySelector(".quantity__button[name='minus']");
    if (buttonMinus) {
      const min = parseInt(this.input.min);
      buttonMinus.classList.toggle('disabled', !isNaN(min) && value <= min);
    }

    const buttonPlus = this.querySelector(".quantity__button[name='plus']");
    if (buttonPlus) {
      const max = parseInt(this.input.max);
      buttonPlus.classList.toggle('disabled', !isNaN(max) && value >= max);
    }
  }
}

customElements.define('quantity-input', QuantityInput);

function debounce(fn, wait) {
  let t;
  return function (...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

function throttle(fn, delay = 150) {
  let lastCall = 0;
  return function (...args) {
    const now = new Date().getTime();
    if (now - lastCall < delay) {
      return;
    }
    lastCall = now;
    return fn(...args);
  };
}

function fetchConfig(type = 'json') {
  return {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: `application/${type}` },
  };
}

/*
 * Shopify Common JS
 *
 */
if (typeof window.Shopify == 'undefined') {
  window.Shopify = {};
}

Shopify.bind = function (fn, scope) {
  return function () {
    return fn.apply(scope, arguments);
  };
};

Shopify.setSelectorByValue = function (selector, value) {
  for (var i = 0, count = selector.options.length; i < count; i++) {
    var option = selector.options[i];
    if (value == option.value || value == option.innerHTML) {
      selector.selectedIndex = i;
      return i;
    }
  }
};

Shopify.addListener = function (target, eventName, callback) {
  target.addEventListener(eventName, callback, false);
};

Shopify.postLink = function (path, options) {
  options = options || {};
  var method = options['method'] || 'post';
  var params = options['parameters'] || {};

  var form = document.createElement('form');
  form.setAttribute('method', method);
  form.setAttribute('action', path);

  for (var key in params) {
    var hiddenField = document.createElement('input');
    hiddenField.setAttribute('type', 'hidden');
    hiddenField.setAttribute('name', key);
    hiddenField.setAttribute('value', params[key]);
    form.appendChild(hiddenField);
  }
  document.body.appendChild(form);
  form.submit();
  document.body.removeChild(form);
};

Shopify.CountryProvinceSelector = function (country_domid, province_domid, options) {
  this.countryEl = document.getElementById(country_domid);
  this.provinceEl = document.getElementById(province_domid);
  this.provinceContainer = document.getElementById(options['hideElement'] || province_domid);

  Shopify.addListener(this.countryEl, 'change', Shopify.bind(this.countryHandler, this));

  this.initCountry();
  this.initProvince();
};

Shopify.CountryProvinceSelector.prototype = {
  initCountry: function () {
    var value = this.countryEl.getAttribute('data-default');
    Shopify.setSelectorByValue(this.countryEl, value);
    this.countryHandler();
  },

  initProvince: function () {
    var value = this.provinceEl.getAttribute('data-default');
    if (value && this.provinceEl.options.length > 0) {
      Shopify.setSelectorByValue(this.provinceEl, value);
    }
  },

  countryHandler: function (e) {
    var opt = this.countryEl.options[this.countryEl.selectedIndex];
    var raw = opt.getAttribute('data-provinces');
    var provinces;
    try {
      provinces = JSON.parse(raw);
    } catch (err) {
      provinces = [];
    }

    this.clearOptions(this.provinceEl);
    if (provinces && provinces.length == 0) {
      this.provinceContainer.style.display = 'none';
    } else {
      for (var i = 0; i < provinces.length; i++) {
        var opt = document.createElement('option');
        opt.value = provinces[i][0];
        opt.innerHTML = provinces[i][1];
        this.provinceEl.appendChild(opt);
      }

      this.provinceContainer.style.display = '';
    }
  },

  clearOptions: function (selector) {
    while (selector.firstChild) {
      selector.removeChild(selector.firstChild);
    }
  },

  setOptions: function (selector, values) {
    for (var i = 0, count = values.length; i < count; i++) {
      var opt = document.createElement('option');
      opt.value = values[i];
      opt.innerHTML = values[i];
      selector.appendChild(opt);
    }
  },
};

class MenuDrawer extends HTMLElement {
  constructor() {
    super();

    this.mainDetailsToggle = this.querySelector('details');

    this.addEventListener('keyup', this.onKeyUp.bind(this));
    this.addEventListener('focusout', this.onFocusOut.bind(this));
    this.bindEvents();
  }

  bindEvents() {
    this.querySelectorAll('summary').forEach((summary) =>
      summary.addEventListener('click', this.onSummaryClick.bind(this))
    );
    this.querySelectorAll('button:not(.localization-selector)').forEach((button) =>
      button.addEventListener('click', this.onCloseButtonClick.bind(this))
    );
  }

  onKeyUp(event) {
    if (event.code.toUpperCase() !== 'ESCAPE') return;

    const openDetailsElement = event.target.closest('details[open]');
    if (!openDetailsElement) return;

    openDetailsElement === this.mainDetailsToggle
      ? this.closeMenuDrawer(event, this.mainDetailsToggle.querySelector('summary'))
      : this.closeSubmenu(openDetailsElement);
  }

  onSummaryClick(event) {
    const summaryElement = event.currentTarget;
    const detailsElement = summaryElement.parentNode;
    const parentMenuElement = detailsElement.closest('.has-submenu');
    const isOpen = detailsElement.hasAttribute('open');
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const $drawerMenu = document.getElementById('menu-drawer');

    if (detailsElement?.classList?.contains('js-menu-item') && $drawerMenu) {
      $drawerMenu.scrollTop = 0;
    }

    function addTrapFocus() {
      trapFocus(summaryElement.nextElementSibling, detailsElement.querySelector('button'));
      summaryElement.nextElementSibling.removeEventListener('transitionend', addTrapFocus);
    }

    if (detailsElement === this.mainDetailsToggle) {
      if (isOpen) event.preventDefault();
      isOpen ? this.closeMenuDrawer(event, summaryElement) : this.openMenuDrawer(summaryElement);

      if (window.matchMedia('(max-width: 990px)').matches) {
        document.documentElement.style.setProperty('--viewport-height', `${window.innerHeight}px`);
      }
    } else {
      setTimeout(() => {
        detailsElement.classList.add('menu-opening');
        summaryElement.setAttribute('aria-expanded', true);
        parentMenuElement && parentMenuElement.classList.add('submenu-open');
        !reducedMotion || reducedMotion.matches
          ? addTrapFocus()
          : summaryElement.nextElementSibling.addEventListener('transitionend', addTrapFocus);
      }, 100);
    }
  }

  openMenuDrawer(summaryElement) {
    setTimeout(() => {
      this.mainDetailsToggle.classList.add('menu-opening');
    });
    summaryElement.setAttribute('aria-expanded', true);
    trapFocus(this.mainDetailsToggle, summaryElement);
    document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
  }

  closeMenuDrawer(event, elementToFocus = false) {
    if (event === undefined) return;

    this.mainDetailsToggle.classList.remove('menu-opening');
    this.mainDetailsToggle.querySelectorAll('details').forEach((details) => {
      const { filterMenusExpanded } = details.dataset

      if (!filterMenusExpanded) {
        details.removeAttribute('open');
        details.classList.remove('menu-opening');
      }
    });
    this.mainDetailsToggle.querySelectorAll('.submenu-open').forEach((submenu) => {
      submenu.classList.remove('submenu-open');
    });
    document.body.classList.remove(`overflow-hidden-${this.dataset.breakpoint}`);
    removeTrapFocus(elementToFocus);
    this.closeAnimation(this.mainDetailsToggle);

    if (event instanceof KeyboardEvent) elementToFocus?.setAttribute('aria-expanded', false);
  }

  onFocusOut() {
    setTimeout(() => {
      if (this.mainDetailsToggle.hasAttribute('open') && !this.mainDetailsToggle.contains(document.activeElement))
        this.closeMenuDrawer();
    });
  }

  onCloseButtonClick(event) {
    const detailsElement = event.currentTarget.closest('details');
    this.closeSubmenu(detailsElement);
  }

  closeSubmenu(detailsElement) {
    const parentMenuElement = detailsElement.closest('.submenu-open');
    parentMenuElement && parentMenuElement.classList.remove('submenu-open');
    detailsElement.classList.remove('menu-opening');
    const summary = detailsElement.querySelector('summary');
    summary?.setAttribute('aria-expanded', false);
    removeTrapFocus(summary);
    this.closeAnimation(detailsElement);
  }

  closeAnimation(detailsElement) {
    let animationStart;

    const handleAnimation = (time) => {
      if (animationStart === undefined) {
        animationStart = time;
      }

      const elapsedTime = time - animationStart;

      if (elapsedTime < 400) {
        window.requestAnimationFrame(handleAnimation);
      } else {
        detailsElement.removeAttribute('open');
        if (detailsElement.closest('details[open]')) {
          trapFocus(detailsElement.closest('details[open]'), detailsElement.querySelector('summary'));
        }
      }
    };

    window.requestAnimationFrame(handleAnimation);
  }
}

customElements.define('menu-drawer', MenuDrawer);

class HeaderDrawer extends MenuDrawer {
  constructor() {
    super();
  }

  openMenuDrawer(summaryElement) {
    this.header = this.header || document.querySelector('.section-header');
    this.borderOffset =
      this.borderOffset || (this.closest('.header-wrapper').classList.contains('header-wrapper--border-bottom') ? 1 : 0);
    document.documentElement.style.setProperty(
      '--header-bottom-position',
      `${parseInt(this.header.getBoundingClientRect().bottom - this.borderOffset)}px`
    );
    this.header.classList.add('menu-open');

    setTimeout(() => {
      this.mainDetailsToggle.classList.add('menu-opening');
    });

    summaryElement.setAttribute('aria-expanded', true);
    window.addEventListener('resize', this.onResize);
    trapFocus(this.mainDetailsToggle, summaryElement);
    document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
  }

  closeMenuDrawer(event, elementToFocus) {
    window.removeEventListener('resize', this.onResize);
    if (!elementToFocus) return;
    super.closeMenuDrawer(event, elementToFocus);
    this.header.classList.remove('menu-open');
  }

  onResize = () => {
    this.header &&
      document.documentElement.style.setProperty(
        '--header-bottom-position',
        `${parseInt(this.header.getBoundingClientRect().bottom - this.borderOffset)}px`
      );
    document.documentElement.style.setProperty('--viewport-height', `${window.innerHeight}px`);
  };
}

customElements.define('header-drawer', HeaderDrawer);

class ModalDialog extends HTMLElement {
  constructor() {
    super();
    this.querySelector('[id^="ModalClose-"]')?.addEventListener('click', this.hide.bind(this, false));
    this.addEventListener('keyup', (event) => {
      if (event.code.toUpperCase() === 'ESCAPE') this.hide();
    });
    if (this.classList.contains('media-modal')) {
      this.addEventListener('pointerup', (event) => {
        if (event.pointerType === 'mouse' && !event.target.closest('deferred-media, product-model')) this.hide();
      });
    } else {
      this.addEventListener('click', (event) => {
        if (event.target === this) this.hide();
      });
    }
  }

  connectedCallback() {
    if (this.moved) return;
    this.moved = true;
    document.body.appendChild(this);
  }

  show(opener) {
    this.openedBy = opener;
    const popup = this.querySelector('.template-popup');
    document.body.classList.add('overflow-hidden');
    this.setAttribute('open', '');
    if (popup) popup.loadContent();
    trapFocus(this, this.querySelector('[role="dialog"]') || this);
    window.pauseAllMedia();
  }

  hide() {
    document.body.classList.remove('overflow-hidden');
    document.body.dispatchEvent(new CustomEvent('modalClosed'));
    this.removeAttribute('open');
    removeTrapFocus(this.openedBy);
    window.pauseAllMedia();
  }
}
customElements.define('modal-dialog', ModalDialog);

class ModalOpener extends HTMLElement {
  constructor() {
    super();

    const button = this.querySelector('button');

    if (!button) return;
    button.addEventListener('click', () => {
      const modal = document.querySelector(this.getAttribute('data-modal'));
      if (modal) modal.show(button);
    });
  }
}
customElements.define('modal-opener', ModalOpener);

class DeferredMedia extends HTMLElement {
  constructor() {
    super();
    const poster = this.querySelector('[id^="Deferred-Poster-"]');
    if (!poster) return;
    poster.addEventListener('click', this.loadContent.bind(this));
  }

  loadContent(focus = true) {
    window.pauseAllMedia();
    if (!this.getAttribute('loaded')) {
      const content = document.createElement('div');
      content.appendChild(this.querySelector('template').content.firstElementChild.cloneNode(true));

      this.setAttribute('loaded', true);
      const deferredElement = this.appendChild(content.querySelector('video, model-viewer, iframe'));
      if (focus) deferredElement.focus();
      if (deferredElement.nodeName == 'VIDEO' && deferredElement.getAttribute('autoplay')) {
        // force autoplay for safari
        deferredElement.play();
      }
    }
  }
}

customElements.define('deferred-media', DeferredMedia);

class SliderComponent extends HTMLElement {
  constructor() {
    super();
    this.slider = this.querySelector('[id^="Slider-"]');
    this.sliderItems = this.querySelectorAll('[id^="Slide-"]');
    this.currentSlide = null;
    this.enableSliderLooping = false;
    this.currentPageElement = this.querySelector('.slider-counter--current');
    this.pageTotalElement = this.querySelector('.slider-counter--total');
    this.prevButton = this.querySelector('button[name="previous"]');
    this.nextButton = this.querySelector('button[name="next"]');

    if (!this.slider || !this.sliderItems) return;

    this.initPages();
    const resizeObserver = new ResizeObserver((entries) => this.initPages());
    resizeObserver.observe(this.slider);

    this.slider.addEventListener('scroll', this.update.bind(this));

    if (this.prevButton) {
      this.prevButton.addEventListener('click', this.onButtonClick.bind(this));
    }
    if (this.nextButton) {
      this.nextButton.addEventListener('click', this.onButtonClick.bind(this));
    }
  }

  initPages() {
    this.sliderItemsToShow = Array.from(this.sliderItems).filter((element) => element.clientWidth > 0);
    if (this.sliderItemsToShow.length < 2) return;
    this.sliderItemOffset = this.sliderItemsToShow[1].offsetLeft - this.sliderItemsToShow[0].offsetLeft;
    this.slidesPerPage = Math.floor(
      (this.slider.clientWidth - this.sliderItemsToShow[0].offsetLeft) / this.sliderItemOffset
    );
    this.totalPages = this.sliderItemsToShow.length - this.slidesPerPage + 1;
    this.update();
  }

  resetPages() {
    this.sliderItems = this.querySelectorAll('[id^="Slide-"]');
    this.initPages();
  }

  update() {
    // Temporarily prevents unneeded updates resulting from variant changes
    // This should be refactored as part of https://github.com/Shopify/dawn/issues/2057
    if (!this.slider) return;

    const previousPage = this.currentPage;
    this.currentPage = Math.round(this.slider.scrollLeft / this.sliderItemOffset) + 1;

    if (this.currentPageElement && this.pageTotalElement) {
      this.currentPageElement.textContent = this.currentPage;
      this.pageTotalElement.textContent = this.totalPages;
    }

    if (this.currentPage != previousPage) {
      this.currentSlide = this.sliderItemsToShow[this.currentPage - 1];
      this.dispatchEvent(
        new CustomEvent('slideChanged', {
          detail: {
            currentPage: this.currentPage,
            currentElement: this.currentSlide,
          },
        })
      );
    }

    if (this.isSlideVisible(this.sliderItemsToShow[0]) && this.slider.scrollLeft === 0) {
      if (this.prevButton) this.prevButton.setAttribute('disabled', 'disabled');
    } else {
      if (this.prevButton) this.prevButton.removeAttribute('disabled');
    }

    // Slider arrows
    if (this.isSlideVisible(this.sliderItemsToShow[this.sliderItemsToShow.length - 1])) {
      if (this.nextButton) this.nextButton.setAttribute('disabled', 'disabled');
    } else {
      if (this.nextButton) this.nextButton.removeAttribute('disabled');
    }

    // Slider dots
    this.sliderControlButtons = this.querySelectorAll('.slider-counter__link');

    if (this.sliderControlButtons) {
      this.sliderControlButtons.forEach((link) => {
        link.classList.remove('slider-counter__link--active');
        link.removeAttribute('aria-current');
      });
      this.sliderControlButtons[this.currentPage - 1]?.classList.add('slider-counter__link--active');
      if (!this.autoplay) {
        this.sliderControlButtons[this.currentPage - 1]?.setAttribute('aria-current', true);
      }
    }

    this.setSlideVisibility();

    if (this.enableSliderLooping) return;
  }

  isSlideVisible(element, offset = 0) {
    const lastVisibleSlide = this.slider.clientWidth + this.slider.scrollLeft - offset;
    return element.offsetLeft + element.clientWidth <= lastVisibleSlide && element.offsetLeft >= this.slider.scrollLeft;
  }

  // Set aria-* attributes based on slide visibility
  setSlideVisibility() {
    // List of elements to be observed
    const targets = this.sliderItems;
    const options = {
      root: null, // null means root is viewport
      rootMargin: '0px',
      threshold: .5 // trigger callback when 50% of the element is visible
    }

    function callback(entries, observer) {
      entries.forEach(entry => {
        const slide = entry.target;
        const visible = entry.isIntersecting;

        setAttributes(slide, {'aria-hidden': visible ? 'false' : 'true', tabindex: visible ? '0' : '-1'});
        // Only genuinely interactive descendants belong in the tab order; images are
        // non-interactive (forcing tabindex=0 on them made every slide image a keyboard
        // stop). The slide's own aria-hidden already hides descendant images from AT.
        const focusableElements = slide.querySelectorAll('a, button, input, select');
        if (focusableElements.length > 0) {
          focusableElements.forEach((focusableEl) => {
            setAttributes(focusableEl, {'aria-hidden': visible ? 'false' : 'true', tabindex: visible ? '0' : '-1'});
          });
        }
      });
    };

    // Keep a single live observer so visibility (and therefore keyboard focusability)
    // keeps updating as the section is scrolled into/out of the viewport. Disconnecting
    // inside the callback froze slides as non-focusable when the section loaded below the fold.
    this.slideVisibilityObserver?.disconnect();
    this.slideVisibilityObserver = new IntersectionObserver(callback, options);
    [...targets].forEach(target => this.slideVisibilityObserver.observe(target));
  }

  onButtonClick(event) {
    event.preventDefault();
    const step = event.currentTarget.dataset.step || 1;
    this.slideScrollPosition =
      event.currentTarget.name === 'next'
        ? this.slider.scrollLeft + step * this.sliderItemOffset
        : this.slider.scrollLeft - step * this.sliderItemOffset;
    this.setSlidePosition(this.slideScrollPosition);
    this.setSlideVisibility();
  }

  setSlidePosition(position) {
    this.slider.scrollTo({
      left: position,
    });
  }
}

customElements.define('slider-component', SliderComponent);

class SlideshowComponent extends SliderComponent {
  constructor() {
    super();
    this.sliderControlWrapper = this.querySelector('.slider-buttons');
    this.enableSliderLooping = true;

    if (!this.sliderControlWrapper) return;

    this.sliderFirstItemNode = this.slider.querySelector('.slideshow__slide');
    if (this.sliderItemsToShow.length > 0) this.currentPage = 1;

    this.announcementBarSlider = this.querySelector('.announcement-bar-slider');
    // Value below should match --duration-announcement-bar CSS value
    this.announcerBarAnimationDelay = this.announcementBarSlider ? 250 : 0;

    this.sliderControlLinksArray = Array.from(this.sliderControlWrapper.querySelectorAll('.slider-counter__link'));
    this.sliderControlLinksArray.forEach((link) => link.addEventListener('click', this.linkToSlide.bind(this)));
    this.slider.addEventListener('scroll', this.setSlideVisibility.bind(this));
    this.setSlideVisibility();
    this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    if (this.announcementBarSlider) {
      this.announcementBarArrowButtonWasClicked = false;

      this.reducedMotion.addEventListener('change', () => {
        if (this.slider.getAttribute('data-autoplay') === 'true') this.setAutoPlay();
      });

      [this.prevButton, this.nextButton].forEach((button) => {
        button.addEventListener(
          'click',
          () => {
            this.announcementBarArrowButtonWasClicked = true;
          },
          { once: true }
        );
      });
    }

    // set autoplay after the page is fully loaded
    window.addEventListener('load', () => {
      setTimeout(() => {
        if (this.slider.getAttribute('data-autoplay') === 'true') this.setAutoPlay();
      }, 3000);
    });
  }

  setAutoPlay() {
    this.autoplaySpeed = this.slider.dataset.speed * 1000;

    // setAutoPlay() can be called multiple times (load event + prefers-reduced-motion change);
    // bind handlers once and idempotency-guard the listener attachment so we don't stack
    // mouseover/leave/focusin/out handlers on every call.
    if (!this.__autoplayHoverBound) {
      this.__autoplayHoverBound = true;
      this._boundFocusIn = this.focusInHandling.bind(this);
      this._boundFocusOut = this.focusOutHandling.bind(this);
      this.addEventListener('mouseover', this._boundFocusIn);
      this.addEventListener('mouseleave', this._boundFocusOut);
      this.addEventListener('focusin', this._boundFocusIn);
      this.addEventListener('focusout', this._boundFocusOut);
    }

    if (this.querySelector('.slideshow__autoplay')) {
      this.sliderAutoplayButton = this.querySelector('.slideshow__autoplay');
      if (!this.__autoplayButtonBound) {
        this.__autoplayButtonBound = true;
        this.sliderAutoplayButton.addEventListener('click', this.autoPlayToggle.bind(this));
      }
      this.autoplayButtonIsSetToPlay = true;
      this.play();
    } else {
      this.reducedMotion.matches || this.announcementBarArrowButtonWasClicked
        ? this.pause()
        : this.play();
    }
  }

  onButtonClick(event) {
    super.onButtonClick(event);
    this.wasClicked = true;

    const isFirstSlide = this.currentPage === 1;
    const isLastSlide = this.currentPage === this.sliderItemsToShow.length;

    if (!isFirstSlide && !isLastSlide) {
      this.applyAnimationToAnnouncementBar(event.currentTarget.name);
      return;
    }

    if (isFirstSlide && event.currentTarget.name === 'previous') {
      this.slideScrollPosition =
        this.slider.scrollLeft + this.sliderFirstItemNode.clientWidth * this.sliderItemsToShow.length;
    } else if (isLastSlide && event.currentTarget.name === 'next') {
      this.slideScrollPosition = 0;
    }

    this.setSlidePosition(this.slideScrollPosition);

    this.applyAnimationToAnnouncementBar(event.currentTarget.name);
  }

  setSlidePosition(position) {
    if (this.setPositionTimeout) clearTimeout(this.setPositionTimeout);
    this.setPositionTimeout = setTimeout(() => {
      this.slider.scrollTo({
        left: position,
      });
    }, this.announcerBarAnimationDelay);
  }

  update() {
    super.update();
    this.prevButton?.removeAttribute('disabled');
  }

  autoPlayToggle() {
    this.togglePlayButtonState(this.autoplayButtonIsSetToPlay);
    this.autoplayButtonIsSetToPlay ? this.pause() : this.play();
    this.autoplayButtonIsSetToPlay = !this.autoplayButtonIsSetToPlay;
  }

  focusOutHandling(event) {
    if (this.sliderAutoplayButton) {
      const focusedOnAutoplayButton =
        event.target === this.sliderAutoplayButton || this.sliderAutoplayButton.contains(event.target);
      if (!this.autoplayButtonIsSetToPlay || focusedOnAutoplayButton) return;
      this.play();
    } else if (
      !this.reducedMotion.matches &&
      !this.announcementBarArrowButtonWasClicked
    ) {
      this.play();
    }
  }

  focusInHandling(event) {
    if (this.sliderAutoplayButton) {
      const focusedOnAutoplayButton =
        event.target === this.sliderAutoplayButton || this.sliderAutoplayButton.contains(event.target);
      if (focusedOnAutoplayButton && this.autoplayButtonIsSetToPlay) {
        this.play();
      } else if (this.autoplayButtonIsSetToPlay) {
        this.pause();
      }
    } else if (this.announcementBarSlider.contains(event.target)) {
      this.pause();
    }
  }

  play() {
    this.slider.setAttribute('aria-live', 'off');
    clearInterval(this.autoplay);
    this.autoplay = setInterval(this.autoRotateSlides.bind(this), this.autoplaySpeed);
  }

  pause() {
    this.slider.setAttribute('aria-live', 'polite');
    clearInterval(this.autoplay);
    this.autoplay = null;
  }

  togglePlayButtonState(pauseAutoplay) {
    if (pauseAutoplay) {
      this.sliderAutoplayButton.classList.add('slideshow__autoplay--paused');
      this.sliderAutoplayButton.setAttribute('aria-label', window.accessibilityStrings.playSlideshow);
    } else {
      this.sliderAutoplayButton.classList.remove('slideshow__autoplay--paused');
      this.sliderAutoplayButton.setAttribute('aria-label', window.accessibilityStrings.pauseSlideshow);
    }
  }

  autoRotateSlides() {
    const slideScrollPosition =
      this.currentPage === this.sliderItems.length
        ? 0
        : this.slider.scrollLeft + this.sliderItemOffset;

    this.setSlidePosition(slideScrollPosition);
    this.applyAnimationToAnnouncementBar();
  }

  applyAnimationToAnnouncementBar(button = 'next') {
    if (!this.announcementBarSlider) return;

    const itemsCount = this.sliderItems.length;
    const increment = button === 'next' ? 1 : -1;

    const currentIndex = this.currentPage - 1;
    let nextIndex = (currentIndex + increment) % itemsCount;
    nextIndex = nextIndex === -1 ? itemsCount - 1 : nextIndex;

    const nextSlide = this.sliderItems[nextIndex];
    const currentSlide = this.sliderItems[currentIndex];

    const animationClassIn = 'announcement-bar-slider--fade-in';
    const animationClassOut = 'announcement-bar-slider--fade-out';

    const isFirstSlide = currentIndex === 0;
    const isLastSlide = currentIndex === itemsCount - 1;

    const shouldMoveNext = (button === 'next' && !isLastSlide) || (button === 'previous' && isFirstSlide);
    const direction = shouldMoveNext ? 'next' : 'previous';

    currentSlide.classList.add(`${animationClassOut}-${direction}`);
    nextSlide.classList.add(`${animationClassIn}-${direction}`);

    setTimeout(() => {
      currentSlide.classList.remove(`${animationClassOut}-${direction}`);
      nextSlide.classList.remove(`${animationClassIn}-${direction}`);
    }, this.announcerBarAnimationDelay * 2);
  }

  linkToSlide(event) {
    event.preventDefault();
    const slideScrollPosition =
      this.slider.scrollLeft +
      this.sliderFirstItemNode.clientWidth *
      (this.sliderControlLinksArray.indexOf(event.currentTarget) + 1 - this.currentPage);
    this.slider.scrollTo({
      left: slideScrollPosition,
    });
  }
}

customElements.define('slideshow-component', SlideshowComponent);

class VariantSelects extends HTMLElement {
  constructor() {
    super();
    this.addEventListener('change', this.onVariantChange);
  }

  onVariantChange() {
    this.updateOptions();
    this.updateMasterId();
    this.toggleAddButton(true, '', false);
    this.updatePickupAvailability();
    this.removeErrorMessage();
    this.updateVariantStatuses();
    this.removeChecked();

    if (!this.currentVariant) {
      this.toggleAddButton(true, '', true);
      this.setUnavailable();
      // $(".sku-pdp").css("visibility", "hidden");
      // $(".barcode-pdp").css("visibility", "hidden");
      $(".sticky-atc-bar").css("visibility", "hidden");
      $(".pricestyle").html(typeof not_available_message !== 'undefined' ? not_available_message : '');
      $(".pricestyle").css("visibility", "visible");
    } else {
      // $(".sku-pdp").css("visibility", "visible");
      // $(".barcode-pdp").css("visibility", "visible");
      this.updateMedia();
      this.updateURL();
      this.updateVariantInput();
      this.renderProductInfo();
      this.updateShareUrl();
      this.updateVariantMetafields(this.currentVariant); // ADDED BY ANUSHA
    }
  }

  // ADDED BY ANUSHA - code for variant metafield change onclick - start
  updateVariantMetafields(currentVariant) {
    const variants = document.querySelectorAll("[data-variant-id]");
    variants.forEach(function (variant) {
      variant.style.display = "none";
      if (variant.dataset.variantId == currentVariant.id) {
        variant.style.display = "block";
      }
    });
  }

  updateOptions() {
    this.options = Array.from(this.querySelectorAll('select'), (select) => select.value);
  }

  updateMasterId() {
    this.currentVariant = this.getVariantData().find((variant) => {
      return !variant.options
        .map((option, index) => {
          return this.options[index] === option;
        })
        .includes(false);
    });
  }

  updateMedia() {
    if (!this.currentVariant) return;
    if (!this.currentVariant.featured_media) return;

    const mediaGalleries = document.querySelectorAll(`[id^="MediaGallery-${this.dataset.section}"]`);
    mediaGalleries.forEach((mediaGallery) =>
      mediaGallery.setActiveMedia(`${this.dataset.section}-${this.currentVariant.featured_media.id}`, true)
    );

    const modalContent = document.querySelector(`#ProductModal-${this.dataset.section} .product-media-modal__content`);
    if (!modalContent) return;
    const newMediaModal = modalContent.querySelector(`[data-media-id="${this.currentVariant.featured_media.id}"]`);
    modalContent.prepend(newMediaModal);
  }

  updateURL() {
    //added by anusha - 4th variant option cookie approach - start
    function setCookie(name, value, days) {
      var expires = "";
      if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
      }
      document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }
    function getCookie(name) {
      var nameEQ = name + "=";
      var ca = document.cookie.split(';');
      for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
      }
      return null;
    }
    function eraseCookie(name) {
      document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
    }

    // set cookie values for all 3 options , only if the main product has '4th option product list' (cookie array)
    // if(getCookie('optionPIDlist')){
    // setCookie('option1select',this.currentVariant.option1,7);
    // setCookie('option2select',this.currentVariant.option2,7);
    // setCookie('option3select',this.currentVariant.option3,7);
    // }

    //added by anusha - 4th variant option cookie approach - end

    if (!this.currentVariant || this.dataset.updateUrl === "false") return;

    // $("#main-pro-sku").val(this.currentVariant.sku);
    // $("#main-pro-sku-mobile").val(this.currentVariant.sku);


    // $("#skutitle1").val(this.currentVariant.sku);
    // $("#skutitle2").val(this.currentVariant.sku);

    //  $("#main-pro-barcode").val(this.currentVariant.barcode);
    //  $("#main-pro-barcode-mobile").val(this.currentVariant.barcode);
    //  $("#barcodetitle1").val(this.currentVariant.barcode);
    //  $("#barcodetitle2").val(this.currentVariant.barcode);


    window.history.replaceState(
      {},
      "",
      `${this.dataset.url}?variant=${this.currentVariant.id}`
    );
  }

  updateShareUrl() {
    const shareButton = document.getElementById(`Share-${this.dataset.section}`);
    if (!shareButton || !shareButton.updateUrl) return;
    shareButton.updateUrl(`${window.shopUrl}${this.dataset.url}?variant=${this.currentVariant.id}`);
  }

  updateVariantInput() {
    const productForms = document.querySelectorAll(
      `#product-form-${this.dataset.section}, #product-form-installment-${this.dataset.section}`
    );
    productForms.forEach((productForm) => {
      const input = productForm.querySelector('input[name="id"]');
      if (!input) return;
      input.value = this.currentVariant.id;
      input.dispatchEvent(new Event('change', { bubbles: true }));
      const variantNameEl = document.getElementById("mpn_handle_" + this.currentVariant.id);
      const variantName = variantNameEl?.value;
      const mpninput = document.getElementById("mpn_handle");
      if (mpninput && variantName !== undefined) {
        mpninput.value = variantName;
        mpninput.dispatchEvent(new Event("change", { bubbles: true }));
      }
    });
  }

  updateVariantStatuses() {
    const firstChecked = this.querySelector(':checked');
    if (!firstChecked) return;
    const selectedOptionOneVariants = this.variantData.filter(
      (variant) => firstChecked.value === variant.option1
    );
    const inputWrappers = [...this.querySelectorAll('.product-form__input')];
    inputWrappers.forEach((option, index) => {
      if (index === 0) return;
      const optionInputs = [...option.querySelectorAll('input[type="radio"], option')];
      const previousChecked = inputWrappers[index - 1].querySelector(':checked');
      if (!previousChecked) return;
      const previousOptionSelected = previousChecked.value;
      const availableOptionInputsValue = selectedOptionOneVariants
        .filter((variant) => variant.available && variant[`option${index}`] === previousOptionSelected)
        .map((variantOption) => variantOption[`option${index + 1}`]);
      this.setInputAvailability(optionInputs, availableOptionInputsValue);
    });
  }

  setInputAvailability(listOfOptions, listOfAvailableOptions) {
    listOfOptions.forEach((input) => {
      if (listOfAvailableOptions.includes(input.getAttribute('value'))) {
        input.innerText = input.getAttribute('value');
      } else {
        input.innerText = window.variantStrings.unavailable_with_option.replace('[value]', input.getAttribute('value'));
      }
    });
  }

  removeChecked() {
    var check2 = 0;
    $('.product-form__input input[type=radio].2.disabled').each(function () {
      if ($(this).is(":checked")) {
        check2 = 1;
      }
    });
    $('.product-form__input input[type=radio].2').each(function () {
      if (check2 == 1) {
        if (!$(this).hasClass('disabled')) {
          $(this).trigger("click");
          return false;
        }
      }
    });
    var check3 = 0;
    $('.product-form__input input[type=radio].3.disabled').each(function () {
      if ($(this).is(":checked")) {
        check3 = 1;
      }
    });
    $('.product-form__input input[type=radio].3').each(function () {
      if (check3 == 1) {
        if (!$(this).hasClass('disabled')) {
          $(this).trigger("click");
          return false;
        }
      }
    });
  }

  updatePickupAvailability() {
    const pickUpAvailabilities = document.querySelectorAll('pickup-availability');
    if (!pickUpAvailabilities.length) return;

    pickUpAvailabilities.forEach((pickUpAvailability) => {
      pickUpAvailability.renderLoading();
    });
    pickUpAvailabilities.forEach((pickUpAvailability) => {
      pickUpAvailability.setAttribute('data-product-id', this.currentVariant.product.id);
      const options = JSON.stringify(this.currentVariant.options).replace(/"/g, '&quot;');
      pickUpAvailability.setAttribute('data-selected-options', options);
    });
    // init store locator again with new variant details
    const storeLocator = document.querySelector('my-store-locator');
    if (storeLocator) {
      storeLocator.init();
    }
  }

  removeErrorMessage() {
    const section = this.closest('section');
    if (!section) return;

    const productForm = section.querySelector('product-form');
    if (productForm) productForm.handleErrorMessage();
  }

  renderProductInfo() {
    const requestedVariantId = this.currentVariant.id;
    const sectionId = this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section;

    fetch(
      `${this.dataset.url}?variant=${requestedVariantId}&section_id=${this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section
      }`
    )
      .then((response) => response.text())
      .then((responseText) => {
        // prevent unnecessary ui changes from abandoned selections
        if (this.currentVariant.id !== requestedVariantId) return;

        const html = new DOMParser().parseFromString(responseText, 'text/html');
        const destination = document.getElementById(`price-${this.dataset.section}`);
        const source = html.getElementById(
          `price-${this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section}`
        );
        const skuSource = html.getElementById(
          `Sku-${this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section}`
        );
        const skuDestination = document.getElementById(`Sku-${this.dataset.section}`);
        const inventorySource = html.getElementById(
          `Inventory-${this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section}`
        );
        const inventoryDestination = document.getElementById(`Inventory-${this.dataset.section}`);

        const volumePricingSource = html.getElementById(
          `Volume-${this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section}`
        );

        const pricePerItemDestination = document.getElementById(`Price-Per-Item-${this.dataset.section}`);
        const pricePerItemSource = html.getElementById(`Price-Per-Item-${this.dataset.originalSection ? this.dataset.originalSection : this.dataset.section}`);

        const volumePricingDestination = document.getElementById(`Volume-${this.dataset.section}`);
        const qtyRules = document.getElementById(`Quantity-Rules-${this.dataset.section}`);
        const volumeNote = document.getElementById(`Volume-Note-${this.dataset.section}`);

        if (volumeNote) volumeNote.classList.remove('hidden');
        if (volumePricingDestination) volumePricingDestination.classList.remove('hidden');
        if (qtyRules) qtyRules.classList.remove('hidden');

        //Souvik Code for monthly price - desktop starts
        $("#price_mon_section").html($(html).find("#price_mon_section").html());
        //Souvik Code for monthly price - desktop ends
        //Anusha Code for monthly price - mobile starts
        $("#price_mon_section_mb").html(
          $(html).find("#price_mon_section_mb").html()
        );
        //Anusha Code for monthly price - mobile starts
        if (source && destination) destination.innerHTML = source.innerHTML;
        if (inventorySource && inventoryDestination) inventoryDestination.innerHTML = inventorySource.innerHTML;
        if (skuSource && skuDestination) {
          skuDestination.innerHTML = skuSource.innerHTML;
          skuDestination.classList.toggle('hidden', skuSource.classList.contains('hidden'));
        }

        if (volumePricingSource && volumePricingDestination) {
          volumePricingDestination.innerHTML = volumePricingSource.innerHTML;
        }

        if (pricePerItemSource && pricePerItemDestination) {
          pricePerItemDestination.innerHTML = pricePerItemSource.innerHTML;
          pricePerItemDestination.classList.toggle('hidden', pricePerItemSource.classList.contains('hidden'));
        }

        const price = document.getElementById(`price-${this.dataset.section}`);

        if (price) price.classList.remove('hidden');
        this.toggleAddButton(
          !this.currentVariant.available,
          window.variantStrings.soldOut
        );

        // SKU barcode CODE ADDED BY ANUSHA -------- START
        function skubarc(name) {
          const last = document.getElementById(name);
          const first = html.getElementById(name);
          if (first && last) last.innerHTML = first.innerHTML;
        }

        const sku = `sku-${this.dataset.section}`; skubarc(sku);
        const skumob = `skumob-${this.dataset.section}`; skubarc(skumob);
        const barc = `barc-${this.dataset.section}`; skubarc(barc);
        const barcmob = `barcmob-${this.dataset.section}`; skubarc(barcmob);
        // SKU barcode CODE ADDED BY ANUSHA -------- END

        // Pricing CODE ADDED BY HEMA -------- START
        let price_footer = price ? price.innerHTML : '';
        $("#price-element").text("");
        var textreplace = "<div id='price-footer-element'></div>";
        $("#price-element").append(textreplace);
        $("#price-footer-element").replaceWith(price_footer);
        // Pricing CODE ADDED BY HEMA -------- END

        $(".product__pickup-availabilities").css("display", "block");

        $(".sticky-atc-bar").css("visibility", "visible");

        if (inventorySource && inventoryDestination)
          inventoryDestination.classList.toggle('hidden', inventorySource.textContent === '');

        const addButtonUpdated = html.getElementById(`ProductSubmitButton-${sectionId}`);
        this.toggleAddButton(
          addButtonUpdated ? addButtonUpdated.hasAttribute('disabled') : true,
          window.variantStrings.soldOut
        );

        publish(PUB_SUB_EVENTS.variantChange, {
          data: {
            sectionId,
            html,
            variant: this.currentVariant,
          },
        });
      });
  }

  toggleAddButton(disable = true, text, modifyClass = true) {
    const productForm = document.getElementById(`product-form-${this.dataset.section}`);
    if (!productForm) return;
    const addButton = productForm.querySelector('[name="add"]');
    const addButtonText = productForm.querySelector('[name="add"] > span');
    if (!addButton) return;

    if (disable) {
      addButton.setAttribute('disabled', 'disabled');
      if (text && addButtonText) addButtonText.textContent = text;

      // $('.hide---atc button').show();
    } else {
      addButton.removeAttribute('disabled');
      if (addButtonText) addButtonText.textContent = window.variantStrings.addToCart;

      // $('.hide---atc button').hide();
    }

    if (!modifyClass) return;
  }

  setUnavailable() {
    const button = document.getElementById(`product-form-${this.dataset.section}`);
    if (!button) return;
    const addButton = button.querySelector('[name="add"]');
    const addButtonText = button.querySelector('[name="add"] > span');
    const price = document.getElementById(`price-${this.dataset.section}`);
    const inventory = document.getElementById(`Inventory-${this.dataset.section}`);
    const sku = document.getElementById(`Sku-${this.dataset.section}`);
    const pricePerItem = document.getElementById(`Price-Per-Item-${this.dataset.section}`);
    const volumeNote = document.getElementById(`Volume-Note-${this.dataset.section}`);
    const volumeTable = document.getElementById(`Volume-${this.dataset.section}`);
    const qtyRules = document.getElementById(`Quantity-Rules-${this.dataset.section}`);

    if (!addButton) return;
    if (addButtonText) addButtonText.textContent = window.variantStrings.unavailable;
    if (price) price.classList.add('hidden');
    if (inventory) inventory.classList.add('hidden');
    if (sku) sku.classList.add('hidden');
    if (pricePerItem) pricePerItem.classList.add('hidden');
    if (volumeNote) volumeNote.classList.add('hidden');
    if (volumeTable) volumeTable.classList.add('hidden');
    if (qtyRules) qtyRules.classList.add('hidden');
  }

  getVariantData() {
    if (!this.variantData) {
      try {
        this.variantData = JSON.parse(this.querySelector('[type="application/json"]').textContent);
      } catch (e) {
        console.error('Variant data parse failed', e);
        this.variantData = [];
      }
    }
    return this.variantData;
  }
}

customElements.define('variant-selects', VariantSelects);

class VariantRadios extends VariantSelects {
  constructor() {
    super();
  }

  setInputAvailability(listOfOptions, listOfAvailableOptions) {
    listOfOptions.forEach((input) => {
      if (listOfAvailableOptions.includes(input.getAttribute('value'))) {
        input.classList.remove('disabled');
        input.removeAttribute('disabled');
      } else {
        input.classList.add('disabled');
        input.setAttribute('disabled', '');
      }
    });
  }

  updateOptions() {
    const fieldsets = Array.from(this.querySelectorAll('fieldset'));
    this.options = fieldsets.map((fieldset) => {
      return Array.from(fieldset.querySelectorAll('input')).find((radio) => radio.checked)?.value;
    });
  }
}

customElements.define('variant-radios', VariantRadios);

/*
// Commented by SDG, this class already called in product-recommendations.liquid, product-recommendations-cart.liquid and frequently-bought-products.liquid which causing error in console

class ProductRecommendations extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    const handleIntersection = (entries, observer) => {
      if (!entries[0].isIntersecting) return;
      observer.unobserve(this);

      fetch(this.dataset.url)
        .then((response) => response.text())
        .then((text) => {
          const html = document.createElement('div');
          html.innerHTML = text;
          const recommendations = html.querySelector('product-recommendations');

          if (recommendations && recommendations.innerHTML.trim().length) {
            this.innerHTML = recommendations.innerHTML;
          }

          if (!this.querySelector('slideshow-component') && this.classList.contains('complementary-products')) {
            this.remove();
          }

          if (html.querySelector('.grid__item')) {
            this.classList.add('product-recommendations--loaded');
          }
        })
        .catch((e) => {
          console.error(e);
        });
    };

    new IntersectionObserver(handleIntersection.bind(this), { rootMargin: '0px 0px 400px 0px' }).observe(this);
  }
}

customElements.define('product-recommendations', ProductRecommendations);
*/

//Souvik Button color change on pressed starts
//carousel Button
$(document).ready(function () {
  $(".button_primary_anchor").click(function () {
    var id = this.id;
    var par = $(this).parent().attr("id");
    $("#" + par).addClass("button_primary_clicked_clicked");
  });
});

//whatsnew richtext2 button & image with text 2 button
$(document).on("click", ".button_primary_clicked", function () {
  var id = this.id;
  $("#" + id).addClass("button_primary_clicked_clicked");
});

//image with text 3 button
$(document).on("click", ".button_primary_clicked_hollow", function () {
  var id = this.id;
  $("#" + id).addClass("button_primary_clicked_hollow_clicked");
});
//Souvik Button color change on pressed ends

//Souvik Frequently brought together height adjust starts
$(window).on('load', function () {
  // you may like carousel code

  var collection = new Array();
  $(".collection_name").each(function () {
    if ($(this).text() != "") collection.push($(this).text().toLowerCase());
  });

  $.each(collection, function (index, value) {
    var height;
    var maxheight = 0;
    var minheight = 100;
    jQuery(".price__container_" + value).each(function () {
      height = parseInt($(this).height());
      if (height > maxheight) {
        maxheight = height;
      }
    });
    if (maxheight > 22) {
      jQuery(".price__container_" + value).attr(
        "style",
        "display: flex; flex-flow: column; justify-content: flex-start; height: auto; max-height:" +
        maxheight +
        "px;"
      );
    }
  });

  $(".collection_slider").each(function (index, value) {
    var height1 = 0;
    var maxheight1 = 0;
    $(value).find(".price__container_").each(function () {
      height1 = parseInt($(this).height());
      if (height1 > maxheight1) {
        maxheight1 = height1;
      }
    });
    if (maxheight1 > 22) {
      $(value).find(".price__container_").attr(
        "style",
        "display: flex; flex-flow: column; justify-content: flex-start; height: auto; max-height:" +
        maxheight1 +
        "px;"
      );
    }

    setTimeout(() => {
      adaFormatSlickSlides(value);
    }, 250);
  });

  //sold out button on sliders
  $(".button_disabled").each(function () {
    $(this).parent().addClass("card-slider-buttons-disabled");
  });
});

//Souvik Frequently brought and you may like carousel height adjust ends

// Set product price with formatting
function setPriceWithTradeIn(type, productPriceEl) {
  const tradeInPriceEl = $('#selected-trade-in-value').val();
  const parents = $(productPriceEl).parents();
  const productPrice = $(parents).find('.price.price-product-pdp');
  const priceChildren = $(productPrice).children();
  const actualPriceEL = $(priceChildren).find('.js-product-price-with-care-warranty.actual_price_bold');
  const price = $(productPriceEl).attr(type);
  const actualPrice = $(actualPriceEL).attr(type);
  const isNMP = !$(productPriceEl).hasClass('actual_price_bold');
  let finalPrice;

  if (!price || !actualPrice || !tradeInPriceEl) return;

  const tradeInPrice = formatMoney(tradeInPriceEl);

  // Check if the element is the NMP pricing
  if (isNMP) {
    const nmpPrice = setNMPPriceWithTradeIn(actualPrice, tradeInPrice, productPriceEl);
    return nmpPrice;
  }

  // Format price for calculation
  const priceWithAddOnOptions = formatMoney(price);

  // Calculate price with trade-in
  finalPrice = priceWithAddOnOptions < tradeInPrice
    ? 0.00
    : priceWithAddOnOptions - tradeInPrice;

  return formatPriceWithCurrency(finalPrice);
}

// Set NMP product price with formatting
function setNMPPriceWithTradeIn(dataActualPrice, dataTradeInPrice, el) {
  const nmpPriceCalculationEl = $(el).attr('data-price-calculation');

  if (!dataActualPrice || !dataTradeInPrice || !nmpPriceCalculationEl) return;

  const nmpPriceCalculation = parseInt(nmpPriceCalculationEl);
  let tempPrice = formatMoney(dataActualPrice) - formatMoney(dataTradeInPrice);

  if (tempPrice < 0) tempPrice = 0.00;
  const finalNMPPrice = (tempPrice / nmpPriceCalculation).toFixed(2);

  return formatPriceWithCurrency(finalNMPPrice);
}

// Remove Shopify currency formatting
function formatMoney(price) {
  if (typeof price === 'number') {
    return price;
  }

  // Use parseFloat (not parseInt) so cents aren't truncated on decimal
  // money strings, e.g. "$1,099.99" -> 1099.99 rather than 1099. Outputs
  // feed formatPriceWithCurrency/.toFixed(2) (display only), so float is safe.
  const formattedMoney = price.replace(/[^0-9.-]+/g, '');
  return parseFloat(formattedMoney);
}

// Format price to USD
function formatPrice(price) {
  return parseInt(price, 10);
}

// Format price with currency and locale
function formatPriceWithCurrency(price) {
  const locale = window.themeJsData.currentLocale;
  const currency = window.themeJsData.currentCurrency || window.themeJsData.shopCurrency;
  const format = window.themeJsData.moneyWithCurrencyFormat;
  const commaLocaleMap = {
    EUR: 'de-DE',
    SEK: 'sv-SE',
    NOK: 'nb-NO',
    DKK: 'da-DK',
    PLN: 'pl-PL',
    CZK: 'cs-CZ',
    HUF: 'hu-HU',
  };

  const getCommaLocale = (currency, defaultLocale) => commaLocaleMap[currency] || defaultLocale;

  const commaLocale = getCommaLocale(currency, locale);

  return format
    .replace('{{amount}}', price.toLocaleString(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }))
    .replace('{{amount_no_decimals}}', price.toLocaleString(locale, { maximumFractionDigits: 0 }))
    .replace('{{amount_with_comma_separator}}', price.toLocaleString(commaLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }))
    .replace('{{amount_no_decimals_with_comma_separator}}', price.toLocaleString(commaLocale, { maximumFractionDigits: 0 }));
}

// Format price without currency
function formatPriceWithoutCurrency(price) {
  const locale = window.themeJsData.currentLocale;
  const currency = window.themeJsData.currentCurrency || window.themeJsData.shopCurrency;
  const format = window.themeJsData.moneyFormat;
  const commaLocaleMap = {
    EUR: 'de-DE',
    SEK: 'sv-SE',
    NOK: 'nb-NO',
    DKK: 'da-DK',
    PLN: 'pl-PL',
    CZK: 'cs-CZ',
    HUF: 'hu-HU',
  };

  const getCommaLocale = (currency, defaultLocale) => commaLocaleMap[currency] || defaultLocale;

  const commaLocale = getCommaLocale(currency, locale);

  return format
    .replace('{{amount}}', price.toLocaleString(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }))
    .replace('{{amount_no_decimals}}', price.toLocaleString(locale, { maximumFractionDigits: 0 }))
    .replace('{{amount_with_comma_separator}}', price.toLocaleString(commaLocale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }))
    .replace('{{amount_no_decimals_with_comma_separator}}', price.toLocaleString(commaLocale, { maximumFractionDigits: 0 }));
}

// Remove aria-describedby from Slick slides
function adaFormatSlickSlides(slidesArray) {
  const slickSlides = $(slidesArray);

  if (!slickSlides?.length) return;

  const slideCount = $(slickSlides).length;

  $(slickSlides).each(function () {
    const slide = $(this);

    $(slide).removeAttr('aria-describedby');
  });

  const slickDots = $(slidesArray).find('.slick-dots li button');
  const slickDotsLi = $(slidesArray).find('.slick-dots li');

  if (slickDots?.length) {
    // If there are dots, add aria-label to each dot
    const slideDotCount = $(slickDots).length;
  
    $(slickDots).each(function () {
      const slickDot = $(this);
      const number = $(slickDot).text();
      const parent = $(slickDot).parent();
  
      if (slideCount > slideDotCount) {
        const groupLabel = (SDG?.Data?.sliderSlideGroupCounter || 'Slide group __CURRENT__ of __TOTAL__')
          .replace('__CURRENT__', number)
          .replace('__TOTAL__', slideDotCount);
        $(parent).attr('aria-label', groupLabel);
      } else {
        const slideLabel = (SDG?.Data?.sliderSlideCounter || 'Slide __CURRENT__ of __TOTAL__')
          .replace('__CURRENT__', number)
          .replace('__TOTAL__', slideCount);
        $(parent).attr('aria-label', slideLabel);
      }
    });
  }

  if (slickDotsLi?.length) {
    // If there are li, remove unnecessary 'role="presentation"' attribute  
    $(slickDotsLi).each(function () {
      const slickDotLi = $(this);
      $(slickDotLi).removeAttr('role');
      $(slickDotLi).removeAttr('aria-controls');
      $(slickDotLi).removeAttr('aria-hidden');
    });
  }
}

// Set multiple attributes w/out jQuery
// Usage: setAttributes(el, { 'data-foo': 'bar', 'data-baz': 'qux', src: 'https://example.com' });
function setAttributes(el, options) {
  Object.keys(options).forEach(function(attr) {
    el.setAttribute(attr, options[attr]);
  })
}

/**
 * is parent
 * @param  {Node} elem
 * @param  {String} selector
 * @return {Node}
 */
function getParents(elem, selector) {
  let parents = [];
  let firstChar;
  if ( selector ) {
    firstChar = selector.charAt(0);
  }

  // Get matches
  for ( ; elem && elem !== document; elem = elem.parentNode ) {
    if ( selector ) {
      // If selector is a class
      if ( firstChar === '.' ) {
        if ( elem.classList.contains( selector.substr(1) ) ) {
          parents.push( elem );
        }
      }

      // If selector is an ID
      if ( firstChar === '#' ) {
        if ( elem.id === selector.substr(1) ) {
          parents.push( elem );
        }
      }

      // If selector is a data attribute
      if ( firstChar === '[' ) {
        if ( elem.hasAttribute( selector.substr(1, selector.length - 2) ) ) {
          parents.push( elem );
        }
      }

      // If selector is a tag
      if ( elem.tagName.toLowerCase() === selector ) {
        parents.push( elem );
      }
    } else {
      parents.push( elem );
    }
  }

  // Return parents if any exist
  if ( parents.length === 0 ) {
    return null;
  } else {
    return parents;
  }
};

/**
 * Set Initial Visibility
 * @description Sets the 'aria-hidden' state of slides as they come into the viewport
 * @param {HTMLElement} el - Slider element
 * @return {void}
 */
function setInitialSlideVisibility(el) {
  if (!el) return;

  const $slides = el.querySelectorAll('.slick-slide');
  $slides.forEach((slide) => {
    setAttributes(slide, {'aria-hidden': 'false', tabindex: '0'});
    const focusableElements = slide.querySelectorAll('a, button, input, select, img');
    if (focusableElements.length > 0) {
      focusableElements.forEach((focusableEl) => {
        if (focusableEl.tagName === 'IMG') {
          const alt = focusableEl.getAttribute('alt');
          if (alt !== null && alt !== '') {
            setAttributes(focusableEl, {'aria-hidden': 'false', tabindex: '0'});
          }
        } else {
          setAttributes(focusableEl, {'aria-hidden': 'false', tabindex: '0'});
        }
      });
    }
  });
}

/**
 * Set Visibility
 * @description Sets the 'aria-hidden' state of slides as they come into the viewport
 * @param {HTMLElement} el - Slider element
 * @return {void}
 */
function setSlideVisibility(el) {
  if (!el) return;

  const $slides = el.querySelectorAll('.slick-slide');

  // List of elements to be observed
  const targets = $slides;
  const options = {
    root: null, // null means root is viewport
    rootMargin: '0px',
    threshold: .5 // trigger callback when 90% of the element is visible
  }

  function callback(entries, observer) {
    entries.forEach(entry => {
      const slide = entry.target;

      if (entry.isIntersecting) {
        setAttributes(slide, {'aria-hidden': 'false', tabindex: '0'});
        const focusableElements = slide.querySelectorAll('a, button, input, select, img');
        if (focusableElements.length > 0) {
          focusableElements.forEach((focusableEl) => setAttributes(focusableEl, {'aria-hidden': 'false', tabindex: '0'}));
        }
        // Keep observing so slides re-hide/re-show as they leave/re-enter view
        // (unobserving here froze slide a11y after first eval — see R18-083).
      } else {
        setAttributes(slide, {'aria-hidden': 'true', tabindex: '-1'});
        const focusableElements = slide.querySelectorAll('a, button, input, select, img');
        if (focusableElements.length > 0) {
          focusableElements.forEach((focusableEl) => {
            setAttributes(focusableEl, {'aria-hidden': 'true', tabindex: '-1'});
          });
        }
      }
    });
  };

  let observer = new IntersectionObserver(callback, options);
  [...targets].forEach(target => observer.observe(target));
}
